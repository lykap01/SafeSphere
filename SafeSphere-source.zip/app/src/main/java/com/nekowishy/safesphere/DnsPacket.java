package com.nekowishy.safesphere;

import java.util.Arrays;
import java.util.Locale;

/** Reads DNS questions out of raw IPv4/UDP packets and builds the reply packets. */
final class DnsPacket {

    static final class Query {
        final byte[] srcIp = new byte[4];
        final byte[] dstIp = new byte[4];
        int srcPort;
        int dstPort;
        byte[] dns;
        String name;
    }

    private DnsPacket() {}

    static int u16(byte[] b, int off) {
        return ((b[off] & 0xFF) << 8) | (b[off + 1] & 0xFF);
    }

    /** Returns the DNS query in this packet, or null if it is not a plain IPv4 UDP DNS query. */
    static Query parse(byte[] p, int len) {
        if (len < 28) return null;
        if (((p[0] >> 4) & 0xF) != 4) return null;
        int ihl = (p[0] & 0xF) * 4;
        if (ihl < 20 || len < ihl + 8) return null;
        if ((p[9] & 0xFF) != 17) return null; // UDP only
        boolean moreFragments = (p[6] & 0x20) != 0;
        int fragOffset = ((p[6] & 0x1F) << 8) | (p[7] & 0xFF);
        if (moreFragments || fragOffset != 0) return null;
        int dstPort = u16(p, ihl + 2);
        if (dstPort != 53) return null;
        int udpLen = u16(p, ihl + 4);
        int dnsStart = ihl + 8;
        int dnsLen = Math.min(udpLen - 8, len - dnsStart);
        if (dnsLen < 12) return null;

        Query q = new Query();
        System.arraycopy(p, 12, q.srcIp, 0, 4);
        System.arraycopy(p, 16, q.dstIp, 0, 4);
        q.srcPort = u16(p, ihl);
        q.dstPort = dstPort;
        q.dns = Arrays.copyOfRange(p, dnsStart, dnsStart + dnsLen);
        if ((q.dns[2] & 0x80) != 0) return null; // a response, not a query
        if (u16(q.dns, 4) < 1) return null;      // no question
        q.name = readName(q.dns, 12);
        if (q.name == null) return null;
        return q;
    }

    /** Reads the question name. Returns "" for the root and null when malformed. */
    static String readName(byte[] d, int off) {
        StringBuilder sb = new StringBuilder();
        int i = off;
        int labels = 0;
        while (i < d.length) {
            int l = d[i] & 0xFF;
            if (l == 0) return sb.toString().toLowerCase(Locale.ROOT);
            if ((l & 0xC0) != 0) return null;
            if (++labels > 127) return null;
            i++;
            if (i + l > d.length) return null;
            if (sb.length() > 0) sb.append('.');
            for (int k = 0; k < l; k++) sb.append((char) (d[i + k] & 0xFF));
            i += l;
        }
        return null;
    }

    /** Offset just after the question name (before QTYPE/QCLASS). */
    private static int nameEnd(byte[] d, int off) {
        int i = off;
        while (i < d.length) {
            int l = d[i] & 0xFF;
            if (l == 0) return i + 1;
            i += l + 1;
        }
        return d.length;
    }

    /** NXDOMAIN reply: tells the app this domain does not exist, so it never connects. */
    static byte[] blocked(Query q) {
        byte[] d = q.dns;
        int end = Math.min(nameEnd(d, 12) + 4, d.length);
        byte[] r = Arrays.copyOf(d, end);
        r[2] = (byte) (0x80 | (d[2] & 0x79)); // QR=1, keep opcode + RD
        r[3] = (byte) (0x80 | 0x03);          // RA=1, RCODE=NXDOMAIN
        r[4] = 0; r[5] = 1;                   // QDCOUNT=1
        for (int i = 6; i < 12; i++) r[i] = 0; // AN/NS/AR = 0
        return wrap(q, r);
    }

    /** Wraps a DNS reply in IPv4/UDP headers addressed back to the app that asked. */
    static byte[] wrap(Query q, byte[] dns) {
        int total = 20 + 8 + dns.length;
        byte[] p = new byte[total];
        p[0] = 0x45;
        p[2] = (byte) (total >> 8);
        p[3] = (byte) total;
        p[6] = 0x40; // don't fragment
        p[8] = 64;   // TTL
        p[9] = 17;   // UDP
        System.arraycopy(q.dstIp, 0, p, 12, 4);
        System.arraycopy(q.srcIp, 0, p, 16, 4);
        int sum = 0;
        for (int i = 0; i < 20; i += 2) sum += u16(p, i);
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        int csum = ~sum & 0xFFFF;
        p[10] = (byte) (csum >> 8);
        p[11] = (byte) csum;
        int udpLen = 8 + dns.length;
        p[20] = (byte) (q.dstPort >> 8);
        p[21] = (byte) q.dstPort;
        p[22] = (byte) (q.srcPort >> 8);
        p[23] = (byte) q.srcPort;
        p[24] = (byte) (udpLen >> 8);
        p[25] = (byte) udpLen;
        // UDP checksum 0 = not used (allowed for IPv4)
        System.arraycopy(dns, 0, p, 28, dns.length);
        return p;
    }
}
