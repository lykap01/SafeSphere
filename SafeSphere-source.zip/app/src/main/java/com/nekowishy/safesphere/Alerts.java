package com.nekowishy.safesphere;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Icon;
import android.os.Build;

import java.util.HashMap;
import java.util.Map;

/** Notification channels, the "protection is on" notification and threat alerts. */
final class Alerts {

    static final int ONGOING_ID = 1;
    private static final String CH_ALERTS = "threat_alerts";
    private static final String CH_STATUS = "protection_status";
    private static final long SAME_DOMAIN_COOLDOWN = 5 * 60_000L;
    private static final long ANY_ALERT_COOLDOWN = 4_000L;

    private static final Map<String, Long> lastByDomain = new HashMap<>();
    private static long lastAny;

    private Alerts() {}

    static void channels(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel alerts = new NotificationChannel(CH_ALERTS, "Threat alerts", NotificationManager.IMPORTANCE_HIGH);
        alerts.setDescription("Blocked dangerous sites and scam-message warnings");
        alerts.enableLights(true);
        alerts.setLightColor(Ui.DANGER);
        nm.createNotificationChannel(alerts);
        NotificationChannel status = new NotificationChannel(CH_STATUS, "Protection status", NotificationManager.IMPORTANCE_LOW);
        status.setDescription("Shows while protection is running (Android requires this for VPN apps)");
        nm.createNotificationChannel(status);
    }

    /** Why threat alerts can't pop up right now, or null when they can. */
    static String alertsBlockedReason(Context c) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return "SafeSphere isn't allowed to show notifications";
        }
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return null;
        if (!nm.areNotificationsEnabled()) return "SafeSphere notifications are turned off";
        channels(c);
        NotificationChannel ch = nm.getNotificationChannel(CH_ALERTS);
        if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) return "The \"Threat alerts\" category is turned off";
        if (ch != null && ch.getImportance() < NotificationManager.IMPORTANCE_HIGH) {
            return "\"Threat alerts\" is set to silent, so alerts won't pop up";
        }
        return null;
    }

    static Notification ongoing(Context c) {
        channels(c);
        PendingIntent open = PendingIntent.getActivity(c, 1, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop = PendingIntent.getService(c, 2,
                new Intent(c, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(c, R.drawable.ic_notify), "Turn off", stop).build();
        Notification.Builder b = new Notification.Builder(c, CH_STATUS)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("Protection is on")
                .setContentText(Prefs.encryptedDns(c) ? "Checking website lookups · encrypted DNS"
                        : "Checking website lookups")
                .setColor(Ui.PRIMARY)
                .setOngoing(true)
                .setContentIntent(open);
        if (!Prefs.hasPin(c)) b.addAction(stopAction); // with a protection lock, turning off needs the PIN in the app
        return b.build();
    }

    static void scamMessage(Context c, String appName, String host, boolean dangerous, String why) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        channels(c);
        Intent i = new Intent(c, MainActivity.class)
                .putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_HISTORY)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 5, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String title = (dangerous ? "Dangerous link in " : "Possible scam message in ") + appName;
        String body = (host != null ? "Don't open the link (" + host + "). " : "Don't reply or do what it asks. ")
                + why + "." + (dangerous ? " SafeSphere blocks this site while protection is on." : "");
        Notification n = new Notification.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setColor(dangerous ? Ui.DANGER : Ui.SUSPICIOUS)
                .setCategory(Notification.CATEGORY_STATUS)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(2000 + ((host == null ? why : host).hashCode() & 0xFFFF), n);
    }

    static void wifi(Context c, String title, String detail) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        channels(c);
        PendingIntent pi = PendingIntent.getActivity(c, 4, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(detail)
                .setStyle(new Notification.BigTextStyle().bigText(detail))
                .setColor(Ui.WARNING)
                .setCategory(Notification.CATEGORY_STATUS)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(50, n);
    }

    static void blocked(Context c, String domain, String reason) {
        long now = System.currentTimeMillis();
        synchronized (lastByDomain) {
            Long last = lastByDomain.get(domain);
            if (last != null && now - last < SAME_DOMAIN_COOLDOWN) return;
            if (now - lastAny < ANY_ALERT_COOLDOWN) return;
            if (lastByDomain.size() > 500) lastByDomain.clear();
            lastByDomain.put(domain, now);
            lastAny = now;
        }
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        channels(c);
        Intent i = new Intent(c, MainActivity.class)
                .putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_HISTORY)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 3, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH_ALERTS)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("SafeSphere blocked a threat")
                .setContentText(domain)
                .setStyle(new Notification.BigTextStyle().bigText("Domain: " + domain + "\nReason: " + reason))
                .setColor(Ui.DANGER)
                .setCategory(Notification.CATEGORY_STATUS)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(1000 + (domain.hashCode() & 0xFFFF), n);
    }
}
