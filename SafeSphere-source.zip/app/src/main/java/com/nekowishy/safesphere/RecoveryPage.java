package com.nekowishy.safesphere;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Recovery Center: for people who may already have been scammed or attacked. Pick what happened,
 * follow the checklist, and keep a private incident report that can be shared when reporting.
 * Everything stays on the phone unless the user shares the report. SafeSphere never contacts anyone.
 */
final class RecoveryPage {

    private final MainActivity a;
    private EventLog.Incident draft; // the incident being viewed (saved or not yet saved)

    RecoveryPage(MainActivity a) { this.a = a; }

    String incidentTitle() {
        return draft == null ? "Recovery steps" : "Recovery steps";
    }

    // ------------------------------------------------------------------ list

    /** Opens one incident's checklist directly (e.g. from a message warning). */
    void start(String incidentId) {
        EventLog.Incident inc = new EventLog.Incident();
        inc.type = incidentId;
        inc.occurredAt = System.currentTimeMillis();
        draft = inc;
        a.open(MainActivity.PAGE_INCIDENT);
    }

    void buildList(LinearLayout col) {
        a.section(col, "What happened?");
        LinearLayout list = Ui.listCard(a);
        for (int i = 0; i < RecoveryGuide.INCIDENTS.length; i++) {
            RecoveryGuide.Incident g = RecoveryGuide.INCIDENTS[i];
            if (i > 0) list.addView(Ui.divider(a));
            list.addView(Ui.row(a, null, g.title, null,
                    g.urgent ? Ui.badge(a, Ui.T_DANGER, "Act now") : Ui.chevron(a), v -> {
                        EventLog.Incident inc = new EventLog.Incident();
                        inc.type = g.id;
                        inc.occurredAt = System.currentTimeMillis();
                        draft = inc;
                        a.open(MainActivity.PAGE_INCIDENT);
                    }));
        }
        col.addView(list);

        List<EventLog.Incident> saved = EventLog.get(a).incidents();
        a.section(col, "Your incident reports");
        LinearLayout s = Ui.listCard(a);
        if (saved.isEmpty()) {
            TextView t = Ui.support(a, "None yet");
            t.setPadding(Ui.dp(a, 16), Ui.dp(a, 12), Ui.dp(a, 16), Ui.dp(a, 12));
            s.addView(t);
        }
        DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
        for (int i = 0; i < saved.size(); i++) {
            EventLog.Incident inc = saved.get(i);
            RecoveryGuide.Incident g = RecoveryGuide.byId(inc.type);
            int done = RecoveryGuide.doneSet(inc.stepsDone).size();
            if (i > 0) s.addView(Ui.divider(a));
            s.addView(Ui.row(a, null, g.title, df.format(new Date(inc.occurredAt)) + " · " + done + " of " + g.steps.length
                    + " steps done", Ui.badge(a, done >= g.steps.length ? Ui.T_SUCCESS : Ui.T_WARNING,
                    done >= g.steps.length ? "Done" : "In progress"), v -> {
                draft = EventLog.get(a).incident(inc.id);
                a.open(MainActivity.PAGE_INCIDENT);
            }));
        }
        col.addView(s);
        col.addView(Ui.support(a, "Contact your bank through its official app or the number on your card."),
                Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
    }

    // ------------------------------------------------------------------ one incident

    void buildIncident(LinearLayout col) {
        if (draft == null) {
            buildList(col);
            return;
        }
        EventLog.Incident inc = draft;
        RecoveryGuide.Incident g = RecoveryGuide.byId(inc.type);
        Set<Integer> done = RecoveryGuide.doneSet(inc.stepsDone);

        LinearLayout head = Ui.card(a);
        head.addView(Ui.cardTitle(a, g.title));
        TextView sum = Ui.support(a, g.summary);
        sum.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 10));
        head.addView(sum);
        head.addView(Ui.body(a, done.size() + " of " + g.steps.length + " steps done"));
        head.addView(Ui.progress(a, done.size(), g.steps.length, done.size() >= g.steps.length ? Ui.T_SUCCESS : Ui.T_INFO),
                Ui.margins(a, Ui.MATCH, Ui.dp(a, 8), 8));
        col.addView(head, Ui.margins(a, Ui.MATCH, Ui.WRAP, 8));

        a.section(col, "Recovery checklist");
        LinearLayout steps = Ui.listCard(a);
        for (int i = 0; i < g.steps.length; i++) {
            if (i > 0) steps.addView(Ui.divider(a));
            steps.addView(stepRow(inc, g, i, done.contains(i)));
        }
        col.addView(steps);

        a.section(col, "Incident report");
        col.addView(reportForm(inc, g));
    }

    private View stepRow(EventLog.Incident inc, RecoveryGuide.Incident g, int index, boolean isDone) {
        RecoveryGuide.Step st = g.steps[index];
        LinearLayout row = Ui.hbox(a);
        row.setGravity(Gravity.TOP);
        row.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 16), Ui.dp(a, 10));
        CheckBox box = new CheckBox(a);
        box.setChecked(isDone);
        box.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        box.setContentDescription("Step " + (index + 1) + ": " + st.title + (isDone ? ", done" : ", not done"));
        box.setOnCheckedChangeListener((b, checked) -> {
            Set<Integer> s = RecoveryGuide.doneSet(inc.stepsDone);
            if (checked) s.add(index);
            else s.remove(index);
            inc.stepsDone = RecoveryGuide.doneCsv(s);
            save(inc, g, false);
            if (checked && s.size() == g.steps.length) {
                EventLog.get(a).record(EventLog.CAT_RECOVERY, "", "Recovery checklist completed: " + g.title, System.currentTimeMillis());
            }
            a.show(MainActivity.PAGE_INCIDENT);
            if (checked) a.success(s.size() >= g.steps.length ? "All steps done. Well done."
                    : "Step done · " + s.size() + " of " + g.steps.length);
        });
        row.addView(box);
        LinearLayout texts = Ui.vbox(a);
        texts.setPadding(Ui.dp(a, 4), Ui.dp(a, 4), 0, 0);
        texts.addView(Ui.text(a, (index + 1) + ". " + st.title, Ui.BODY, isDone ? Ui.TEXT2 : Ui.TEXT, true));
        TextView d = Ui.support(a, st.detail);
        d.setPadding(0, Ui.dp(a, 2), 0, 0);
        texts.addView(d);
        if (st.button != null && st.action != RecoveryGuide.A_NONE) {
            texts.addView(Ui.link(a, st.button, v -> runAction(st.action)));
        }
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private void runAction(int action) {
        switch (action) {
            case RecoveryGuide.A_CHECK: a.show(MainActivity.TAB_CHECK); break;
            case RecoveryGuide.A_PROTECT:
                if (SafeSphereVpnService.isRunning()) a.toast("Protection is already on");
                else a.toggleProtection();
                break;
            case RecoveryGuide.A_PASSWORD: a.show(MainActivity.TAB_CHECK); a.toast("Use the password leak check on this page"); break;
            case RecoveryGuide.A_APPS: a.openSettings(Settings.ACTION_APPLICATION_SETTINGS, Settings.ACTION_SETTINGS); break;
            case RecoveryGuide.A_SECURITY: a.show(MainActivity.TAB_DEVICE); break;
            case RecoveryGuide.A_DIAL_1326: a.open(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:1326"))); break;
            case RecoveryGuide.A_PLAY_PROTECT:
                a.openSettings("com.google.android.gms.settings.VERIFY_APPS_SETTINGS", Settings.ACTION_SECURITY_SETTINGS);
                break;
            case RecoveryGuide.A_DOWNLOADS:
                a.open(new Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS));
                break;
            case RecoveryGuide.A_UNKNOWN_SOURCES:
                a.openSettings(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Settings.ACTION_SECURITY_SETTINGS);
                break;
            case RecoveryGuide.A_ACCESSIBILITY: a.openSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS); break;
            case RecoveryGuide.A_NOTIF_ACCESS:
                a.openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS);
                break;
            default:
        }
    }

    private EditText input(String hint, boolean multi, String value) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setText(value == null ? "" : value);
        if (multi) {
            e.setMinLines(3);
            e.setGravity(Gravity.TOP | Gravity.START);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        } else {
            e.setSingleLine(true);
        }
        Ui.field(e);
        return e;
    }

    private TextView label(String s) {
        TextView t = Ui.text(a, s, Ui.SUPPORT, Ui.TEXT, true);
        t.setPadding(0, Ui.dp(a, 14), 0, Ui.dp(a, 6));
        return t;
    }

    private View reportForm(EventLog.Incident inc, RecoveryGuide.Incident g) {
        LinearLayout c = Ui.card(a);
        c.addView(Ui.banner(a, Ui.T_WARNING, "Don't include secrets",
                "Never type passwords, OTPs, MPINs, PINs or full card numbers here."));

        c.addView(label("When did it happen?"));
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        TextView when = Ui.secondary(a, df.format(new Date(inc.occurredAt)), null);
        when.setContentDescription("Date and time: " + df.format(new Date(inc.occurredAt)) + ". Tap to change.");
        when.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(inc.occurredAt);
            new DatePickerDialog(a, (dp, y, m, d) -> {
                cal.set(y, m, d);
                new TimePickerDialog(a, (tp, h, min) -> {
                    cal.set(Calendar.HOUR_OF_DAY, h);
                    cal.set(Calendar.MINUTE, min);
                    inc.occurredAt = Math.min(cal.getTimeInMillis(), System.currentTimeMillis());
                    when.setText(df.format(new Date(inc.occurredAt)));
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show();
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
        });
        c.addView(when);

        c.addView(label("Suspicious sender, number or website (optional)"));
        EditText sender = input("e.g. +63 9xx…, bdo-verify.example, \"GCash Support\"", false, inc.sender);
        c.addView(sender);
        c.addView(label("What happened"));
        EditText desc = input("Describe what happened, in your own words", true, inc.description);
        c.addView(desc);
        c.addView(label("Actions already taken"));
        EditText taken = input("e.g. Called my bank at 3:10 PM, changed my password", true, inc.actionsTaken);
        c.addView(taken);
        TextView note = Ui.support(a, "Completed checklist steps are added to the report automatically.");
        note.setPadding(0, Ui.dp(a, 8), 0, 0);
        c.addView(note);

        Runnable collect = () -> {
            inc.sender = sender.getText().toString().trim();
            inc.description = desc.getText().toString().trim();
            inc.actionsTaken = taken.getText().toString().trim();
        };
        c.addView(Ui.primary(a, inc.id > 0 ? "Save changes" : "Save report", v -> {
            collect.run();
            guardSecrets(inc, () -> {
                save(inc, g, true);
                a.success("Report saved on this phone");
                a.show(MainActivity.PAGE_INCIDENT);
            });
        }), Ui.margins(a, Ui.MATCH, Ui.WRAP, 16));
        c.addView(Ui.secondary(a, "Share report", v -> {
            collect.run();
            guardSecrets(inc, () -> {
                save(inc, g, true);
                Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain")
                        .putExtra(Intent.EXTRA_SUBJECT, "Incident report: " + g.title)
                        .putExtra(Intent.EXTRA_TEXT, RecoveryGuide.report(inc));
                a.open(Intent.createChooser(send, "Share incident report"));
            });
        }), Ui.margins(a, Ui.MATCH, Ui.WRAP, 8));
        if (inc.id > 0) {
            c.addView(Ui.destructive(a, "Delete report", v -> new AlertDialog.Builder(a)
                    .setTitle("Delete this report?")
                    .setMessage("The report and its checklist progress will be removed from this phone.")
                    .setPositiveButton("Delete", (d, w) -> {
                        EventLog.get(a).deleteIncident(inc.id);
                        draft = null;
                        a.success("Report deleted");
                        a.onBackPressed();
                    })
                    .setNegativeButton("Cancel", null)
                    .show()), Ui.margins(a, Ui.MATCH, Ui.WRAP, 8));
        }
        return c;
    }

    /** Stops codes and passwords from being stored: offers to remove them first. */
    private void guardSecrets(EventLog.Incident inc, Runnable then) {
        Redactor.Result d = Redactor.redact(inc.description), t = Redactor.redact(inc.actionsTaken);
        int secrets = d.secrets + t.secrets + d.codes + t.codes;
        if (secrets == 0) {
            then.run();
            return;
        }
        new AlertDialog.Builder(a)
                .setTitle("Remove codes or passwords?")
                .setMessage("The report seems to contain a code, PIN or password. SafeSphere doesn't keep those. "
                        + "Remove them and continue?")
                .setPositiveButton("Remove and continue", (x, w) -> {
                    inc.description = scrubSecrets(inc.description);
                    inc.actionsTaken = scrubSecrets(inc.actionsTaken);
                    then.run();
                })
                .setNegativeButton("Edit myself", null)
                .show();
    }

    /** Removes only secrets and short codes; keeps amounts, reference numbers and phone numbers the user wrote. */
    private static String scrubSecrets(String s) {
        if (s == null) return "";
        String out = s.replaceAll("(?i)\\b(password|passwd|pass|pwd|passcode|mpin|pin|otp|code|cvv|cvc)\\b(\\s*(?:is|:|=|-)\\s*)(\\S+)",
                "$1$2[removed]");
        return out.replaceAll("(?<![\\w.,₱$])\\d{4,8}(?![\\w.,])", "[removed]");
    }

    private void save(EventLog.Incident inc, RecoveryGuide.Incident g, boolean explicit) {
        boolean isNew = inc.id <= 0;
        EventLog.get(a).saveIncident(inc);
        if (isNew) {
            EventLog.get(a).record(EventLog.CAT_RECOVERY, "", "Started recovery: " + g.title, System.currentTimeMillis());
        }
    }
}
