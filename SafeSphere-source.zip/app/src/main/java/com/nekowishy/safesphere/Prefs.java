package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Locale;

/** App settings: auto-start, encrypted DNS, message scanning and the protection lock PIN. */
final class Prefs {

    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    /** True when the user left protection ON, so it restarts after a reboot. */
    static boolean protectionWanted(Context c) { return p(c).getBoolean("wanted", false); }
    static void setProtectionWanted(Context c, boolean v) { p(c).edit().putBoolean("wanted", v).apply(); }

    static boolean encryptedDns(Context c) { return p(c).getBoolean("doh", true); }
    static void setEncryptedDns(Context c, boolean v) { p(c).edit().putBoolean("doh", v).apply(); }

    /** True once the Check tab has asked for notification permission (after that we open Android settings instead). */
    static boolean askedNotify(Context c) { return p(c).getBoolean("askedNotify", false); }
    static void setAskedNotify(Context c) { p(c).edit().putBoolean("askedNotify", true).apply(); }

    // ---------------------------------------------------------------- AI explainer

    static String aiUrl(Context c) { return p(c).getString("aiUrl", ""); }
    static String aiToken(Context c) { return p(c).getString("aiToken", ""); }
    static void setAi(Context c, String url, String token) {
        p(c).edit().putString("aiUrl", url.trim()).putString("aiToken", token.trim()).apply();
    }
    static boolean aiConsent(Context c) { return p(c).getBoolean("aiConsent", false); }
    static void setAiConsent(Context c, boolean v) { p(c).edit().putBoolean("aiConsent", v).apply(); }

    // ---------------------------------------------------------------- protection lock

    static boolean hasPin(Context c) { return p(c).getString("pinHash", null) != null; }

    static void setPin(Context c, String pin) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String s = hex(salt);
        p(c).edit().putString("pinSalt", s).putString("pinHash", hash(s, pin)).apply();
    }

    static void clearPin(Context c) { p(c).edit().remove("pinSalt").remove("pinHash").apply(); }

    static boolean checkPin(Context c, String pin) {
        String salt = p(c).getString("pinSalt", null), h = p(c).getString("pinHash", null);
        return salt != null && h != null && h.equals(hash(salt, pin));
    }

    static String hash(String salt, String pin) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = (salt + ":" + pin).getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < 10_000; i++) d = md.digest(d); // slow down guessing
            return hex(d);
        } catch (Exception e) {
            return "";
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format(Locale.US, "%02x", x));
        return sb.toString();
    }

    // ---------------------------------------------------------------- Android settings

    /** "off", "opportunistic" (Automatic) or "hostname" (a specific provider), or null if unreadable. */
    static String privateDnsMode(Context c) {
        try {
            return Settings.Global.getString(c.getContentResolver(), "private_dns_mode");
        } catch (Exception e) {
            return null;
        }
    }

    /** True when Private DNS is set to a specific provider, which makes apps skip SafeSphere's filter. */
    static boolean privateDnsBypasses(Context c) {
        return "hostname".equals(privateDnsMode(c));
    }
}
