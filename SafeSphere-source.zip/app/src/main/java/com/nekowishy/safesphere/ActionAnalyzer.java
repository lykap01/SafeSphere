package com.nekowishy.safesphere;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * "Before You Act": works out what a message is asking the reader to DO (share an OTP, pay a fee,
 * install an app...) and explains the risk, even when the message has no link at all.
 *
 * Fully local and rule-based. Nothing is stored or sent anywhere. English and common Filipino/Taglish
 * phrasings are covered; the rules are transparent so every warning can show the exact words that
 * triggered it.
 */
final class ActionAnalyzer {

    private ActionAnalyzer() {}

    static final int LOW = 1, MEDIUM = 2, HIGH = 4, CRITICAL = 6;

    /** One requested action or supporting sign found in the message. */
    static final class Finding {
        final String id;
        final String title;     // what the sender wants, in plain words
        final String why;       // why it matters
        final String[] advice;  // what to do
        final boolean action;   // true = a requested action; false = a supporting warning sign
        int weight;
        final List<String> evidence = new ArrayList<>(); // exact words that triggered it

        Finding(Rule r) {
            id = r.id;
            title = r.title;
            why = r.why;
            advice = r.advice;
            action = r.action;
        }
    }

    static final class Report {
        int level = ScamDetector.SAFE;
        int points;
        String summary = "";
        String note;                  // reassurance for normal messages (e.g. a genuine OTP text)
        final List<Finding> findings = new ArrayList<>();
        final List<ScamDetector.LinkResult> links = new ArrayList<>();
        final List<String> advice = new ArrayList<>();

        boolean has(String id) {
            for (Finding f : findings) if (f.id.equals(id)) return true;
            return false;
        }

        List<Finding> actions() {
            List<Finding> out = new ArrayList<>();
            for (Finding f : findings) if (f.action) out.add(f);
            return out;
        }

        List<Finding> signs() {
            List<Finding> out = new ArrayList<>();
            for (Finding f : findings) if (!f.action) out.add(f);
            return out;
        }
    }

    // ------------------------------------------------------------------ rules

    private static final class Pat {
        final Pattern p;
        final int weight;
        Pat(String regex, int weight) {
            this.p = Pattern.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            this.weight = weight;
        }
    }

    private static final class Rule {
        final String id, title, why;
        final String[] advice;
        final boolean action, negatable;
        final Pat[] pats;
        Rule(String id, boolean action, boolean negatable, String title, String why, String[] advice, Pat... pats) {
            this.id = id; this.action = action; this.negatable = negatable; this.title = title; this.why = why;
            this.advice = advice; this.pats = pats;
        }
    }

    static final String OTP = "otp", CREDENTIALS = "credentials", MONEY = "money", FEE = "fee", APK = "apk",
            REMOTE = "remote", PERSONAL = "personal", SHORT_LINK = "short_link", VERIFY_LINK = "verify_link",
            URGENCY = "urgency", PRIZE = "prize", JOB = "job", IMPERSONATION = "impersonation", MOVE_APP = "move_app",
            NEW_NUMBER = "new_number", REFUND = "refund";

    private static final String S = "[^.!?\\n]"; // stays inside one sentence

    private static final Rule[] RULES = {
            new Rule(OTP, true, true, "Share a one-time code (OTP), MPIN or PIN",
                    "Whoever has your OTP or MPIN can log in to your account or approve transfers as you. "
                            + "Banks, e-wallets and real companies never ask for them.",
                    new String[]{"Don't send the code to anyone, even someone who says they're from your bank or e-wallet.",
                            "If you already shared it, open the official app now, change your password or MPIN, and contact "
                                    + "the provider through the app or the number printed on your card.",
                            "Open Recovery Center → \"I shared an OTP or MPIN\" for a step-by-step checklist."},
                    new Pat("\\b(send|give|share|forward|tell|provide|reply|text|type|read|dictate)\\b" + S
                            + "{0,30}\\b(otp|one[- ]?time (?:pin|password|passcode|code)|verification code|auth(?:entication)? code|"
                            + "mpin|6[- ]?digit (?:code|pin)|code (?:we|you|i) (?:just )?(?:sent|received|got))\\b", CRITICAL),
                    new Pat("\\b(otp|mpin|verification code|one[- ]?time (?:pin|password))\\b" + S
                            + "{0,40}\\b(send|reply|forward|give|share|provide|i-?send|ibigay|ipadala|i-?forward|isend)\\b", CRITICAL),
                    new Pat("\\b(i-?send|ibigay|ipadala|pakisend|pa-?send|send mo|bigay mo|sabihin mo|i-?type mo|i-?forward)\\b"
                            + S + "{0,30}\\b(otp|code|mpin|pin)\\b", CRITICAL),
                    new Pat("\\b(what(?:'s| is)|ano(?:ng)?(?: ang| yung)?)\\s+(?:the |your |ang |yung )?(otp|code|mpin)\\b", CRITICAL)),

            new Rule(CREDENTIALS, true, true, "Enter your password or account login details",
                    "Fake login pages copy the look of real ones. Anything typed there goes straight to the scammer.",
                    new String[]{"Don't log in through a link in a message. Open the official app or type the address yourself.",
                            "If you already entered your password, change it now on the official site and turn on 2-step verification.",
                            "Recovery Center → \"I entered my password on a suspicious website\"."},
                    new Pat("\\b(enter|input|confirm|verify|update|provide|submit|type|re-?enter)\\b" + S
                            + "{0,25}\\b(password|passcode|username|user ?id|log-?in details|login details|credentials|"
                            + "card (?:number|details)|cvv|cvc|card pin)\\b", HIGH),
                    new Pat("\\b(log ?in|sign ?in|mag-?log ?in)\\b" + S + "{0,25}\\b(to (?:verify|confirm|secure|restore|unlock|"
                            + "avoid|continue|reactivate|keep)|via (?:the |this )?link|using (?:the |this )?link)\\b", HIGH),
                    new Pat("\\b(verify|confirm|validate|update|re-?activate)\\s+(?:your |ang |yung )?(account|identity|details|"
                            + "information|info|profile|e-?wallet)\\b", HIGH)),

            new Rule(MONEY, true, false, "Send or transfer money",
                    "Money sent by transfer or e-wallet usually can't be pulled back once it reaches a scammer's account.",
                    new String[]{"Confirm the request by calling the person on a number you already have, not one in the message.",
                            "Be wary of new numbers, \"emergency\" stories and requests to keep it secret.",
                            "If you already sent money, see Recovery Center → \"I sent money to a suspected scammer\"."},
                    new Pat("\\b(send|transfer|deposit|remit|wire|i-?send|ipadala|magpadala|padalhan|pa-?send|pasend)\\b" + S
                            + "{0,30}(₱|\\bphp\\b|\\bp\\d|\\$|\\busd\\b|\\bpesos?\\b|\\bmoney\\b|\\bfunds\\b|\\bpera\\b|\\b\\d{3,}\\b|\\b\\d+k\\b)", MEDIUM),
                    new Pat("\\b(transfer|send|deposit) (?:it |the money |the amount )?to (?:this|the following|my|our|the)\\s+"
                            + "(?:new )?(account|number|gcash|maya|wallet|bank)\\b", MEDIUM),
                    new Pat("\\b(gift ?cards?|google play cards?|itunes cards?|steam cards?|apple gift cards?)\\b", HIGH),
                    new Pat("\\b(bitcoin|btc|usdt|crypto(?:currency)?|wallet address)\\b" + S + "{0,30}\\b(send|transfer|deposit|pay)\\b", HIGH),
                    new Pat("\\b(send|transfer|deposit|pay)\\b" + S + "{0,20}\\b(bitcoin|btc|usdt|eth|crypto(?:currency)?|to (?:this|my|our) wallet)\\b", HIGH)),

            new Rule(FEE, true, false, "Pay a fee before receiving something",
                    "Paying a \"release\", \"processing\" or \"delivery\" fee to unlock a prize, loan, job or parcel is the classic "
                            + "advance-fee scam. The promised item never arrives.",
                    new String[]{"Don't pay. Real prizes and loans don't require an upfront fee sent by transfer.",
                            "Check a parcel only in the courier's official app or website using your own tracking number.",
                            "Report the sender in your messaging app."},
                    new Pat("\\b(processing|release|clearance|customs|redelivery|re-delivery|handling|activation|registration|"
                            + "insurance|verification|unlock|withdrawal|reservation|membership|admin(?:istrative)?)\\s+fees?\\b", MEDIUM),
                    new Pat("\\b(unpaid|outstanding|pending) (?:delivery |shipping |customs )?(fee|fees|duty|duties|toll|charges?)\\b", HIGH),
                    new Pat("\\bpay\\b" + S + "{0,30}\\b(to|before|para|first|muna)\\b" + S
                            + "{0,25}\\b(receive|claim|release|get|withdraw|unlock|makuha|ma-?claim|ma-?release|deliver)\\b", HIGH),
                    new Pat("\\b(small|minimal|maliit na) (fee|amount|bayad)\\b|\\bbayad muna\\b|\\badvance (?:payment|fee)\\b", HIGH)),

            new Rule(APK, true, false, "Install an app from outside the Play Store",
                    "Apps sent as APK files or download links skip Google's checks. Fake bank, delivery and \"update\" apps can read "
                            + "your messages and OTPs or take over your phone.",
                    new String[]{"Only install apps from Google Play or your phone maker's official store.",
                            "Never turn on \"Install unknown apps\" because a message told you to.",
                            "If you installed it, see Recovery Center → \"I installed a suspicious APK\"."},
                    new Pat("[a-z0-9_-]\\.apk\\b|\\bapk (?:file|link)\\b", HIGH),
                    new Pat("\\b(unknown sources|install unknown apps|allow (?:installation|installing|install) from)\\b", HIGH),
                    new Pat("\\b(download|install|i-?install|i-?download)\\b" + S + "{0,40}\\b(app|application|update|file)\\b" + S
                            + "{0,30}\\b(link|here|below|this|attached)\\b", MEDIUM),
                    new Pat("\\b(mod apk|modded app|cracked app|premium unlocked)\\b", HIGH)),

            new Rule(REMOTE, true, false, "Install a remote-access app or share your screen",
                    "Screen-sharing and remote-control apps let the other person see your OTPs and operate your banking apps.",
                    new String[]{"Don't install AnyDesk, TeamViewer, RustDesk or similar apps for someone who contacted you.",
                            "Real banks and e-wallets never need to see or control your screen.",
                            "If you installed one, uninstall it and change your banking passwords from another device."},
                    new Pat("\\b(anydesk|any desk|teamviewer|team viewer|rustdesk|quick ?support|airdroid|splashtop|ultraviewer)\\b", CRITICAL),
                    new Pat("\\b(share|sharing|i-?share)\\s+(?:your |ang |yung )?screen\\b|\\bscreen ?shar(?:e|ing)\\b", HIGH),
                    new Pat("\\bremote (?:access|support|control|assistance)\\b", HIGH)),

            new Rule(PERSONAL, true, true, "Send personal or identity information",
                    "IDs, selfies, birthdays and account numbers let scammers open loans, SIMs or e-wallets in your name.",
                    new String[]{"Don't send ID photos or selfies to someone who contacted you first.",
                            "If an organisation really needs documents, submit them only inside its official app or office."},
                    new Pat("\\b(send|provide|submit|upload|give|reply with|i-?send|ibigay|forward)\\b" + S
                            + "{0,30}\\b(valid id|government id|id (?:photo|picture|card)|selfie|birth ?date|birthday|date of birth|"
                            + "mother'?s maiden|home address|sss (?:number|no)|tin (?:number|no)|passport|full name|"
                            + "bank account (?:number|details)|account number|card number|crn)\\b", MEDIUM)),

            new Rule(VERIFY_LINK, true, false, "Verify, claim or pay through a link",
                    "Messages that push you to \"verify\" or \"claim\" through a link are how most phishing pages are reached.",
                    new String[]{"Don't use the link. Open the official app or type the website address yourself.",
                            "If the link was already opened, don't enter anything. Close the page."},
                    new Pat("\\b(click|tap|open|visit|go to|pindutin|i-?click|i-?tap|follow)\\b" + S + "{0,25}\\b(link|here|below|"
                            + "website|site|url)\\b" + S + "{0,35}\\b(verify|confirm|update|claim|unlock|reactivate|validate|avoid|"
                            + "restore|secure|receive|redeliver|reschedule|pay|track)\\b", MEDIUM),
                    new Pat("\\b(verify|confirm|update|validate|unlock|reactivate|claim|pay)\\b" + S + "{0,20}\\b(at|via|here|"
                            + "through|sa|on)\\b\\s*:?\\s*(https?://|www\\.|[\\p{L}0-9-]+\\.[\\p{L}]{2,})", MEDIUM),
                    new Pat("\\b(i-?claim|i-?verify|i-?update|i-?confirm|kunin|i-?click)\\b(?: mo| nyo| niyo| na)*" + S
                            + "{0,40}(https?://|www\\.)", MEDIUM)),

            new Rule(URGENCY, false, false, "Creates urgency or threatens you",
                    "Pressure (\"within 24 hours\", \"your account will be blocked\", \"legal action\") is used to stop you checking first.",
                    new String[]{"Slow down. Real organisations give you time and other ways to confirm."},
                    new Pat("\\b(urgent|urgently|immediately|asap|right away|within \\d+ ?(?:hours?|hrs?|minutes?|mins?|days?)|"
                            + "today only|final (?:notice|warning|reminder)|last (?:chance|warning|reminder)|act now|agad|ngayon din|"
                            + "bago mag-?expire|mag-?e-?expire|hanggang ngayong araw)\\b", LOW),
                    new Pat("\\b(will be|has been|is|was) (?:temporarily |permanently )?(suspended|blocked|deactivated|closed|terminated|"
                            + "disabled|locked|forfeited|restricted|on hold)\\b|\\b(suspension|deactivation)\\b", MEDIUM),
                    new Pat("\\b(legal action|arrest|warrant|lawsuit|subpoena|makukulong|ipapakulong|kakasuhan|case (?:filed|will be filed))\\b", MEDIUM)),

            new Rule(PRIZE, false, false, "Promises a prize or winnings",
                    "Surprise winnings you never entered for are bait for an advance fee or your personal details.",
                    new String[]{"If you didn't join a promo, you didn't win one. Ignore and delete."},
                    new Pat("\\b(congratulations|congrats|you(?:'ve| have)? won|you are (?:the |a )?(?:lucky )?winner|nanalo|panalo ka|"
                            + "prize|premyo|jackpot|raffle|lucky draw|claim your (?:reward|prize|gift))\\b", MEDIUM)),

            new Rule(JOB, false, false, "Offers easy money or a too-good-to-be-true job",
                    "\"Like videos, earn ₱3,000 a day\" task jobs pay small amounts first, then demand deposits you never get back.",
                    new String[]{"Real employers don't pay you to like posts or ask you to deposit money to unlock earnings."},
                    new Pat("\\b(easy money|earn (?:up to|as much as)|earn ₱|earn php|earn \\$|per day|daily (?:income|salary|pay)|"
                            + "work from home|part[- ]time (?:job|work)|kumita|extra income)\\b", MEDIUM),
                    new Pat("\\b((?:like|liking) (?:and subscribe|youtube videos|videos|posts|tiktok videos)|rate (?:products|hotels|apps)|"
                            + "rating (?:products|hotels|apps)|simple tasks?|task (?:job|work)|tasks? to (?:earn|complete)|"
                            + "recharge (?:to|and) (?:earn|unlock))\\b", HIGH),
                    new Pat("\\bcommission\\b", LOW),
                    new Pat("\\b(guaranteed (?:returns?|profits?|income|earnings)|\\d+ ?% (?:daily|weekly|per day|a day|returns?|profit)|"
                            + "double your (?:money|investment)|risk[- ]free (?:investment|returns?))\\b", MEDIUM)),

            new Rule(REFUND, false, false, "Talks about a refund or overpayment",
                    "\"Refund\" and \"you were overpaid\" stories are used to get remote access to your phone or a payment back.",
                    new String[]{"Check refunds only inside the official app or website where you paid."},
                    new Pat("\\b((?:process|claim|receive|get) (?:your |a |the )?refund|refund (?:process|request|department)|"
                            + "overpaid|over-?payment|sobra (?:ang |yung )?(?:bayad|transfer))\\b", MEDIUM)),

            new Rule(MOVE_APP, false, false, "Moves the conversation to another app",
                    "Scammers move victims to Telegram, WhatsApp or similar apps where they are harder to report and trace.",
                    new String[]{"Stay on the official channel. Don't add unknown contacts on another app."},
                    new Pat("\\b(message|contact|chat|add|text|reach) (?:us|me|our (?:agent|hr|admin))\\b" + S
                            + "{0,15}\\b(on|via|sa|thru|through) (telegram|whatsapp|viber|wechat|signal|line)\\b", LOW),
                    new Pat("\\b(t\\.me/|wa\\.me/)", LOW)),

            new Rule(NEW_NUMBER, false, false, "Claims to be someone you know using a new number",
                    "\"Hi Ma, this is my new number\" messages often lead to an urgent money request.",
                    new String[]{"Call the person on their old number or ask a question only they would know."},
                    new Pat("\\b(my new number|this is my new (?:number|phone)|bagong number|nawala (?:ang|yung) (?:phone|cellphone|cp)|"
                            + "lost my phone|changed my number)\\b", MEDIUM)),
    };

    private static final Pattern CODE_TERM = Pattern.compile(
            "\\b(otp|verification code|one[- ]?time (?:pin|password|code)|mpin|6[- ]?digit code|code)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SEND_IT_BACK = Pattern.compile(
            "\\b(forward|send|give|share|i-?forward|i-?send|ibigay)\\s+(?:it|this|that|them|mo)\\s+(?:back\\s+)?(?:to me|to us|back|sa akin|sakin)\\b",
            Pattern.CASE_INSENSITIVE);

    /** Words that cancel a request in front of it: "Do NOT share this OTP". */
    private static final Pattern NEGATION = Pattern.compile(
            "\\b(do not|don't|dont|never|huwag|wag|hindi dapat|no one|nobody|will not|won't|not to|never ask)\\b",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern OTP_NOTICE = Pattern.compile(
            "\\b(otp|one[- ]?time (?:pin|password)|verification code|code)\\b" + S + "{0,40}\\b(is|:)\\s*\\d{4,8}\\b|\\b\\d{4,8}\\b"
                    + S + "{0,20}\\b(is your|ang iyong)\\b", Pattern.CASE_INSENSITIVE);

    // ------------------------------------------------------------------ analysis

    /** Analyzes the text and any links in it. Links are checked with ScamDetector (threat lists + heuristics). */
    static Report analyzeText(String text) {
        List<ScamDetector.LinkResult> links = new ArrayList<>();
        for (String l : ScamDetector.extractLinks(text)) links.add(ScamDetector.analyze(l));
        return analyze(text, links);
    }

    static Report analyze(String rawText, List<ScamDetector.LinkResult> linkResults) {
        Report rep = new Report();
        if (linkResults != null) rep.links.addAll(linkResults);
        String text = rawText == null ? "" : rawText.replace('’', '\'').replaceAll("\\s+", " ").trim();

        for (Rule r : RULES) {
            Finding f = null;
            for (Pat pat : r.pats) {
                Matcher m = pat.p.matcher(text);
                while (m.find()) {
                    if (r.negatable && negated(text, m.start(), m.end())) continue;
                    if (r.id.equals(APK) && mentionsOfficialStore(text, m.start(), m.end())) continue;
                    if (f == null) f = new Finding(r);
                    f.weight = Math.max(f.weight, pat.weight);
                    String ev = snippet(text, m.start(), m.end());
                    if (f.evidence.size() < 3 && !f.evidence.contains(ev)) f.evidence.add(ev);
                }
            }
            if (f != null) rep.findings.add(f);
        }

        // "I sent my code to your number by mistake. Can you forward it to me?" — the code is named in another sentence.
        if (!rep.has(OTP) && CODE_TERM.matcher(text).find()) {
            Matcher m = SEND_IT_BACK.matcher(text);
            if (m.find() && !negated(text, m.start(), m.end())) {
                Finding f = new Finding(RULES[0]);
                f.weight = CRITICAL;
                f.evidence.add(snippet(text, m.start(), m.end()));
                rep.findings.add(0, f);
            }
        }

        // Brand or institution named in the text: a claim of identity (impersonation is a supporting sign).
        String claimed = claimedBrand(text);
        if (claimed != null) {
            Finding f = new Finding(new Rule(IMPERSONATION, false, false, "Claims to be from " + claimed,
                    "Anyone can put a company's name in a message. The name alone proves nothing.",
                    new String[]{"Contact " + claimed + " only through its official app, website or the number on your card."}));
            f.weight = LOW;
            f.evidence.add(claimed);
            rep.findings.add(f);
        }

        // Links
        int worst = -1;
        boolean shortLink = false;
        for (ScamDetector.LinkResult l : rep.links) {
            worst = Math.max(worst, l.level);
            if (l.shortener) shortLink = true;
        }
        if (shortLink) {
            Finding f = new Finding(new Rule(SHORT_LINK, true, false, "Open a shortened link",
                    "Short links hide the real destination, so you can't see where you'll land until it's too late.",
                    new String[]{"Don't open short links from people or companies you didn't expect to hear from."}));
            f.weight = LOW;
            for (ScamDetector.LinkResult l : rep.links) if (l.shortener && f.evidence.size() < 3) f.evidence.add(l.host);
            rep.findings.add(f);
        }
        // A "verify through a link" request is serious when the link itself looks wrong
        for (Finding f : rep.findings) {
            if ((f.id.equals(VERIFY_LINK) || f.id.equals(CREDENTIALS)) && worst >= ScamDetector.CAUTION) f.weight = Math.max(f.weight, HIGH);
        }

        // ---------------------------------------------------------------- score
        int points = 0;
        boolean hasHighAction = false, hasAmplifier = false;
        for (Finding f : rep.findings) {
            points += f.weight;
            if (f.action && f.weight >= HIGH) hasHighAction = true;
            if (!f.action && f.weight >= MEDIUM) hasAmplifier = true;
            if (!f.action && (f.id.equals(URGENCY) || f.id.equals(IMPERSONATION))) hasAmplifier = true;
        }
        if (worst == ScamDetector.DANGEROUS) points += 6;
        else if (worst == ScamDetector.SUSPICIOUS) points += 3;
        else if (worst == ScamDetector.CAUTION) points += 1;
        rep.points = points;

        boolean dangerousLink = false;
        for (ScamDetector.LinkResult l : rep.links) if (l.level == ScamDetector.DANGEROUS) dangerousLink = true;
        if (dangerousLink) rep.level = ScamDetector.DANGEROUS;
        else if (points >= 5 || (hasHighAction && hasAmplifier)) rep.level = ScamDetector.SUSPICIOUS;
        else if (points >= 2) rep.level = ScamDetector.CAUTION;
        else rep.level = ScamDetector.SAFE;

        // Genuine OTP texts: contain a code plus a "never share" line, and ask for nothing.
        if (!rep.has(OTP) && OTP_NOTICE.matcher(text).find()) {
            rep.note = "This looks like a normal one-time code message. Use the code only in the app or site where you "
                    + "requested it, and never forward it to anyone.";
        }

        // ---------------------------------------------------------------- wording
        List<Finding> acts = rep.actions();
        String firstAction = acts.isEmpty() ? null : lowerFirst(acts.get(0).title);
        switch (rep.level) {
            case ScamDetector.DANGEROUS:
                rep.summary = "A link in this message is on a threat list. Don't open it and don't reply.";
                break;
            case ScamDetector.SUSPICIOUS:
                rep.summary = firstAction != null
                        ? "Suspicious: the sender wants you to " + firstAction + ", with warning signs typical of scams. Don't act on it."
                        : "Suspicious: this message has several warning signs typical of scams. Don't act on it.";
                break;
            case ScamDetector.CAUTION:
                rep.summary = firstAction != null
                        ? "Be careful: the sender wants you to " + firstAction + ". Confirm through a channel you already trust before doing it."
                        : "Be careful: there are some warning signs. Confirm with the sender through a channel you already trust.";
                break;
            default:
                rep.summary = text.isEmpty() ? "" : "No risky requests or warning signs found. If you didn't expect this message, "
                        + "still check with the sender through a channel you already know.";
        }
        Set<String> adv = new LinkedHashSet<>();
        for (Finding f : rep.findings) if (f.action) for (String a : f.advice) adv.add(a);
        for (Finding f : rep.findings) if (!f.action && rep.level >= ScamDetector.CAUTION) for (String a : f.advice) adv.add(a);
        if (rep.level >= ScamDetector.SUSPICIOUS) adv.add("Report the sender in your messaging app, then delete the message.");
        rep.advice.addAll(adv);
        return rep;
    }

    private static boolean negated(String text, int start, int end) {
        int from = Math.max(0, start - 30);
        String window = text.substring(from, end);
        // stop the look-back at the previous sentence
        int cut = Math.max(window.lastIndexOf(". ", start - from), Math.max(window.lastIndexOf("! ", start - from), window.lastIndexOf("? ", start - from)));
        if (cut >= 0) window = window.substring(cut + 2);
        return NEGATION.matcher(window).find();
    }

    private static boolean mentionsOfficialStore(String text, int start, int end) {
        String w = text.substring(Math.max(0, start - 20), Math.min(text.length(), end + 40)).toLowerCase(Locale.ROOT);
        return w.contains("play store") || w.contains("google play") || w.contains("app store") || w.contains("appgallery")
                || w.contains("galaxy store");
    }

    private static String snippet(String text, int start, int end) {
        String s = text.substring(start, end).trim();
        if (s.length() > 70) s = s.substring(0, 67) + "…";
        return s;
    }

    private static String lowerFirst(String s) {
        return s.isEmpty() ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }

    /** First catalogued brand (or a generic institution) named in the text. */
    static String claimedBrand(String text) {
        String t = " " + text.toLowerCase(Locale.ROOT) + " ";
        for (BrandCatalog.Brand b : BrandCatalog.all()) {
            String n = b.name.toLowerCase(Locale.ROOT);
            if (Pattern.compile("(?<![\\p{L}\\p{N}])" + Pattern.quote(n) + "(?![\\p{L}\\p{N}])").matcher(t).find()) return b.name;
        }
        Matcher m = Pattern.compile("\\b(your bank|the bank|bangko|customer service|security team|fraud department|"
                + "bsp|bir|customs|lto|dict|cicc|pnp|nbi)\\b", Pattern.CASE_INSENSITIVE).matcher(t);
        if (m.find()) {
            String g = m.group(1);
            return g.length() <= 4 ? g.toUpperCase(Locale.ROOT) : g;
        }
        return null;
    }
}
