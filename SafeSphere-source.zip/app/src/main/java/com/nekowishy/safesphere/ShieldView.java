package com.nekowishy.safesphere;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Animated neon shield: pulsing sonar rings, a spinning scanner ring and a glowing core. */
final class ShieldView extends View {

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shield = new Path();
    private final Path icon = new Path();
    private final ValueAnimator anim;
    private float phase;
    private boolean active;
    private int lastW = -1;
    private int lastColor;

    ShieldView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null); // needed for the blur glow
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Ui.dp(c, 2));
        dash.setStyle(Paint.Style.STROKE);
        dash.setStrokeWidth(Ui.dp(c, 3));
        dash.setStrokeCap(Paint.Cap.ROUND);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeWidth(Ui.dp(c, 8));
        glow.setMaskFilter(new BlurMaskFilter(Ui.dp(c, 10), BlurMaskFilter.Blur.NORMAL));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Ui.dp(c, 3));
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(2600);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        setClickable(true);
    }

    void setActive(boolean on) {
        if (on == active) return;
        active = on;
        lastW = -1;
        invalidate();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f * 0.96f;
        int main = active ? Ui.CYAN : Ui.PINK;
        int accent = active ? Ui.GREEN : Ui.RED;

        if (w != lastW || main != lastColor) {
            lastW = w;
            lastColor = main;
            halo.setShader(new RadialGradient(cx, cy, r, new int[]{Ui.alpha(main, 0x55), Ui.alpha(main, 0x10), 0},
                    new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            float s = r * 0.42f;
            shield.reset();
            shield.moveTo(cx, cy - s);
            shield.lineTo(cx + s * 0.78f, cy - s * 0.68f);
            shield.lineTo(cx + s * 0.78f, cy + s * 0.02f);
            shield.cubicTo(cx + s * 0.78f, cy + s * 0.55f, cx + s * 0.4f, cy + s * 0.85f, cx, cy + s);
            shield.cubicTo(cx - s * 0.4f, cy + s * 0.85f, cx - s * 0.78f, cy + s * 0.55f, cx - s * 0.78f, cy + s * 0.02f);
            shield.lineTo(cx - s * 0.78f, cy - s * 0.68f);
            shield.close();
            icon.reset();
            if (active) { // check mark
                icon.moveTo(cx - s * 0.32f, cy + s * 0.02f);
                icon.lineTo(cx - s * 0.06f, cy + s * 0.28f);
                icon.lineTo(cx + s * 0.36f, cy - s * 0.2f);
            } else { // power symbol
                icon.addArc(cx - s * 0.3f, cy - s * 0.24f, cx + s * 0.3f, cy + s * 0.36f, -60, 300);
                icon.moveTo(cx, cy - s * 0.36f);
                icon.lineTo(cx, cy + s * 0.02f);
            }
        }

        // breathing halo
        float breathe = 0.85f + 0.15f * (float) Math.sin(phase * Math.PI * 2);
        canvas.save();
        canvas.scale(breathe, breathe, cx, cy);
        canvas.drawCircle(cx, cy, r, halo);
        canvas.restore();

        // sonar pulses
        for (int i = 0; i < 3; i++) {
            float t = (phase + i / 3f) % 1f;
            ring.setColor(Ui.alpha(main, (int) (170 * (1f - t))));
            canvas.drawCircle(cx, cy, r * (0.5f + 0.48f * t), ring);
        }

        // spinning scanner rings
        float d = Ui.dp(getContext(), 7);
        dash.setPathEffect(new DashPathEffect(new float[]{d * 2.4f, d}, 0));
        dash.setColor(Ui.alpha(main, 0xCC));
        canvas.save();
        canvas.rotate(phase * 360f, cx, cy);
        canvas.drawCircle(cx, cy, r * 0.6f, dash);
        canvas.restore();
        dash.setPathEffect(new DashPathEffect(new float[]{d * 0.6f, d * 1.6f}, 0));
        dash.setColor(Ui.alpha(accent, 0x99));
        canvas.save();
        canvas.rotate(-phase * 540f, cx, cy);
        canvas.drawCircle(cx, cy, r * 0.68f, dash);
        canvas.restore();

        // shield core
        fill.setColor(Ui.alpha(main, 0x26));
        canvas.drawPath(shield, fill);
        glow.setColor(main);
        canvas.drawPath(shield, glow);
        line.setColor(main);
        canvas.drawPath(shield, line);
        glow.setColor(accent);
        canvas.drawPath(icon, glow);
        line.setColor(accent);
        canvas.drawPath(icon, line);
    }
}
