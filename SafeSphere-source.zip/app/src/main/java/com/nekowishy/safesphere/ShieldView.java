package com.nekowishy.safesphere;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * Hero dial on the Shield card (Build 15 design and colours): an arc showing security setup
 * progress with tick dots and a softly pulsing marker, a slowly turning scanner ring and a white shield
 * (tick when protection runs, power symbol when it is off).
 */
final class ShieldView extends View {

    private static final int ACCENT = 0xFF7CE0FF; // Build 15 luminous cyan

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shield = new Path();
    private final Path icon = new Path();
    private final RectF box = new RectF();
    private final ValueAnimator anim;
    private float phase;
    private boolean active;
    private float score = 0f;       // 0..100, animated toward target
    private float targetScore = 0f;
    private int lastW = -1;
    private boolean lastActive;

    ShieldView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null); // needed for the soft glow
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(Ui.dp(c, 6));
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(Ui.alpha(Ui.WHITE, 0x40));
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(Ui.dp(c, 6));
        arc.setStrokeCap(Paint.Cap.ROUND);
        dash.setStyle(Paint.Style.STROKE);
        dash.setStrokeWidth(Ui.dp(c, 1.5f));
        dash.setColor(Ui.alpha(Ui.WHITE, 0x70));
        dot.setStyle(Paint.Style.FILL);
        glow.setStyle(Paint.Style.FILL);
        glow.setMaskFilter(new BlurMaskFilter(Ui.dp(c, 9), BlurMaskFilter.Blur.NORMAL));
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(Ui.dp(c, 2.5f));
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(3200);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            score += (targetScore - score) * 0.08f; // ease the arc toward the real score
            invalidate();
        });
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO); // the card's text says the same
    }

    void setActive(boolean on) {
        if (on == active) return;
        active = on;
        invalidate();
    }

    void setScore(int s) {
        targetScore = Math.max(0, Math.min(100, s));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        anim.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        anim.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f - Ui.dp(getContext(), 14);
        int accent = active ? ACCENT : 0xFFFF8A8A;

        if (w != lastW || active != lastActive) {
            lastW = w;
            lastActive = active;
            float s = r * 0.42f;
            shield.reset();
            shield.moveTo(cx, cy - s);
            shield.lineTo(cx + s * 0.78f, cy - s * 0.68f);
            shield.lineTo(cx + s * 0.78f, cy + s * 0.02f);
            shield.cubicTo(cx + s * 0.78f, cy + s * 0.55f, cx + s * 0.4f, cy + s * 0.85f, cx, cy + s);
            shield.cubicTo(cx - s * 0.4f, cy + s * 0.85f, cx - s * 0.78f, cy + s * 0.55f, cx - s * 0.78f, cy + s * 0.02f);
            shield.lineTo(cx - s * 0.78f, cy - s * 0.68f);
            shield.close();
            icon.reset();
            if (active) {
                icon.moveTo(cx - s * 0.32f, cy + s * 0.02f);
                icon.lineTo(cx - s * 0.06f, cy + s * 0.28f);
                icon.lineTo(cx + s * 0.36f, cy - s * 0.2f);
            } else {
                icon.addArc(cx - s * 0.3f, cy - s * 0.24f, cx + s * 0.3f, cy + s * 0.36f, -60, 300);
                icon.moveTo(cx, cy - s * 0.36f);
                icon.lineTo(cx, cy + s * 0.02f);
            }
        }

        // score dial: 270 degree track, progress arc, tick dots
        box.set(cx - r, cy - r, cx + r, cy + r);
        canvas.drawArc(box, 135, 270, false, track);
        arc.setColor(active ? Ui.WHITE : Ui.alpha(Ui.WHITE, 0x90));
        float sweep = 270f * score / 100f;
        if (sweep > 0.5f) canvas.drawArc(box, 135, sweep, false, arc);
        for (int i = 0; i <= 4; i++) {
            double a = Math.toRadians(135 + 270 * i / 4.0);
            float tx = cx + (float) Math.cos(a) * (r + Ui.dp(getContext(), 10));
            float ty = cy + (float) Math.sin(a) * (r + Ui.dp(getContext(), 10));
            dot.setColor(Ui.alpha(Ui.WHITE, 0xB0));
            canvas.drawCircle(tx, ty, Ui.dp(getContext(), 2), dot);
        }
        // glowing marker at the score position, gently pulsing
        double ma = Math.toRadians(135 + sweep);
        float mx = cx + (float) Math.cos(ma) * r, my = cy + (float) Math.sin(ma) * r;
        float pulse = 1f + 0.25f * (float) Math.sin(phase * Math.PI * 2);
        glow.setColor(Ui.alpha(accent, 0xAA));
        canvas.drawCircle(mx, my, Ui.dp(getContext(), 10) * pulse, glow);
        dot.setColor(accent);
        canvas.drawCircle(mx, my, Ui.dp(getContext(), 6), dot);

        // slowly turning scanner ring
        float d = Ui.dp(getContext(), 5);
        dash.setPathEffect(new DashPathEffect(new float[]{d * 3, d * 2}, 0));
        canvas.save();
        canvas.rotate(phase * 360f, cx, cy);
        canvas.drawCircle(cx, cy, r * 0.66f, dash);
        canvas.restore();

        // shield core
        fill.setColor(Ui.alpha(Ui.WHITE, 0x30));
        canvas.drawPath(shield, fill);
        line.setColor(Ui.WHITE);
        canvas.drawPath(shield, line);
        line.setColor(active ? ACCENT : Ui.WHITE);
        canvas.drawPath(icon, line);
    }
}
