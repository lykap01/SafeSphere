package com.nekowishy.safesphere;

import android.net.Uri;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallScreeningService;

/**
 * Android asks this service about each incoming call from a number that isn't in the user's contacts
 * (only after the user picks SafeSphere as the call-screening app). It must answer within a few seconds,
 * so it does nothing slow: a local block-list lookup and, if needed, a warning notification.
 */
public class CallGuardService extends CallScreeningService {

    @Override
    public void onScreenCall(Call.Details details) {
        CallResponse.Builder r = new CallResponse.Builder();
        try {
            if (Build.VERSION.SDK_INT >= 29 && details.getCallDirection() != Call.Details.DIRECTION_INCOMING) {
                respondToCall(details, r.build());
                return;
            }
            Uri handle = details.getHandle();
            String number = handle == null ? null : handle.getSchemeSpecificPart();
            int kind = CallGuard.classify(number, CallGuard.blocked(this));
            long now = System.currentTimeMillis();
            if (kind == CallGuard.BLOCKED) {
                r.setDisallowCall(true).setRejectCall(true).setSkipNotification(true);
                EventLog.get(this).record(EventLog.CAT_CALL, "", "Rejected a call from " + CallGuard.mask(number)
                        + " (you blocked this number)", now);
            } else {
                if (kind == CallGuard.HIDDEN && CallGuard.silenceHidden(this) && Build.VERSION.SDK_INT >= 29) {
                    r.setSilenceCall(true);
                }
                if (CallGuard.warnings(this)) {
                    Alerts.callWarning(this, kind, CallGuard.normalize(number));
                    EventLog.get(this).record(EventLog.CAT_CALL, "", "Warned about a call: " + CallGuard.title(kind, number), now);
                }
            }
        } catch (RuntimeException e) {
            // Never block a call because of our own error.
            r = new CallResponse.Builder();
        }
        respondToCall(details, r.build());
    }
}
