package com.nekowishy.safesphere;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.IDN;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Finds the "registrable domain" of a host (example.co.uk, example.com.au, user.github.io) using the
 * Mozilla Public Suffix List bundled in assets/public_suffix_list.dat (MPL-2.0, https://publicsuffix.org).
 *
 * Build 15 only knew a few second-level endings (com.ph, co.uk...), so many international domains
 * (ne.jp, ac.uk, com.br, gov.sg...) and shared hosting platforms (web.app, github.io) were cut at the
 * wrong place. A small heuristic is used only until the list has been loaded.
 */
final class PublicSuffix {

    private static volatile Set<String> normal, wildcard, exception, privateRules;

    private PublicSuffix() {}

    static boolean isLoaded() { return normal != null; }

    /** Parses the list. Later calls are ignored. */
    static synchronized void load(InputStream in) throws IOException {
        if (normal != null) return;
        Set<String> n = new HashSet<>(12000), w = new HashSet<>(512), e = new HashSet<>(64), p = new HashSet<>(4000);
        boolean inPrivate = false;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("// ===BEGIN PRIVATE DOMAINS")) inPrivate = true;
                if (line.isEmpty() || line.startsWith("//")) continue;
                int sp = line.indexOf(' ');
                if (sp > 0) line = line.substring(0, sp);
                Set<String> target = n;
                if (line.startsWith("!")) { target = e; line = line.substring(1); }
                else if (line.startsWith("*.")) { target = w; line = line.substring(2); }
                String ascii = toAscii(line);
                if (ascii == null || ascii.isEmpty()) continue;
                target.add(ascii);
                if (inPrivate && target != e) p.add(ascii);
            }
        }
        wildcard = w;
        exception = e;
        privateRules = p;
        normal = n;
    }

    private static String toAscii(String s) {
        try {
            return IDN.toASCII(s, IDN.ALLOW_UNASSIGNED).toLowerCase(Locale.ROOT);
        } catch (Exception ex) {
            return null;
        }
    }

    /** Public suffix of an ASCII host, e.g. "co.uk" for "shop.example.co.uk" (longest matching rule). */
    static String suffix(String host) {
        String[] labels = host.split("\\.");
        Set<String> n = normal;
        if (n == null) return heuristicSuffix(labels);
        for (int i = 0; i < labels.length; i++) {
            String cand = join(labels, i);
            if (exception.contains(cand)) return join(labels, i + 1);
            if (n.contains(cand)) return cand;
            if (i + 1 < labels.length && wildcard.contains(join(labels, i + 1))) return cand;
        }
        return labels[labels.length - 1]; // default rule "*"
    }

    /** True when the list knows this top-level domain (all ICANN TLDs appear as rules). Null = list not loaded. */
    static Boolean isKnownTld(String tld) {
        Set<String> n = normal;
        if (n == null) return null;
        String a = toAscii(tld);
        return a != null && (n.contains(a) || wildcard.contains(a));
    }

    /** True when the host sits on a shared platform from the list's private section (web.app, github.io...). */
    static boolean onSharedPlatform(String host) {
        Set<String> p = privateRules;
        if (p == null || host == null) return false;
        String s = suffix(host);
        return p.contains(s) && !s.equals(host);
    }

    /** The shared platform's own suffix (e.g. "web.app"), or null. */
    static String sharedPlatform(String host) {
        return onSharedPlatform(host) ? suffix(host) : null;
    }

    /** example.co.uk for www.example.co.uk. Returns the host itself when it is a bare suffix or has no dot. */
    static String registrable(String host) {
        if (host == null || host.indexOf('.') < 0) return host;
        String suf = suffix(host);
        if (suf.length() >= host.length()) return host;
        String rest = host.substring(0, host.length() - suf.length() - 1);
        int dot = rest.lastIndexOf('.');
        return (dot < 0 ? rest : rest.substring(dot + 1)) + "." + suf;
    }

    private static String join(String[] labels, int from) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < labels.length; i++) {
            if (sb.length() > 0) sb.append('.');
            sb.append(labels[i]);
        }
        return sb.toString();
    }

    /** Fallback until the list is loaded: common two-level country endings. */
    private static String heuristicSuffix(String[] p) {
        if (p.length >= 3) {
            String sld = p[p.length - 2], tld = p[p.length - 1];
            if (tld.length() == 2 && (sld.equals("com") || sld.equals("co") || sld.equals("net") || sld.equals("org")
                    || sld.equals("gov") || sld.equals("edu") || sld.equals("ac") || sld.equals("ne") || sld.equals("or")
                    || sld.equals("go") || sld.equals("gob") || sld.equals("mil"))) {
                return sld + "." + tld;
            }
        }
        return p[p.length - 1];
    }
}
