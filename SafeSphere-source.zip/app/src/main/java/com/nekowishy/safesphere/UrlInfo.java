package com.nekowishy.safesphere;

import java.net.IDN;
import java.util.Locale;

/**
 * Parses a link the way a browser would and records the tricks scammers use to disguise where it
 * really goes. Build 15 used a hand-written split that missed Unicode domains, numeric IP forms,
 * percent-encoded hosts and backslash tricks.
 *
 * Pure Java (no Android classes) so it can be unit-tested on a normal JVM.
 */
final class UrlInfo {

    String raw;            // what the user gave us
    String scheme;         // http, https, or null when the link had no scheme
    String userInfo;       // text before '@' in the address part (a disguise trick), or null
    String host = "";      // ASCII (punycode) lower-case host
    String hostUnicode = "";
    int port = -1;
    String pathAndQuery = "";
    boolean valid;
    boolean ipv4, ipv6;
    boolean ipObfuscated;   // e.g. http://3232235777/ or http://0x7f.1/
    boolean encodedHost;    // %2e style characters inside the host
    boolean backslashes;    // https://paypal.com\@evil.example
    boolean idn;            // contains international (non-ASCII) characters
    boolean mixedScript;    // one label mixes alphabets, e.g. Latin + Cyrillic
    String skeleton;        // host with look-alike characters replaced by their Latin twins (homograph check)
    boolean webScheme = true;

    private static final java.util.regex.Pattern HOST_OK =
            java.util.regex.Pattern.compile("[a-z0-9_]([a-z0-9_-]*[a-z0-9_])?(\\.[a-z0-9_]([a-z0-9_-]*[a-z0-9_])?)*");
    private static final java.util.regex.Pattern SCHEME = java.util.regex.Pattern.compile("[A-Za-z][A-Za-z0-9+.-]*");
    private static final java.util.regex.Pattern HOST_PORT =
            java.util.regex.Pattern.compile("(?i)[a-z0-9.-]+\\.[a-z]{2,}:\\d{1,5}([/?#].*)?");

    private UrlInfo() {}

    static UrlInfo parse(String input) {
        UrlInfo u = new UrlInfo();
        String s = input == null ? "" : input.trim();
        while (!s.isEmpty() && "<(\"'[".indexOf(s.charAt(0)) >= 0) s = s.substring(1);
        while (!s.isEmpty() && ".,;:!?)]}>'\"".indexOf(s.charAt(s.length() - 1)) >= 0) s = s.substring(0, s.length() - 1);
        u.raw = s;
        if (s.isEmpty()) return u;

        if (s.indexOf('\\') >= 0) { // browsers treat \ like / in web addresses
            u.backslashes = true;
            s = s.replace('\\', '/');
        }
        String rest = s;
        int colon = s.indexOf(':');
        if (colon > 0 && SCHEME.matcher(s.substring(0, colon)).matches()) {
            String sch = s.substring(0, colon).toLowerCase(Locale.ROOT);
            boolean slashes = s.startsWith("//", colon + 1);
            if (slashes || sch.equals("http") || sch.equals("https")) {
                u.scheme = sch;
                rest = s.substring(colon + 1);
                while (rest.startsWith("/")) rest = rest.substring(1);
                u.webScheme = sch.equals("http") || sch.equals("https") || sch.equals("ftp");
            } else if (!looksLikeHostPort(s)) {
                // mailto:, tel:, javascript:, data: ... not a web address
                u.scheme = sch;
                u.webScheme = false;
                return u;
            }
        }
        int cut = rest.length();
        for (int i = 0; i < rest.length(); i++) {
            if ("/?#".indexOf(rest.charAt(i)) >= 0) { cut = i; break; }
        }
        String authority = rest.substring(0, cut);
        u.pathAndQuery = rest.substring(cut);

        int at = authority.lastIndexOf('@');
        if (at >= 0) {
            u.userInfo = authority.substring(0, at);
            authority = authority.substring(at + 1);
        }
        String hostPart = authority;
        if (hostPart.startsWith("[")) { // IPv6 literal
            int end = hostPart.indexOf(']');
            if (end < 0) return u;
            u.host = hostPart.substring(1, end).toLowerCase(Locale.ROOT);
            u.hostUnicode = u.host;
            u.ipv6 = true;
            String after = hostPart.substring(end + 1);
            if (after.startsWith(":")) u.port = parsePort(after.substring(1));
            u.valid = true;
            return u;
        }
        int pc = hostPart.lastIndexOf(':');
        if (pc >= 0) {
            u.port = parsePort(hostPart.substring(pc + 1));
            hostPart = hostPart.substring(0, pc);
        }
        if (hostPart.indexOf('%') >= 0) {
            String dec = percentDecode(hostPart);
            if (!dec.equals(hostPart)) { u.encodedHost = true; hostPart = dec; }
        }
        // Full-width dots and the ideographic full stop are read as dots by browsers.
        hostPart = hostPart.replace('。', '.').replace('．', '.').replace('｡', '.');
        while (hostPart.endsWith(".")) hostPart = hostPart.substring(0, hostPart.length() - 1);
        if (hostPart.isEmpty()) return u;

        String lower = hostPart.toLowerCase(Locale.ROOT);
        long ip = parseIpv4(lower);
        if (ip >= 0) {
            u.ipv4 = true;
            u.host = ((ip >> 24) & 255) + "." + ((ip >> 16) & 255) + "." + ((ip >> 8) & 255) + "." + (ip & 255);
            u.hostUnicode = u.host;
            u.ipObfuscated = !lower.equals(u.host);
            u.valid = true;
            return u;
        }

        boolean nonAscii = false;
        for (int i = 0; i < lower.length(); i++) if (lower.charAt(i) > 127) { nonAscii = true; break; }
        String ascii;
        try {
            ascii = IDN.toASCII(lower, IDN.ALLOW_UNASSIGNED).toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            ascii = null;
        }
        if (ascii == null || ascii.isEmpty()) return u;
        u.host = ascii;
        String unicode;
        try {
            unicode = IDN.toUnicode(ascii, IDN.ALLOW_UNASSIGNED).toLowerCase(Locale.ROOT);
        } catch (Exception e) {
            unicode = lower;
        }
        u.hostUnicode = unicode;
        u.idn = nonAscii || ascii.contains("xn--");
        if (u.idn) {
            u.mixedScript = hasMixedScriptLabel(unicode);
            u.skeleton = skeleton(unicode);
        }
        u.valid = HOST_OK.matcher(ascii).matches()
                && ascii.length() <= 253 && (ascii.indexOf('.') > 0 || ascii.equals("localhost"));
        return u;
    }

    private static boolean looksLikeHostPort(String s) {
        // "example.com:8080/path" has a "scheme" that is really a host
        return HOST_PORT.matcher(s).matches();
    }

    private static int parsePort(String p) {
        if (p.isEmpty() || p.length() > 5) return -1;
        for (int i = 0; i < p.length(); i++) if (!Character.isDigit(p.charAt(i))) return -1;
        return Integer.parseInt(p);
    }

    private static String percentDecode(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '%' && i + 2 < s.length()) {
                try {
                    sb.append((char) Integer.parseInt(s.substring(i + 1, i + 3), 16));
                    i += 2;
                    continue;
                } catch (NumberFormatException ignored) {
                }
            }
            sb.append(c);
        }
        return sb.toString();
    }

    /**
     * IPv4 parsing as browsers do it (WHATWG URL standard): 1 to 4 parts, each decimal, 0x-hex or
     * 0-octal; the last part fills the remaining bytes. Returns -1 when it is not an IPv4 address.
     */
    static long parseIpv4(String h) {
        if (h.isEmpty()) return -1;
        String[] parts = h.split("\\.", -1);
        if (parts.length > 4) return -1;
        // The last label must be numeric for a browser to treat the host as an address.
        long[] nums = new long[parts.length];
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            if (p.isEmpty()) return -1;
            int radix = 10;
            if (p.startsWith("0x") || p.startsWith("0X")) { radix = 16; p = p.substring(2); if (p.isEmpty()) p = "0"; }
            else if (p.length() > 1 && p.startsWith("0")) { radix = 8; p = p.substring(1); }
            try {
                nums[i] = Long.parseLong(p, radix);
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        long ip = 0;
        for (int i = 0; i < nums.length - 1; i++) {
            if (nums[i] > 255) return -1;
            ip = (ip << 8) | nums[i];
        }
        int remaining = 4 - (nums.length - 1);
        long last = nums[nums.length - 1];
        if (last >= (1L << (8 * remaining))) return -1;
        ip = (ip << (8 * remaining)) | last;
        return ip;
    }

    /** True when any single label mixes two alphabets (Latin + Cyrillic, Latin + Greek...). */
    static boolean hasMixedScriptLabel(String unicodeHost) {
        for (String label : unicodeHost.split("\\.")) {
            Character.UnicodeScript first = null;
            for (int i = 0; i < label.length(); ) {
                int cp = label.codePointAt(i);
                i += Character.charCount(cp);
                if (!Character.isLetter(cp)) continue;
                Character.UnicodeScript sc = Character.UnicodeScript.of(cp);
                if (sc == Character.UnicodeScript.COMMON || sc == Character.UnicodeScript.INHERITED) continue;
                if (first == null) first = sc;
                else if (first != sc) {
                    // Japanese legitimately mixes Han, Hiragana and Katakana
                    if (isCjk(first) && isCjk(sc)) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean isCjk(Character.UnicodeScript s) {
        return s == Character.UnicodeScript.HAN || s == Character.UnicodeScript.HIRAGANA
                || s == Character.UnicodeScript.KATAKANA || s == Character.UnicodeScript.HANGUL;
    }

    /** Characters from other alphabets that look the same as Latin letters (subset of Unicode confusables). */
    private static final String CONFUSABLE_FROM =
            "аеорсухіјѕԁӏһԛԝɡѵкмтвнгпьзαοορτυνικεχγѕℓ" + "０１２３４５６７８９";
    private static final String CONFUSABLE_TO =
            "aeopcyxijsdlhqwgvkmtbhrnb3aoop" + "tuvikexysl" + "0123456789";

    static {
        if (CONFUSABLE_FROM.length() != CONFUSABLE_TO.length()) throw new AssertionError("confusable table mismatch");
    }

    /** The host as it would look to a reader: look-alike letters replaced by Latin ones. */
    static String skeleton(String unicodeHost) {
        StringBuilder sb = new StringBuilder(unicodeHost.length());
        for (int i = 0; i < unicodeHost.length(); i++) {
            char c = unicodeHost.charAt(i);
            int k = CONFUSABLE_FROM.indexOf(c);
            if (k >= 0 && k < CONFUSABLE_TO.length()) sb.append(CONFUSABLE_TO.charAt(k));
            else if (c > 127) {
                // Strip accents: é → e, ö → o
                String d = java.text.Normalizer.normalize(String.valueOf(c), java.text.Normalizer.Form.NFD);
                char base = d.isEmpty() ? c : d.charAt(0);
                sb.append(base < 128 ? base : c);
            } else sb.append(c);
        }
        return sb.toString();
    }

    /** True if the address has a scheme-less, dotted host part that looks like a domain. */
    boolean hasDottedHost() {
        return host.indexOf('.') > 0;
    }

    String tld() {
        int d = host.lastIndexOf('.');
        return d < 0 ? host : host.substring(d + 1);
    }
}
