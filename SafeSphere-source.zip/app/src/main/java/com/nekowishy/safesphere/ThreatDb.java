package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Downloads public malware / phishing domain feeds and keeps them on the phone. */
final class ThreatDb {

    interface Progress { void on(String message); }

    static final String[][] FEEDS = {
            {"URLhaus malware domains", "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-domains.txt"},
            {"Phishing Army", "https://phishing.army/download/phishing_army_blocklist.txt"},
            {"HaGeZi Threat Intelligence", "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/tif.mini-onlydomains.txt"},
    };
    private static final int MAX_DOMAINS = 250_000;

    private static volatile Set<String> domains = Collections.emptySet();
    private static boolean loaded;
    private static final AtomicBoolean updating = new AtomicBoolean();

    private ThreatDb() {}

    static boolean contains(String d) { return domains.contains(d); }
    static int size() { return domains.size(); }
    static boolean isUpdating() { return updating.get(); }

    /** How long ago the database was last downloaded (Long.MAX_VALUE if never). */
    static long ageMillis(Context c) {
        long at = prefs(c).getLong("updatedAt", 0);
        return at == 0 ? Long.MAX_VALUE : System.currentTimeMillis() - at;
    }

    private static File file(Context c) { return new File(c.getFilesDir(), "threats.txt"); }
    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("threatdb", Context.MODE_PRIVATE);
    }

    static synchronized void ensureLoaded(Context c) {
        if (loaded) return;
        HashSet<String> s = new HashSet<>();
        File f = file(c);
        if (f.exists()) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) if (!line.isEmpty()) s.add(line);
            } catch (IOException ignored) {
            }
        }
        domains = s;
        loaded = true;
    }

    static String status(Context c) {
        long at = prefs(c).getLong("updatedAt", 0);
        if (isUpdating()) return "Updating threat database…";
        if (at == 0 || size() == 0) {
            return "Not downloaded yet. Tap UPDATE to download the latest malware and phishing domains.";
        }
        String when = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(at));
        return String.format(Locale.US, "%,d dangerous domains · updated %s\nSources: %s",
                size(), when, prefs(c).getString("sources", "-"));
    }

    /** Downloads every feed. Returns a message for the user. Safe to call from any background thread. */
    static String update(Context c, Progress progress) {
        if (!updating.compareAndSet(false, true)) return "An update is already running";
        try {
            HashSet<String> all = new HashSet<>();
            int ok = 0;
            StringBuilder names = new StringBuilder();
            for (String[] feed : FEEDS) {
                if (all.size() >= MAX_DOMAINS) break;
                if (progress != null) progress.on("Downloading " + feed[0] + "…");
                try {
                    download(feed[1], all);
                    ok++;
                    if (names.length() > 0) names.append(", ");
                    names.append(feed[0]);
                } catch (Exception ignored) {
                    // one feed failing should not stop the others
                }
            }
            if (ok == 0 || all.isEmpty()) return "Update failed. Check your internet connection and try again.";

            File f = file(c);
            File tmp = new File(f.getPath() + ".tmp");
            try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
                for (String d : all) { w.write(d); w.write('\n'); }
            } catch (IOException e) {
                return "Could not save the threat database: " + e.getMessage();
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(f);
            synchronized (ThreatDb.class) {
                domains = all;
                loaded = true;
            }
            prefs(c).edit().putLong("updatedAt", System.currentTimeMillis()).putString("sources", names.toString()).apply();
            return String.format(Locale.US, "Threat database updated: %,d dangerous domains from %d source%s",
                    all.size(), ok, ok == 1 ? "" : "s");
        } finally {
            updating.set(false);
        }
    }

    private static void download(String url, Set<String> out) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "SafeSphere/1.0 (Android)");
        try {
            int code = con.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null && out.size() < MAX_DOMAINS) {
                    String d = parseLine(line);
                    if (d != null) out.add(d);
                }
            }
        } finally {
            con.disconnect();
        }
    }

    /** Accepts hosts-file lines ("0.0.0.0 bad.com"), plain domains and simple adblock lines. */
    static String parseLine(String line) {
        int hash = line.indexOf('#');
        if (hash >= 0) line = line.substring(0, hash);
        line = line.trim();
        if (line.isEmpty() || line.startsWith("!")) return null;
        String[] parts = line.split("\\s+");
        String d = parts[0];
        if (parts.length >= 2 && (d.equals("0.0.0.0") || d.equals("127.0.0.1") || d.equals("::") || d.equals("::1"))) {
            d = parts[1];
        }
        d = d.toLowerCase(Locale.ROOT);
        if (d.startsWith("||")) d = d.substring(2);
        if (d.endsWith("^")) d = d.substring(0, d.length() - 1);
        if (d.startsWith("*.")) d = d.substring(2);
        if (d.indexOf('.') < 0 || d.equals("localhost") || d.length() > 253) return null;
        for (int i = 0; i < d.length(); i++) {
            char ch = d.charAt(i);
            boolean okChar = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '-' || ch == '_';
            if (!okChar) return null;
        }
        char last = d.charAt(d.length() - 1);
        if (last >= '0' && last <= '9') return null; // bare IP address, not a domain
        return d;
    }
}
