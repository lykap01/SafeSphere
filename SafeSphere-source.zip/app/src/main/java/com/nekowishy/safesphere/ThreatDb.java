package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Downloads public malware / phishing domain feeds and keeps them on the phone.
 *
 * Build 16: each feed is stored in its own file. If a feed fails to download, its last good copy is
 * kept (Build 15 rewrote one merged file, so a failed feed's domains were silently dropped).
 * Every domain remembers which feed(s) listed it, so a match can be explained.
 */
final class ThreatDb {

    interface Progress { void on(String message); }

    static final String[][] FEEDS = {
            {"URLhaus malware domains", "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-domains.txt"},
            {"Phishing Army", "https://phishing.army/download/phishing_army_blocklist.txt"},
            {"HaGeZi Threat Intelligence", "https://cdn.jsdelivr.net/gh/hagezi/dns-blocklists@latest/wildcard/tif.mini-onlydomains.txt"},
    };
    private static final byte LEGACY = (byte) 0x80; // Build 15 merged file, until every feed has its own copy
    private static final int MAX_DOMAINS = 250_000;
    static final long DAY = 24L * 60 * 60 * 1000;

    /** Domain → bit mask of the feeds that list it. */
    private static volatile Map<String, Byte> domains = Collections.emptyMap();
    private static boolean loaded;
    private static final AtomicBoolean updating = new AtomicBoolean();

    private ThreatDb() {}

    static boolean contains(String d) { return domains.containsKey(d); }
    static int size() { return domains.size(); }
    static boolean isUpdating() { return updating.get(); }
    static boolean isLoaded() { return loaded; }

    /** Names of the feeds that list this domain or one of its parent domains, or null. */
    static String sourcesFor(String host) {
        int mask = 0;
        Map<String, Byte> m = domains;
        for (String s = host; s != null; s = parent(s)) {
            Byte b = m.get(s);
            if (b != null) mask |= b & 0xFF;
        }
        if (mask == 0) return null;
        List<String> names = new ArrayList<>();
        for (int i = 0; i < FEEDS.length; i++) if ((mask & (1 << i)) != 0) names.add(FEEDS[i][0]);
        if ((mask & (LEGACY & 0xFF)) != 0 && names.isEmpty()) names.add("a previously downloaded threat feed");
        return String.join(", ", names);
    }

    private static String parent(String s) {
        int i = s.indexOf('.');
        return i < 0 ? null : s.substring(i + 1);
    }

    // ------------------------------------------------------------------ status

    static final class FeedStatus {
        String name;
        long okAt;        // last successful download (0 = never)
        long triedAt;     // last attempt
        int count;        // domains in the saved copy
        String error;     // last error, cleared on success
    }

    static List<FeedStatus> feedStatus(Context c) {
        SharedPreferences p = prefs(c);
        List<FeedStatus> out = new ArrayList<>();
        for (int i = 0; i < FEEDS.length; i++) {
            FeedStatus s = new FeedStatus();
            s.name = FEEDS[i][0];
            s.okAt = p.getLong("f" + i + "_ok", 0);
            s.triedAt = p.getLong("f" + i + "_tried", 0);
            s.count = p.getInt("f" + i + "_count", 0);
            s.error = p.getString("f" + i + "_err", null);
            out.add(s);
        }
        return out;
    }

    /** How long ago any feed was last downloaded successfully (Long.MAX_VALUE if never). */
    static long ageMillis(Context c) {
        long at = prefs(c).getLong("updatedAt", 0);
        return at == 0 ? Long.MAX_VALUE : System.currentTimeMillis() - at;
    }

    static final int FRESH = 0, AGING = 1, STALE = 2, NEVER = 3;

    static int freshness(Context c) {
        if (size() == 0 && prefs(c).getLong("updatedAt", 0) == 0) return NEVER;
        long age = ageMillis(c);
        return age < DAY * 2 ? FRESH : age < DAY * 7 ? AGING : STALE;
    }

    static String freshnessLabel(int f) {
        switch (f) {
            case FRESH: return "Up to date";
            case AGING: return "A few days old";
            case STALE: return "Out of date";
            default: return "Not downloaded";
        }
    }

    private static File feedFile(Context c, int i) { return new File(c.getFilesDir(), "threats_" + i + ".txt"); }
    private static File legacyFile(Context c) { return new File(c.getFilesDir(), "threats.txt"); }
    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("threatdb", Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------ loading

    static synchronized void ensureLoaded(Context c) {
        if (loaded) return;
        reload(c);
    }

    private static synchronized void reload(Context c) {
        HashMap<String, Byte> map = new HashMap<>(1 << 16);
        boolean allFeedsSaved = true;
        for (int i = 0; i < FEEDS.length; i++) {
            File f = feedFile(c, i);
            if (f.exists()) readInto(f, (byte) (1 << i), map);
            else allFeedsSaved = false;
        }
        File legacy = legacyFile(c);
        if (legacy.exists()) {
            if (allFeedsSaved) {
                //noinspection ResultOfMethodCallIgnored
                legacy.delete(); // every feed now has its own fresh copy
            } else {
                readInto(legacy, LEGACY, map); // keep Build 15 data until it has been replaced
            }
        }
        domains = map;
        loaded = true;
    }

    private static void readInto(File f, byte bit, Map<String, Byte> map) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isEmpty()) continue;
                Byte old = map.get(line);
                if (old == null && map.size() >= MAX_DOMAINS) continue;
                map.put(line, (byte) ((old == null ? 0 : old) | bit));
            }
        } catch (IOException ignored) {
            // a damaged file only loses that feed until the next update
        }
    }

    // ------------------------------------------------------------------ updating

    /** One-line summary for the dashboard. */
    static String status(Context c) {
        if (isUpdating()) return "Updating threat lists…";
        long at = prefs(c).getLong("updatedAt", 0);
        if (at == 0 && size() == 0) return "Not downloaded yet";
        String when = android.text.format.DateUtils.getRelativeTimeSpanString(at, System.currentTimeMillis(),
                android.text.format.DateUtils.MINUTE_IN_MILLIS).toString();
        return String.format(Locale.US, "%,d domains · updated %s", size(), at == 0 ? "earlier" : when);
    }

    /** Downloads every feed. Returns a message for the user. Safe to call from any background thread. */
    static String update(Context c, Progress progress) {
        if (!updating.compareAndSet(false, true)) return "An update is already running";
        try {
            SharedPreferences p = prefs(c);
            int ok = 0, failed = 0;
            for (int i = 0; i < FEEDS.length; i++) {
                String[] feed = FEEDS[i];
                if (progress != null) progress.on("Downloading " + feed[0] + "…");
                long now = System.currentTimeMillis();
                Set<String> got = new HashSet<>();
                try {
                    download(feed[1], got);
                    if (got.isEmpty()) throw new IOException("the list was empty");
                    writeAtomically(feedFile(c, i), got);
                    p.edit().putLong("f" + i + "_ok", now).putLong("f" + i + "_tried", now)
                            .putInt("f" + i + "_count", got.size()).remove("f" + i + "_err").apply();
                    ok++;
                } catch (Exception e) {
                    failed++;
                    String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                    p.edit().putLong("f" + i + "_tried", now).putString("f" + i + "_err", msg).apply();
                    // the previous copy of this feed (if any) stays in place
                }
            }
            if (ok > 0) p.edit().putLong("updatedAt", System.currentTimeMillis()).apply();
            reload(c);
            if (ok == 0) {
                return size() > 0
                        ? "Update failed. Your last downloaded threat lists are still in use."
                        : "Update failed. Check your internet connection and try again.";
            }
            return String.format(Locale.US, "Threat lists updated: %,d domains%s", size(),
                    failed > 0 ? " (" + failed + " source" + (failed == 1 ? "" : "s") + " failed; previous copy kept)" : "");
        } finally {
            updating.set(false);
        }
    }

    private static void writeAtomically(File f, Set<String> all) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
            for (String d : all) { w.write(d); w.write('\n'); }
        }
        if (!tmp.renameTo(f)) {
            //noinspection ResultOfMethodCallIgnored
            f.delete();
            if (!tmp.renameTo(f)) throw new IOException("could not save");
        }
    }

    private static void download(String url, Set<String> out) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "SafeSphere/1.16 (Android)");
        try {
            int code = con.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null && out.size() < MAX_DOMAINS) {
                    String d = parseLine(line);
                    if (d != null) out.add(d);
                }
            }
        } finally {
            con.disconnect();
        }
    }

    /** Accepts hosts-file lines ("0.0.0.0 bad.com"), plain domains and simple adblock lines. */
    static String parseLine(String line) {
        int hash = line.indexOf('#');
        if (hash >= 0) line = line.substring(0, hash);
        line = line.trim();
        if (line.isEmpty() || line.startsWith("!")) return null;
        String[] parts = line.split("\\s+");
        String d = parts[0];
        if (parts.length >= 2 && (d.equals("0.0.0.0") || d.equals("127.0.0.1") || d.equals("::") || d.equals("::1"))) {
            d = parts[1];
        }
        d = d.toLowerCase(Locale.ROOT);
        if (d.startsWith("||")) d = d.substring(2);
        if (d.endsWith("^")) d = d.substring(0, d.length() - 1);
        if (d.startsWith("*.")) d = d.substring(2);
        if (d.indexOf('.') < 0 || d.equals("localhost") || d.length() > 253) return null;
        for (int i = 0; i < d.length(); i++) {
            char ch = d.charAt(i);
            boolean okChar = (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '-' || ch == '_';
            if (!okChar) return null;
        }
        char last = d.charAt(d.length() - 1);
        if (last >= '0' && last <= '9') return null; // bare IP address, not a domain
        return d;
    }
}
