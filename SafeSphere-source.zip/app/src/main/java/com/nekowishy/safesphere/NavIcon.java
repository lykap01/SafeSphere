package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Line icons drawn in code (shield, search, rules, history, device, menu), sharp at any size. */
final class NavIcon extends View {

    static final int SHIELD = 0, SEARCH = 1, RULES = 2, HISTORY = 3, DEVICE = 4, MENU = 5;

    private final int type;
    private int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    NavIcon(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    void setColor(int c) {
        if (c == color) return;
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float ox = (getWidth() - s) / 2f, oy = (getHeight() - s) / 2f;
        p.setColor(color);
        p.setStrokeWidth(s * 0.085f);
        c.save();
        c.translate(ox, oy);
        float u = s / 24f; // draw on a 24-unit grid
        switch (type) {
            case SHIELD:
                path.reset();
                path.moveTo(12 * u, 2.5f * u);
                path.lineTo(20 * u, 5.5f * u);
                path.lineTo(20 * u, 11 * u);
                path.cubicTo(20 * u, 16 * u, 16.6f * u, 19.8f * u, 12 * u, 21.5f * u);
                path.cubicTo(7.4f * u, 19.8f * u, 4 * u, 16 * u, 4 * u, 11 * u);
                path.lineTo(4 * u, 5.5f * u);
                path.close();
                c.drawPath(path, p);
                path.reset();
                path.moveTo(8.6f * u, 11.8f * u);
                path.lineTo(11 * u, 14.2f * u);
                path.lineTo(15.6f * u, 9.4f * u);
                c.drawPath(path, p);
                break;
            case SEARCH:
                c.drawCircle(10.5f * u, 10.5f * u, 6.5f * u, p);
                c.drawLine(15.4f * u, 15.4f * u, 20.5f * u, 20.5f * u, p);
                break;
            case RULES:
                for (int i = 0; i < 3; i++) {
                    float y = (6 + i * 6) * u;
                    c.drawPoint(4.5f * u, y, p);
                    c.drawLine(9 * u, y, 20 * u, y, p);
                }
                break;
            case HISTORY:
                c.drawCircle(12 * u, 12 * u, 8.5f * u, p);
                c.drawLine(12 * u, 7.5f * u, 12 * u, 12 * u, p);
                c.drawLine(12 * u, 12 * u, 15.5f * u, 14 * u, p);
                break;
            case DEVICE:
                c.drawRoundRect(6 * u, 2.5f * u, 18 * u, 21.5f * u, 3 * u, 3 * u, p);
                c.drawLine(10.5f * u, 18 * u, 13.5f * u, 18 * u, p);
                break;
            default: // MENU
                c.drawLine(5 * u, 7 * u, 19 * u, 7 * u, p);
                c.drawLine(5 * u, 12 * u, 19 * u, 12 * u, p);
                c.drawLine(5 * u, 17 * u, 14 * u, 17 * u, p);
                break;
        }
        c.restore();
    }
}
