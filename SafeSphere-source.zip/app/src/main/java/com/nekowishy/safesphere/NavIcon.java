package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Line icons drawn in code (navigation and actions), sharp at any size and scaled with the layout. */
final class NavIcon extends View {

    static final int SHIELD = 0, SEARCH = 1, RULES = 2, HISTORY = 3, DEVICE = 4, MENU = 5,
            BACK = 6, SEND = 7, SPARKLE = 8, PLUS = 9, REFRESH = 10, LINK = 11, KEY = 12, ALERT = 13, CHAT = 14,
            WALLET = 15, WORK = 16, FLAG = 17, LOCK = 18, MORE = 19, CLOSE = 20;

    private final int type;
    private int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    NavIcon(Context c, int type, int color) {
        super(c);
        this.type = type;
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    void setColor(int c) {
        if (c == color) return;
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float s = Math.min(getWidth(), getHeight());
        float ox = (getWidth() - s) / 2f, oy = (getHeight() - s) / 2f;
        p.setColor(color);
        p.setStrokeWidth(s * 0.075f);
        p.setStyle(type == SPARKLE ? Paint.Style.FILL : Paint.Style.STROKE);
        c.save();
        c.translate(ox, oy);
        float u = s / 24f; // draw on a 24-unit grid
        switch (type) {
            case SHIELD:
                path.reset();
                path.moveTo(12 * u, 2.5f * u);
                path.lineTo(20 * u, 5.5f * u);
                path.lineTo(20 * u, 11 * u);
                path.cubicTo(20 * u, 16 * u, 16.6f * u, 19.8f * u, 12 * u, 21.5f * u);
                path.cubicTo(7.4f * u, 19.8f * u, 4 * u, 16 * u, 4 * u, 11 * u);
                path.lineTo(4 * u, 5.5f * u);
                path.close();
                c.drawPath(path, p);
                path.reset();
                path.moveTo(8.6f * u, 11.8f * u);
                path.lineTo(11 * u, 14.2f * u);
                path.lineTo(15.6f * u, 9.4f * u);
                c.drawPath(path, p);
                break;
            case SEARCH:
                c.drawCircle(10.5f * u, 10.5f * u, 6.5f * u, p);
                c.drawLine(15.4f * u, 15.4f * u, 20.5f * u, 20.5f * u, p);
                break;
            case RULES:
                for (int i = 0; i < 3; i++) {
                    float y = (6 + i * 6) * u;
                    c.drawPoint(4.5f * u, y, p);
                    c.drawLine(9 * u, y, 20 * u, y, p);
                }
                break;
            case HISTORY:
                c.drawCircle(12 * u, 12 * u, 8.5f * u, p);
                c.drawLine(12 * u, 7.5f * u, 12 * u, 12 * u, p);
                c.drawLine(12 * u, 12 * u, 15.5f * u, 14 * u, p);
                break;
            case DEVICE:
                c.drawRoundRect(6 * u, 2.5f * u, 18 * u, 21.5f * u, 3 * u, 3 * u, p);
                c.drawLine(10.5f * u, 18 * u, 13.5f * u, 18 * u, p);
                break;
            case BACK:
                path.reset();
                path.moveTo(14.5f * u, 5.5f * u);
                path.lineTo(8 * u, 12 * u);
                path.lineTo(14.5f * u, 18.5f * u);
                c.drawPath(path, p);
                break;
            case SEND:
                c.drawLine(12 * u, 19 * u, 12 * u, 5.5f * u, p);
                path.reset();
                path.moveTo(6.5f * u, 11 * u);
                path.lineTo(12 * u, 5.5f * u);
                path.lineTo(17.5f * u, 11 * u);
                c.drawPath(path, p);
                break;
            case SPARKLE:
                sparkle(c, 11 * u, 13 * u, 8 * u);
                sparkle(c, 18.5f * u, 5.5f * u, 3.2f * u);
                break;
            case PLUS:
                c.drawLine(12 * u, 5.5f * u, 12 * u, 18.5f * u, p);
                c.drawLine(5.5f * u, 12 * u, 18.5f * u, 12 * u, p);
                break;
            case REFRESH:
                c.drawArc(5 * u, 5 * u, 19 * u, 19 * u, -60, 300, false, p);
                path.reset();
                path.moveTo(15.5f * u, 2.8f * u);
                path.lineTo(16.6f * u, 6.4f * u);
                path.lineTo(13 * u, 7.4f * u);
                c.drawPath(path, p);
                break;
            case LINK:
                c.save();
                c.rotate(-45, 12 * u, 12 * u);
                c.drawRoundRect(3.5f * u, 9 * u, 12.5f * u, 15 * u, 3 * u, 3 * u, p);
                c.drawRoundRect(11.5f * u, 9 * u, 20.5f * u, 15 * u, 3 * u, 3 * u, p);
                c.restore();
                break;
            case KEY:
                c.drawCircle(8 * u, 12 * u, 4 * u, p);
                c.drawLine(12 * u, 12 * u, 20.5f * u, 12 * u, p);
                c.drawLine(17.5f * u, 12 * u, 17.5f * u, 15.5f * u, p);
                c.drawLine(20.5f * u, 12 * u, 20.5f * u, 15 * u, p);
                break;
            case ALERT:
                path.reset();
                path.moveTo(12 * u, 3.5f * u);
                path.lineTo(21 * u, 19.5f * u);
                path.lineTo(3 * u, 19.5f * u);
                path.close();
                c.drawPath(path, p);
                c.drawLine(12 * u, 9.5f * u, 12 * u, 13.5f * u, p);
                c.drawPoint(12 * u, 16.6f * u, p);
                break;
            case CHAT:
                path.reset();
                path.moveTo(5 * u, 5 * u);
                path.lineTo(19 * u, 5 * u);
                path.lineTo(19 * u, 16 * u);
                path.lineTo(10 * u, 16 * u);
                path.lineTo(6 * u, 19.5f * u);
                path.lineTo(6 * u, 16 * u);
                path.lineTo(5 * u, 16 * u);
                path.close();
                c.drawPath(path, p);
                break;
            case WALLET:
                c.drawRoundRect(3.5f * u, 6 * u, 20.5f * u, 19 * u, 3 * u, 3 * u, p);
                c.drawLine(6 * u, 6 * u, 16 * u, 3.5f * u, p);
                c.drawPoint(16.5f * u, 12.5f * u, p);
                break;
            case WORK:
                c.drawRoundRect(3.5f * u, 7.5f * u, 20.5f * u, 19 * u, 2.5f * u, 2.5f * u, p);
                c.drawRoundRect(9 * u, 4 * u, 15 * u, 7.5f * u, 1.5f * u, 1.5f * u, p);
                c.drawLine(3.5f * u, 12.5f * u, 20.5f * u, 12.5f * u, p);
                break;
            case FLAG:
                c.drawLine(6 * u, 3.5f * u, 6 * u, 20.5f * u, p);
                path.reset();
                path.moveTo(6 * u, 4.5f * u);
                path.lineTo(18.5f * u, 4.5f * u);
                path.lineTo(15.5f * u, 9 * u);
                path.lineTo(18.5f * u, 13.5f * u);
                path.lineTo(6 * u, 13.5f * u);
                c.drawPath(path, p);
                break;
            case LOCK:
                c.drawRoundRect(5 * u, 10.5f * u, 19 * u, 20.5f * u, 2.5f * u, 2.5f * u, p);
                c.drawArc(8 * u, 3.5f * u, 16 * u, 14 * u, 180, 180, false, p);
                c.drawPoint(12 * u, 15.5f * u, p);
                break;
            case MORE: { // vertical three dots (overflow menu)
                Paint.Style old = p.getStyle();
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(12 * u, 5.5f * u, 1.6f * u, p);
                c.drawCircle(12 * u, 12 * u, 1.6f * u, p);
                c.drawCircle(12 * u, 18.5f * u, 1.6f * u, p);
                p.setStyle(old);
                break;
            }
            case CLOSE:
                c.drawLine(6 * u, 6 * u, 18 * u, 18 * u, p);
                c.drawLine(18 * u, 6 * u, 6 * u, 18 * u, p);
                break;
            default: // MENU
                c.drawLine(5 * u, 7 * u, 19 * u, 7 * u, p);
                c.drawLine(5 * u, 12 * u, 19 * u, 12 * u, p);
                c.drawLine(5 * u, 17 * u, 14 * u, 17 * u, p);
                break;
        }
        c.restore();
    }

    /** Four-point star (filled). */
    private void sparkle(Canvas c, float cx, float cy, float r) {
        float k = r * 0.2f;
        path.reset();
        path.moveTo(cx, cy - r);
        path.quadTo(cx + k, cy - k, cx + r, cy);
        path.quadTo(cx + k, cy + k, cx, cy + r);
        path.quadTo(cx - k, cy + k, cx - r, cy);
        path.quadTo(cx - k, cy - k, cx, cy - r);
        path.close();
        c.drawPath(path, p);
    }
}
