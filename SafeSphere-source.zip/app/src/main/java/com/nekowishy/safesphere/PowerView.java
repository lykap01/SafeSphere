package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.view.View;

/** Round glass power button (drawn, so it looks the same on every phone). */
final class PowerView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color = Ui.WHITE;

    PowerView(Context c) {
        super(c);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Ui.alpha(Ui.WHITE, 0x33));
        g.setStroke(Ui.dp(c, 1), Ui.alpha(Ui.WHITE, 0x88));
        setBackground(g);
        setClickable(true);
    }

    void setColor(int c) {
        if (c == color) return;
        color = c;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f, r = Math.min(w, h) * 0.2f;
        p.setColor(color);
        p.setStrokeWidth(Math.min(w, h) * 0.06f);
        canvas.drawArc(cx - r, cy - r, cx + r, cy + r, -60, 300, false, p);
        canvas.drawLine(cx, cy - r * 1.25f, cx, cy - r * 0.2f, p);
    }
}
