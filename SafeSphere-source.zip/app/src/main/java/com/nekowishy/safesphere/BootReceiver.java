package com.nekowishy.safesphere;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

/** Turns protection and App lock back on after the phone restarts or SafeSphere is updated, if they were on before. */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action) && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;
        AppLock.start(context); // App lock comes back after a restart too
        if (!Prefs.protectionWanted(context)) return;
        if (VpnService.prepare(context) != null) return; // VPN permission was taken away; the user must open the app
        try {
            context.startForegroundService(new Intent(context, SafeSphereVpnService.class)
                    .setAction(SafeSphereVpnService.ACTION_START));
        } catch (RuntimeException ignored) {
            // the system refused a background start; protection starts next time the app opens
        }
    }
}
