package com.nekowishy.safesphere;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/**
 * Local DNS-filtering VPN. Only DNS traffic enters the tunnel (a single route to a virtual DNS
 * server), so normal app traffic keeps flowing at full speed. Every domain lookup on the phone is
 * checked against the threat database and the user's rules before it is answered.
 */
public class SafeSphereVpnService extends VpnService implements Runnable {

    static final String ACTION_START = "com.nekowishy.safesphere.START";
    static final String ACTION_STOP = "com.nekowishy.safesphere.STOP";

    private static final String VPN_ADDRESS = "10.111.222.1";
    private static final String DNS_ADDRESS = "10.111.222.2";
    private static final String[] UPSTREAM = {"1.1.1.1", "8.8.8.8", "9.9.9.9"};

    private static volatile boolean running;
    private static volatile String lastError;
    private static volatile long startedAt;
    static volatile String lastBlocked;
    static volatile long lastBlockedAt;

    private ParcelFileDescriptor tun;
    private FileInputStream in;
    private FileOutputStream out;
    private ExecutorService dnsPool;
    private ExecutorService logPool;
    private final Object writeLock = new Object();
    private final Map<String, Long> recentlyLogged = new HashMap<>();

    static boolean isRunning() { return running; }
    static String lastError() { return lastError; }
    static long startedAt() { return startedAt; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            shutdown(null);
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(Alerts.ONGOING_ID, Alerts.ongoing(this));
        if (!running) start();
        return START_STICKY;
    }

    private synchronized void start() {
        Context app = getApplicationContext();
        RuleStore.init(app);
        try {
            Builder b = new Builder();
            b.setSession("SafeSphere");
            b.addAddress(VPN_ADDRESS, 32);
            b.addRoute(DNS_ADDRESS, 32);
            b.addDnsServer(DNS_ADDRESS);
            b.setMtu(1500);
            if (Build.VERSION.SDK_INT >= 29) {
                b.setBlocking(true);
                b.setMetered(false);
            }
            b.setConfigureIntent(PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
            tun = b.establish();
        } catch (Exception e) {
            fail("Could not start protection: " + e.getMessage());
            return;
        }
        if (tun == null) {
            fail("VPN permission is missing. Tap the shield again and press OK.");
            return;
        }
        in = new FileInputStream(tun.getFileDescriptor());
        out = new FileOutputStream(tun.getFileDescriptor());
        dnsPool = Executors.newFixedThreadPool(6);
        logPool = Executors.newSingleThreadExecutor();
        lastError = null;
        startedAt = System.currentTimeMillis();
        running = true;
        new Thread(this, "safesphere-dns").start();

        // Load the threat database; download it automatically the first time.
        new Thread(() -> {
            ThreatDb.ensureLoaded(app);
            if (ThreatDb.size() == 0) {
                try { Thread.sleep(1500); } catch (InterruptedException ignored) { }
                if (running) ThreatDb.update(app, null);
            }
        }, "safesphere-threatdb").start();
    }

    private void fail(String message) {
        shutdown(message);
        stopForeground(true);
        stopSelf();
    }

    private synchronized void shutdown(String error) {
        running = false;
        if (error != null) lastError = error;
        closeQuietly(in);
        closeQuietly(out);
        closeQuietly(tun);
        in = null;
        out = null;
        tun = null;
        if (dnsPool != null) dnsPool.shutdownNow();
        if (logPool != null) logPool.shutdown();
        dnsPool = null;
        logPool = null;
    }

    private static void closeQuietly(Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (IOException ignored) { }
    }

    @Override
    public void run() {
        byte[] buf = new byte[32767];
        try {
            while (running) {
                FileInputStream src = in;
                if (src == null) break;
                int n = src.read(buf);
                if (n < 0) break;
                if (n == 0) { // older Android: non-blocking tunnel
                    Thread.sleep(20);
                    continue;
                }
                handle(Arrays.copyOf(buf, n));
            }
        } catch (Exception e) {
            if (running) lastError = "Protection stopped unexpectedly: " + e.getMessage();
        } finally {
            if (running) {
                shutdown(lastError);
                stopForeground(true);
                stopSelf();
            }
        }
    }

    private void handle(byte[] packet) {
        DnsPacket.Query q = DnsPacket.parse(packet, packet.length);
        if (q == null) return;
        String reason = q.name.isEmpty() ? null : RuleStore.check(q.name);
        if (reason != null) {
            write(DnsPacket.blocked(q));
            onBlocked(q.name, reason);
            return;
        }
        ExecutorService pool = dnsPool;
        if (pool == null) return;
        try {
            pool.execute(() -> forward(q));
        } catch (RejectedExecutionException ignored) {
        }
    }

    private void onBlocked(String domain, String reason) {
        long now = System.currentTimeMillis();
        lastBlocked = domain;
        lastBlockedAt = now;
        synchronized (recentlyLogged) {
            Long last = recentlyLogged.get(domain);
            if (last != null && now - last < 15_000) return; // apps retry; log once
            if (recentlyLogged.size() > 300) recentlyLogged.clear();
            recentlyLogged.put(domain, now);
        }
        ExecutorService pool = logPool;
        if (pool == null) return;
        Context app = getApplicationContext();
        try {
            pool.execute(() -> {
                EventLog.get(app).record(domain, reason, now);
                Alerts.blocked(app, domain, reason);
            });
        } catch (RejectedExecutionException ignored) {
        }
    }

    /** Sends an allowed query to a real DNS server (outside the tunnel) and returns the answer. */
    private void forward(DnsPacket.Query q) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            if (!protect(socket)) return;
            socket.setSoTimeout(3500);
            for (String server : UPSTREAM) {
                if (!running) return;
                try {
                    InetAddress addr = InetAddress.getByName(server);
                    socket.send(new DatagramPacket(q.dns, q.dns.length, addr, 53));
                    byte[] rb = new byte[4096];
                    DatagramPacket reply = new DatagramPacket(rb, rb.length);
                    socket.receive(reply);
                    write(DnsPacket.wrap(q, Arrays.copyOf(rb, reply.getLength())));
                    return;
                } catch (SocketTimeoutException timeout) {
                    // try the next DNS server
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (socket != null) socket.close();
        }
    }

    private void write(byte[] packet) {
        synchronized (writeLock) {
            FileOutputStream o = out;
            if (o == null) return;
            try { o.write(packet); } catch (IOException ignored) { }
        }
    }

    @Override
    public void onRevoke() {
        shutdown("Protection was turned off by Android or by another VPN app.");
        stopForeground(true);
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        shutdown(null);
        super.onDestroy();
    }
}
