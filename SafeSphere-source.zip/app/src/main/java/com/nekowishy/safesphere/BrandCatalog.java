package com.nekowishy.safesphere;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Brand names and their verified official domains, loaded from assets/brands.tsv so the list can be
 * reviewed and extended without touching detection code. See the file header for the format.
 */
final class BrandCatalog {

    static final int MATCH_CONTAINS = 0, MATCH_TOKEN = 1, MATCH_EDGE = 2;

    static final class Key {
        final String word;
        final int mode;
        final boolean typos;
        Key(String word, int mode, boolean typos) { this.word = word; this.mode = mode; this.typos = typos; }
    }

    static final class Brand {
        final String name;
        final List<Key> keys = new ArrayList<>();
        final List<String> official = new ArrayList<>();
        final List<String> ownedTlds = new ArrayList<>();
        boolean countryFamily;
        boolean naturalSpaces; // "Pag-IBIG", "Security Bank": a hyphen inside the name is normal
        String region;
        String source;

        Brand(String name) { this.name = name; }

        /** True when the host belongs to this brand: an official domain, its subdomain, or a country site. */
        boolean isOfficial(String host, String registrable) {
            for (String o : official) if (host.equals(o) || host.endsWith("." + o)) return true;
            String tld = host.substring(host.lastIndexOf('.') + 1);
            if (ownedTlds.contains(tld)) return true;
            if (countryFamily && registrable != null) {
                // brand.<cc>, brand.co.<cc>, brand.com.<cc> for a two-letter country ending
                String[] p = registrable.split("\\.");
                String last = p[p.length - 1];
                if (last.length() == 2) {
                    for (Key k : keys) {
                        String w = k.word;
                        if (p.length == 2 && p[0].equals(w)) return true;
                        if (p.length == 3 && p[0].equals(w) && (p[1].equals("co") || p[1].equals("com"))) return true;
                    }
                }
            }
            return false;
        }
    }

    private static volatile List<Brand> brands = Collections.emptyList();

    private BrandCatalog() {}

    static List<Brand> all() { return brands; }

    static boolean isLoaded() { return !brands.isEmpty(); }

    static synchronized void load(InputStream in) throws IOException {
        if (!brands.isEmpty()) return;
        brands = parse(in);
    }

    static List<Brand> parse(InputStream in) throws IOException {
        List<Brand> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) continue;
                String[] c = line.split("\t", -1);
                if (c.length < 3) continue;
                Brand b = new Brand(c[0].trim());
                b.naturalSpaces = b.name.indexOf(' ') >= 0 || b.name.indexOf('&') >= 0 || b.name.indexOf('-') >= 0;
                for (String k : c[1].split(",")) {
                    k = k.trim().toLowerCase(Locale.ROOT);
                    if (k.isEmpty()) continue;
                    int mode = MATCH_CONTAINS;
                    boolean typos = false;
                    while (!k.isEmpty() && "=^~".indexOf(k.charAt(0)) >= 0) {
                        if (k.charAt(0) == '=') mode = MATCH_TOKEN;
                        else if (k.charAt(0) == '^') mode = MATCH_EDGE;
                        else typos = true;
                        k = k.substring(1);
                    }
                    b.keys.add(new Key(k, mode, typos));
                }
                for (String o : c[2].split(",")) {
                    o = o.trim().toLowerCase(Locale.ROOT);
                    if (o.startsWith("tld:")) b.ownedTlds.add(o.substring(4));
                    else if (!o.isEmpty()) b.official.add(o);
                }
                b.countryFamily = c.length > 3 && c[3].contains("cc");
                b.region = c.length > 4 ? c[4].trim() : "";
                b.source = c.length > 5 ? c[5].trim() : "";
                out.add(b);
            }
        }
        return out;
    }

    /** Test hook / fallback. */
    static synchronized void set(List<Brand> list) { brands = list; }
}
