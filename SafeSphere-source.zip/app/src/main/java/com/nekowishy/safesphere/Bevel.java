package com.nekowishy.safesphere;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Bevel and emboss surfaces drawn in code, so they look identical on every phone:
 * raised cards (bright top-left rim, shaded bottom-right rim), pressed-in fields (the reverse),
 * glowing blue buttons, the luminous hero gradient and the embossed page background.
 */
final class Bevel {

    private Bevel() {}

    static final int RIM_LIGHT = 0xFFFFFFFF;
    static final int RIM_SHADE = 0xFFC3D2EA;

    /** Raised (or pressed-in) rounded surface with a two-tone bevelled rim. */
    static class Surface extends Drawable {
        final float radius, rim;
        final boolean pressed;
        final int top, bottom, rimLight, rimShade, glossColor;
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        Surface(float radius, float rim, boolean pressed, int top, int bottom, int rimLight, int rimShade, int glossColor) {
            this.radius = radius;
            this.rim = rim;
            this.pressed = pressed;
            this.top = top;
            this.bottom = bottom;
            this.rimLight = rimLight;
            this.rimShade = rimShade;
            this.glossColor = glossColor;
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(rim);
            gloss.setStyle(Paint.Style.STROKE);
            gloss.setStrokeWidth(rim * 0.8f);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            r.set(b.left + rim / 2, b.top + rim / 2, b.right - rim / 2, b.bottom - rim / 2);
            fill.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, top, bottom, Shader.TileMode.CLAMP));
            int a = pressed ? rimShade : rimLight, z = pressed ? rimLight : rimShade;
            edge.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, a, z, Shader.TileMode.CLAMP));
            gloss.setShader(new LinearGradient(0, b.top, 0, b.top + b.height() * 0.45f, glossColor, 0x00FFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            float rr = Math.min(radius, r.height() / 2);
            c.drawRoundRect(r, rr, rr, fill);
            c.drawRoundRect(r, rr, rr, edge);
            if (!pressed && glossColor != 0) {
                float in = rim * 1.6f;
                c.drawRoundRect(r.left + in, r.top + in, r.right - in, r.bottom - in, Math.max(0, rr - in), Math.max(0, rr - in), gloss);
            }
        }

        @Override
        public void getOutline(Outline o) {
            Rect b = getBounds();
            o.setRoundRect(b, Math.min(radius, b.height() / 2f));
            o.setAlpha(1f);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** White raised card / pill. */
    static Surface raised(float radius, float rim) {
        return new Surface(radius, rim, false, 0xFFFFFFFF, 0xFFEAF0F9, RIM_LIGHT, RIM_SHADE, 0xCCFFFFFF);
    }

    /** Pressed-in field (text boxes). */
    static Surface pressed(float radius, float rim) {
        return new Surface(radius, rim, true, 0xFFE6EDF7, 0xFFF4F7FC, RIM_LIGHT, 0xFFBACBE4, 0);
    }

    /** Glowing blue button, like the reference Login button. */
    static Surface blue(float radius, float rim) {
        return new Surface(radius, rim, false, 0xFF5C9DFF, 0xFF2355EA, 0xB3FFFFFF, 0x332355EA, 0x66FFFFFF);
    }

    /** A colored glossy tile (used behind the selected nav icon). */
    static Surface tinted(float radius, float rim, int top, int bottom) {
        return new Surface(radius, rim, false, top, bottom, 0x99FFFFFF, 0x22000000, 0x55FFFFFF);
    }

    /** Luminous deep-blue hero: diagonal gradient, two light glows and soft vertical light streaks. */
    static class Hero extends Drawable {
        final float radius;
        final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glowA = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glowB = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint rimP = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path clip = new Path();
        final RectF r = new RectF();

        Hero(float radius, float rim) {
            this.radius = radius;
            rimP.setStyle(Paint.Style.STROKE);
            rimP.setStrokeWidth(rim);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            r.set(b);
            clip.reset();
            clip.addRoundRect(r, radius, radius, Path.Direction.CW);
            base.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{0xFF0A1A55, 0xFF14389C, 0xFF2A64F0}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            float w = b.width(), h = b.height();
            glowA.setShader(new RadialGradient(b.left + w * 0.72f, b.top + h * 0.32f, Math.max(w, h) * 0.6f,
                    0xB04FB3FF, 0x004FB3FF, Shader.TileMode.CLAMP));
            glowB.setShader(new RadialGradient(b.left + w * 0.15f, b.top + h * 0.95f, Math.max(w, h) * 0.55f,
                    0x803A7BFF, 0x003A7BFF, Shader.TileMode.CLAMP));
            rimP.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, 0x99FFFFFF, 0x1AFFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            c.save();
            c.clipPath(clip);
            c.drawRect(r, base);
            c.drawRect(r, glowA);
            c.drawRect(r, glowB);
            // vertical light streaks, like ribbed glass
            int n = 16;
            float sw = r.width() / n;
            for (int i = 0; i < n; i++) {
                int a = 0x0C + (int) (0x16 * (0.5 + 0.5 * Math.sin(i * 1.7)));
                streak.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                        new int[]{0x00FFFFFF, (a << 24) | 0xFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(r.left + i * sw, r.top, r.left + i * sw + sw * 0.45f, r.bottom, streak);
            }
            c.restore();
            float h = rimP.getStrokeWidth() / 2;
            c.drawRoundRect(r.left + h, r.top + h, r.right - h, r.bottom - h, radius, radius, rimP);
        }

        @Override
        public void getOutline(Outline o) {
            o.setRoundRect(getBounds(), radius);
            o.setAlpha(1f);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Page background: soft blue-white gradient with large embossed circles in the corners. */
    static class Page extends Drawable {
        final float rim;
        final Paint bg = new Paint();
        final Paint disc = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);

        Page(float rim) {
            this.rim = rim;
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(rim);
            halo.setStyle(Paint.Style.STROKE);
            halo.setStrokeWidth(rim * 5);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            bg.setShader(new LinearGradient(0, b.top, 0, b.bottom, new int[]{0xFFDCE7F7, 0xFFEEF3FB, 0xFFF6F8FD},
                    new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        }

        private void circle(Canvas c, float cx, float cy, float rad) {
            halo.setColor(0x223A6BFF);
            c.drawCircle(cx, cy, rad + rim * 3, halo);
            disc.setShader(new LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad, 0xFFF7FAFF, 0xFFD9E5F6, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, rad, disc);
            edge.setShader(new LinearGradient(cx - rad, cy - rad, cx + rad, cy + rad, 0xFFFFFFFF, 0xFFAFC4E8, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, rad, edge);
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, bg);
            float w = b.width(), h = b.height();
            circle(c, b.left - w * 0.18f, b.top - w * 0.12f, w * 0.48f);
            circle(c, b.right + w * 0.02f, b.top + h * 0.33f, w * 0.17f);
            circle(c, b.right + w * 0.05f, b.bottom + w * 0.02f, w * 0.42f);
            circle(c, b.left - w * 0.1f, b.bottom - h * 0.02f, w * 0.26f);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
