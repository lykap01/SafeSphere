package com.nekowishy.safesphere;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * SafeSphere's surfaces, drawn in code so they look the same on every phone (Build 15 design,
 * recoloured in Build 16 for the dark navy / periwinkle theme): raised cards with a soft rim,
 * pressed-in fields, glowing periwinkle buttons, the luminous hero card and the page background.
 */
final class Bevel {

    private Bevel() {}

    /** Raised (or pressed-in) rounded surface with a two-tone rim and a faint top gloss. */
    static class Surface extends Drawable {
        final float radius, rim;
        final boolean pressed;
        final int top, bottom, rimLight, rimShade, glossColor;
        final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        Surface(float radius, float rim, boolean pressed, int top, int bottom, int rimLight, int rimShade, int glossColor) {
            this.radius = radius;
            this.rim = rim;
            this.pressed = pressed;
            this.top = top;
            this.bottom = bottom;
            this.rimLight = rimLight;
            this.rimShade = rimShade;
            this.glossColor = glossColor;
            edge.setStyle(Paint.Style.STROKE);
            edge.setStrokeWidth(rim);
            gloss.setStyle(Paint.Style.STROKE);
            gloss.setStrokeWidth(rim * 0.8f);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            r.set(b.left + rim / 2, b.top + rim / 2, b.right - rim / 2, b.bottom - rim / 2);
            fill.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, top, bottom, Shader.TileMode.CLAMP));
            int a = pressed ? rimShade : rimLight, z = pressed ? rimLight : rimShade;
            edge.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, a, z, Shader.TileMode.CLAMP));
            gloss.setShader(new LinearGradient(0, b.top, 0, b.top + b.height() * 0.45f, glossColor, glossColor & 0x00FFFFFF,
                    Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            float rr = Math.min(radius, r.height() / 2);
            c.drawRoundRect(r, rr, rr, fill);
            c.drawRoundRect(r, rr, rr, edge);
            if (!pressed && glossColor != 0) {
                float in = rim * 1.6f;
                c.drawRoundRect(r.left + in, r.top + in, r.right - in, r.bottom - in, Math.max(0, rr - in), Math.max(0, rr - in), gloss);
            }
        }

        @Override
        public void getOutline(Outline o) {
            Rect b = getBounds();
            o.setRoundRect(b, Math.min(radius, b.height() / 2f));
            o.setAlpha(1f);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Dark raised card / pill. */
    static Surface raised(float radius, float rim) {
        return new Surface(radius, rim, false, 0xFF1A2249, 0xFF111839, 0x40FFFFFF, 0x66000010, 0x18FFFFFF);
    }

    /** Pressed-in field (text boxes). */
    static Surface pressed(float radius, float rim) {
        return new Surface(radius, rim, true, 0xFF0A0F2B, 0xFF121A3D, 0x30FFFFFF, 0x80000010, 0);
    }

    /** Glowing periwinkle button for the main action (white text stays above 4.5:1). */
    static Surface blue(float radius, float rim) {
        return new Surface(radius, rim, false, 0xFF7270F7, 0xFF4B47DC, 0x99FFFFFF, 0x334B47DC, 0x40FFFFFF);
    }

    /** A coloured glossy tile (behind the selected navigation icon). */
    static Surface tinted(float radius, float rim, int top, int bottom) {
        return new Surface(radius, rim, false, top, bottom, 0x55FFFFFF, 0x22000000, 0x30FFFFFF);
    }

    /** Luminous indigo hero card: diagonal gradient, two soft glows, ribbed-glass streaks and a light wave. */
    static class Hero extends Drawable {
        final float radius;
        final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glowA = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint glowB = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint rimP = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path clip = new Path();
        final Path wavePath = new Path();
        final RectF r = new RectF();

        Hero(float radius, float rim) {
            this.radius = radius;
            rimP.setStyle(Paint.Style.STROKE);
            rimP.setStrokeWidth(rim);
            wave.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            r.set(b);
            clip.reset();
            clip.addRoundRect(r, radius, radius, Path.Direction.CW);
            base.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{0xFF141A4E, 0xFF2C2A93, 0xFF5B50E6}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            float w = b.width(), h = b.height();
            glowA.setShader(new RadialGradient(b.left + w * 0.78f, b.top + h * 0.28f, Math.max(w, h) * 0.6f,
                    0x998F8BFF, 0x008F8BFF, Shader.TileMode.CLAMP));
            glowB.setShader(new RadialGradient(b.left + w * 0.12f, b.top + h * 1.0f, Math.max(w, h) * 0.55f,
                    0x663B6BFF, 0x003B6BFF, Shader.TileMode.CLAMP));
            wavePath.reset();
            wavePath.moveTo(b.left, b.bottom - h * 0.18f);
            wavePath.cubicTo(b.left + w * 0.3f, b.bottom - h * 0.42f, b.left + w * 0.62f, b.bottom - h * 0.02f, b.right, b.bottom - h * 0.36f);
            wavePath.lineTo(b.right, b.bottom);
            wavePath.lineTo(b.left, b.bottom);
            wavePath.close();
            wave.setShader(new LinearGradient(0, b.bottom - h * 0.42f, 0, b.bottom, 0x40B9B6FF, 0x00B9B6FF, Shader.TileMode.CLAMP));
            rimP.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom, 0x80FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            c.save();
            c.clipPath(clip);
            c.drawRect(r, base);
            c.drawRect(r, glowA);
            c.drawRect(r, glowB);
            int n = 16;
            float sw = r.width() / n;
            for (int i = 0; i < n; i++) {
                int a = 0x08 + (int) (0x10 * (0.5 + 0.5 * Math.sin(i * 1.7)));
                streak.setShader(new LinearGradient(0, r.top, 0, r.bottom,
                        new int[]{0x00FFFFFF, (a << 24) | 0xFFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(r.left + i * sw, r.top, r.left + i * sw + sw * 0.45f, r.bottom, streak);
            }
            c.drawPath(wavePath, wave);
            c.restore();
            float h = rimP.getStrokeWidth() / 2;
            c.drawRoundRect(r.left + h, r.top + h, r.right - h, r.bottom - h, radius, radius, rimP);
        }

        @Override
        public void getOutline(Outline o) {
            o.setRoundRect(getBounds(), radius);
            o.setAlpha(1f);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Page background: deep navy with a softly lit planet edge top-left and light waves top-right. */
    static class Page extends Drawable {
        final float rim;
        final Paint bg = new Paint();
        final Paint planet = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint planetRim = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Path w1 = new Path(), w2 = new Path();
        float cx, cy, pr;

        Page(float rim) {
            this.rim = rim;
            planetRim.setStyle(Paint.Style.STROKE);
            planetRim.setStrokeWidth(rim);
            wave.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float w = b.width(), h = b.height();
            bg.setShader(new LinearGradient(0, b.top, 0, b.bottom, new int[]{0xFF0D1333, 0xFF0A0F28, 0xFF070B1E},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            cx = b.left - w * 0.28f;
            cy = b.top + h * 0.10f;
            pr = w * 0.62f;
            planet.setShader(new RadialGradient(cx + pr * 0.35f, cy - pr * 0.2f, pr * 1.2f, 0xFF262E66, 0xFF0B1030, Shader.TileMode.CLAMP));
            planetRim.setShader(new LinearGradient(cx, cy - pr, cx + pr, cy + pr, 0x80A5A3FF, 0x00A5A3FF, Shader.TileMode.CLAMP));
            halo.setShader(new RadialGradient(cx, cy, pr * 1.35f, new int[]{0x00000000, 0x22726FFF, 0x00726FFF},
                    new float[]{0.72f, 0.76f, 1f}, Shader.TileMode.CLAMP));
            w1.reset();
            w1.moveTo(b.right - w * 0.55f, b.top);
            w1.cubicTo(b.right - w * 0.35f, b.top + h * 0.10f, b.right - w * 0.30f, b.top + h * 0.03f, b.right, b.top + h * 0.16f);
            w1.lineTo(b.right, b.top);
            w1.close();
            w2.reset();
            w2.moveTo(b.right - w * 0.40f, b.top);
            w2.cubicTo(b.right - w * 0.22f, b.top + h * 0.06f, b.right - w * 0.15f, b.top + h * 0.01f, b.right, b.top + h * 0.09f);
            w2.lineTo(b.right, b.top);
            w2.close();
            wave.setShader(new LinearGradient(b.right - w * 0.5f, b.top, b.right, b.top + h * 0.16f, 0x105B57F0, 0x407A76FF,
                    Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            c.drawRect(b, bg);
            c.drawCircle(cx, cy, pr * 1.35f, halo);
            c.drawCircle(cx, cy, pr, planet);
            c.drawCircle(cx, cy, pr, planetRim);
            c.drawPath(w1, wave);
            c.drawPath(w2, wave);
        }

        @Override public void setAlpha(int alpha) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
