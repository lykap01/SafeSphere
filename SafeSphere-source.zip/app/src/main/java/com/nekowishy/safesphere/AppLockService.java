package com.nekowishy.safesphere;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.HashMap;
import java.util.Map;

/**
 * Watches which app comes to the front and covers locked apps with SafeSphere's lock screen.
 * Checks about twice a second while the screen is on; sleeps while the screen is off.
 */
public class AppLockService extends Service {

    static final int NOTIFY_ID = 60;
    private static final String CHANNEL = "app_lock";
    private static final long POLL_MS = 450;
    private static final long UNLOCK_MS = 10 * 60_000L; // an app unlocked with the PIN stays open for 10 minutes

    /** Apps unlocked with the PIN, and until when. Cleared when the screen turns off. */
    private static final Map<String, Long> unlockedUntil = new HashMap<>();
    private static volatile boolean running;

    private HandlerThread thread;
    private Handler handler;
    private UsageStatsManager usage;
    private PowerManager power;
    private long lastQuery;
    private String lastShownFor;
    private long lastShownAt;

    static boolean isRunning() { return running; }

    /** Called by the lock screen after the right PIN. */
    static synchronized void unlock(String pkg) {
        unlockedUntil.put(pkg, System.currentTimeMillis() + UNLOCK_MS);
    }

    private static synchronized boolean isUnlocked(String pkg) {
        Long until = unlockedUntil.get(pkg);
        return until != null && until > System.currentTimeMillis();
    }

    private static synchronized void relockAll() { unlockedUntil.clear(); }

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            relockAll();
        }
    };

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            try {
                check();
            } catch (RuntimeException ignored) {
                // keep watching
            }
            handler.postDelayed(this, POLL_MS);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        usage = getSystemService(UsageStatsManager.class);
        power = getSystemService(PowerManager.class);
        startForeground(NOTIFY_ID, notification());
        registerReceiver(screenOff, new IntentFilter(Intent.ACTION_SCREEN_OFF));
        thread = new HandlerThread("SafeSphereAppLock");
        thread.start();
        handler = new Handler(thread.getLooper());
        lastQuery = System.currentTimeMillis() - 5000;
        running = true;
        handler.post(poll);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!AppLock.enabled(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            unregisterReceiver(screenOff);
        } catch (RuntimeException ignored) {
        }
        if (handler != null) handler.removeCallbacksAndMessages(null);
        if (thread != null) thread.quitSafely();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void check() {
        if (power != null && !power.isInteractive()) {
            lastQuery = System.currentTimeMillis();
            return; // screen off: nothing to watch
        }
        if (usage == null || !AppLock.hasUsageAccess(this)) return;
        long now = System.currentTimeMillis();
        UsageEvents events = usage.queryEvents(lastQuery - 1000, now);
        lastQuery = now;
        String front = null;
        UsageEvents.Event e = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(e);
            if (e.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) front = e.getPackageName();
        }
        if (front == null || front.equals(getPackageName())) return;
        if (!AppLock.isLocked(this, front) || isUnlocked(front) || !Prefs.hasPin(this)) return;
        // Don't relaunch the lock screen again and again for the same app within a moment
        if (front.equals(lastShownFor) && now - lastShownAt < 700) return;
        lastShownFor = front;
        lastShownAt = now;
        startActivity(new Intent(this, LockActivity.class)
                .putExtra(LockActivity.EXTRA_PKG, front)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                        | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS));
    }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "App lock", NotificationManager.IMPORTANCE_MIN);
            ch.setDescription("Shows that App lock is running");
            nm.createNotificationChannel(ch);
        }
        PendingIntent open = PendingIntent.getActivity(this, 7,
                new Intent(this, MainActivity.class).putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_APPLOCK),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("App lock is on")
                .setContentText("Locked apps need your PIN")
                .setColor(Ui.CYAN)
                .setOngoing(true)
                .setContentIntent(open)
                .build();
    }
}
