package com.nekowishy.safesphere;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen lock shown over an app that a parent has locked. */
public class LockActivity extends Activity {

    static final String EXTRA_PKG = "pkg";
    private static int wrongTries;
    private static long lockedOutUntil;

    private String pkg;
    private LinearLayout pinBox;
    private EditText pin;
    private TextView pinMsg;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        build(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        build(intent);
    }

    private void build(Intent intent) {
        pkg = intent == null ? null : intent.getStringExtra(EXTRA_PKG);
        if (pkg == null) {
            finish();
            return;
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Bevel.Page(Ui.dp(this, 1.5f)));

        LinearLayout col = Ui.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(this, 24);
        col.setPadding(p, Ui.dp(this, 64), p, p);

        FrameLayout iconBox = new FrameLayout(this);
        iconBox.setBackground(Bevel.raised(Ui.dp(this, 24), Ui.dp(this, 1.2f)));
        Ui.shadow(iconBox, 8, Ui.SHADOW);
        ImageView icon = new ImageView(this);
        try {
            PackageManager pm = getPackageManager();
            Drawable d = pm.getApplicationIcon(pkg);
            icon.setImageDrawable(d);
        } catch (Exception ignored) {
        }
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        int is = Ui.dp(this, 56);
        iconBox.addView(icon, new FrameLayout.LayoutParams(is, is, Gravity.CENTER));
        int box = Ui.dp(this, 88);
        col.addView(iconBox, new LinearLayout.LayoutParams(box, box));

        TextView title = Ui.pageTitle(this, AppLock.label(this, pkg) + " is locked");
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(this, 20), 0, 0);
        col.addView(title);
        TextView sub = Ui.support(this, "Ask a parent to unlock it.");
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 24));
        col.addView(sub);

        col.addView(Ui.primary(this, "Go to home screen", v -> goHome()), Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        col.addView(Ui.secondary(this, "Parent unlock", v -> {
            pinBox.setVisibility(View.VISIBLE);
            pin.requestFocus();
        }), Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));

        pinBox = Ui.vbox(this);
        pinBox.setVisibility(View.GONE);
        pinBox.setPadding(0, Ui.dp(this, 16), 0, 0);
        pin = new EditText(this);
        pin.setHint("PIN");
        pin.setSingleLine(true);
        pin.setGravity(Gravity.CENTER);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        Ui.field(pin);
        pin.setContentDescription("Parent PIN");
        pinBox.addView(pin);
        pinMsg = Ui.support(this, "Unlocks this app for 10 minutes");
        pinMsg.setGravity(Gravity.CENTER);
        pinMsg.setPadding(0, Ui.dp(this, 8), 0, 0);
        pinBox.addView(pinMsg);
        pinBox.addView(Ui.primary(this, "Unlock", v -> tryUnlock()), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(pinBox, Ui.params(Ui.MATCH, Ui.WRAP, 0f));

        TextView brand = Ui.text(this, "Protected by SafeSphere", Ui.LABEL, Ui.TEXT2, false);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, Ui.dp(this, 32), 0, 0);
        col.addView(brand);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
    }

    private void tryUnlock() {
        long now = SystemClock.elapsedRealtime();
        if (now < lockedOutUntil) {
            pinMsg.setText("Too many wrong tries. Wait " + ((lockedOutUntil - now) / 1000 + 1) + " seconds.");
            pinMsg.setTextColor(Ui.DANGER);
            Ui.shake(pin);
            return;
        }
        if (Prefs.checkPin(this, pin.getText().toString())) {
            wrongTries = 0;
            AppLockService.unlock(pkg);
            finish();
            overridePendingTransition(0, 0);
            return;
        }
        wrongTries++;
        pin.setText("");
        Ui.shake(pin);
        if (wrongTries >= 5) {
            wrongTries = 0;
            lockedOutUntil = now + 30_000;
            pinMsg.setText("Too many wrong tries. Wait 30 seconds.");
        } else {
            pinMsg.setText("Wrong PIN");
        }
        pinMsg.setTextColor(Ui.DANGER);
    }

    private void goHome() {
        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        goHome(); // back never returns to the locked app
    }
}
