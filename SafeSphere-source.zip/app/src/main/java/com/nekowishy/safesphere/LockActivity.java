package com.nekowishy.safesphere;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen lock shown over an app that a parent has locked. */
public class LockActivity extends Activity {

    static final String EXTRA_PKG = "pkg";
    private static int wrongTries;
    private static long lockedOutUntil;

    private String pkg;
    private LinearLayout pinBox;
    private EditText pin;
    private TextView pinMsg;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Ui.SKY);
        getWindow().setNavigationBarColor(Ui.BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        build(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        build(intent);
    }

    private void build(Intent intent) {
        pkg = intent == null ? null : intent.getStringExtra(EXTRA_PKG);
        if (pkg == null) {
            finish();
            return;
        }
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Bevel.Page(Ui.dp(this, 2)));

        LinearLayout col = Ui.vbox(this);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(this, 28);
        col.setPadding(p, Ui.dp(this, 70), p, p);

        // App icon in a raised circle, with a blue lock badge
        FrameLayout iconWrap = new FrameLayout(this);
        int ring = Ui.dp(this, 132);
        FrameLayout circle = new FrameLayout(this);
        circle.setBackground(Bevel.raised(ring / 2f, Ui.dp(this, 1.6f)));
        Ui.shadow(circle, 10, Ui.SHADOW);
        ImageView icon = new ImageView(this);
        try {
            PackageManager pm = getPackageManager();
            Drawable d = pm.getApplicationIcon(pkg);
            icon.setImageDrawable(d);
        } catch (Exception ignored) {
        }
        int is = Ui.dp(this, 72);
        circle.addView(icon, new FrameLayout.LayoutParams(is, is, Gravity.CENTER));
        iconWrap.addView(circle, new FrameLayout.LayoutParams(ring, ring, Gravity.CENTER));
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(Bevel.blue(Ui.dp(this, 22), Ui.dp(this, 1.2f)));
        Ui.shadow(badge, 8, Ui.CYAN);
        int bi = Ui.dp(this, 22);
        badge.addView(new NavIcon(this, NavIcon.LOCK, Ui.WHITE), new FrameLayout.LayoutParams(bi, bi, Gravity.CENTER));
        int bs = Ui.dp(this, 44);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(bs, bs, Gravity.BOTTOM | Gravity.END);
        iconWrap.addView(badge, blp);
        col.addView(iconWrap, new LinearLayout.LayoutParams(ring + Ui.dp(this, 10), ring + Ui.dp(this, 6)));

        TextView title = Ui.text(this, AppLock.label(this, pkg) + " is locked", 24, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, Ui.dp(this, 26), 0, 0);
        col.addView(title);
        TextView sub = Ui.text(this, "Ask a parent to unlock it.", 14, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 26));
        col.addView(sub);

        TextView home = Ui.primary(Ui.button(this, "GO TO HOME SCREEN", Ui.WHITE, v -> goHome()));
        col.addView(home, Ui.params(Ui.MATCH, Ui.WRAP, 0f));

        TextView parent = Ui.button(this, "PARENT UNLOCK", Ui.CYAN, v -> {
            pinBox.setVisibility(View.VISIBLE);
            pin.requestFocus();
        });
        col.addView(parent, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        pinBox = Ui.vbox(this);
        pinBox.setVisibility(View.GONE);
        pinBox.setPadding(0, Ui.dp(this, 16), 0, 0);
        pin = new EditText(this);
        pin.setHint("PIN");
        pin.setHintTextColor(Ui.MUTED);
        pin.setTextColor(Ui.TEXT);
        pin.setSingleLine(true);
        pin.setGravity(Gravity.CENTER);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        pin.setBackground(Bevel.pressed(Ui.dp(this, 18), Ui.dp(this, 1.2f)));
        int fp = Ui.dp(this, 14);
        pin.setPadding(fp, fp, fp, fp);
        pinBox.addView(pin);
        pinMsg = Ui.text(this, "Unlocks this app for 10 minutes", 12, Ui.MUTED, false);
        pinMsg.setGravity(Gravity.CENTER);
        pinMsg.setPadding(0, Ui.dp(this, 8), 0, 0);
        pinBox.addView(pinMsg);
        pinBox.addView(Ui.button(this, "UNLOCK", Ui.GREEN, v -> tryUnlock()), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(pinBox, Ui.params(Ui.MATCH, Ui.WRAP, 0f));

        TextView brand = Ui.text(this, "Protected by SafeSphere", 11, Ui.MUTED, true);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(0.08f);
        brand.setPadding(0, Ui.dp(this, 30), 0, 0);
        col.addView(brand);

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        for (int i = 0; i < col.getChildCount(); i++) Ui.enter(col.getChildAt(i), i);
    }

    private void tryUnlock() {
        long now = SystemClock.elapsedRealtime();
        if (now < lockedOutUntil) {
            pinMsg.setText("Too many wrong tries. Wait " + ((lockedOutUntil - now) / 1000 + 1) + " seconds.");
            pinMsg.setTextColor(Ui.RED);
            Ui.shake(pin);
            return;
        }
        if (Prefs.checkPin(this, pin.getText().toString())) {
            wrongTries = 0;
            AppLockService.unlock(pkg);
            finish();
            overridePendingTransition(0, 0);
            return;
        }
        wrongTries++;
        pin.setText("");
        Ui.shake(pin);
        if (wrongTries >= 5) {
            wrongTries = 0;
            lockedOutUntil = now + 30_000;
            pinMsg.setText("Too many wrong tries. Wait 30 seconds.");
        } else {
            pinMsg.setText("Wrong PIN");
        }
        pinMsg.setTextColor(Ui.RED);
    }

    private void goHome() {
        startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        finish();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        goHome(); // back never returns to the locked app
    }
}
