package com.nekowishy.safesphere;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Light "sky glass" design system: white frosted cards on a soft sky-blue gradient, navy text,
 * light-weight big numbers, pill buttons and a lime accent for "active / protected".
 */
final class Ui {

    // Surfaces
    static final int BG = 0xFFF5F8FC;          // page background (bottom of gradient)
    static final int SKY = 0xFFC9DBEE;         // top of page gradient
    static final int PANEL = 0xFFFFFFFF;       // card
    static final int LINE = 0xFFE2E9F2;        // hairlines, borders
    static final int FIELD = 0xFFF1F5FA;       // input background
    static final int HERO_TOP = 0xFF4E78A7;    // blue hero card
    static final int HERO_BOTTOM = 0xFF7E9EC6;

    // Text
    static final int TEXT = 0xFF14233A;        // navy
    static final int MUTED = 0xFF66758C;       // slate
    static final int NAVY = 0xFF1B2B44;        // primary button fill
    static final int WHITE = 0xFFFFFFFF;

    // Accents (names kept so every screen picks up the new palette)
    static final int CYAN = 0xFF2D78C8;        // sky blue: primary accent
    static final int LIME = 0xFFD3EE3A;        // "active / protected" highlight
    static final int GREEN = 0xFF0E8F61;
    static final int AMBER = 0xFFB97300;
    static final int RED = 0xFFD93A45;
    static final int PINK = 0xFFE0566E;        // threat / blocked
    static final int VIOLET = 0xFF5873A8;      // slate blue
    static final int SLATE_BAR = 0xFF7D8FA9;   // chart bars

    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** Frosted white card. The stroke colour is kept as a faint tint on the border. */
    static GradientDrawable panel(Context c, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(alpha(PANEL, 0xF2));
        g.setCornerRadius(dp(c, 26));
        g.setStroke(dp(c, 1), alpha(stroke, 0x2A));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    /** Display text: big numbers and headlines in a light weight, like the reference design. */
    static TextView glow(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(Typeface.create(sp >= 20 ? "sans-serif-light" : "sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    static TextView button(Context c, String s, int color, View.OnClickListener l) {
        TextView b = text(c, s, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.06f);
        int p = dp(c, 14);
        b.setPadding(p * 2, p, p * 2, p);
        b.setClickable(true);
        b.setFocusable(true);
        restyle(b, color);
        b.setOnClickListener(v -> {
            tap(v);
            l.onClick(v);
        });
        return b;
    }

    /** Soft tinted pill: colored text on a light wash of the same color. */
    static void restyle(TextView b, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(alpha(color, 0x1C));
        g.setCornerRadius(dp(b.getContext(), 50));
        b.setBackground(g);
        b.setTextColor(color);
        b.setShadowLayer(0, 0, 0, 0);
    }

    /** Solid pill for the main action on a screen. */
    static void solid(TextView b, int fill, int textColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(b.getContext(), 50));
        b.setBackground(g);
        b.setTextColor(textColor);
        b.setShadowLayer(0, 0, 0, 0);
    }

    static TextView chip(Context c, String s, int color) {
        TextView t = text(c, s, 10, color == LIME ? NAVY : color, true);
        t.setLetterSpacing(0.08f);
        int p = dp(c, 6);
        t.setPadding(p * 2, p - 1, p * 2, p - 1);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color == LIME ? LIME : alpha(color, 0x1F));
        g.setCornerRadius(dp(c, 50));
        t.setBackground(g);
        return t;
    }

    /** Round frosted icon button, like the search / menu buttons in the reference. */
    static TextView circle(Context c, String glyph, int fill, int stroke, int textColor) {
        TextView t = text(c, glyph, 16, textColor, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        g.setStroke(dp(c, 1), stroke);
        t.setBackground(g);
        t.setClickable(true);
        return t;
    }

    /** Springy press feedback used on every tappable element. */
    static void tap(View v) {
        v.animate().cancel();
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(4f)).start();
    }

    /** Staggered slide-up entrance with a slight 3D tilt. */
    static void enter(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 28));
        v.setRotationX(10f);
        v.animate().alpha(1f).translationY(0f).rotationX(0f).setStartDelay(70L * index).setDuration(480)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    static void shake(View v) {
        ObjectAnimator.ofFloat(v, "translationX", 0, 24, -24, 16, -16, 6, -6, 0).setDuration(420).start();
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c, int stroke) {
        LinearLayout l = vbox(c);
        l.setBackground(panel(c, stroke));
        l.setElevation(dp(c, 2));
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        return l;
    }

    static LinearLayout.LayoutParams params(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(Context c, int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(c, top);
        return lp;
    }
}
