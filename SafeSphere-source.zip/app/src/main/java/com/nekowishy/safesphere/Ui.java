package com.nekowishy.safesphere;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Neon design system: colours, glowing text, glass panels and tap animations. */
final class Ui {

    static final int BG = 0xFF07060F;
    static final int PANEL = 0xFF110E22;
    static final int CYAN = 0xFF00F0FF;
    static final int PINK = 0xFFFF2BD6;
    static final int GREEN = 0xFF39FF88;
    static final int RED = 0xFFFF3B5C;
    static final int AMBER = 0xFFFFC23D;
    static final int VIOLET = 0xFF9D5CFF;
    static final int TEXT = 0xFFEDEBFF;
    static final int MUTED = 0xFF8D89B3;

    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    static GradientDrawable panel(Context c, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF15112B, PANEL, 0xFF0C0A19});
        g.setCornerRadius(dp(c, 20));
        g.setStroke(dp(c, 1.2f), alpha(stroke, 0x88));
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    static TextView glow(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, true);
        t.setShadowLayer(dp(c, 12), 0, 0, color);
        return t;
    }

    static TextView button(Context c, String s, int color, View.OnClickListener l) {
        TextView b = text(c, s, 14, color, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.08f);
        int p = dp(c, 13);
        b.setPadding(p * 2, p, p * 2, p);
        b.setClickable(true);
        b.setFocusable(true);
        restyle(b, color);
        b.setOnClickListener(v -> {
            tap(v);
            l.onClick(v);
        });
        return b;
    }

    static void restyle(TextView b, int color) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(alpha(color, 0x24));
        g.setCornerRadius(dp(b.getContext(), 16));
        g.setStroke(dp(b.getContext(), 1.6f), color);
        b.setBackground(g);
        b.setTextColor(color);
        b.setShadowLayer(dp(b.getContext(), 10), 0, 0, color);
    }

    static TextView chip(Context c, String s, int color) {
        TextView t = text(c, s, 10, color, true);
        t.setLetterSpacing(0.1f);
        int p = dp(c, 6);
        t.setPadding(p + p / 2, p / 2, p + p / 2, p / 2);
        GradientDrawable g = new GradientDrawable();
        g.setColor(alpha(color, 0x22));
        g.setCornerRadius(dp(c, 50));
        g.setStroke(dp(c, 1), alpha(color, 0xAA));
        t.setBackground(g);
        return t;
    }

    /** Springy press feedback used on every tappable element. */
    static void tap(View v) {
        v.animate().cancel();
        v.setScaleX(0.9f);
        v.setScaleY(0.9f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(4f)).start();
    }

    /** Staggered slide-up entrance for cards. */
    static void enter(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 28));
        v.setRotationX(12f);
        v.animate().alpha(1f).translationY(0f).rotationX(0f).setStartDelay(70L * index).setDuration(480)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    static void shake(View v) {
        ObjectAnimator.ofFloat(v, "translationX", 0, 24, -24, 16, -16, 6, -6, 0).setDuration(420).start();
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c, int stroke) {
        LinearLayout l = vbox(c);
        l.setBackground(panel(c, stroke));
        int p = dp(c, 18);
        l.setPadding(p, p, p, p);
        return l;
    }

    static LinearLayout.LayoutParams params(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(Context c, int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(c, top);
        return lp;
    }
}
