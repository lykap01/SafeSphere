package com.nekowishy.safesphere;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.MetricAffectingSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * SafeSphere design system. Build 15's look and motion, unchanged: light sky page, bevelled white cards
 * with soft blue shadows, the blue glass hero, glowing blue pill buttons, springy taps and staggered
 * slide-in. Only the type is new: Lora serif headlines (one italic accent word) and Inter for the rest.
 *
 * Status is never shown by colour alone: badges pair colour with a symbol and a word.
 * All text sizes are in sp, so Android font scaling works.
 */
final class Ui {

    // ------------------------------------------------------------------ colour (Build 15 light theme)
    static final int BG = 0xFFF4F7FC;
    static final int SKY = 0xFFDCE7F7;          // top of the page gradient (status bar)
    static final int SURFACE = 0xFFFFFFFF;
    static final int SURFACE_MUTED = 0xFFE6EDF7;
    static final int BORDER = 0xFFD5DFEE;
    static final int TEXT = 0xFF0F1B3D;         // deep navy
    static final int TEXT2 = 0xFF56647F;        // slate, ≥ 5:1 on cards
    static final int PRIMARY = 0xFF2F6BFF;      // Build 15 vivid blue (button fill)
    static final int ACCENT = 0xFF2558E8;       // links and accent words, 5.6:1 on white
    static final int LIME = 0xFF7CE0FF;         // Build 15 luminous cyan, on the blue hero only
    static final int NAVY = 0xFF0F2A7A;         // text on the white pill in the hero
    static final int PRIMARY_TINT = 0xFFE1EAFD;
    static final int WHITE = 0xFFFFFFFF;
    static final int SHADOW = 0xFF6F8FD0;       // Build 15 soft blue shadow

    // Semantic status colours, all ≥ 4.5:1 on their tints and on white
    static final int SUCCESS = 0xFF0B7A53;     // protection active, verified
    static final int WARNING = 0xFF8A5600;     // attention required
    static final int SUSPICIOUS = 0xFFA2470E;  // suspicious activity
    static final int DANGER = 0xFFB32632;      // dangerous / blocked
    static final int INFO = 0xFF2350C8;        // information, user-confirmed
    static final int NEUTRAL = 0xFF56647F;     // off, unavailable, unverified

    static final int T_SUCCESS = 0, T_WARNING = 1, T_SUSPICIOUS = 2, T_DANGER = 3, T_INFO = 4, T_NEUTRAL = 5;
    private static final int[] TONE_FG = {SUCCESS, WARNING, SUSPICIOUS, DANGER, INFO, NEUTRAL};
    private static final int[] TONE_BG = {0xFFDDF3EA, 0xFFFBEFD6, 0xFFFCE8DA, 0xFFFBE3E5, 0xFFE1EAFD, 0xFFEDF1F7};
    private static final String[] TONE_GLYPH = {"✓", "!", "?", "✕", "i", "–"};

    static int fg(int tone) { return TONE_FG[tone]; }
    static int tint(int tone) { return TONE_BG[tone]; }
    static String glyph(int tone) { return TONE_GLYPH[tone]; }

    // ------------------------------------------------------------------ type
    static final float PAGE_TITLE = 26, SECTION = 12, CARD_TITLE = 16, BODY = 14, SUPPORT = 13, LABEL = 12;

    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private static Typeface regular, medium, semibold, serif, serifItalic;

    /** Loads the bundled fonts once (res/font). Falls back to the system font if a file can't load. */
    private static void fonts(Context c) {
        if (regular != null) return;
        android.content.res.Resources r = c.getApplicationContext().getResources();
        regular = load(r, R.font.inter_regular, Typeface.create("sans-serif", Typeface.NORMAL));
        medium = load(r, R.font.inter_medium, Typeface.create("sans-serif-medium", Typeface.NORMAL));
        semibold = load(r, R.font.inter_semibold, medium);
        serif = load(r, R.font.lora, Typeface.create("serif", Typeface.NORMAL));
        serifItalic = load(r, R.font.lora_italic, Typeface.create("serif", Typeface.ITALIC));
    }

    private static Typeface load(android.content.res.Resources r, int id, Typeface fallback) {
        try {
            Typeface t = r.getFont(id);
            return t != null ? t : fallback;
        } catch (RuntimeException e) {
            return fallback;
        }
    }

    static Typeface sans(Context c, int weight) {
        fonts(c);
        return weight >= 600 ? semibold : weight >= 500 ? medium : regular;
    }

    static Typeface serif(Context c, boolean italic) {
        fonts(c);
        return italic ? serifItalic : serif;
    }

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    // ------------------------------------------------------------------ text

    static TextView text(Context c, String s, float sp, int color, boolean medium) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(sans(c, medium ? 500 : 400));
        t.setLineSpacing(0, 1.2f);
        return t;
    }

    /** Marks a view as a heading for screen readers (Android 9+; ignored on 8.x). */
    static void heading(View v) {
        if (Build.VERSION.SDK_INT >= 28) v.setAccessibilityHeading(true);
    }

    /** A typeface span that works on Android 8 (TypefaceSpan(Typeface) needs Android 9). */
    static final class FontSpan extends MetricAffectingSpan {
        private final Typeface tf;
        FontSpan(Typeface tf) { this.tf = tf; }
        @Override public void updateDrawState(TextPaint p) { apply(p); }
        @Override public void updateMeasureState(TextPaint p) { apply(p); }
        private void apply(Paint p) { p.setTypeface(tf); }
    }

    /**
     * Serif display headline. Text between asterisks becomes the italic accent, e.g.
     * "You're *protected*." → "protected" in italic blue.
     */
    static TextView display(Context c, String s, float sp, int color) {
        return display(c, s, sp, color, ACCENT);
    }

    static TextView display(Context c, String s, float sp, int color, int accent) {
        TextView t = new TextView(c);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(serif(c, false));
        t.setLineSpacing(0, 1.05f);
        int a = s.indexOf('*'), b = a < 0 ? -1 : s.indexOf('*', a + 1);
        if (a >= 0 && b > a) {
            String plain = s.substring(0, a) + s.substring(a + 1, b) + s.substring(b + 1);
            SpannableString sp2 = new SpannableString(plain);
            sp2.setSpan(new FontSpan(serif(c, true)), a, b - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp2.setSpan(new ForegroundColorSpan(accent), a, b - 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            t.setText(sp2);
        } else {
            t.setText(s);
        }
        heading(t);
        return t;
    }

    static TextView pageTitle(Context c, String s) {
        return display(c, s, 24, TEXT);
    }

    static TextView cardTitle(Context c, String s) {
        TextView t = text(c, s, CARD_TITLE, TEXT, true);
        t.setTypeface(sans(c, 600));
        heading(t);
        return t;
    }

    static TextView body(Context c, String s) {
        return text(c, s, BODY, TEXT, false);
    }

    static TextView support(Context c, String s) {
        return text(c, s, SUPPORT, TEXT2, false);
    }

    /** Small spaced eyebrow above a group of cards. */
    static TextView section(Context c, String s) {
        TextView t = text(c, s.toUpperCase(java.util.Locale.ROOT), SECTION, TEXT2, true);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(c, 4), dp(c, 24), dp(c, 4), dp(c, 10));
        t.setContentDescription(s);
        heading(t);
        return t;
    }

    static TextView bullets(Context c, java.util.List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String s : items) {
            if (sb.length() > 0) sb.append('\n');
            sb.append("•  ").append(s);
        }
        TextView t = body(c, sb.toString());
        t.setLineSpacing(dp(c, 4), 1.15f);
        return t;
    }

    // ------------------------------------------------------------------ surfaces

    static GradientDrawable rounded(int fill, int stroke, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    /** Soft blue shadow under raised surfaces (Android 9+ tints it). */
    static void shadow(View v, float elevationDp, int color) {
        v.setElevation(dp(v.getContext(), elevationDp));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineSpotShadowColor(color);
            v.setOutlineAmbientShadowColor(color);
        }
    }

    /** Raised bevelled card. */
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(Bevel.raised(dp(c, 26), dp(c, 1.6f)));
        shadow(l, 6, SHADOW);
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** Raised card for lists of rows. */
    static LinearLayout listCard(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(Bevel.raised(dp(c, 26), dp(c, 1.6f)));
        shadow(l, 6, SHADOW);
        l.setPadding(0, dp(c, 6), 0, dp(c, 6));
        return l;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1)));
        lp.leftMargin = dp(c, 16);
        lp.rightMargin = dp(c, 16);
        v.setLayoutParams(lp);
        return v;
    }

    static Drawable ripple(Drawable content, Drawable mask) {
        return new RippleDrawable(ColorStateList.valueOf(alpha(PRIMARY, 0x2E)), content, mask);
    }

    /** Springy press feedback (Build 15). */
    static void tap(View v) {
        v.animate().cancel();
        v.setScaleX(0.94f);
        v.setScaleY(0.94f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(4f)).start();
    }

    /** Staggered slide-up entrance with a slight 3D tilt (Build 15). */
    static void enter(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 28));
        v.setRotationX(10f);
        v.animate().alpha(1f).translationY(0f).rotationX(0f).setStartDelay(60L * Math.min(index, 8)).setDuration(460)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    private static View.OnClickListener springy(View.OnClickListener l) {
        return v -> {
            tap(v);
            if (l != null) l.onClick(v);
        };
    }

    static void clickable(View v, String description, View.OnClickListener l) {
        if (v.getBackground() == null) v.setBackground(ripple(null, rounded(WHITE, 0, 12, v.getContext())));
        v.setClickable(true);
        v.setFocusable(true);
        if (description != null) v.setContentDescription(description);
        v.setOnClickListener(springy(l));
    }

    // ------------------------------------------------------------------ buttons

    private static TextView baseButton(Context c, String s, View.OnClickListener l) {
        TextView b = text(c, s, BODY, ACCENT, true);
        b.setTypeface(sans(c, 600));
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 50));
        b.setMinimumHeight(dp(c, 50));
        b.setPadding(dp(c, 20), dp(c, 12), dp(c, 20), dp(c, 12));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(springy(l));
        return b;
    }

    /** Glowing blue pill (Build 15): the main action on a screen. */
    static TextView primary(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setTextColor(WHITE);
        b.setBackground(ripple(Bevel.blue(dp(c, 50), dp(c, 1.4f)), null));
        shadow(b, 8, PRIMARY);
        return b;
    }

    /** Raised white pill for secondary actions. */
    static TextView secondary(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setBackground(ripple(Bevel.raised(dp(c, 50), dp(c, 1.4f)), null));
        shadow(b, 3, SHADOW);
        return b;
    }

    static TextView destructive(Context c, String s, View.OnClickListener l) {
        TextView b = secondary(c, s, l);
        b.setTextColor(DANGER);
        return b;
    }

    /** Low-emphasis inline action. */
    static TextView link(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(0, dp(c, 10), dp(c, 8), dp(c, 10));
        b.setBackground(ripple(null, rounded(WHITE, 0, 8, c)));
        return b;
    }

    static LinearLayout pair(Context c, View a, View b) {
        LinearLayout row = hbox(c);
        row.addView(a, params(0, WRAP, 1f));
        LinearLayout.LayoutParams lp = params(0, WRAP, 1f);
        lp.leftMargin = dp(c, 10);
        row.addView(b, lp);
        return row;
    }

    // ------------------------------------------------------------------ status

    static TextView badge(Context c, int tone, String label) {
        TextView t = text(c, glyph(tone) + "  " + label, LABEL, fg(tone), true);
        t.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));
        t.setBackground(rounded(tint(tone), 0, 50, c));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    static TextView statusDot(Context c, int tone) {
        TextView t = text(c, glyph(tone), 13, fg(tone), true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(tint(tone));
        g.setStroke(dp(c, 1), alpha(fg(tone), 0x55));
        t.setBackground(g);
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        int s = dp(c, 30);
        t.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return t;
    }

    static LinearLayout banner(Context c, int tone, String title, String detail) {
        LinearLayout box = hbox(c);
        box.setGravity(Gravity.TOP);
        GradientDrawable g = rounded(tint(tone), 0, 16, c);
        g.setStroke(dp(c, 1), alpha(fg(tone), 0x40));
        box.setBackground(g);
        int p = dp(c, 14);
        box.setPadding(p, p, p, p);
        box.addView(statusDot(c, tone));
        LinearLayout texts = vbox(c);
        texts.setPadding(dp(c, 12), dp(c, 3), 0, 0);
        TextView t = text(c, title, BODY, fg(tone), true);
        t.setTypeface(sans(c, 600));
        texts.addView(t);
        if (detail != null && !detail.isEmpty()) {
            TextView d = text(c, detail, SUPPORT, TEXT, false);
            d.setPadding(0, dp(c, 3), 0, 0);
            texts.addView(d);
        }
        box.addView(texts, params(0, WRAP, 1f));
        box.setContentDescription(title + ". " + (detail == null ? "" : detail));
        return box;
    }

    static LinearLayout progress(Context c, int done, int total, int tone) {
        LinearLayout track = hbox(c);
        track.setBackground(rounded(SURFACE_MUTED, 0, 4, c));
        View fill = new View(c);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{alpha(fg(tone), 0xAA), fg(tone)});
        g.setCornerRadius(dp(c, 4));
        fill.setBackground(g);
        View rest = new View(c);
        int h = dp(c, 8);
        track.addView(fill, params(0, h, Math.max(0, done)));
        track.addView(rest, params(0, h, Math.max(0, total - done)));
        track.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return track;
    }

    // ------------------------------------------------------------------ rows

    static LinearLayout row(Context c, View leading, String title, String subtitle, View trailing, View.OnClickListener l) {
        LinearLayout row = hbox(c);
        row.setMinimumHeight(dp(c, 58));
        row.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        if (leading != null) {
            row.addView(leading);
            View gap = new View(c);
            row.addView(gap, new LinearLayout.LayoutParams(dp(c, 12), 1));
        }
        LinearLayout texts = vbox(c);
        texts.addView(text(c, title, BODY, TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = support(c, subtitle);
            s.setPadding(0, dp(c, 2), 0, 0);
            texts.addView(s);
        }
        row.addView(texts, params(0, WRAP, 1f));
        if (trailing != null) {
            LinearLayout.LayoutParams lp = params(WRAP, WRAP, 0f);
            lp.leftMargin = dp(c, 8);
            row.addView(trailing, lp);
        }
        if (l != null) {
            row.setBackground(ripple(null, rounded(WHITE, 0, 0, c)));
            row.setClickable(true);
            row.setFocusable(true);
            row.setOnClickListener(l);
        }
        return row;
    }

    static TextView chevron(Context c) {
        TextView t = text(c, "›", 22, TEXT2, false);
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return t;
    }

    // ------------------------------------------------------------------ input

    static void field(EditText e) {
        Context c = e.getContext();
        e.setBackground(Bevel.pressed(dp(c, 16), dp(c, 1.2f)));
        int p = dp(c, 14);
        e.setPadding(p, p, p, p);
        e.setTextColor(TEXT);
        e.setHintTextColor(TEXT2);
        e.setTypeface(sans(c, 400));
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, BODY);
        e.setMinHeight(dp(c, 50));
    }

    static void shake(View v) {
        android.animation.ObjectAnimator.ofFloat(v, "translationX", 0, 24, -24, 16, -16, 6, -6, 0).setDuration(420).start();
    }

    // ------------------------------------------------------------------ layout

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams params(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(Context c, int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(c, top);
        return lp;
    }

    static FrameLayout.LayoutParams frame(int w, int h, int gravity) {
        return new FrameLayout.LayoutParams(w, h, gravity);
    }
}
