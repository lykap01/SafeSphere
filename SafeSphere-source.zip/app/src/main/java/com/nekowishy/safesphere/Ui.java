package com.nekowishy.safesphere;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * "Bevelled glass" design system: raised white cards with a bright top-left rim and soft blue
 * shadow, pressed-in text fields, glowing blue main buttons and a luminous deep-blue hero.
 */
final class Ui {

    // Surfaces
    static final int BG = 0xFFF4F7FC;
    static final int SKY = 0xFFDCE7F7;
    static final int PANEL = 0xFFFFFFFF;
    static final int LINE = 0xFFE0E8F4;
    static final int FIELD = 0xFFEEF3FA;
    static final int HERO_TOP = 0xFF0A1A55;
    static final int HERO_BOTTOM = 0xFF2A64F0;

    // Text
    static final int TEXT = 0xFF0F1B3D;        // deep navy
    static final int MUTED = 0xFF5F6E8C;       // slate
    static final int NAVY = 0xFF14245A;
    static final int WHITE = 0xFFFFFFFF;

    // Accents (names kept so every screen picks up the palette)
    static final int CYAN = 0xFF2F6BFF;        // vivid blue: primary accent
    static final int LIME = 0xFF7CE0FF;        // luminous cyan highlight ("active")
    static final int GREEN = 0xFF0E8F61;
    static final int AMBER = 0xFFB97300;
    static final int RED = 0xFFD93A45;
    static final int PINK = 0xFFE0566E;        // threat / blocked
    static final int VIOLET = 0xFF4F64C8;      // indigo
    static final int SLATE_BAR = 0xFF9DB1D6;   // chart bars
    static final int SHADOW = 0xFF6F8FD0;      // soft blue shadow

    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** Soft blue shadows instead of grey ones (Android 9+). */
    static void shadow(View v, float elevationDp, int color) {
        v.setElevation(dp(v.getContext(), elevationDp));
        if (Build.VERSION.SDK_INT >= 28) {
            v.setOutlineSpotShadowColor(color);
            v.setOutlineAmbientShadowColor(color);
        }
    }

    /** Raised bevelled card. (The stroke argument is kept for older call sites.) */
    static Drawable panel(Context c, int stroke) {
        return Bevel.raised(dp(c, 26), dp(c, 1.6f));
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setLineSpacing(0, 1.15f);
        return t;
    }

    /** Display text: big numbers and headlines in a light weight. */
    static TextView glow(Context c, String s, float sp, int color) {
        TextView t = text(c, s, sp, color, false);
        t.setTypeface(Typeface.create(sp >= 20 ? "sans-serif-light" : "sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    /** Raised bevelled pill with colored text. */
    static TextView button(Context c, String s, int color, View.OnClickListener l) {
        TextView b = text(c, s, 13, color, true);
        b.setGravity(Gravity.CENTER);
        b.setLetterSpacing(0.06f);
        int p = dp(c, 15);
        b.setPadding(p * 2, p, p * 2, p);
        b.setClickable(true);
        b.setFocusable(true);
        restyle(b, color);
        b.setOnClickListener(v -> {
            tap(v);
            l.onClick(v);
        });
        return b;
    }

    static void restyle(TextView b, int color) {
        b.setBackground(Bevel.raised(dp(b.getContext(), 50), dp(b.getContext(), 1.4f)));
        b.setTextColor(color);
        b.setShadowLayer(0, 0, 0, 0);
        shadow(b, 3, SHADOW);
    }

    /** Glowing blue gradient button for the main action on a screen. */
    static TextView primary(TextView b) {
        b.setBackground(Bevel.blue(dp(b.getContext(), 50), dp(b.getContext(), 1.4f)));
        b.setTextColor(WHITE);
        shadow(b, 8, CYAN);
        return b;
    }

    /** White raised pill (on the blue hero) or blue pill, depending on fill. */
    static void solid(TextView b, int fill, int textColor) {
        if (fill == WHITE) {
            b.setBackground(Bevel.raised(dp(b.getContext(), 50), dp(b.getContext(), 1.4f)));
            shadow(b, 6, 0xFF0A1A55);
        } else {
            b.setBackground(Bevel.blue(dp(b.getContext(), 50), dp(b.getContext(), 1.4f)));
            shadow(b, 8, CYAN);
        }
        b.setTextColor(textColor);
        b.setShadowLayer(0, 0, 0, 0);
    }

    static TextView chip(Context c, String s, int color) {
        TextView t = text(c, s, 10, color == LIME ? NAVY : color, true);
        t.setLetterSpacing(0.08f);
        int p = dp(c, 6);
        t.setPadding(p * 2, p - 1, p * 2, p - 1);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color == LIME ? LIME : alpha(color, 0x1F));
        g.setCornerRadius(dp(c, 50));
        t.setBackground(g);
        return t;
    }

    /** Raised bevelled square icon button, like the reference's social / theme buttons. */
    static FrameLayout iconButton(Context c, int icon, int iconColor, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(c);
        f.setBackground(Bevel.raised(dp(c, 16), dp(c, 1.4f)));
        shadow(f, 4, SHADOW);
        int s = dp(c, 24);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(s, s);
        lp.gravity = Gravity.CENTER;
        f.addView(new NavIcon(c, icon, iconColor), lp);
        f.setClickable(true);
        f.setOnClickListener(v -> {
            tap(v);
            l.onClick(v);
        });
        return f;
    }

    /** Kept for compatibility: round glass button with a text glyph. */
    static TextView circle(Context c, String glyph, int fill, int stroke, int textColor) {
        TextView t = text(c, glyph, 16, textColor, false);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        g.setStroke(dp(c, 1), stroke);
        t.setBackground(g);
        t.setClickable(true);
        return t;
    }

    /** Springy press feedback used on every tappable element. */
    static void tap(View v) {
        v.animate().cancel();
        v.setScaleX(0.92f);
        v.setScaleY(0.92f);
        v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(new OvershootInterpolator(4f)).start();
    }

    /** Staggered slide-up entrance with a slight 3D tilt. */
    static void enter(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(v.getContext(), 28));
        v.setRotationX(10f);
        v.animate().alpha(1f).translationY(0f).rotationX(0f).setStartDelay(70L * index).setDuration(480)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
    }

    static void shake(View v) {
        ObjectAnimator.ofFloat(v, "translationX", 0, 24, -24, 16, -16, 6, -6, 0).setDuration(420).start();
    }

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout card(Context c, int stroke) {
        LinearLayout l = vbox(c);
        l.setBackground(panel(c, stroke));
        shadow(l, 6, SHADOW);
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        return l;
    }

    static LinearLayout.LayoutParams params(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(Context c, int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(c, top);
        return lp;
    }
}
