package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.os.SystemClock;
import android.view.View;

/**
 * The SafeSphere AI orb: a glowing sphere made of wavy rings (cyan → blue → violet → pink) that slowly turns
 * and ripples. When the AI is thinking it spins faster and the waves grow.
 */
final class OrbView extends View {

    static final int CYAN = 0xFF3DE7FF, BLUE = 0xFF2F6BFF, VIOLET = 0xFF8B5CF6, PINK = 0xFFFF4FA3;

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Matrix spin = new Matrix();
    private SweepGradient sweep;
    private final boolean animated;
    private final int rings;
    private float energy = 0f, targetEnergy = 0f; // 0 = calm, 1 = thinking
    private long start = SystemClock.uptimeMillis();
    private float phase;
    private long lastFrame;

    OrbView(Context c, boolean animated, int rings) {
        super(c);
        this.animated = animated;
        this.rings = rings;
        ring.setStyle(Paint.Style.STROKE);
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    void setThinking(boolean thinking) {
        targetEnergy = thinking ? 1f : 0f;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f;
        sweep = new SweepGradient(cx, cy, new int[]{CYAN, BLUE, VIOLET, PINK, 0xFFFF9A5C, VIOLET, CYAN}, null);
        glow.setShader(new RadialGradient(cx, cy, r, new int[]{Ui.alpha(VIOLET, 110), Ui.alpha(BLUE, 60), 0x00000000},
                new float[]{0.25f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        core.setShader(new RadialGradient(cx - r * 0.12f, cy - r * 0.15f, r * 0.62f,
                new int[]{0xCC0A1030, 0x99060B22, 0x00060B22}, new float[]{0f, 0.7f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || sweep == null) return;
        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        energy += (targetEnergy - energy) * Math.min(1f, dt * 3f);
        phase += dt * (0.7f + energy * 2.6f);
        float t = (now - start) / 1000f;

        float cx = w / 2f, cy = h / 2f;
        float R = Math.min(w, h) / 2f * 0.74f;
        float breathe = 1f + 0.025f * (float) Math.sin(t * 1.6f) + energy * 0.04f * (float) Math.sin(t * 7f);

        c.drawCircle(cx, cy, Math.min(w, h) / 2f, glow);

        spin.setRotate((phase * 40f) % 360f, cx, cy);
        sweep.setLocalMatrix(spin);
        ring.setShader(sweep);
        ring.setStrokeWidth(Math.max(1f, R * (rings > 20 ? 0.012f : 0.03f)));

        int steps = rings > 20 ? 72 : 40;
        float amp = 0.05f + energy * 0.07f;
        for (int k = 0; k < rings; k++) {
            float lat = -1.35f + 2.7f * k / (rings - 1);          // latitude, radians-ish
            float ringR = R * breathe * (float) Math.cos(lat * 0.95f);
            float y0 = cy + R * breathe * (float) Math.sin(lat) * 0.92f;
            float squash = 0.30f + 0.06f * (float) Math.sin(phase + k * 0.3f); // tilt: ellipses seen from slightly above
            float edge = 1f - Math.abs(lat) / 1.35f;
            ring.setAlpha((int) (70 + 150 * edge));
            path.reset();
            for (int i = 0; i <= steps; i++) {
                double a = Math.PI * 2 * i / steps;
                float wave = 1f + amp * (float) (Math.sin(a * 5 + phase * 1.7 + k * 0.45)
                        + 0.6 * Math.sin(a * 3 - phase * 1.1 + k * 0.8));
                float x = cx + ringR * wave * (float) Math.cos(a);
                float y = y0 + ringR * squash * wave * (float) Math.sin(a)
                        + R * 0.04f * (float) Math.sin(a * 2 + phase + k * 0.2) * edge;
                if (i == 0) path.moveTo(x, y);
                else path.lineTo(x, y);
            }
            c.drawPath(path, ring);
        }
        c.drawCircle(cx, cy, R * 0.62f, core);
        if (animated && isShown()) postInvalidateOnAnimation();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        lastFrame = 0;
        invalidate();
    }

    /** Small static gradient "avatar" used next to AI chat bubbles. */
    static final class Badge extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path star = new Path();

        Badge(Context c) {
            super(c);
            s.setColor(Color.WHITE);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            p.setShader(new LinearGradient(0, 0, w, h, new int[]{CYAN, BLUE, VIOLET, PINK}, null, Shader.TileMode.CLAMP));
            float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) * 0.26f, k = r * 0.22f;
            star.reset();
            star.moveTo(cx, cy - r);
            star.quadTo(cx + k, cy - k, cx + r, cy);
            star.quadTo(cx + k, cy + k, cx, cy + r);
            star.quadTo(cx - k, cy + k, cx - r, cy);
            star.quadTo(cx - k, cy - k, cx, cy - r);
            star.close();
        }

        @Override
        protected void onDraw(Canvas c) {
            float r = Math.min(getWidth(), getHeight()) / 2f;
            c.drawCircle(getWidth() / 2f, getHeight() / 2f, r, p);
            c.drawPath(star, s);
        }
    }
}
