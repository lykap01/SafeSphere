package com.nekowishy.safesphere;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Process;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * App lock (for kids): chosen apps can't be opened without the parent's PIN.
 * Uses Usage access (to see which app opened) and "Display over other apps" (to show the lock screen on top).
 */
final class AppLock {

    private AppLock() {}

    /** Apps worth suggesting first, because a child could use them to undo the lock or spend money. */
    static final String[][] SUGGESTED = {
            {"com.android.settings", "Settings (stops turning off SafeSphere)"},
            {"com.google.android.packageinstaller", "App installer (stops uninstalling)"},
            {"com.android.packageinstaller", "App installer (stops uninstalling)"},
            {"com.android.vending", "Play Store (stops buying and installing)"},
            {"com.heytap.market", "App Market"},
            {"com.oppo.market", "App Market"},
            {"com.globe.gcash.android", "GCash"},
            {"com.paymaya", "Maya"},
    };

    static final class App {
        final String pkg;
        final String label;
        App(String pkg, String label) { this.pkg = pkg; this.label = label; }
    }

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("app_lock", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return p(c).getBoolean("enabled", false); }

    static void setEnabled(Context c, boolean on) {
        p(c).edit().putBoolean("enabled", on).apply();
        if (on) start(c);
        else c.stopService(new Intent(c, AppLockService.class));
    }

    static Set<String> locked(Context c) {
        return new HashSet<>(p(c).getStringSet("locked", Collections.emptySet()));
    }

    static boolean isLocked(Context c, String pkg) { return locked(c).contains(pkg); }

    static void setLocked(Context c, String pkg, boolean lock) {
        Set<String> s = locked(c);
        if (lock) s.add(pkg);
        else s.remove(pkg);
        p(c).edit().putStringSet("locked", s).apply();
    }

    /** Ready to lock: switched on, both permissions given, and a PIN exists. */
    static boolean ready(Context c) {
        return enabled(c) && hasUsageAccess(c) && canOverlay(c) && Prefs.hasPin(c);
    }

    static void start(Context c) {
        if (!enabled(c) || !hasUsageAccess(c)) return;
        try {
            c.startForegroundService(new Intent(c, AppLockService.class));
        } catch (RuntimeException ignored) {
            // the system refused a background start; it starts next time SafeSphere opens
        }
    }

    @SuppressWarnings("deprecation")
    static boolean hasUsageAccess(Context c) {
        try {
            AppOpsManager ops = c.getSystemService(AppOpsManager.class);
            if (ops == null) return false;
            int mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Exception e) {
            return false;
        }
    }

    static boolean canOverlay(Context c) {
        return Settings.canDrawOverlays(c);
    }

    /** Apps that appear in the app drawer (what a child can tap), sorted by name. SafeSphere itself is left out. */
    static List<App> launchableApps(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        Set<String> seen = new HashSet<>();
        List<App> out = new ArrayList<>();
        for (ResolveInfo r : list) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(c.getPackageName()) || !seen.add(pkg)) continue;
            out.add(new App(pkg, String.valueOf(r.loadLabel(pm))));
        }
        Collections.sort(out, (a, b) -> a.label.toLowerCase(Locale.ROOT).compareTo(b.label.toLowerCase(Locale.ROOT)));
        return out;
    }

    /** Suggested apps that are actually installed on this phone. */
    static List<App> suggestedInstalled(Context c) {
        PackageManager pm = c.getPackageManager();
        List<App> out = new ArrayList<>();
        Set<String> seenLabels = new HashSet<>();
        for (String[] s : SUGGESTED) {
            try {
                pm.getApplicationInfo(s[0], 0);
                if (seenLabels.add(s[1])) out.add(new App(s[0], s[1]));
            } catch (PackageManager.NameNotFoundException ignored) {
                // not on this phone
            }
        }
        return out;
    }

    static String label(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return pkg;
        }
    }
}
