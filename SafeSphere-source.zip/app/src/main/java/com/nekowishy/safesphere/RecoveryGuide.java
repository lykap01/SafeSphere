package com.nekowishy.safesphere;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Recovery Center content: what to do after a scam or attack, as an ordered checklist.
 *
 * Contact details: SafeSphere does not list bank or e-wallet phone numbers (they differ per country and
 * change). Steps point to the provider's official app or the number printed on the user's own card.
 * The only hotline shown is the Philippines' Inter-Agency Response Center 1326 (CICC/DICT), confirmed
 * from CICC statements reported by PNA, ABS-CBN and the Inquirer (Nov 2024 – Jan 2025).
 */
final class RecoveryGuide {

    // Step actions the app can perform
    static final int A_NONE = 0, A_CHECK = 1, A_PROTECT = 2, A_PASSWORD = 3, A_SETTINGS = 4, A_APPS = 5,
            A_DIAL_1326 = 6, A_SECURITY = 7, A_PLAY_PROTECT = 8, A_DOWNLOADS = 9, A_UNKNOWN_SOURCES = 10,
            A_ACCESSIBILITY = 11, A_NOTIF_ACCESS = 12;

    static final class Step {
        final String title, detail, button;
        final int action;
        Step(String title, String detail) { this(title, detail, null, A_NONE); }
        Step(String title, String detail, String button, int action) {
            this.title = title; this.detail = detail; this.button = button; this.action = action;
        }
    }

    static final class Incident {
        final String id, title, summary;
        final boolean urgent;
        final Step[] steps;
        Incident(String id, String title, String summary, boolean urgent, Step... steps) {
            this.id = id; this.title = title; this.summary = summary; this.urgent = urgent; this.steps = steps;
        }
    }

    private static final Step OFFICIAL_CONTACT = new Step("Contact the provider through an official channel",
            "Use the official app's help or chat, or call the number printed on the back of your card. "
                    + "Don't use numbers or links from the suspicious message.");
    private static final Step EVIDENCE = new Step("Keep the evidence",
            "Take screenshots of the messages, the sender's number or account name, the link, and any receipts or "
                    + "reference numbers. Don't delete the conversation yet.");
    private static final Step REPORT_PH = new Step("Report it (Philippines)",
            "Call the government's Inter-Agency Response Center hotline 1326 (CICC). It is toll-free and open 24/7. "
                    + "Outside the Philippines, use your country's police or cybercrime reporting service.",
            "Call 1326", A_DIAL_1326);
    private static final Step NO_RECOVERY_AGENTS = new Step("Ignore \"recovery\" offers",
            "People who message you offering to get your money back for a fee are usually the same scammers again.");

    static final Incident[] INCIDENTS = {
            new Incident("clicked_link", "I clicked a suspicious link",
                    "Opening a link is usually low risk if you didn't type anything or install anything.", false,
                    new Step("Close the page", "Don't enter any details and don't allow downloads or notifications from it."),
                    new Step("Check the link", "Paste it into Check to see whether it is on a threat list.", "Open Check", A_CHECK),
                    new Step("Look for downloaded files", "Open your Downloads and delete any file you didn't expect, especially "
                            + "anything ending in .apk.", "Open Downloads", A_DOWNLOADS),
                    new Step("Turn on protection", "If the site is on a threat list, SafeSphere will block it next time.",
                            "Turn on", A_PROTECT),
                    new Step("If you typed anything", "Entered a password or code? Follow \"I entered my password\" or "
                            + "\"I shared an OTP or MPIN\" as well.")),

            new Incident("entered_password", "I entered my password on a suspicious website",
                    "Assume the password is known to the scammer. Change it before they use it.", true,
                    new Step("Change the password now", "Open the official app or type the website address yourself, then "
                            + "change the password. Don't use the link from the message."),
                    new Step("Change it everywhere you reused it", "Any account with the same password is at risk too.",
                            "Check a password", A_PASSWORD),
                    new Step("Sign out other sessions", "In the account's security settings, sign out of devices you don't "
                            + "recognise."),
                    new Step("Turn on 2-step verification", "Prefer an authenticator app or passkey over SMS codes."),
                    new Step("Check recovery details", "Make sure the recovery e-mail and phone number weren't changed, "
                            + "and that no e-mail forwarding rules were added."),
                    EVIDENCE),

            new Incident("shared_otp", "I shared an OTP or MPIN",
                    "Act quickly: an OTP can approve a login or a transfer within minutes.", true,
                    OFFICIAL_CONTACT,
                    new Step("Ask them to secure the account", "Ask the provider to block suspicious transfers, lock the "
                            + "account or remove unknown devices while you recover it."),
                    new Step("Change your MPIN and password", "Do it inside the official app once you have access."),
                    new Step("Review recent transactions", "Note any you didn't make, with dates, amounts and reference numbers."),
                    new Step("Remove unknown devices and sessions", "Most banking and e-wallet apps list the devices linked to "
                            + "your account."),
                    EVIDENCE, REPORT_PH),

            new Incident("installed_apk", "I installed a suspicious APK",
                    "Apps installed from outside the Play Store can read messages and OTPs, or control the screen.", true,
                    new Step("Disconnect", "Turn on airplane mode so the app can't send data or receive commands."),
                    new Step("Uninstall the app", "Settings → Apps → find the app → Uninstall.", "Open app list", A_APPS),
                    new Step("Remove special access", "If it won't uninstall, check Accessibility, Notification access and "
                            + "Device admin apps, and turn the app off there first.", "Accessibility", A_ACCESSIBILITY),
                    new Step("Block unknown installs again", "Turn off \"Install unknown apps\" for the browser or chat app "
                            + "you used.", "Open setting", A_UNKNOWN_SOURCES),
                    new Step("Scan with Play Protect", "Open Google Play → profile → Play Protect → Scan.", "Open Play Protect",
                            A_PLAY_PROTECT),
                    new Step("Change passwords from another device", "Change banking, e-wallet and e-mail passwords from a "
                            + "different phone or computer, then contact your bank."),
                    new Step("Consider a factory reset", "If the app keeps coming back or you can't remove its access, back up "
                            + "photos and reset the phone.")),

            new Incident("granted_permissions", "I granted suspicious app permissions",
                    "Permissions can be taken back at any time.", false,
                    new Step("Find the app's permissions", "Settings → Apps → the app → Permissions. Turn off anything it "
                            + "doesn't need (SMS, contacts, location, microphone...).", "Open app list", A_APPS),
                    new Step("Check high-risk access", "Accessibility and Notification access let an app read your screen and "
                            + "messages. Remove the app from both lists.", "Accessibility", A_ACCESSIBILITY),
                    new Step("Check notification access", "Only apps you trust should read your notifications.",
                            "Notification access", A_NOTIF_ACCESS),
                    new Step("Run SafeSphere's app scan", "Device → App permissions shows apps holding sensitive access.",
                            "Open Device", A_SECURITY),
                    new Step("Uninstall if unsure", "If you don't recognise or need the app, remove it.")),

            new Incident("sent_money", "I sent money to a suspected scammer",
                    "Speed matters: providers can sometimes hold funds that haven't been withdrawn yet.", true,
                    OFFICIAL_CONTACT,
                    new Step("Ask to dispute or flag the transfer", "Give the reference number, amount, time and the "
                            + "recipient's account name and number."),
                    EVIDENCE, REPORT_PH, NO_RECOVERY_AGENTS),

            new Incident("account_compromised", "My account may have been compromised",
                    "Signs: messages you didn't send, password-change e-mails, unknown logins.", true,
                    new Step("Use the official recovery page", "Open the service's app or type its address yourself and choose "
                            + "\"Forgot password\" or \"Account hacked\"."),
                    new Step("Change the password from a safe device", "Use a long, unique password.", "Check a password",
                            A_PASSWORD),
                    new Step("Sign out all other sessions", "Remove devices and apps you don't recognise."),
                    new Step("Check recovery e-mail, phone and forwarding", "Attackers often change these to keep access."),
                    new Step("Turn on 2-step verification", "Prefer an authenticator app or passkey."),
                    new Step("Warn your contacts", "Tell friends not to send money or codes to anyone using your account."),
                    EVIDENCE),

            new Incident("sim_compromised", "My SIM card may have been compromised",
                    "Signs: signal suddenly lost, calls fail, OTP texts stop arriving.", true,
                    new Step("Contact your mobile network", "From another phone, use the network's official hotline or store. "
                            + "Ask them to block the SIM and stop any SIM replacement you didn't request."),
                    new Step("Alert your bank and e-wallets", "Your OTPs may be going to the attacker. Ask providers to secure "
                            + "your accounts.", null, A_NONE),
                    new Step("Change passwords that rely on SMS codes", "Start with e-mail, then banking and e-wallets."),
                    new Step("Move to app-based verification", "Use an authenticator app or passkey where the service allows it."),
                    EVIDENCE, REPORT_PH),
    };

    private RecoveryGuide() {}

    static Incident byId(String id) {
        for (Incident i : INCIDENTS) if (i.id.equals(id)) return i;
        return INCIDENTS[0];
    }

    static Set<Integer> doneSet(String csv) {
        Set<Integer> s = new HashSet<>();
        if (csv == null || csv.isEmpty()) return s;
        for (String p : csv.split(",")) {
            try { s.add(Integer.parseInt(p.trim())); } catch (NumberFormatException ignored) { }
        }
        return s;
    }

    static String doneCsv(Set<Integer> s) {
        StringBuilder sb = new StringBuilder();
        for (Integer i : new java.util.TreeSet<>(s)) {
            if (sb.length() > 0) sb.append(',');
            sb.append(i);
        }
        return sb.toString();
    }

    /** Plain-text evidence report the user can share. Contains only what the user typed and ticked. */
    static String report(EventLog.Incident rec) {
        Incident g = byId(rec.type);
        Set<Integer> done = doneSet(rec.stepsDone);
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.SHORT, Locale.getDefault());
        StringBuilder sb = new StringBuilder();
        sb.append("SafeSphere incident report\n");
        sb.append("==========================\n\n");
        sb.append("Incident: ").append(g.title).append('\n');
        sb.append("When it happened: ").append(df.format(new Date(rec.occurredAt))).append('\n');
        if (rec.sender != null && !rec.sender.trim().isEmpty()) {
            sb.append("Suspicious sender / website: ").append(rec.sender.trim()).append('\n');
        }
        sb.append('\n');
        if (rec.description != null && !rec.description.trim().isEmpty()) {
            sb.append("What happened:\n").append(rec.description.trim()).append("\n\n");
        }
        if (rec.actionsTaken != null && !rec.actionsTaken.trim().isEmpty()) {
            sb.append("Actions already taken:\n").append(rec.actionsTaken.trim()).append("\n\n");
        }
        sb.append("Recovery steps completed (").append(done.size()).append(" of ").append(g.steps.length).append("):\n");
        for (int i = 0; i < g.steps.length; i++) {
            sb.append(done.contains(i) ? "  [x] " : "  [ ] ").append(g.steps[i].title).append('\n');
        }
        sb.append("\nReport created ").append(df.format(new Date())).append(" with SafeSphere.\n");
        sb.append("The details above were entered by the user and were not verified by SafeSphere.\n");
        return sb.toString();
    }
}
