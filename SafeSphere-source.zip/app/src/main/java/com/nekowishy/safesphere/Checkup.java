package com.nekowishy.safesphere;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

/** Account Security Checkup items for the phone, Google, Facebook and GCash. */
final class Checkup {

    static final int MANUAL = 0, AUTO_PROTECTION = 1, AUTO_SCREEN_LOCK = 2;
    static final int ACT_NONE = 0, ACT_URL = 1, ACT_SETTINGS = 2, ACT_APP = 3, ACT_DIAL = 4, ACT_PROTECT = 5;

    static final class Item {
        final String id, group, title, detail, button;
        final int auto, action;
        final String[] targets;

        Item(String id, String group, String title, String detail, String button, int auto, int action, String... targets) {
            this.id = id;
            this.group = group;
            this.title = title;
            this.detail = detail;
            this.button = button;
            this.auto = auto;
            this.action = action;
            this.targets = targets;
        }
    }

    private static final String PHONE = "This phone";
    private static final String GOOGLE = "Google account";
    private static final String FACEBOOK = "Facebook & Messenger";
    private static final String GCASH = "GCash & banks";
    private static final String FB_SECURITY = "https://accountscenter.facebook.com/password_and_security";

    static final Item[] ITEMS = {
            new Item("protect", PHONE, "SafeSphere protection is on",
                    "Blocks malware, phishing and fake sites in every app.", "TURN ON", AUTO_PROTECTION, ACT_PROTECT),
            new Item("lock", PHONE, "Screen lock is set",
                    "A PIN, pattern or fingerprint stops others from opening your e-wallet and chats.", "OPEN SETTINGS",
                    AUTO_SCREEN_LOCK, ACT_SETTINGS, Settings.ACTION_SECURITY_SETTINGS),
            new Item("playprotect", PHONE, "Google Play Protect is on",
                    "Scans your apps for malware. Make sure \"Scan apps with Play Protect\" is ON.", "OPEN",
                    MANUAL, ACT_SETTINGS, "com.google.android.gms.settings.VERIFY_APPS_SETTINGS", Settings.ACTION_SECURITY_SETTINGS),
            new Item("update", PHONE, "Phone software is up to date",
                    "Updates fix security holes that scammers use. Look for System or Software update.", "OPEN",
                    MANUAL, ACT_SETTINGS, "android.settings.SYSTEM_UPDATE_SETTINGS", Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_SETTINGS),

            new Item("g2sv", GOOGLE, "Turn on 2-Step Verification",
                    "Even with your password, nobody can sign in without your phone.", "OPEN",
                    MANUAL, ACT_URL, "https://myaccount.google.com/signinoptions/two-step-verification"),
            new Item("gcheck", GOOGLE, "Run Google Security Checkup",
                    "Google's own scan for risky settings, apps and sign-ins.", "OPEN",
                    MANUAL, ACT_URL, "https://myaccount.google.com/security-checkup"),
            new Item("gdevices", GOOGLE, "Remove devices you don't recognize",
                    "Sign out any phone or computer that isn't yours.", "OPEN",
                    MANUAL, ACT_URL, "https://myaccount.google.com/device-activity"),
            new Item("gpasswords", GOOGLE, "Check saved passwords for leaks",
                    "Finds passwords exposed in data breaches so you can change them.", "OPEN",
                    MANUAL, ACT_URL, "https://passwords.google.com/checkup"),

            new Item("f2fa", FACEBOOK, "Turn on two-factor authentication",
                    "In Password and security, tap Two-factor authentication.", "OPEN",
                    MANUAL, ACT_URL, FB_SECURITY),
            new Item("fsessions", FACEBOOK, "Log out devices you don't recognize",
                    "In Password and security, tap Where you're logged in.", "OPEN",
                    MANUAL, ACT_URL, FB_SECURITY),
            new Item("falerts", FACEBOOK, "Turn on login alerts",
                    "In Password and security, tap Login alerts so you're warned about unknown logins.", "OPEN",
                    MANUAL, ACT_URL, FB_SECURITY),

            new Item("mpin", GCASH, "Never share your MPIN or OTP",
                    "GCash, Maya and banks will never ask for them by text, call, chat or link.", "I UNDERSTAND",
                    MANUAL, ACT_NONE),
            new Item("gcashlogin", GCASH, "Secure your GCash login",
                    "In GCash: Profile → Settings → Security. Turn on biometrics and check your registered device.", "OPEN GCASH",
                    MANUAL, ACT_APP, "com.globe.gcash.android"),
            new Item("report", GCASH, "Know where to report scams",
                    "Call the CICC Inter-Agency Response Center hotline 1326 to report scams.", "CALL 1326",
                    MANUAL, ACT_DIAL, "1326"),
    };

    private Checkup() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("checkup", Context.MODE_PRIVATE);
    }

    static boolean isDone(Context c, Item i) {
        if (i.auto == AUTO_PROTECTION) return SafeSphereVpnService.isRunning();
        if (i.auto == AUTO_SCREEN_LOCK) {
            KeyguardManager km = c.getSystemService(KeyguardManager.class);
            return km != null && km.isDeviceSecure();
        }
        return prefs(c).getBoolean(i.id, false);
    }

    static void setDone(Context c, Item i, boolean done) {
        prefs(c).edit().putBoolean(i.id, done).apply();
    }

    static int doneCount(Context c) {
        int n = 0;
        for (Item i : ITEMS) if (isDone(c, i)) n++;
        return n;
    }
}
