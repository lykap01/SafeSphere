package com.nekowishy.safesphere;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** "Block number" button on a call warning. Not exported: only SafeSphere's own notification can send it. */
public class CallActionReceiver extends BroadcastReceiver {

    static final String ACTION_BLOCK = "com.nekowishy.safesphere.BLOCK_NUMBER";
    static final String EXTRA_NUMBER = "number";
    static final String EXTRA_NOTIFICATION = "notification";

    @Override
    public void onReceive(Context c, Intent i) {
        if (!ACTION_BLOCK.equals(i.getAction())) return;
        String n = CallGuard.block(c, i.getStringExtra(EXTRA_NUMBER));
        if (n == null) return;
        EventLog.get(c).record(EventLog.CAT_CALL, "", "You blocked " + CallGuard.mask(n), System.currentTimeMillis());
        Alerts.callBlocked(c, n, i.getIntExtra(EXTRA_NOTIFICATION, 0));
    }
}
