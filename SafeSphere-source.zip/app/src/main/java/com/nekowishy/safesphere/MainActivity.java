package com.nekowishy.safesphere;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SafeSphere's single activity. One navigation system: the bottom bar (Shield, Check, Rules, History,
 * Device). Sub-pages (Recovery Center, Account checkup, App lock...) show a back arrow in the header.
 * The header's overflow menu only holds pages that are not reachable anywhere else.
 */
public class MainActivity extends Activity {

    static final String EXTRA_TAB = "tab";
    static final int TAB_SHIELD = 0, TAB_CHECK = 1, TAB_RULES = 2, TAB_HISTORY = 3, TAB_DEVICE = 4;
    static final int PAGE_CHECKUP = 10, PAGE_APPLOCK = 11, PAGE_RECOVERY = 12, PAGE_INCIDENT = 13, PAGE_INTEL = 14,
            PAGE_PRIVACY = 15, PAGE_ABOUT = 16, PAGE_MESSAGE = 17;
    // Extras of the scam-message notification (opens the Message warning page). Message text is never passed.
    static final String EXTRA_ALERT_APP = "alertApp", EXTRA_ALERT_HOST = "alertHost", EXTRA_ALERT_DANGER = "alertDanger",
            EXTRA_ALERT_WHY = "alertWhy", EXTRA_ALERT_REASONS = "alertReasons", EXTRA_ALERT_TIME = "alertTime";
    /** Kept for intents created by Build 15 code (notifications). */
    static final int TAB_APPS = TAB_DEVICE, TAB_APPLOCK = PAGE_APPLOCK;

    private static final int REQ_VPN = 10;
    private static final int REQ_NOTIFY = 11;
    static final int REQ_QR = 12;
    private static final int[] TAB_ICONS = {NavIcon.SHIELD, NavIcon.SEARCH, NavIcon.RULES, NavIcon.HISTORY, NavIcon.DEVICE};
    private static final String[] TAB_NAMES = {"Shield", "Check", "Rules", "History", "Device"};

    final Handler handler = new Handler(Looper.getMainLooper());
    final ExecutorService bg = Executors.newCachedThreadPool();
    private final TextView[] tabLabels = new TextView[TAB_NAMES.length];
    private final NavIcon[] tabIcons = new NavIcon[TAB_NAMES.length];
    private final View[] tabItems = new View[TAB_NAMES.length];
    private TextView title;
    private TextView subtitle;
    private FrameLayout snackHost;
    private Intent alert; // the scam-message notification being shown on PAGE_MESSAGE
    private View logo;
    private final FrameLayout[] tabTiles = new FrameLayout[TAB_NAMES.length];
    private FrameLayout backButton;
    private ScrollView scroll;
    private FrameLayout page;
    private int current = -1;
    private final ArrayDeque<Integer> backStack = new ArrayDeque<>();
    Runnable refresher;

    final CheckPage checkPage = new CheckPage(this);
    final RecoveryPage recoveryPage = new RecoveryPage(this);

    private List<AppScanner.AppRisk> lastScan;
    private boolean scanning, auditing;
    private String historyFilter;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (refresher != null) refresher.run();
            handler.postDelayed(this, 1500);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        RuleStore.init(this);
        Alerts.channels(this);
        Context app = getApplicationContext();
        bg.execute(() -> ThreatDb.ensureLoaded(app));
        bg.execute(() -> {
            DeviceAudit.run(app);
            runOnUiThread(() -> { if (current == TAB_SHIELD || current == TAB_DEVICE) show(current); });
        });
        WifiGuard.start(app);
        getWindow().setStatusBarColor(Ui.SKY);
        getWindow().setNavigationBarColor(Ui.BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); // dark icons on the light bars

        LinearLayout root = Ui.vbox(this);
        root.setBackground(new Bevel.Page(Ui.dp(this, 2))); // Build 15: soft sky gradient with embossed corner circle

        // Header (Build 15): logo + title + tagline, one raised ⋮ button. No History shortcut, no hamburger.
        LinearLayout header = Ui.hbox(this);
        header.setPadding(Ui.dp(this, 20), Ui.dp(this, 14), Ui.dp(this, 20), Ui.dp(this, 10));
        int hb = Ui.dp(this, 44);
        backButton = iconButton(NavIcon.BACK, "Back", v -> onBackPressed());
        header.addView(backButton, new LinearLayout.LayoutParams(hb, hb));
        logo = new LogoView(this, Ui.TEXT);
        logo.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        header.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 30), Ui.dp(this, 30)));
        LinearLayout titles = Ui.vbox(this);
        title = Ui.display(this, "SafeSphere", 23, Ui.TEXT);
        title.setTypeface(Ui.serif(this, false));
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(title);
        subtitle = Ui.text(this, "", 12, Ui.TEXT2, false);
        subtitle.setSingleLine(true);
        subtitle.setEllipsize(TextUtils.TruncateAt.END);
        titles.addView(subtitle);
        LinearLayout.LayoutParams tlp = Ui.params(0, Ui.WRAP, 1f);
        tlp.leftMargin = Ui.dp(this, 12);
        header.addView(titles, tlp);
        FrameLayout more = iconButton(NavIcon.MORE, "More options", v -> showOverflow(v));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(hb, hb);
        mlp.leftMargin = Ui.dp(this, 10);
        header.addView(more, mlp);
        root.addView(header);

        FrameLayout stage = new FrameLayout(this);
        page = new FrameLayout(this);
        stage.addView(page, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        snackHost = new FrameLayout(this);
        FrameLayout.LayoutParams shp = new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.BOTTOM);
        shp.leftMargin = shp.rightMargin = Ui.dp(this, 20);
        shp.bottomMargin = Ui.dp(this, 10);
        stage.addView(snackHost, shp);
        root.addView(stage, Ui.params(Ui.MATCH, 0, 1f));

        // Floating raised navigation bar (Build 15), selected tab on a glowing blue tile
        LinearLayout nav = Ui.hbox(this);
        nav.setBackground(Bevel.raised(Ui.dp(this, 30), Ui.dp(this, 1.6f)));
        Ui.shadow(nav, 10, Ui.SHADOW);
        int np = Ui.dp(this, 6);
        nav.setPadding(np, np, np, np);
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int index = i;
            LinearLayout item = Ui.vbox(this);
            item.setGravity(Gravity.CENTER);
            item.setMinimumHeight(Ui.dp(this, 60));
            item.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
            NavIcon icon = new NavIcon(this, TAB_ICONS[i], Ui.TEXT2);
            icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            FrameLayout tile = new FrameLayout(this);
            tile.addView(icon, Ui.frame(Ui.dp(this, 23), Ui.dp(this, 23), Gravity.CENTER));
            item.addView(tile, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 34)));
            tabTiles[i] = tile;
            TextView label = Ui.text(this, TAB_NAMES[i], Ui.LABEL, Ui.TEXT2, false);
            label.setGravity(Gravity.CENTER);
            label.setSingleLine(true);
            label.setPadding(0, Ui.dp(this, 3), 0, 0);
            label.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11);
            item.addView(label);
            item.setClickable(true);
            item.setFocusable(true);
            item.setContentDescription(TAB_NAMES[i]);
            item.setOnClickListener(v -> { Ui.tap(tile); show(index); });
            tabLabels[i] = label;
            tabIcons[i] = icon;
            tabItems[i] = item;
            nav.addView(item, Ui.params(0, Ui.WRAP, 1f));
        }
        LinearLayout.LayoutParams navLp = Ui.params(Ui.MATCH, Ui.WRAP, 0f);
        navLp.leftMargin = Ui.dp(this, 14);
        navLp.rightMargin = Ui.dp(this, 14);
        navLp.topMargin = Ui.dp(this, 4);
        navLp.bottomMargin = Ui.dp(this, 12);
        root.addView(nav, navLp);
        setContentView(root);

        askNotificationPermission();
        AppLock.start(this);
        if (checkPage.handleShared(getIntent())) return;
        if (!openAlert(getIntent())) show(getIntent().getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    /** A tap on a scam-message notification opens its Message warning page. */
    private boolean openAlert(Intent i) {
        if (i == null || !i.hasExtra(EXTRA_ALERT_WHY)) return false;
        alert = new Intent(i);
        i.removeExtra(EXTRA_ALERT_WHY); // don't reopen it after rotation or Back
        if (current < 0) render(TAB_HISTORY, false);
        open(PAGE_MESSAGE);
        return true;
    }

    private FrameLayout iconButton(int icon, String description, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        NavIcon ic = new NavIcon(this, icon, Ui.TEXT);
        f.addView(ic, Ui.frame(Ui.dp(this, 22), Ui.dp(this, 22), Gravity.CENTER));
        f.setBackground(Ui.ripple(Bevel.raised(Ui.dp(this, 15), Ui.dp(this, 1.4f)), null)); // Build 15 raised square
        Ui.shadow(f, 4, Ui.SHADOW);
        f.setClickable(true);
        f.setFocusable(true);
        f.setContentDescription(description);
        f.setOnClickListener(v -> { Ui.tap(v); l.onClick(v); });
        return f;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (checkPage.handleShared(intent)) return;
        if (openAlert(intent)) return;
        if (intent.hasExtra(EXTRA_TAB)) show(intent.getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        // The user may be back from Android settings: re-read what can be verified.
        if (current == TAB_DEVICE || current == TAB_SHIELD) runAudit();
        if (current == TAB_CHECK) checkPage.refreshAlertsCard();
        if (current == PAGE_APPLOCK) {
            AppLock.start(this);
            show(PAGE_APPLOCK);
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (!backStack.isEmpty()) {
            int prev = backStack.pop();
            render(prev, false);
            return;
        }
        if (current != TAB_SHIELD && current >= 0) {
            show(TAB_SHIELD);
            return;
        }
        super.onBackPressed();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
    }

    // ------------------------------------------------------------------ navigation

    /** Opens a bottom-navigation tab (clears the sub-page history) or re-draws the current page. */
    void show(int target) {
        if (target >= PAGE_CHECKUP) {
            if (target == current) render(target, true);
            else open(target);
            return;
        }
        if (target < 0 || target > TAB_DEVICE) target = TAB_SHIELD;
        if (target != current) backStack.clear();
        render(target, target == current);
    }

    /** Opens a sub-page on top of the current one. Back returns to where the user was. */
    void open(int subPage) {
        if (current >= 0 && current != subPage) backStack.push(current);
        render(subPage, false);
    }

    private static int parentTab(int p) {
        switch (p) {
            case PAGE_CHECKUP: case PAGE_APPLOCK: return TAB_DEVICE;
            case PAGE_INTEL: case PAGE_RECOVERY: case PAGE_INCIDENT: return TAB_SHIELD;
            case PAGE_MESSAGE: return TAB_HISTORY;
            default: return -1;
        }
    }

    private String subtitleFor(int p) {
        switch (p) {
            case TAB_SHIELD: return "Real-time online activity guardian";
            case TAB_CHECK: return "Check a link or message first";
            case TAB_RULES: return "Sites you block or allow";
            case TAB_HISTORY: return "Everything SafeSphere did for you";
            case TAB_DEVICE: return "What's left to make this phone safe";
            case PAGE_RECOVERY: return "Step-by-step help after a scam";
            case PAGE_MESSAGE: return alert == null ? "" : "From " + alert.getStringExtra(EXTRA_ALERT_APP) + " · "
                    + android.text.format.DateUtils.getRelativeTimeSpanString(alert.getLongExtra(EXTRA_ALERT_TIME,
                    System.currentTimeMillis()), System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS);
            default: return "";
        }
    }

    private String titleFor(int p) {
        switch (p) {
            case TAB_CHECK: return "Before you act";
            case TAB_RULES: return "Rules";
            case TAB_HISTORY: return "Security activity";
            case TAB_DEVICE: return "Protection gaps";
            case PAGE_CHECKUP: return "Account checkup";
            case PAGE_APPLOCK: return "App lock";
            case PAGE_RECOVERY: return "Recovery Center";
            case PAGE_INCIDENT: return recoveryPage.incidentTitle();
            case PAGE_INTEL: return "Threat intelligence";
            case PAGE_PRIVACY: return "Privacy & permissions";
            case PAGE_ABOUT: return "About & limitations";
            case PAGE_MESSAGE: return "Message warning";
            default: return "SafeSphere";
        }
    }

    private void render(int p, boolean keepScroll) {
        boolean refresh = keepScroll && p == current && scroll != null;
        int keepY = refresh ? scroll.getScrollY() : 0;
        current = p;
        boolean sub = p >= PAGE_CHECKUP;
        backButton.setVisibility(sub ? View.VISIBLE : View.GONE);
        logo.setVisibility(sub ? View.GONE : View.VISIBLE);
        title.setText(titleFor(p));
        String sl = subtitleFor(p);
        subtitle.setText(sl);
        subtitle.setVisibility(sl.isEmpty() ? View.GONE : View.VISIBLE);
        int highlight = sub ? parentTab(p) : p;
        if (sub && highlight < 0 && !backStack.isEmpty()) {
            for (Integer b : backStack) if (b < PAGE_CHECKUP) { highlight = b; break; }
        }
        for (int i = 0; i < tabLabels.length; i++) {
            boolean sel = i == highlight;
            tabLabels[i].setTextColor(sel ? Ui.ACCENT : Ui.TEXT2);
            tabLabels[i].setTypeface(Ui.sans(this, sel ? 600 : 500));
            tabIcons[i].setColor(sel ? Ui.WHITE : Ui.TEXT2);
            tabItems[i].setSelected(sel);
            tabTiles[i].setBackground(sel ? Bevel.blue(Ui.dp(this, 13), Ui.dp(this, 1.2f)) : null);
        }
        refresher = null;
        LinearLayout content = Ui.vbox(this);
        int pad = Ui.dp(this, 16);
        content.setPadding(pad, Ui.dp(this, 4), pad, Ui.dp(this, 24));
        switch (p) {
            case TAB_CHECK: checkPage.build(content); break;
            case TAB_RULES: buildRules(content); break;
            case TAB_HISTORY: buildHistory(content); break;
            case TAB_DEVICE: buildDevice(content); break;
            case PAGE_CHECKUP: buildCheckup(content); break;
            case PAGE_APPLOCK: buildAppLock(content); break;
            case PAGE_RECOVERY: recoveryPage.buildList(content); break;
            case PAGE_INCIDENT: recoveryPage.buildIncident(content); break;
            case PAGE_INTEL: buildIntel(content); break;
            case PAGE_PRIVACY: buildPrivacy(content); break;
            case PAGE_ABOUT: buildAbout(content); break;
            case PAGE_MESSAGE: buildMessageWarning(content); break;
            default: buildShield(content); break;
        }
        content.setFocusableInTouchMode(true);
        content.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        if (refresh) {
            ScrollView sv = scroll;
            sv.removeAllViews();
            sv.addView(content);
            content.requestFocus();
            sv.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                @Override
                public boolean onPreDraw() {
                    sv.getViewTreeObserver().removeOnPreDrawListener(this);
                    sv.scrollTo(0, keepY);
                    return false;
                }
            });
        } else {
            ScrollView sv = new ScrollView(this);
            sv.setFillViewport(true);
            sv.setClipToPadding(false);
            sv.addView(content);
            page.removeAllViews();
            page.addView(sv);
            scroll = sv;
            content.requestFocus();
            for (int i = 0; i < content.getChildCount(); i++) Ui.enter(content.getChildAt(i), i); // Build 15 slide-in
        }
        if (refresher != null) refresher.run();
    }

    int currentPage() { return current; }

    private void showOverflow(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add(0, 1, 0, "Privacy & permissions");
        menu.getMenu().add(0, 2, 1, "About & limitations");
        menu.setOnMenuItemClickListener(item -> {
            open(item.getItemId() == 1 ? PAGE_PRIVACY : PAGE_ABOUT);
            return true;
        });
        menu.show();
    }

    void add(LinearLayout parent, View child) {
        parent.addView(child, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
    }

    void section(LinearLayout parent, String s) {
        parent.addView(Ui.section(this, s));
    }

    // ------------------------------------------------------------------ Shield

    private void buildShield(LinearLayout col) {
        FrameLayout statusHolder = new FrameLayout(this);
        col.addView(statusHolder, Ui.margins(this, Ui.MATCH, Ui.WRAP, 6));
        final String[] shown = {null};
        Runnable paintStatus = () -> {
            ProtectionState ps = ProtectionState.compute(this);
            List<DeviceAudit.Check> checks = DeviceAudit.last();
            DeviceAudit.Progress pr = checks == null ? null : DeviceAudit.progress(checks);
            String sig = ps.state + "|" + ps.title + "|" + ps.detail + "|" + ps.gaps + "|"
                    + (pr == null ? "-" : pr.done + "/" + pr.applicable) + "|" + Prefs.privateDnsBypasses(this);
            if (sig.equals(shown[0])) return;
            shown[0] = sig;
            statusHolder.removeAllViews();
            statusHolder.addView(statusCard(ps, pr));
        };
        paintStatus.run();
        if (DeviceAudit.last() == null) runAudit();

        add(col, aiCard());

        // Before you act: one tappable card that opens the Check tab
        LinearLayout act = Ui.card(this);
        LinearLayout actRow = Ui.hbox(this);
        actRow.addView(blueIcon(NavIcon.SEARCH), new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        LinearLayout actTexts = Ui.vbox(this);
        actTexts.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 8), 0);
        actTexts.addView(Ui.display(this, "Before you act", 18, Ui.TEXT));
        TextView actSub = Ui.support(this, "Paste a link or message. We'll tell you if it's safe to open, pay or reply.");
        actSub.setPadding(0, Ui.dp(this, 3), 0, 0);
        actTexts.addView(actSub);
        actRow.addView(actTexts, Ui.params(0, Ui.WRAP, 1f));
        actRow.addView(Ui.chevron(this));
        act.addView(actRow);
        Ui.clickable(act, "Before you act: check a link or message", v -> show(TAB_CHECK));
        act.setBackground(Ui.ripple(Bevel.raised(Ui.dp(this, 26), Ui.dp(this, 1.6f)), null));
        add(col, act);

        // This week
        LinearLayout week = Ui.card(this);
        LinearLayout wh = Ui.hbox(this);
        wh.addView(Ui.display(this, "This week", 18, Ui.TEXT), Ui.params(0, Ui.WRAP, 1f));
        wh.addView(Ui.support(this, "Last 7 days"));
        week.addView(wh);
        LinearLayout nums = Ui.hbox(this);
        nums.setPadding(0, Ui.dp(this, 12), 0, 0);
        TextView vBlocked = stat(nums, "Sites blocked", Ui.DANGER, false);
        TextView vMsgs = stat(nums, "Scam messages", Ui.SUSPICIOUS, true);
        TextView vChecks = stat(nums, "Checks run", Ui.INFO, true);
        week.addView(nums);
        BarsView bars = new BarsView(this);
        week.addView(bars, Ui.margins(this, Ui.MATCH, Ui.dp(this, 110), 14));
        add(col, week);

        // Recovery Center entry (not reachable from the bottom bar)
        LinearLayout rec = Ui.listCard(this);
        long open = EventLog.get(this).openIncidentCount();
        rec.addView(Ui.row(this, Ui.statusDot(this, Ui.T_INFO), "Recovery Center",
                "Clicked a link, shared a code or sent money? Get a step-by-step recovery checklist."
                        + (open > 0 ? "\n" + open + " saved incident report" + (open == 1 ? "" : "s") : ""),
                Ui.chevron(this), v -> open(PAGE_RECOVERY)));
        add(col, rec);

        // Threat intelligence + Wi-Fi
        section(col, "Protection details");
        LinearLayout details = Ui.listCard(this);
        FrameLayout intelHolder = new FrameLayout(this);
        details.addView(intelHolder);
        details.addView(Ui.divider(this));
        FrameLayout wifiHolder = new FrameLayout(this);
        details.addView(wifiHolder);
        details.addView(Ui.divider(this));
        details.addView(Ui.row(this, null, "Test protection", "Safely checks that blocking works. No website is visited.",
                Ui.chevron(this), v -> new AlertDialog.Builder(this)
                        .setTitle("Test protection")
                        .setItems(new CharSequence[]{"Malware site test", "Fake-site test"}, (d, w) -> runLiveTest(w == 1))
                        .show()));
        col.addView(details);

        final long[] shownId = {-1};
        final String[] intelSig = {null}, wifiSig = {null};
        refresher = () -> {
            paintStatus.run();
            EventLog log = EventLog.get(this);
            long since = startOfToday() - 6L * 86_400_000L;
            long latest = log.latestId();
            if (latest != shownId[0]) {
                shownId[0] = latest;
                vBlocked.setText(String.valueOf(log.countSince(EventLog.CAT_BLOCKED, since)));
                vMsgs.setText(String.valueOf(log.countSince(EventLog.CAT_MESSAGE, since)));
                vChecks.setText(String.valueOf(log.countSince(EventLog.CAT_CHECK, since)));
                String[] days = new String[7];
                SimpleDateFormat dayFmt = new SimpleDateFormat("EEE", Locale.getDefault());
                long today = startOfToday();
                for (int i = 0; i < 7; i++) days[i] = i == 6 ? "Today" : dayFmt.format(new Date(today - (6L - i) * 86_400_000L));
                bars.setData(log.countsPerDay(7, today), days);
            }
            int fresh = ThreatDb.freshness(this);
            String isig = fresh + ThreatDb.status(this);
            if (!isig.equals(intelSig[0])) {
                intelSig[0] = isig;
                intelHolder.removeAllViews();
                int tone = fresh == ThreatDb.FRESH ? Ui.T_SUCCESS : fresh == ThreatDb.AGING ? Ui.T_NEUTRAL
                        : fresh == ThreatDb.STALE ? Ui.T_WARNING : Ui.T_NEUTRAL;
                intelHolder.addView(Ui.row(this, null, "Threat intelligence", ThreatDb.status(this),
                        Ui.badge(this, tone, ThreatDb.freshnessLabel(fresh)), v -> open(PAGE_INTEL)));
            }
            String wsig;
            View wrow;
            if (!WifiGuard.supported()) {
                wsig = "unsupported";
                wrow = Ui.row(this, null, "Wi-Fi security", "This Android version doesn't report Wi-Fi security to apps.",
                        Ui.badge(this, Ui.T_NEUTRAL, "Unavailable"), null);
            } else {
                WifiGuard.Status ws = WifiGuard.current();
                if (ws == null) {
                    wsig = "none";
                    wrow = Ui.row(this, null, "Wi-Fi security", "Not connected to Wi-Fi.", Ui.badge(this, Ui.T_NEUTRAL, "Not on Wi-Fi"), null);
                } else {
                    wsig = ws.level + ws.title;
                    int tone = ws.level == WifiGuard.LEVEL_UNSAFE ? Ui.T_DANGER : ws.level == WifiGuard.LEVEL_CAUTION ? Ui.T_WARNING : Ui.T_SUCCESS;
                    wrow = Ui.row(this, null, ws.title, ws.detail, Ui.badge(this, tone,
                            ws.level == WifiGuard.LEVEL_SAFE ? "Secured" : ws.level == WifiGuard.LEVEL_CAUTION ? "Caution" : "Unsafe"), null);
                }
            }
            if (!wsig.equals(wifiSig[0])) {
                wifiSig[0] = wsig;
                wifiHolder.removeAllViews();
                wifiHolder.addView(wrow);
            }
        };
    }

    /** Shield hero (Build 15): blue glass card, status pill, animated shield dial, headline, one white pill toggle. */
    private View statusCard(ProtectionState ps, DeviceAudit.Progress pr) {
        LinearLayout c = Ui.vbox(this);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setBackground(new Bevel.Hero(Ui.dp(this, 32), Ui.dp(this, 1.6f)));
        Ui.shadow(c, 12, Ui.PRIMARY);
        int pad = Ui.dp(this, 20);
        c.setPadding(pad, Ui.dp(this, 18), pad, pad);
        boolean running = ps.state == ProtectionState.ACTIVE || ps.state == ProtectionState.PARTIAL;

        LinearLayout top = Ui.hbox(this);
        String word = ps.state == ProtectionState.ACTIVE ? "Protected" : ps.state == ProtectionState.PARTIAL ? "Partly protected"
                : ps.state == ProtectionState.INTERRUPTED ? "Stopped" : "Off";
        TextView pill = Ui.text(this, "●  " + word, Ui.LABEL, running ? 0xFF0A1A55 : Ui.WHITE, true);
        pill.setTypeface(Ui.sans(this, 600));
        pill.setPadding(Ui.dp(this, 12), Ui.dp(this, 5), Ui.dp(this, 12), Ui.dp(this, 5));
        pill.setBackground(Ui.rounded(running ? Ui.LIME : 0xFFD93A45, 0, 50, this));
        pill.setContentDescription("Protection status: " + ps.title);
        top.addView(pill);
        top.addView(new View(this), Ui.params(0, 1, 1f));
        if (pr != null && pr.applicable > 0) {
            TextView setup = Ui.text(this, "Setup " + pr.done + " of " + pr.applicable + "  ›", Ui.LABEL, 0xFFD6E2FF, true);
            setup.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), 0, Ui.dp(this, 12));
            Ui.clickable(setup, "Security setup: " + pr.done + " of " + pr.applicable + " checks done. Open Device.", v -> show(TAB_DEVICE));
            setup.setBackground(Ui.ripple(null, Ui.rounded(Ui.WHITE, 0, 12, this)));
            top.addView(setup);
        }
        c.addView(top, Ui.params(Ui.MATCH, Ui.WRAP, 0f));

        ShieldView dial = new ShieldView(this);
        dial.setActive(running);
        dial.setScore(pr == null || pr.applicable == 0 ? 0 : 100 * pr.done / pr.applicable);
        int size = Ui.dp(this, 176);
        c.addView(dial, new LinearLayout.LayoutParams(size, size));

        String headline = ps.state == ProtectionState.ACTIVE ? "You're *protected*."
                : ps.state == ProtectionState.PARTIAL ? "Protected, *with gaps*."
                : ps.state == ProtectionState.INTERRUPTED ? "Protection *stopped*." : "Protection is *off*.";
        TextView h = Ui.display(this, headline, 28, Ui.WHITE, running ? Ui.LIME : 0xFFFFB3B8);
        h.setGravity(Gravity.CENTER);
        c.addView(h);
        TextView d = Ui.text(this, ps.detail, Ui.SUPPORT, 0xFFDCE6FF, false);
        d.setGravity(Gravity.CENTER);
        d.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 4));
        c.addView(d);
        for (String gap : ps.gaps) {
            c.addView(Ui.banner(this, Ui.T_WARNING, "Coverage gap", gap), Ui.margins(this, Ui.MATCH, Ui.WRAP, 10));
        }
        if (Prefs.privateDnsBypasses(this)) {
            LinearLayout b = Ui.banner(this, Ui.T_DANGER, "Private DNS is skipping SafeSphere", "Tap to set it to Automatic or Off.");
            Ui.clickable(b, "Private DNS is skipping SafeSphere. Open network settings.",
                    v -> openSettings(Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS));
            c.addView(b, Ui.margins(this, Ui.MATCH, Ui.WRAP, 10));
        }
        boolean on = SafeSphereVpnService.isRunning();
        TextView btn = Ui.secondary(this, on ? "Turn off protection" : "Turn on protection", v -> toggleProtection());
        btn.setTextColor(Ui.NAVY);
        btn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
        Ui.shadow(btn, 6, 0xFF0A1A55);
        c.addView(btn, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
        TextView cover = Ui.link(this, "What does protection cover?", v -> info("What protection covers",
                ProtectionState.COVERS + "\n\nNot covered: " + ProtectionState.NOT_COVERED
                        + "\n\nSafeSphere works alongside Google Play Protect and your browser's Safe Browsing. It does not replace them."));
        cover.setTextColor(0xFFE4ECFF);
        cover.setGravity(Gravity.CENTER);
        c.addView(cover, Ui.params(Ui.WRAP, Ui.WRAP, 0f));
        return c;
    }

    /** SafeSphere AI on the Shield (Build 15 orb). The whole card is one button that opens the chat. */
    private View aiCard() {
        LinearLayout c = Ui.card(this);
        c.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 16));
        LinearLayout row = Ui.hbox(this);
        OrbView orb = new OrbView(this, true, 14);
        orb.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        row.addView(orb, new LinearLayout.LayoutParams(Ui.dp(this, 58), Ui.dp(this, 58)));
        LinearLayout texts = Ui.vbox(this);
        texts.setPadding(Ui.dp(this, 14), 0, 0, 0);
        texts.addView(Ui.display(this, "Ask SafeSphere *AI*", 18, Ui.TEXT));
        TextView sub = Ui.support(this, "Not sure about a message, link or caller? Ask before you reply.");
        sub.setPadding(0, Ui.dp(this, 3), 0, 0);
        texts.addView(sub);
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        c.addView(row);

        LinearLayout bar = Ui.hbox(this);
        bar.setBackground(Bevel.pressed(Ui.dp(this, 50), Ui.dp(this, 1.2f)));
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
        bar.addView(Ui.text(this, "\u201CIs this GCash text real?\u201D", Ui.BODY, Ui.TEXT2, false), Ui.params(0, Ui.WRAP, 1f));
        FrameLayout send = blueIcon(NavIcon.SEND);
        bar.addView(send, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
        bar.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        c.addView(bar, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        TextView note = Ui.text(this, "OTPs, passwords and card numbers are hidden before anything is sent.", 11, Ui.TEXT2, false);
        note.setPadding(Ui.dp(this, 4), Ui.dp(this, 8), 0, 0);
        c.addView(note);
        c.setBackground(Ui.ripple(Bevel.raised(Ui.dp(this, 26), Ui.dp(this, 1.6f)), null));
        Ui.clickable(c, "Ask SafeSphere AI about a message, link or caller", v -> startActivity(new Intent(this, AiChatActivity.class)));
        return c;
    }

    /** Glowing blue rounded square with a white icon (Build 15 style). */
    private FrameLayout blueIcon(int icon) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Bevel.blue(Ui.dp(this, 16), Ui.dp(this, 1.2f)));
        Ui.shadow(f, 4, Ui.PRIMARY);
        NavIcon ic = new NavIcon(this, icon, Ui.WHITE);
        ic.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        f.addView(ic, Ui.frame(Ui.dp(this, 22), Ui.dp(this, 22), Gravity.CENTER));
        f.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return f;
    }

    private TextView stat(LinearLayout row, String label) {
        return stat(row, label, Ui.TEXT, row.getChildCount() > 0);
    }

    /** A pressed-in stat tile with a coloured number (Build 15 stat tiles). */
    private TextView stat(LinearLayout row, String label, int color, boolean gap) {
        LinearLayout c = Ui.vbox(this);
        c.setBackground(Bevel.pressed(Ui.dp(this, 16), Ui.dp(this, 1.2f)));
        c.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
        TextView value = Ui.text(this, "0", 24, color, true);
        value.setTypeface(Ui.sans(this, 600));
        c.addView(value);
        TextView l = Ui.text(this, label, Ui.LABEL, Ui.TEXT2, true);
        c.addView(l);
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        if (gap) lp.leftMargin = Ui.dp(this, 10);
        row.addView(c, lp);
        return value;
    }

    // ------------------------------------------------------------------ feedback

    /**
     * Clear feedback for user actions: a dark bar slides up above the navigation with a coloured symbol,
     * the result in words and, where it makes sense, Undo. Screen readers announce it.
     */
    void snack(int tone, String message, String action, Runnable onAction) {
        if (snackHost == null) { toast(message); return; }
        snackHost.removeAllViews();
        LinearLayout bar = Ui.hbox(this);
        bar.setBackground(Ui.rounded(Ui.TEXT, 0, 18, this));
        Ui.shadow(bar, 10, Ui.TEXT);
        bar.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        bar.setMinimumHeight(Ui.dp(this, 52));
        int dot = tone == Ui.T_SUCCESS ? 0xFF3CCB8F : tone == Ui.T_DANGER ? 0xFFFF8A8A : tone == Ui.T_WARNING ? 0xFFF2B84B : 0xFF8FC0FF;
        TextView mark = Ui.text(this, Ui.glyph(tone), 12, Ui.TEXT, true);
        mark.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(dot);
        mark.setBackground(g);
        mark.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        bar.addView(mark, new LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)));
        TextView msg = Ui.text(this, message, Ui.BODY, Ui.WHITE, true);
        msg.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
        bar.addView(msg, Ui.params(0, Ui.WRAP, 1f));
        Runnable hide = () -> {
            if (bar.getParent() == null) return;
            bar.animate().alpha(0f).translationY(Ui.dp(this, 24)).setDuration(220)
                    .withEndAction(() -> snackHost.removeView(bar)).start();
        };
        if (action != null && onAction != null) {
            TextView act = Ui.text(this, action, Ui.BODY, 0xFF8FC0FF, true);
            act.setTypeface(Ui.sans(this, 600));
            act.setGravity(Gravity.CENTER);
            act.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
            act.setMinHeight(Ui.dp(this, 44));
            act.setMinimumHeight(Ui.dp(this, 44));
            act.setBackground(Ui.ripple(null, Ui.rounded(Ui.WHITE, 0, 12, this)));
            act.setClickable(true);
            act.setFocusable(true);
            act.setOnClickListener(v -> { hide.run(); onAction.run(); });
            bar.addView(act);
        }
        snackHost.addView(bar, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        bar.setAlpha(0f);
        bar.setTranslationY(Ui.dp(this, 40));
        bar.animate().alpha(1f).translationY(0f).setDuration(320)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.4f)).start();
        bar.announceForAccessibility(message);
        handler.postDelayed(hide, action != null ? 5000 : 3200);
    }

    void success(String message) { snack(Ui.T_SUCCESS, message, null, null); }

    void success(String message, String action, Runnable onAction) { snack(Ui.T_SUCCESS, message, action, onAction); }

    /** Block a site and confirm it, with Undo. */
    void blockWithUndo(String host, int returnTo) {
        RuleStore.addBlock(host);
        EventLog.get(this).record(EventLog.CAT_CHECK, host, "You blocked " + host, System.currentTimeMillis());
        show(returnTo);
        success("Blocked. " + host + " won't open on this phone.", "Undo", () -> {
            RuleStore.remove(host);
            show(returnTo);
            snack(Ui.T_INFO, host + " is no longer blocked", null, null);
        });
    }

    // ------------------------------------------------------------------ Message warning (from a scam-message notification)

    private void buildMessageWarning(LinearLayout col) {
        if (alert == null) { buildHistory(col); return; }
        String host = alert.getStringExtra(EXTRA_ALERT_HOST);
        boolean danger = alert.getBooleanExtra(EXTRA_ALERT_DANGER, false);
        String why = alert.getStringExtra(EXTRA_ALERT_WHY);
        String[] reasons = alert.getStringArrayExtra(EXTRA_ALERT_REASONS);
        int tone = danger ? Ui.T_DANGER : Ui.T_SUSPICIOUS;

        LinearLayout card = Ui.listCard(this);
        card.setPadding(0, 0, 0, Ui.dp(this, 6));
        LinearLayout head = Ui.hbox(this);
        head.setBackground(Ui.rounded(Ui.tint(tone), 0, 0, this));
        head.setPadding(Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 20), Ui.dp(this, 16));
        TextView icon = Ui.text(this, Ui.glyph(tone), 18, Ui.WHITE, true);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(Ui.fg(tone));
        icon.setBackground(g);
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        head.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        LinearLayout ht = Ui.vbox(this);
        ht.setPadding(Ui.dp(this, 12), 0, 0, 0);
        TextView lvl = Ui.text(this, danger ? "DANGEROUS" : "SUSPICIOUS", Ui.LABEL, Ui.fg(tone), true);
        lvl.setLetterSpacing(0.06f);
        ht.addView(lvl);
        ht.addView(Ui.display(this, host != null ? "Don't open this link" : "Don't reply or do what it asks", 19, Ui.TEXT));
        head.addView(ht, Ui.params(0, Ui.WRAP, 1f));
        card.addView(head);

        LinearLayout body = Ui.vbox(this);
        body.setPadding(Ui.dp(this, 20), Ui.dp(this, 14), Ui.dp(this, 20), Ui.dp(this, 12));
        if (host != null) {
            TextView h = Ui.text(this, host, Ui.BODY, Ui.TEXT, true);
            h.setBackground(Bevel.pressed(Ui.dp(this, 14), Ui.dp(this, 1.2f)));
            h.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11));
            h.setContentDescription("Link address: " + host);
            body.addView(h);
        }
        List<String> why2 = new ArrayList<>();
        if (why != null) why2.add(why);
        if (reasons != null) for (String r : reasons) if (r != null && !r.isEmpty() && !why2.contains(r) && why2.size() < 4) why2.add(r);
        TextView wl = Ui.text(this, "Why", Ui.SUPPORT, Ui.TEXT, true);
        wl.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 4));
        body.addView(wl);
        body.addView(Ui.bullets(this, why2));
        if (host != null && danger) {
            boolean on = SafeSphereVpnService.isRunning();
            if (on) {
                body.addView(Ui.badge(this, Ui.T_SUCCESS, "Blocked while protection is on"), Ui.margins(this, Ui.WRAP, Ui.WRAP, 14));
            } else {
                body.addView(Ui.banner(this, Ui.T_WARNING, "Protection is off", "Turn it on so this site can't open."),
                        Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
                body.addView(Ui.primary(this, "Turn on protection", v -> toggleProtection()), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
            }
        } else if (host != null && !RuleStore.blocked().contains(host)) {
            body.addView(Ui.primary(this, "Block this site", v -> blockWithUndo(host, PAGE_MESSAGE)), Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
        }
        card.addView(body);
        col.addView(card, Ui.margins(this, Ui.MATCH, Ui.WRAP, 6));

        LinearLayout todo = Ui.card(this);
        todo.addView(Ui.display(this, "What to do", 18, Ui.TEXT));
        List<String> steps = new ArrayList<>();
        steps.add(host != null ? "Don't log in or download anything from it." : "Don't reply, pay, or share any code.");
        steps.add("If a friend sent it, their account may be hacked. Tell them another way, like a call or text.");
        steps.add("Delete the message once you've told them.");
        TextView t = Ui.bullets(this, steps);
        t.setPadding(0, Ui.dp(this, 8), 0, 0);
        todo.addView(t);
        todo.addView(Ui.destructive(this, "I already typed my password", v -> recoveryPage.start("entered_password")),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 16));
        add(col, todo);
        col.addView(Ui.support(this, "SafeSphere only read the preview Android showed. The message itself was not saved or sent anywhere."),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
    }

    void toggleProtection() {
        if (SafeSphereVpnService.isRunning()) {
            requirePin("Enter your PIN to turn protection off.", () ->
                    new AlertDialog.Builder(this)
                            .setTitle("Turn off protection?")
                            .setMessage("Dangerous websites will no longer be blocked until you turn it on again.")
                            .setPositiveButton("Turn off", (d, w) -> {
                                startService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_STOP));
                                snack(Ui.T_INFO, "Protection turned off", null, null);
                                handler.postDelayed(() -> { if (current == TAB_SHIELD) show(TAB_SHIELD); }, 500);
                            })
                            .setNegativeButton("Cancel", null)
                            .show());
            return;
        }
        if (ProtectionState.otherVpnActive(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("Another VPN is connected")
                    .setMessage("Android allows one VPN at a time. Turning on SafeSphere will disconnect the other VPN app.")
                    .setPositiveButton("Continue", (d, w) -> requestVpn())
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        requestVpn();
    }

    private void requestVpn() {
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            try {
                startActivityForResult(consent, REQ_VPN);
            } catch (ActivityNotFoundException e) {
                toast("This phone does not allow VPN apps");
            }
        } else {
            onActivityResult(REQ_VPN, RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_QR) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) checkPage.readQr(data.getData());
            return;
        }
        if (requestCode != REQ_VPN) return;
        if (resultCode == RESULT_OK) {
            startForegroundService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_START));
            success("Protection is turning on");
            handler.postDelayed(() -> { if (current == TAB_SHIELD) show(TAB_SHIELD); }, 700);
        } else {
            toast("Protection needs the VPN connection request to be allowed");
        }
    }

    private void runLiveTest(boolean fakeSite) {
        if (!SafeSphereVpnService.isRunning()) {
            toast("Turn protection on first, then run the test");
            return;
        }
        String id = Integer.toHexString(new Random().nextInt(0xFFFFFF));
        String domain = fakeSite ? "gcash-verify-login-" + id + ".example" : "t" + id + "." + RuleStore.TEST_ZONE;
        long started = System.currentTimeMillis();
        toast("Testing…");
        bg.execute(() -> {
            try {
                InetAddress.getByName(domain);
            } catch (Exception ignored) {
                // expected: the lookup is refused
            }
            try { Thread.sleep(700); } catch (InterruptedException ignored) { }
            boolean passed = domain.equals(SafeSphereVpnService.lastBlocked) && SafeSphereVpnService.lastBlockedAt >= started;
            String why = RuleStore.check(domain);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(passed ? "Test passed" : "Test did not trigger")
                        .setMessage(passed
                                ? "SafeSphere refused the lookup for\n" + domain + "\nbefore any connection was made.\n\nReason: " + why
                                : "The test lookup did not reach SafeSphere. If Private DNS is set to a specific provider, "
                                + "set it to Automatic or Off, then try again.")
                        .setPositiveButton("OK", null)
                        .show();
            });
        });
    }

    // ------------------------------------------------------------------ Threat intelligence page

    private void buildIntel(LinearLayout col) {
        LinearLayout head = Ui.card(this);
        int fresh = ThreatDb.freshness(this);
        head.addView(Ui.badge(this, fresh == ThreatDb.FRESH ? Ui.T_SUCCESS : fresh == ThreatDb.STALE ? Ui.T_WARNING : Ui.T_NEUTRAL,
                ThreatDb.freshnessLabel(fresh)), new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        TextView size = Ui.text(this, String.format(Locale.US, "%,d known dangerous domains", ThreatDb.size()), 18, Ui.TEXT, true);
        size.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
        head.addView(size);
        TextView info = Ui.support(this, ThreatDb.status(this));
        head.addView(info);
        head.addView(Ui.support(this, "Updated automatically about once a day while protection is on. If a source fails, "
                + "its last good copy is kept."), Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        TextView update = Ui.primary(this, ThreatDb.isUpdating() ? "Updating…" : "Update now", null);
        update.setOnClickListener(v -> {
            if (ThreatDb.isUpdating()) return;
            update.setText("Updating…");
            update.setEnabled(false);
            Context app = getApplicationContext();
            bg.execute(() -> {
                String result = ThreatDb.update(app, msg -> runOnUiThread(() -> info.setText(msg)));
                runOnUiThread(() -> {
                    toast(result);
                    if (current == PAGE_INTEL) show(PAGE_INTEL);
                });
            });
        });
        head.addView(update, Ui.margins(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(head, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));

        section(col, "Sources");
        LinearLayout list = Ui.listCard(this);
        List<ThreatDb.FeedStatus> feeds = ThreatDb.feedStatus(this);
        for (int i = 0; i < feeds.size(); i++) {
            ThreatDb.FeedStatus f = feeds.get(i);
            if (i > 0) list.addView(Ui.divider(this));
            String sub;
            int tone;
            String label;
            if (f.okAt == 0) {
                sub = f.error != null ? "Never downloaded. Last error: " + f.error : "Not downloaded yet.";
                tone = f.error != null ? Ui.T_WARNING : Ui.T_NEUTRAL;
                label = f.error != null ? "Failed" : "Not downloaded";
            } else {
                sub = String.format(Locale.US, "%,d domains · last success %s", f.count, ago(f.okAt));
                if (f.error != null && f.triedAt > f.okAt) {
                    sub += "\nLast attempt failed (" + f.error + "). Using the previous copy.";
                    tone = Ui.T_WARNING;
                    label = "Using last copy";
                } else {
                    tone = Ui.T_SUCCESS;
                    label = "OK";
                }
            }
            list.addView(Ui.row(this, null, f.name, sub, Ui.badge(this, tone, label), null));
        }
        col.addView(list);
        col.addView(Ui.support(this, "Feeds: URLhaus domain list (malware-filter project), Phishing Army blocklist and HaGeZi "
                + "Threat Intelligence (mini). A domain is listed as dangerous only if one of these sources lists it. "
                + "SafeSphere's fake-brand patterns are reported separately as SafeSphere's own judgment."),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
    }

    static String ago(long t) {
        return android.text.format.DateUtils.getRelativeTimeSpanString(t, System.currentTimeMillis(),
                android.text.format.DateUtils.MINUTE_IN_MILLIS).toString();
    }

    // ------------------------------------------------------------------ Rules

    private void buildRules(LinearLayout col) {
        LinearLayout addCard = Ui.card(this);
        addCard.addView(Ui.cardTitle(this, "Add a rule"));
        addCard.addView(Ui.support(this, "Block a site on this phone, or always allow one that SafeSphere blocks by mistake."));
        EditText input = new EditText(this);
        input.setHint("example.com");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        Ui.field(input);
        addCard.addView(input, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        addCard.addView(Ui.pair(this,
                Ui.primary(this, "Block", v -> saveRule(input, true)),
                Ui.secondary(this, "Always allow", v -> saveRule(input, false))), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(addCard, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));

        section(col, "Blocked (" + RuleStore.blocked().size() + ")");
        col.addView(ruleList(RuleStore.blocked(), "No sites blocked by you yet."));
        section(col, "Always allowed (" + RuleStore.allowed().size() + ")");
        col.addView(ruleList(RuleStore.allowed(), "Nothing here. Add a site if SafeSphere blocks something you trust."));
    }

    private View ruleList(List<String> items, String emptyText) {
        LinearLayout c = Ui.listCard(this);
        if (items.isEmpty()) {
            TextView e = Ui.support(this, emptyText);
            e.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
            c.addView(e);
        }
        for (int i = 0; i < items.size(); i++) {
            String d = items.get(i);
            if (i > 0) c.addView(Ui.divider(this));
            TextView remove = Ui.link(this, "Remove", v -> requirePin("Enter your PIN to change protection rules.", () ->
                    new AlertDialog.Builder(this)
                            .setTitle("Remove " + d + "?")
                            .setPositiveButton("Remove", (dd, w) -> {
                                boolean wasBlocked = RuleStore.blocked().contains(d);
                                RuleStore.remove(d);
                                show(TAB_RULES);
                                success("Removed " + d, "Undo", () -> {
                                    if (wasBlocked) RuleStore.addBlock(d); else RuleStore.addAllow(d);
                                    show(TAB_RULES);
                                });
                            })
                            .setNegativeButton("Cancel", null)
                            .show()));
            remove.setContentDescription("Remove " + d);
            c.addView(Ui.row(this, null, d, null, remove, null));
        }
        return c;
    }

    private void saveRule(EditText input, boolean block) {
        String domain = RuleStore.normalize(input.getText().toString());
        if (domain == null) {
            input.setError("Enter a valid domain, like example.com");
            Ui.shake(input);
            return;
        }
        hideKeyboard(input);
        if (block) {
            RuleStore.addBlock(domain);
            show(TAB_RULES);
            success("Blocked " + domain, "Undo", () -> { RuleStore.remove(domain); show(TAB_RULES); });
            return;
        }
        requirePin("Enter your PIN to always allow a site.", () -> {
            RuleStore.addAllow(domain);
            show(TAB_RULES);
            success("Always allowed " + domain, "Undo", () -> { RuleStore.remove(domain); show(TAB_RULES); });
        });
    }

    void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ History (security activity)

    private static final String[][] FILTERS = {
            {null, "All"}, {EventLog.CAT_BLOCKED, "Blocked"}, {EventLog.CAT_MESSAGE, "Messages"}, {EventLog.CAT_CHECK, "Checks"},
            {EventLog.CAT_PROTECTION, "Protection"}, {EventLog.CAT_DEVICE, "Device"}, {EventLog.CAT_RECOVERY, "Recovery"}};

    private void buildHistory(LinearLayout col) {
        EventLog log = EventLog.get(this);
        long weekAgo = startOfToday() - 6L * 86_400_000L;

        if (Prefs.weeklySummary(this)) {
            LinearLayout sum = Ui.card(this);
            LinearLayout head = Ui.hbox(this);
            head.addView(Ui.cardTitle(this, "This week"), Ui.params(0, Ui.WRAP, 1f));
            head.addView(Ui.link(this, "Hide", v -> { Prefs.setWeeklySummary(this, false); show(TAB_HISTORY); }));
            sum.addView(head);
            sum.addView(Ui.support(this, "Calculated on this phone from your saved activity."));
            LinearLayout nums = Ui.hbox(this);
            nums.setPadding(0, Ui.dp(this, 12), 0, 0);
            stat(nums, "Sites blocked").setText(String.valueOf(log.countSince(EventLog.CAT_BLOCKED, weekAgo)));
            stat(nums, "Warnings").setText(String.valueOf(log.countSince(EventLog.CAT_MESSAGE, weekAgo)
                    + countWarningsFromChecks(log, weekAgo)));
            stat(nums, "Checks run").setText(String.valueOf(log.countSince(EventLog.CAT_CHECK, weekAgo)));
            sum.addView(nums);

            List<EventLog.DomainCount> repeated = log.repeatedDomains(weekAgo, 3);
            if (!repeated.isEmpty()) {
                TextView h = Ui.text(this, "Repeated threats", Ui.BODY, Ui.TEXT, true);
                h.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
                sum.addView(h);
                List<String> lines = new ArrayList<>();
                for (EventLog.DomainCount d : repeated) lines.add(d.domain + " — " + d.count + " times");
                sum.addView(Ui.bullets(this, lines));
                sum.addView(Ui.support(this, "Something on this phone keeps trying to reach these. If it continues, check "
                        + "recently installed apps."), Ui.margins(this, Ui.MATCH, Ui.WRAP, 4));
            }
            List<DeviceAudit.Check> checks = DeviceAudit.last();
            if (checks != null) {
                int open = DeviceAudit.progress(checks).attention;
                TextView dev = Ui.body(this, open == 0 ? "No unresolved device issues."
                        : open + " device setting" + (open == 1 ? " needs" : "s need") + " attention (see Device).");
                dev.setPadding(0, Ui.dp(this, 12), 0, 0);
                sum.addView(dev);
            }
            List<EventLog.Event> prot = log.recent(1, EventLog.CAT_PROTECTION);
            if (!prot.isEmpty()) {
                TextView p = Ui.support(this, "Last protection change: " + prot.get(0).reason + ", " + ago(prot.get(0).time));
                p.setPadding(0, Ui.dp(this, 4), 0, 0);
                sum.addView(p);
            }
            col.addView(sum, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        } else {
            LinearLayout c = Ui.listCard(this);
            c.addView(Ui.row(this, null, "Weekly summary is hidden", "Show a summary of the last 7 days, calculated on this phone.",
                    Ui.link(this, "Show", v -> { Prefs.setWeeklySummary(this, true); show(TAB_HISTORY); }), null));
            col.addView(c, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        }

        // Filters
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = Ui.hbox(this);
        chips.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 4));
        for (String[] f : FILTERS) {
            boolean sel = (f[0] == null && historyFilter == null) || (f[0] != null && f[0].equals(historyFilter));
            TextView chip = Ui.text(this, f[1], Ui.SUPPORT, Ui.WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setMinHeight(Ui.dp(this, 40));
            chip.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
            chip.setBackground(Ui.ripple(sel ? Bevel.blue(Ui.dp(this, 20), Ui.dp(this, 1)) : Bevel.raised(Ui.dp(this, 20), Ui.dp(this, 1)), null));
            chip.setClickable(true);
            chip.setContentDescription("Show " + f[1] + (sel ? ", selected" : ""));
            chip.setOnClickListener(v -> { historyFilter = f[0]; show(TAB_HISTORY); });
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.rightMargin = Ui.dp(this, 8);
            chips.addView(chip, lp);
        }
        hs.addView(chips);
        col.addView(hs);

        LinearLayout list = Ui.listCard(this);
        add(col, list);
        col.addView(Ui.support(this, "Saved only on this phone. SafeSphere stores the time, website name and a short reason, "
                + "never the text of your messages or your browsing history."), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        col.addView(Ui.destructive(this, "Clear history", v -> requirePin("Enter your PIN to clear the history.", () ->
                new AlertDialog.Builder(this)
                        .setTitle("Clear security activity?")
                        .setMessage("This deletes every saved event on this phone. Recovery incident reports are kept.")
                        .setPositiveButton("Clear", (d, w) -> {
                            EventLog.get(this).clear();
                            success("History cleared");
                            show(TAB_HISTORY);
                        })
                        .setNegativeButton("Cancel", null)
                        .show())), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        final long[] shownId = {-1};
        refresher = () -> {
            long latest = log.latestId();
            if (latest == shownId[0]) return;
            shownId[0] = latest;
            list.removeAllViews();
            List<EventLog.Event> events = log.recent(300, historyFilter);
            if (events.isEmpty()) {
                TextView t = Ui.support(this, historyFilter == null
                        ? "Nothing yet. Blocked sites, scam-message warnings, checks you run and protection changes will appear here."
                        : "No events in this category.");
                t.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
                list.addView(t);
                return;
            }
            for (int i = 0; i < events.size(); i++) {
                if (i > 0) list.addView(Ui.divider(this));
                list.addView(eventRow(events.get(i)));
            }
        };
    }

    private long countWarningsFromChecks(EventLog log, long since) {
        long n = 0;
        for (EventLog.Event e : log.recent(500, EventLog.CAT_CHECK)) {
            if (e.time >= since && (e.reason.contains("Suspicious") || e.reason.contains("Dangerous"))) n++;
        }
        return n;
    }

    static int eventTone(EventLog.Event e) {
        switch (e.category == null ? "" : e.category) {
            case EventLog.CAT_BLOCKED: return Ui.T_DANGER;
            case EventLog.CAT_MESSAGE: return Ui.T_SUSPICIOUS;
            case EventLog.CAT_CHECK:
                return e.reason.contains("Dangerous") ? Ui.T_DANGER : e.reason.contains("Suspicious") ? Ui.T_SUSPICIOUS
                        : e.reason.contains("careful") ? Ui.T_WARNING : Ui.T_INFO;
            case EventLog.CAT_DEVICE: return e.reason.startsWith("Resolved") ? Ui.T_SUCCESS : Ui.T_WARNING;
            case EventLog.CAT_PROTECTION:
                if (e.reason.endsWith(" on")) return Ui.T_SUCCESS;
                return e.reason.contains("unexpectedly") || e.reason.contains("by Android") || e.reason.contains("could not")
                        ? Ui.T_WARNING : Ui.T_NEUTRAL;
            case EventLog.CAT_RECOVERY: return Ui.T_INFO;
            default: return Ui.T_NEUTRAL;
        }
    }

    static String eventLabel(EventLog.Event e) {
        switch (e.category == null ? "" : e.category) {
            case EventLog.CAT_BLOCKED: return "Blocked";
            case EventLog.CAT_MESSAGE: return "Warned";
            case EventLog.CAT_CHECK: return "Check";
            case EventLog.CAT_DEVICE: return "Device";
            case EventLog.CAT_PROTECTION: return "Protection";
            case EventLog.CAT_RECOVERY: return "Recovery";
            case EventLog.CAT_TEST: return "Test";
            default: return "Event";
        }
    }

    private View eventRow(EventLog.Event e) {
        String when = new SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(new Date(e.time));
        String main = e.domain == null || e.domain.isEmpty() ? e.reason : e.domain;
        String sub = (e.domain == null || e.domain.isEmpty() ? "" : e.reason + "\n") + when;
        View r = Ui.row(this, null, main, sub, Ui.badge(this, eventTone(e), eventLabel(e)), null);
        TextView firstText = (TextView) ((LinearLayout) ((LinearLayout) r).getChildAt(0)).getChildAt(0);
        firstText.setSingleLine(true);
        firstText.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        return r;
    }

    // ------------------------------------------------------------------ Device (Protection Gap Analyzer)

    void runAudit() {
        if (auditing) return;
        auditing = true;
        Context app = getApplicationContext();
        bg.execute(() -> {
            DeviceAudit.run(app);
            runOnUiThread(() -> {
                auditing = false;
                if (current == TAB_DEVICE || current == TAB_SHIELD) show(current);
            });
        });
    }

    private void buildDevice(LinearLayout col) {
        List<DeviceAudit.Check> checks = DeviceAudit.last();
        LinearLayout intro = Ui.card(this);
        intro.addView(Ui.cardTitle(this, "Protection check"));
        intro.addView(Ui.support(this, "Which protections this phone already has, and what still needs attention. SafeSphere "
                + "adds to Android's built-in security; it doesn't replace Play Protect or your phone maker's protection."));
        if (checks == null) {
            intro.addView(Ui.body(this, "Checking…"), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
            col.addView(intro, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
            runAudit();
            return;
        }
        DeviceAudit.Progress pr = DeviceAudit.progress(checks);
        TextView count = Ui.body(this, "Setup progress: " + pr.done + " of " + pr.applicable + " checks complete"
                + (pr.attention > 0 ? " · " + pr.attention + " need attention" : ""));
        count.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 8));
        intro.addView(count);
        intro.addView(Ui.progress(this, pr.done, pr.applicable, pr.attention > 0 ? Ui.T_WARNING : Ui.T_SUCCESS),
                Ui.params(Ui.MATCH, Ui.dp(this, 8), 0f));
        intro.addView(Ui.link(this, auditing ? "Checking…" : "Check again", v -> runAudit()));
        col.addView(intro, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));

        String group = null;
        LinearLayout card = null;
        for (DeviceAudit.Check ch : checks) {
            if (!ch.group.equals(group)) {
                group = ch.group;
                section(col, group);
                card = Ui.listCard(this);
                col.addView(card);
            } else {
                card.addView(Ui.divider(this));
            }
            card.addView(checkRow(ch));
        }

        section(col, "Apps");
        col.addView(appScanCard());
        if (lastScan != null) for (AppScanner.AppRisk r : lastScan) add(col, appCard(r));

        section(col, "Accounts and family");
        LinearLayout more = Ui.listCard(this);
        int done = Checkup.doneCount(this), total = Checkup.ITEMS.length;
        more.addView(Ui.row(this, null, "Account checkup", done + " of " + total + " steps done for Google, Facebook and e-wallets",
                Ui.chevron(this), v -> open(PAGE_CHECKUP)));
        more.addView(Ui.divider(this));
        boolean lockReady = AppLock.ready(this);
        more.addView(Ui.row(this, null, "App lock", lockReady ? AppLock.locked(this).size() + " apps locked with your PIN"
                : "Lock chosen apps so children can't open them", Ui.badge(this, lockReady ? Ui.T_SUCCESS : Ui.T_NEUTRAL,
                lockReady ? "On" : AppLock.enabled(this) ? "Setup needed" : "Off"), v -> open(PAGE_APPLOCK)));
        col.addView(more);

        section(col, "Settings");
        col.addView(settingsCard());
    }

    private View checkRow(DeviceAudit.Check ch) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, ch.title, Ui.BODY, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.badge(this, DeviceAudit.tone(ch), DeviceAudit.stateLabel(ch.state)));
        row.addView(head);
        TextView d = Ui.support(this, ch.detail + (ch.apps.isEmpty() ? "" : "\n" + TextUtils.join(", ", ch.apps)));
        d.setPadding(0, Ui.dp(this, 4), 0, 0);
        row.addView(d);
        if (ch.state == DeviceAudit.CONFIRMED && ch.confirmedAt > 0) {
            row.addView(Ui.support(this, "You confirmed this " + ago(ch.confirmedAt) + ". SafeSphere can't verify it."));
        } else if (ch.guide != null && ch.state != DeviceAudit.VERIFIED && ch.state != DeviceAudit.UNAVAILABLE) {
            TextView g = Ui.support(this, "How to check: " + ch.guide);
            g.setPadding(0, Ui.dp(this, 4), 0, 0);
            row.addView(g);
        }
        TextView how = Ui.text(this, ch.how == null ? "" : ch.how, Ui.LABEL, Ui.TEXT2, false);
        how.setPadding(0, Ui.dp(this, 4), 0, 0);
        if (ch.how != null) row.addView(how);
        LinearLayout actions = Ui.hbox(this);
        boolean any = false;
        if ((ch.settings != null || ch.launchPkg != null) && ch.state != DeviceAudit.VERIFIED && ch.state != DeviceAudit.UNAVAILABLE) {
            actions.addView(Ui.link(this, ch.button == null ? "Open settings" : ch.button, v -> {
                if (ch.launchPkg != null) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(ch.launchPkg);
                    if (launch != null) open(launch);
                    else toast("App not found");
                } else {
                    openSettings(ch.settings);
                }
            }));
            any = true;
        }
        if (ch.confirmable && ch.state == DeviceAudit.NOT_CHECKED) {
            TextView conf = Ui.link(this, "I've checked: it's on", v -> {
                DeviceAudit.confirm(this, ch.id, true);
                runAudit();
            });
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.leftMargin = Ui.dp(this, 16);
            actions.addView(conf, lp);
            any = true;
        } else if (ch.confirmable && ch.state == DeviceAudit.CONFIRMED) {
            actions.addView(Ui.link(this, "Undo confirmation", v -> {
                DeviceAudit.confirm(this, ch.id, false);
                runAudit();
            }));
            any = true;
        }
        if (any) row.addView(actions);
        return row;
    }

    private View appScanCard() {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.cardTitle(this, "App permission scan"));
        c.addView(Ui.support(this, "Finds downloaded apps that hold sensitive access (SMS, accessibility, remote control, "
                + "installing other apps). The list never leaves the phone."));
        if (lastScan != null) {
            int high = 0, medium = 0;
            for (AppScanner.AppRisk r : lastScan) {
                if (r.score >= 8) high++;
                else if (r.score >= 4) medium++;
            }
            LinearLayout b = Ui.hbox(this);
            b.setPadding(0, Ui.dp(this, 12), 0, 0);
            b.addView(Ui.badge(this, high > 0 ? Ui.T_DANGER : Ui.T_SUCCESS, high + " high"));
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.leftMargin = Ui.dp(this, 8);
            b.addView(Ui.badge(this, medium > 0 ? Ui.T_WARNING : Ui.T_SUCCESS, medium + " medium"), lp);
            c.addView(b);
        }
        c.addView(Ui.secondary(this, scanning ? "Scanning…" : lastScan == null ? "Scan installed apps" : "Scan again",
                v -> scanApps()), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        return c;
    }

    private View appCard(AppScanner.AppRisk r) {
        LinearLayout c = Ui.listCard(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(r.icon);
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        int s = Ui.dp(this, 36);
        icon.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        c.addView(Ui.row(this, icon, r.label, TextUtils.join(" · ", r.flags), Ui.badge(this, r.tone(), r.level()),
                v -> open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)))));
        return c;
    }

    private void scanApps() {
        if (scanning) return;
        scanning = true;
        show(TAB_DEVICE);
        Context app = getApplicationContext();
        bg.execute(() -> {
            List<AppScanner.AppRisk> result = AppScanner.scan(app);
            runOnUiThread(() -> {
                scanning = false;
                lastScan = result;
                if (current == TAB_DEVICE) show(TAB_DEVICE);
                toast(result.isEmpty() ? "No downloaded apps hold sensitive access" : result.size() + " apps hold sensitive access");
            });
        });
    }

    private View settingsCard() {
        LinearLayout c = Ui.listCard(this);
        boolean doh = Prefs.encryptedDns(this);
        c.addView(Ui.row(this, null, "Encrypted DNS", "Sends allowed lookups to Cloudflare (1.1.1.1) over HTTPS so others on "
                        + "the same Wi-Fi can't see them.", Ui.badge(this, doh ? Ui.T_SUCCESS : Ui.T_NEUTRAL, doh ? "On" : "Off"),
                v -> {
                    if (doh) requirePin("Enter your PIN to turn off encrypted DNS.", () -> {
                        Prefs.setEncryptedDns(this, false);
                        show(TAB_DEVICE);
                    });
                    else {
                        Prefs.setEncryptedDns(this, true);
                        show(TAB_DEVICE);
                    }
                }));
        c.addView(Ui.divider(this));
        boolean pin = Prefs.hasPin(this);
        c.addView(Ui.row(this, null, "Protection PIN", pin ? "Needed to turn protection off, allow sites, remove rules or "
                        + "clear history." : "Stop others from turning protection off.",
                Ui.badge(this, pin ? Ui.T_SUCCESS : Ui.T_NEUTRAL, pin ? "Set" : "Not set"), v -> {
                    if (pin) {
                        requirePin("Enter your current PIN to remove it.", () -> {
                            Prefs.clearPin(this);
                            refreshOngoingNotification();
                            toast("Protection PIN removed");
                            show(TAB_DEVICE);
                        });
                    } else {
                        setPinFlow(() -> show(TAB_DEVICE));
                    }
                }));
        c.addView(Ui.divider(this));
        boolean aiReady = AiClient.isSetUp(this);
        c.addView(Ui.row(this, null, "SafeSphere AI server", aiReady ? "Set up (" + AiSetup.serverHost(this) + "). Used only "
                        + "when you ask for an AI explanation." : "Optional. Not set up.",
                Ui.chevron(this), v -> AiSetup.setupDialog(this, () -> { if (current == TAB_DEVICE) show(TAB_DEVICE); })));
        c.addView(Ui.divider(this));
        c.addView(Ui.row(this, null, "Restart after reboot", "SafeSphere turns protection back on after a restart if it was on. "
                        + "For the strongest setting, turn on \"Always-on VPN\" for SafeSphere in Android's VPN settings.",
                Ui.chevron(this), v -> openSettings(Settings.ACTION_VPN_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS)));
        return c;
    }

    // ------------------------------------------------------------------ Account checkup page

    private void buildCheckup(LinearLayout col) {
        int done = Checkup.doneCount(this);
        LinearLayout head = Ui.card(this);
        head.addView(Ui.body(this, done + " of " + Checkup.ITEMS.length + " steps done"));
        head.addView(Ui.progress(this, done, Checkup.ITEMS.length, Ui.T_SUCCESS), Ui.margins(this, Ui.MATCH, Ui.dp(this, 8), 8));
        head.addView(Ui.support(this, "Tick each step after you finish it in the account's own settings. "
                + "SafeSphere can't see inside your accounts."), Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        col.addView(head, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        String group = null;
        LinearLayout card = null;
        for (Checkup.Item item : Checkup.ITEMS) {
            if (!item.group.equals(group)) {
                group = item.group;
                section(col, group);
                card = Ui.listCard(this);
                col.addView(card);
            } else {
                card.addView(Ui.divider(this));
            }
            card.addView(checkupRow(item));
        }
    }

    private View checkupRow(Checkup.Item item) {
        boolean done = Checkup.isDone(this, item);
        LinearLayout row = Ui.hbox(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        android.widget.CheckBox box = new android.widget.CheckBox(this);
        box.setChecked(done);
        box.setContentDescription(item.title + (done ? ", done" : ", not done"));
        box.setOnCheckedChangeListener((b, checked) -> {
            Checkup.setDone(this, item, checked);
            show(PAGE_CHECKUP);
        });
        box.setButtonTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        row.addView(box);
        LinearLayout texts = Ui.vbox(this);
        texts.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), 0, 0);
        texts.addView(Ui.text(this, item.title, Ui.BODY, Ui.TEXT, true));
        TextView d = Ui.support(this, item.detail);
        d.setPadding(0, Ui.dp(this, 2), 0, 0);
        texts.addView(d);
        if (item.action != Checkup.ACT_NONE) {
            texts.addView(Ui.link(this, item.button, v -> runCheckupAction(item)));
        }
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private void runCheckupAction(Checkup.Item item) {
        switch (item.action) {
            case Checkup.ACT_URL:
                open(new Intent(Intent.ACTION_VIEW, Uri.parse(item.targets[0])));
                return;
            case Checkup.ACT_DIAL:
                open(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + item.targets[0])));
                return;
            case Checkup.ACT_APP: {
                Intent launch = getPackageManager().getLaunchIntentForPackage(item.targets[0]);
                if (launch != null) open(launch);
                else open(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + item.targets[0])));
                return;
            }
            case Checkup.ACT_SETTINGS:
                openSettings(item.targets);
                return;
            default:
        }
    }

    // ------------------------------------------------------------------ App lock page

    private List<AppLock.App> lockApps;
    private java.util.Map<String, android.graphics.drawable.Drawable> lockIcons;
    private boolean loadingApps;
    private String lockSearch = "";

    private void buildAppLock(LinearLayout col) {
        boolean on = AppLock.enabled(this);
        boolean usage = AppLock.hasUsageAccess(this), overlay = AppLock.canOverlay(this), pin = Prefs.hasPin(this);
        boolean ready = on && usage && overlay && pin;

        LinearLayout head = Ui.card(this);
        LinearLayout hrow = Ui.hbox(this);
        hrow.addView(Ui.cardTitle(this, "Lock apps with your PIN"), Ui.params(0, Ui.WRAP, 1f));
        hrow.addView(Ui.badge(this, ready ? Ui.T_SUCCESS : on ? Ui.T_WARNING : Ui.T_NEUTRAL, ready ? "On" : on ? "Setup needed" : "Off"));
        head.addView(hrow);
        head.addView(Ui.support(this, "Locked apps ask for your PIN before they open. Useful for children's phones."));
        if (!pin || !usage || !overlay) {
            head.addView(lockStep(pin, "Set a PIN", "Set PIN", v -> setPinFlow(() -> show(PAGE_APPLOCK))));
            head.addView(lockStep(usage, "Allow usage access (to see which app opens)", "Allow", v -> {
                toast("Find SafeSphere and switch it on");
                openSettings(Settings.ACTION_USAGE_ACCESS_SETTINGS, Settings.ACTION_SETTINGS);
            }));
            head.addView(lockStep(overlay, "Allow display over other apps (to show the lock screen)", "Allow", v -> {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                } catch (ActivityNotFoundException e) {
                    openSettings(Settings.ACTION_SETTINGS);
                }
            }));
        }
        if (on) {
            head.addView(Ui.secondary(this, "Turn off app lock", v -> requirePin("Enter your PIN to turn off App lock.", () -> {
                AppLock.setEnabled(this, false);
                toast("App lock is off");
                show(PAGE_APPLOCK);
            })), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        } else {
            head.addView(Ui.primary(this, "Turn on app lock", v -> {
                if (!Prefs.hasPin(this)) {
                    setPinFlow(() -> { AppLock.setEnabled(this, true); show(PAGE_APPLOCK); });
                    return;
                }
                AppLock.setEnabled(this, true);
                toast(AppLock.ready(this) ? "App lock is on" : "Almost there: finish the steps above");
                show(PAGE_APPLOCK);
            }), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        }
        col.addView(head, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));

        if (lockApps == null) {
            col.addView(Ui.support(this, "Loading apps…"), Ui.margins(this, Ui.MATCH, Ui.WRAP, 16));
            loadLockApps();
            return;
        }
        List<AppLock.App> sug = AppLock.suggestedInstalled(this);
        if (!sug.isEmpty()) {
            section(col, "Suggested");
            LinearLayout sc = Ui.listCard(this);
            for (int i = 0; i < sug.size(); i++) {
                if (i > 0) sc.addView(Ui.divider(this));
                sc.addView(lockRow(sug.get(i)));
            }
            col.addView(sc);
        }
        section(col, "All apps");
        EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setSingleLine(true);
        search.setText(lockSearch);
        Ui.field(search);
        col.addView(search);
        LinearLayout rows = Ui.listCard(this);
        for (AppLock.App a : lockApps) {
            View r = lockRow(a);
            r.setTag(a.label.toLowerCase(Locale.ROOT));
            rows.addView(r);
        }
        add(col, rows);
        filterLockRows(rows, lockSearch);
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(android.text.Editable e) {
                lockSearch = e.toString();
                filterLockRows(rows, lockSearch);
            }
        });
    }

    private void filterLockRows(LinearLayout rows, String q) {
        String needle = q.trim().toLowerCase(Locale.ROOT);
        for (int i = 0; i < rows.getChildCount(); i++) {
            View r = rows.getChildAt(i);
            Object tag = r.getTag();
            r.setVisibility(needle.isEmpty() || (tag != null && tag.toString().contains(needle)) ? View.VISIBLE : View.GONE);
        }
    }

    private View lockStep(boolean done, String label, String action, View.OnClickListener l) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 10), 0, 0);
        row.addView(Ui.statusDot(this, done ? Ui.T_SUCCESS : Ui.T_NEUTRAL));
        TextView t = Ui.body(this, label);
        t.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        row.addView(t, Ui.params(0, Ui.WRAP, 1f));
        if (!done) row.addView(Ui.link(this, action, l));
        return row;
    }

    private View lockRow(AppLock.App a) {
        ImageView icon = new ImageView(this);
        android.graphics.drawable.Drawable d = lockIcons == null ? null : lockIcons.get(a.pkg);
        if (d != null) icon.setImageDrawable(d);
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        int is = Ui.dp(this, 32);
        icon.setLayoutParams(new LinearLayout.LayoutParams(is, is));
        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(AppLock.isLocked(this, a.pkg));
        sw.setContentDescription("Lock " + a.label);
        sw.setOnClickListener(v -> {
            boolean wantLocked = sw.isChecked();
            if (!wantLocked) {
                sw.setChecked(true);
                requirePin("Enter your PIN to unlock " + a.label + ".", () -> {
                    AppLock.setLocked(this, a.pkg, false);
                    sw.setChecked(false);
                });
            } else {
                AppLock.setLocked(this, a.pkg, true);
                if (!AppLock.ready(this)) toast("Locked. Turn on App lock above to make it work.");
            }
        });
        return Ui.row(this, icon, a.label, null, sw, null);
    }

    private void loadLockApps() {
        if (loadingApps) return;
        loadingApps = true;
        Context app = getApplicationContext();
        bg.execute(() -> {
            List<AppLock.App> list = AppLock.launchableApps(app);
            java.util.Map<String, android.graphics.drawable.Drawable> icons = new java.util.HashMap<>();
            PackageManager pm = app.getPackageManager();
            List<AppLock.App> all = new ArrayList<>(list);
            all.addAll(AppLock.suggestedInstalled(app));
            for (AppLock.App a : all) {
                try {
                    if (!icons.containsKey(a.pkg)) icons.put(a.pkg, pm.getApplicationIcon(a.pkg));
                } catch (Exception ignored) {
                }
            }
            runOnUiThread(() -> {
                loadingApps = false;
                lockIcons = icons;
                lockApps = list;
                if (current == PAGE_APPLOCK) show(PAGE_APPLOCK);
            });
        });
    }

    // ------------------------------------------------------------------ Privacy & About pages

    private void buildPrivacy(LinearLayout col) {
        col.addView(Ui.body(this, "What SafeSphere can access, why, and what leaves your phone."),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        section(col, "Permissions you grant yourself");
        col.addView(infoList(new String[][]{
                {"VPN connection", "Lets SafeSphere act as the phone's DNS server so it can refuse dangerous website names. "
                        + "Only DNS lookups enter the VPN; other traffic goes directly to the internet."},
                {"Notification access (optional)", "For scam-message alerts. New message notifications are checked on the phone; "
                        + "their text is never saved or sent."},
                {"Usage access (App lock only)", "Shows which app was just opened so a locked app can be covered."},
                {"Display over other apps (App lock only)", "Shows the PIN screen on top of a locked app."},
                {"Notifications", "Alerts about blocked sites and scam messages, and the required \"protection is on\" notice."}}));
        section(col, "Granted at install");
        col.addView(infoList(new String[][]{
                {"Internet", "Downloads threat lists, checks password leaks (hash prefix only) and, if you ask, the AI explanation."},
                {"Network state", "Detects Wi-Fi security and whether another VPN is connected."},
                {"See installed apps", "For the app permission scan and remote-control app check. The app list stays on the phone."},
                {"Run after restart", "Turns protection back on after a reboot if it was on."},
                {"Foreground service", "Keeps protection and App lock running. Android shows a notification while they run."}}));
        section(col, "Not requested");
        col.addView(Ui.body(this, "Contacts, SMS inbox, call logs, location, accessibility control and file storage. "
                + "SafeSphere does not need them."));
        section(col, "What leaves the phone");
        col.addView(infoList(new String[][]{
                {"Website lookups", "Allowed lookups are answered by Cloudflare's DNS over HTTPS (1.1.1.1), or by 1.1.1.1, 8.8.8.8 "
                        + "or 9.9.9.9 if that fails, like any DNS service. Blocked ones never leave the phone."},
                {"Threat list downloads", "Plain downloads from the three feed websites. No personal data is sent."},
                {"Password leak check", "Only the first 5 characters of the password's SHA-1 hash go to Have I Been Pwned. "
                        + "The password itself never leaves the phone."},
                {"AI explanation (optional)", "Only when you tap it and confirm. You see the exact text first; codes, numbers, "
                        + "e-mail addresses and link paths are removed."}}));
        section(col, "Stored on the phone");
        col.addView(Ui.body(this, "Security events (time, website name, short reason), incident reports you write, your rules "
                + "and settings. You can clear history at any time. Uninstalling SafeSphere deletes everything."));
    }

    private View infoList(String[][] items) {
        LinearLayout c = Ui.listCard(this);
        for (int i = 0; i < items.length; i++) {
            if (i > 0) c.addView(Ui.divider(this));
            c.addView(Ui.row(this, null, items[i][0], items[i][1], null, null));
        }
        return c;
    }

    private void buildAbout(LinearLayout col) {
        String version = "";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        LinearLayout c = Ui.card(this);
        c.addView(Ui.cardTitle(this, "SafeSphere " + version));
        c.addView(Ui.support(this, "Checks website lookups against threat lists, explains risky messages before you act, "
                + "reviews your phone's protections and guides recovery after a scam."));
        col.addView(c, Ui.margins(this, Ui.MATCH, Ui.WRAP, 8));
        section(col, "What SafeSphere cannot do");
        List<String> limits = new ArrayList<>();
        limits.add("It is not an antivirus: it does not scan files or app code. Keep Google Play Protect on.");
        limits.add("It only filters DNS lookups. It can't see page content, inside encrypted connections, or apps that use "
                + "their own encrypted DNS or IP addresses.");
        limits.add("Brand checks cover the brands in its catalogue. A brand-new scam site with an unknown name may not be "
                + "flagged until a threat feed lists it.");
        limits.add("Message checks use rules and wording patterns. A carefully written scam can pass, and an honest message "
                + "can be flagged. Always confirm through a channel you already trust.");
        limits.add("Automatic message alerts only see what notifications show. Hidden previews, muted chats and long, "
                + "cut-off messages can't be checked.");
        limits.add("It can't read Play Protect or Chrome Safe Browsing settings; those are confirmed by you.");
        limits.add("It can't block anything while another VPN is connected or when protection is off.");
        limits.add("AI explanations are opinions from an external service and can be wrong.");
        LinearLayout lc = Ui.card(this);
        lc.addView(Ui.bullets(this, limits));
        col.addView(lc);
        section(col, "Open-source data");
        col.addView(Ui.support(this, "Public Suffix List (Mozilla, MPL-2.0). Threat feeds: URLhaus (abuse.ch, via malware-filter), "
                + "Phishing Army, HaGeZi DNS blocklists. QR decoding: ZXing (Apache-2.0)."));
    }

    // ------------------------------------------------------------------ PIN

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        return e;
    }

    private View padded(View v) {
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 20);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(v);
        return f;
    }

    private static int wrongPins;
    private static long pinLockedUntil;

    /** Runs the action right away, or after the correct PIN when a protection PIN is set. */
    void requirePin(String why, Runnable action) {
        if (!Prefs.hasPin(this)) {
            action.run();
            return;
        }
        long now = android.os.SystemClock.elapsedRealtime();
        if (now < pinLockedUntil) {
            toast("Too many wrong PINs. Try again in " + ((pinLockedUntil - now) / 1000 + 1) + " seconds.");
            return;
        }
        EditText pin = pinField("PIN");
        new AlertDialog.Builder(this)
                .setTitle("Protection PIN")
                .setMessage(why)
                .setView(padded(pin))
                .setPositiveButton("OK", (d, w) -> {
                    if (Prefs.checkPin(this, pin.getText().toString())) {
                        wrongPins = 0;
                        action.run();
                    } else if (++wrongPins >= 5) {
                        wrongPins = 0;
                        pinLockedUntil = android.os.SystemClock.elapsedRealtime() + 30_000;
                        toast("Too many wrong PINs. Wait 30 seconds.");
                    } else {
                        toast("Wrong PIN");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void setPinFlow(Runnable after) {
        EditText first = pinField("4 to 8 digits");
        new AlertDialog.Builder(this)
                .setTitle("Set a protection PIN")
                .setMessage("You'll need this PIN to turn protection off, allow sites, remove rules, clear history and unlock apps.")
                .setView(padded(first))
                .setPositiveButton("Next", (d, w) -> {
                    String p1 = first.getText().toString();
                    if (p1.length() < 4 || p1.length() > 8) {
                        toast("Use 4 to 8 digits");
                        return;
                    }
                    EditText second = pinField("Enter the same PIN again");
                    new AlertDialog.Builder(this)
                            .setTitle("Confirm PIN")
                            .setView(padded(second))
                            .setPositiveButton("Save", (d2, w2) -> {
                                if (!p1.equals(second.getText().toString())) {
                                    toast("PINs didn't match. Try again.");
                                    return;
                                }
                                Prefs.setPin(this, p1);
                                refreshOngoingNotification();
                                success("Protection PIN set");
                                after.run();
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshOngoingNotification() {
        if (!SafeSphereVpnService.isRunning()) return;
        android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
        if (nm != null) nm.notify(Alerts.ONGOING_ID, Alerts.ongoing(this));
    }

    // ------------------------------------------------------------------ helpers

    void openSettings(String... actions) {
        for (String action : actions) {
            try {
                Intent i = new Intent(action);
                if (Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES.equals(action) && Build.VERSION.SDK_INT < 26) continue;
                startActivity(i);
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
                // try the next screen
            }
        }
        toast("Open your phone's Settings app to change this");
    }

    void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No app found to open this");
        }
    }

    void info(String t, String msg) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(msg).setPositiveButton("OK", null).show();
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
}
