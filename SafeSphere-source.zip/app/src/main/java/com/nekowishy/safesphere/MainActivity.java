package com.nekowishy.safesphere;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final String EXTRA_TAB = "tab";
    static final int TAB_SHIELD = 0, TAB_CHECK = 1, TAB_RULES = 2, TAB_HISTORY = 3, TAB_APPS = 4, TAB_CHECKUP = 5;

    private static final int REQ_VPN = 10;
    private static final int REQ_NOTIFY = 11;
    private static final int REQ_QR = 12;
    private static final String[] TAB_ICONS = {"◈", "◎", "☰", "◷", "▣"};
    private static final String[] TAB_NAMES = {"Shield", "Check", "Rules", "History", "Device"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newCachedThreadPool();
    private final TextView[] tabs = new TextView[TAB_NAMES.length];
    private FrameLayout page;
    private int currentTab = -1;
    private Runnable refresher;
    private List<AppScanner.AppRisk> lastScan;
    private boolean scanning;

    // Check tab state (kept while switching tabs)
    private String checkText = "";
    private List<ScamDetector.LinkResult> checkLinks;
    private List<String> checkWarnings;
    private String checkNote;
    private boolean checking;

    // Password checker state (the password itself is never kept)
    private PasswordCheck.Result pwResult;
    private boolean pwChecking;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (refresher != null) refresher.run();
            handler.postDelayed(this, 1200);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        RuleStore.init(this);
        Alerts.channels(this);
        Context app = getApplicationContext();
        bg.execute(() -> ThreatDb.ensureLoaded(app));
        bg.execute(() -> DeviceAudit.run(app));
        WifiGuard.start(app);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = Ui.vbox(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF140A2E, Ui.BG, 0xFF04030B}));

        LinearLayout header = Ui.vbox(this);
        int p = Ui.dp(this, 20);
        header.setPadding(p, p, p, Ui.dp(this, 6));
        TextView logo = Ui.glow(this, "SAFESPHERE", 26, Ui.CYAN);
        logo.setLetterSpacing(0.22f);
        header.addView(logo);
        header.addView(Ui.text(this, "Real-time online activity guardian", 12, Ui.MUTED, false));
        root.addView(header);

        page = new FrameLayout(this);
        root.addView(page, Ui.params(Ui.MATCH, 0, 1f));

        LinearLayout bar = Ui.hbox(this);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(0xF00B0919);
        barBg.setStroke(Ui.dp(this, 1), Ui.alpha(Ui.CYAN, 0x33));
        bar.setBackground(barBg);
        int bp = Ui.dp(this, 6);
        bar.setPadding(bp, bp, bp, bp);
        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            TextView t = Ui.text(this, TAB_ICONS[i] + "\n" + TAB_NAMES[i], 11, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            t.setOnClickListener(v -> {
                Ui.tap(v);
                show(index);
            });
            tabs[i] = t;
            bar.addView(t, Ui.params(0, Ui.WRAP, 1f));
        }
        root.addView(bar, Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        setContentView(root);

        askNotificationPermission();
        if (!handleShared(getIntent())) show(getIntent().getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handleShared(intent)) return;
        if (intent.hasExtra(EXTRA_TAB)) show(intent.getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        if (currentTab == TAB_APPS || currentTab == TAB_CHECK) runAudit(); // the user may be back from fixing a setting
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (currentTab == TAB_CHECKUP) {
            show(TAB_SHIELD);
            return;
        }
        super.onBackPressed();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
    }

    /** Text or images shared to SafeSphere, or text selected with "Check with SafeSphere". */
    private boolean handleShared(Intent intent) {
        if (intent == null || intent.getAction() == null) return false;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            String type = intent.getType();
            if (type != null && type.startsWith("image/")) {
                Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (uri != null) {
                    show(TAB_CHECK);
                    readQr(uri);
                    return true;
                }
            }
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null) {
                runCheck(text.toString(), null);
                return true;
            }
        }
        if (Intent.ACTION_PROCESS_TEXT.equals(action)) {
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
            if (text != null) {
                runCheck(text.toString(), null);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ navigation

    private void show(int tab) {
        if (tab < 0 || tab > TAB_CHECKUP) tab = TAB_SHIELD;
        currentTab = tab;
        for (int i = 0; i < tabs.length; i++) {
            TextView t = tabs[i];
            if (i == tab) {
                t.setTextColor(Ui.CYAN);
                t.setShadowLayer(Ui.dp(this, 10), 0, 0, Ui.CYAN);
                GradientDrawable g = new GradientDrawable();
                g.setColor(Ui.alpha(Ui.CYAN, 0x1C));
                g.setCornerRadius(Ui.dp(this, 14));
                t.setBackground(g);
            } else {
                t.setTextColor(Ui.MUTED);
                t.setShadowLayer(0, 0, 0, 0);
                t.setBackground(null);
            }
        }
        refresher = null;
        LinearLayout content = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        content.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 28));
        switch (tab) {
            case TAB_CHECK: buildCheck(content); break;
            case TAB_RULES: buildRules(content); break;
            case TAB_HISTORY: buildHistory(content); break;
            case TAB_APPS: buildDevice(content); break;
            case TAB_CHECKUP: buildCheckup(content); break;
            default: buildShield(content); break;
        }
        for (int i = 0; i < content.getChildCount(); i++) Ui.enter(content.getChildAt(i), i);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(content);
        page.removeAllViews();
        page.addView(scroll);
        if (refresher != null) refresher.run();
    }

    private void add(LinearLayout parent, View child) {
        parent.addView(child, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
    }

    private TextView body(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
        return t;
    }

    private LinearLayout twoButtons(TextView a, TextView b) {
        LinearLayout row = Ui.hbox(this);
        row.addView(a, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(this, 12);
        row.addView(b, lp);
        return row;
    }

    // ------------------------------------------------------------------ Shield (dashboard)

    private void buildShield(LinearLayout col) {
        LinearLayout hero = Ui.vbox(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        ShieldView shield = new ShieldView(this);
        shield.setCameraDistance(12000 * getResources().getDisplayMetrics().density);
        int size = Ui.dp(this, 240);
        hero.addView(shield, new LinearLayout.LayoutParams(size, size));
        shield.setOnClickListener(v -> {
            v.animate().rotationYBy(360f).setDuration(900).setInterpolator(new AccelerateDecelerateInterpolator()).start();
            toggleProtection();
        });
        TextView status = Ui.glow(this, "", 22, Ui.CYAN);
        status.setLetterSpacing(0.1f);
        status.setGravity(Gravity.CENTER);
        hero.addView(status);
        TextView detail = Ui.text(this, "", 13, Ui.MUTED, false);
        detail.setGravity(Gravity.CENTER);
        detail.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 14));
        hero.addView(detail);
        TextView toggle = Ui.button(this, "", Ui.CYAN, v -> toggleProtection());
        hero.addView(toggle, Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        col.addView(hero);

        // Private DNS warning (only shown when it bypasses the filter)
        LinearLayout dnsWarn = Ui.card(this, Ui.RED);
        dnsWarn.addView(Ui.glow(this, "⚠ Private DNS is skipping SafeSphere", 15, Ui.RED));
        dnsWarn.addView(body("Your Private DNS is set to a specific provider, so apps go around SafeSphere's filter. "
                + "Open Settings → Network → Private DNS and choose Automatic or Off."));
        dnsWarn.addView(Ui.button(this, "OPEN NETWORK SETTINGS", Ui.RED,
                v -> openSettings(Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS)));
        add(col, dnsWarn);

        // Security score
        LinearLayout scoreCard = Ui.card(this, Ui.CYAN);
        LinearLayout scoreRow = Ui.hbox(this);
        TextView scoreValue = Ui.glow(this, "--", 40, Ui.CYAN);
        scoreRow.addView(scoreValue);
        LinearLayout scoreTexts = Ui.vbox(this);
        scoreTexts.setPadding(Ui.dp(this, 16), 0, 0, 0);
        TextView scoreLabel = Ui.text(this, "SECURITY SCORE", 11, Ui.MUTED, true);
        scoreLabel.setLetterSpacing(0.12f);
        scoreTexts.addView(scoreLabel);
        TextView scoreWord = Ui.text(this, "", 16, Ui.TEXT, true);
        scoreTexts.addView(scoreWord);
        scoreRow.addView(scoreTexts, Ui.params(0, Ui.WRAP, 1f));
        scoreCard.addView(scoreRow);
        TextView scoreTips = body("");
        scoreCard.addView(scoreTips);
        TextView encLine = Ui.text(this, "", 11, Ui.MUTED, false);
        encLine.setPadding(0, 0, 0, Ui.dp(this, 12));
        scoreCard.addView(encLine);
        scoreCard.addView(Ui.button(this, "IMPROVE MY SCORE", Ui.CYAN, v -> show(TAB_APPS)));
        add(col, scoreCard);

        LinearLayout row1 = Ui.hbox(this);
        TextView vBlocked = stat(row1, "THREATS BLOCKED", Ui.PINK, false);
        TextView vToday = stat(row1, "BLOCKED TODAY", Ui.VIOLET, true);
        add(col, row1);
        LinearLayout row2 = Ui.hbox(this);
        TextView vRules = stat(row2, "CUSTOM RULES", Ui.GREEN, false);
        TextView vDb = stat(row2, "KNOWN THREATS", Ui.CYAN, true);
        add(col, row2);

        // Wi-Fi safety
        LinearLayout wifi = Ui.card(this, Ui.AMBER);
        wifi.addView(Ui.text(this, "Wi-Fi safety", 16, Ui.TEXT, true));
        TextView wifiStatus = Ui.glow(this, "", 17, Ui.GREEN);
        wifiStatus.setPadding(0, Ui.dp(this, 8), 0, 0);
        wifi.addView(wifiStatus);
        TextView wifiDetail = body("");
        wifi.addView(wifiDetail);
        add(col, wifi);

        // Account checkup summary
        LinearLayout checkup = Ui.card(this, Ui.GREEN);
        checkup.addView(Ui.text(this, "Account security checkup", 16, Ui.TEXT, true));
        TextView checkupInfo = body("");
        checkup.addView(checkupInfo);
        LinearLayout track = Ui.hbox(this);
        GradientDrawable trackBg = new GradientDrawable();
        trackBg.setColor(0xFF1C1836);
        trackBg.setCornerRadius(Ui.dp(this, 8));
        track.setBackground(trackBg);
        View fill = new View(this);
        GradientDrawable fillBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Ui.CYAN, Ui.GREEN});
        fillBg.setCornerRadius(Ui.dp(this, 8));
        fill.setBackground(fillBg);
        View rest = new View(this);
        track.addView(fill, Ui.params(0, Ui.dp(this, 8), 0f));
        track.addView(rest, Ui.params(0, Ui.dp(this, 8), 1f));
        checkup.addView(track, Ui.params(Ui.MATCH, Ui.dp(this, 8), 0f));
        TextView openCheckup = Ui.button(this, "OPEN CHECKUP", Ui.GREEN, v -> show(TAB_CHECKUP));
        checkup.addView(openCheckup, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
        add(col, checkup);

        LinearLayout db = Ui.card(this, Ui.CYAN);
        db.addView(Ui.text(this, "Threat intelligence", 16, Ui.TEXT, true));
        TextView dbInfo = body("");
        db.addView(dbInfo);
        final TextView[] updateBtn = new TextView[1];
        updateBtn[0] = Ui.button(this, "UPDATE THREAT DATABASE", Ui.CYAN, v -> updateThreatDb(dbInfo, updateBtn[0]));
        db.addView(updateBtn[0]);
        TextView fakeInfo = Ui.text(this, "Fake-site detector is always on: look-alike GCash, Maya, bank, Shopee, "
                + "Lazada, Facebook and government sites are blocked automatically, even brand-new ones.", 11, Ui.MUTED, false);
        fakeInfo.setPadding(0, Ui.dp(this, 12), 0, 0);
        db.addView(fakeInfo);
        add(col, db);

        LinearLayout test = Ui.card(this, Ui.PINK);
        test.addView(Ui.text(this, "Live protection test", 16, Ui.TEXT, true));
        test.addView(body("Safely simulates the phone trying to open a malware site or a fake GCash site. "
                + "Nothing is actually visited. SafeSphere should block it, send an alert and record it in History."));
        test.addView(twoButtons(
                Ui.button(this, "MALWARE", Ui.PINK, v -> runLiveTest(false)),
                Ui.button(this, "FAKE GCASH", Ui.AMBER, v -> runLiveTest(true))));
        add(col, test);

        LinearLayout recent = Ui.card(this, Ui.VIOLET);
        recent.addView(Ui.text(this, "Recent activity", 16, Ui.TEXT, true));
        LinearLayout recentList = Ui.vbox(this);
        recent.addView(recentList);
        add(col, recent);

        final long[] shownId = {-1};
        refresher = () -> {
            boolean on = SafeSphereVpnService.isRunning();
            String err = SafeSphereVpnService.lastError();
            shield.setActive(on);
            status.setText(on ? "PROTECTION ACTIVE" : "PROTECTION OFF");
            int color = on ? Ui.CYAN : Ui.PINK;
            status.setTextColor(color);
            status.setShadowLayer(Ui.dp(this, 12), 0, 0, color);
            if (on) {
                detail.setText("Checking every domain lookup from every app since "
                        + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(SafeSphereVpnService.startedAt())));
            } else if (err != null) {
                detail.setText("⚠ " + err);
            } else {
                detail.setText("Tap the shield to start protecting this phone");
            }
            toggle.setText(on ? "TURN OFF PROTECTION" : "TURN ON PROTECTION");
            Ui.restyle(toggle, on ? Ui.PINK : Ui.CYAN);

            dnsWarn.setVisibility(Prefs.privateDnsBypasses(this) ? View.VISIBLE : View.GONE);
            int score = DeviceAudit.securityScore(this);
            int sc = score >= 80 ? Ui.GREEN : score >= 60 ? Ui.AMBER : Ui.RED;
            scoreValue.setText(String.valueOf(score));
            setGlow(scoreValue, sc);
            scoreWord.setText(score >= 80 ? "Well protected" : score >= 60 ? "Needs attention" : "At risk");
            scoreTips.setText(scoreTips());
            long enc = SafeSphereVpnService.encryptedLookups, plain = SafeSphereVpnService.plainLookups;
            encLine.setText(!on ? "Turn on protection to filter and encrypt website lookups."
                    : Prefs.encryptedDns(this)
                    ? "🔒 Encrypted DNS on · " + enc + " lookups encrypted" + (plain > 0 ? ", " + plain + " sent normally (fallback)" : "")
                    + (SafeSphereVpnService.bypassBlocked > 0 ? " · " + SafeSphereVpnService.bypassBlocked + " bypass attempts stopped" : "")
                    : "Encrypted DNS is off (Device tab → Settings).");

            EventLog log = EventLog.get(this);
            vBlocked.setText(String.valueOf(log.count()));
            vToday.setText(String.valueOf(log.countSince(startOfToday())));
            vRules.setText(String.valueOf(RuleStore.count()));
            vDb.setText(compact(ThreatDb.size()));
            if (!ThreatDb.isUpdating()) dbInfo.setText(ThreatDb.status(this));

            if (!WifiGuard.supported()) {
                wifiStatus.setText("Needs Android 12 or newer");
                setGlow(wifiStatus, Ui.MUTED);
                wifiDetail.setText("This phone's Android version doesn't report Wi-Fi security to apps.");
            } else {
                WifiGuard.Status ws = WifiGuard.current();
                if (ws == null) {
                    wifiStatus.setText("Not on Wi-Fi");
                    setGlow(wifiStatus, Ui.MUTED);
                    wifiDetail.setText("SafeSphere warns you automatically if you join Wi-Fi with no password or weak security.");
                } else {
                    wifiStatus.setText((ws.level == WifiGuard.LEVEL_SAFE ? "✓ " : "⚠ ") + ws.title);
                    setGlow(wifiStatus, ws.level == WifiGuard.LEVEL_UNSAFE ? Ui.RED
                            : ws.level == WifiGuard.LEVEL_CAUTION ? Ui.AMBER : Ui.GREEN);
                    wifiDetail.setText(ws.detail);
                }
            }

            int done = Checkup.doneCount(this), total = Checkup.ITEMS.length;
            checkupInfo.setText(done + " of " + total + " steps done. "
                    + (done == total ? "Your accounts are well protected." : "Secure your Google, Facebook and GCash accounts."));
            ((LinearLayout.LayoutParams) fill.getLayoutParams()).weight = done;
            ((LinearLayout.LayoutParams) rest.getLayoutParams()).weight = total - done;
            track.requestLayout();

            long latest = log.latestId();
            if (latest != shownId[0]) {
                shownId[0] = latest;
                recentList.removeAllViews();
                List<EventLog.Event> events = log.recent(5);
                if (events.isEmpty()) {
                    TextView empty = Ui.text(this, "No threats blocked yet. Run a live test to see one.", 12, Ui.MUTED, false);
                    empty.setPadding(0, Ui.dp(this, 8), 0, 0);
                    recentList.addView(empty);
                }
                for (EventLog.Event e : events) recentList.addView(eventRow(e, false));
            }
        };
    }

    private void setGlow(TextView t, int color) {
        t.setTextColor(color);
        t.setShadowLayer(Ui.dp(this, 10), 0, 0, color);
    }

    private TextView stat(LinearLayout row, String label, int color, boolean right) {
        LinearLayout c = Ui.card(this, color);
        TextView value = Ui.glow(this, "0", 28, color);
        c.addView(value);
        TextView l = Ui.text(this, label, 10, Ui.MUTED, true);
        l.setLetterSpacing(0.12f);
        c.addView(l);
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        if (right) lp.leftMargin = Ui.dp(this, 12);
        row.addView(c, lp);
        c.setOnClickListener(Ui::tap);
        return value;
    }

    /** Up to three things that would raise the security score most. */
    private String scoreTips() {
        List<String> tips = new ArrayList<>();
        if (!SafeSphereVpnService.isRunning()) tips.add("Turn on protection");
        List<DeviceAudit.Check> audit = DeviceAudit.last();
        if (audit != null) {
            for (DeviceAudit.Check ch : audit) if (ch.level == DeviceAudit.RISK && tips.size() < 3) tips.add(ch.title);
            for (DeviceAudit.Check ch : audit) if (ch.level == DeviceAudit.WARN && tips.size() < 3) tips.add(ch.title);
        }
        int left = Checkup.ITEMS.length - Checkup.doneCount(this);
        if (left > 0 && tips.size() < 3) tips.add("Finish the account checkup (" + left + " steps left)");
        if (tips.isEmpty()) return "Everything checks out. Keep protection on and your phone updated.";
        return "To improve:\n• " + TextUtils.join("\n• ", tips);
    }

    private void toggleProtection() {
        if (SafeSphereVpnService.isRunning()) {
            requirePin("Enter your PIN to turn protection off.", () -> {
                startService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_STOP));
                toast("Protection turned off");
                handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 400);
            });
            return;
        }
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            try {
                startActivityForResult(consent, REQ_VPN);
            } catch (ActivityNotFoundException e) {
                toast("This phone does not allow VPN apps");
            }
        } else {
            onActivityResult(REQ_VPN, RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_QR) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) readQr(data.getData());
            return;
        }
        if (requestCode != REQ_VPN) return;
        if (resultCode == RESULT_OK) {
            startForegroundService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_START));
            toast("Starting protection…");
            handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 600);
        } else {
            toast("Protection needs the VPN connection request to be allowed");
        }
    }

    private void updateThreatDb(TextView info, TextView button) {
        if (ThreatDb.isUpdating()) return;
        button.setEnabled(false);
        button.setText("UPDATING…");
        info.setText("Connecting…");
        Context app = getApplicationContext();
        bg.execute(() -> {
            String result = ThreatDb.update(app, msg -> runOnUiThread(() -> info.setText(msg)));
            runOnUiThread(() -> {
                button.setEnabled(true);
                button.setText("UPDATE THREAT DATABASE");
                info.setText(ThreatDb.status(this));
                toast(result);
            });
        });
    }

    private void runLiveTest(boolean fakeSite) {
        if (!SafeSphereVpnService.isRunning()) {
            toast("Turn protection on first, then run the test");
            return;
        }
        String id = Integer.toHexString(new Random().nextInt(0xFFFFFF));
        String domain = fakeSite ? "gcash-verify-login-" + id + ".example" : "t" + id + "." + RuleStore.TEST_ZONE;
        long started = System.currentTimeMillis();
        toast("Testing…");
        bg.execute(() -> {
            try {
                InetAddress.getByName(domain);
            } catch (Exception ignored) {
                // expected: the lookup is refused
            }
            try { Thread.sleep(700); } catch (InterruptedException ignored) { }
            boolean passed = domain.equals(SafeSphereVpnService.lastBlocked)
                    && SafeSphereVpnService.lastBlockedAt >= started;
            String why = RuleStore.check(domain);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(passed ? "✅ Test passed" : "Test did not trigger")
                        .setMessage(passed
                                ? "SafeSphere caught the lookup for\n" + domain + "\nand blocked it before any connection was made.\n\n"
                                + "Reason: " + why + "\n\nCheck your notifications and the History tab."
                                : "The test lookup did not reach SafeSphere. Open Android Settings → Network → Private DNS and "
                                + "set it to Automatic or Off, then try again.")
                        .setPositiveButton("OK", null)
                        .show();
                if (refresher != null) refresher.run();
            });
        });
    }

    // ------------------------------------------------------------------ Check (scam link & message checker)

    private void buildCheck(LinearLayout col) {
        col.addView(messageAlertsCard());
        buildLinkChecker(col);
        add(col, passwordCard());
    }

    private View messageAlertsCard() {
        boolean on = ScamMessageWatcher.isEnabled(this);
        LinearLayout card = Ui.card(this, on ? Ui.GREEN : Ui.PINK);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, "Automatic scam message alerts", 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, on ? "ON" : "OFF", on ? Ui.GREEN : Ui.MUTED));
        card.addView(head);
        card.addView(body("SafeSphere reads new messages in Messages, Messenger, Viber, Telegram, WhatsApp and Gmail as they "
                + "arrive and warns you right away if one contains a dangerous or fake link, before you tap it. "
                + "Messages are checked on this phone only and are never saved or sent anywhere."));
        if (on) {
            card.addView(Ui.button(this, "MANAGE ACCESS", Ui.GREEN,
                    v -> openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS)));
        } else {
            card.addView(Ui.button(this, "TURN ON", Ui.PINK, v ->
                    new AlertDialog.Builder(this)
                            .setTitle("Allow notification access")
                            .setMessage("On the next screen, find SafeSphere and switch it on.\n\n"
                                    + "If Android says \"Restricted setting\": go back, tap APP INFO below, tap ⋮ at the top right, "
                                    + "choose \"Allow restricted settings\", then try again. Android adds this step for apps "
                                    + "installed outside the Play Store.")
                            .setPositiveButton("Continue", (d, w) ->
                                    openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS))
                            .setNegativeButton("Cancel", null)
                            .show()));
            TextView info = Ui.chip(this, "APP INFO", Ui.MUTED);
            info.setOnClickListener(v -> {
                Ui.tap(v);
                open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            });
            LinearLayout r = Ui.hbox(this);
            r.setPadding(0, Ui.dp(this, 10), 0, 0);
            r.addView(info);
            card.addView(r);
        }
        return card;
    }

    private View passwordCard() {
        LinearLayout card = Ui.card(this, Ui.VIOLET);
        card.addView(Ui.text(this, "Leaked password checker", 16, Ui.TEXT, true));
        card.addView(body("Find out if a password has been exposed in a data breach. Your password never leaves this "
                + "phone: only the first 5 characters of its scrambled fingerprint (SHA-1 hash) are sent to Have I Been "
                + "Pwned, so nobody can learn what you typed."));

        EditText input = new EditText(this);
        input.setHint("Type a password to check");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleField(input);
        card.addView(input);

        final boolean[] visible = {false};
        TextView showBtn = Ui.button(this, "SHOW", Ui.MUTED, v -> {
            visible[0] = !visible[0];
            input.setInputType(InputType.TYPE_CLASS_TEXT | (visible[0]
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            input.setSelection(input.getText().length());
            ((TextView) v).setText(visible[0] ? "HIDE" : "SHOW");
        });
        TextView checkBtn = Ui.button(this, pwChecking ? "CHECKING…" : "CHECK PASSWORD", Ui.VIOLET, v -> {
            String pw = input.getText().toString();
            if (pw.isEmpty()) {
                Ui.shake(input);
                return;
            }
            hideKeyboard(input);
            checkPassword(pw);
        });
        LinearLayout row = Ui.hbox(this);
        row.addView(checkBtn, Ui.params(0, Ui.WRAP, 2f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(this, 12);
        row.addView(showBtn, lp);
        card.addView(row, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        PasswordCheck.Result r = pwResult;
        if (r != null) {
            LinearLayout res = Ui.vbox(this);
            res.setPadding(0, Ui.dp(this, 16), 0, 0);
            if (r.error != null) {
                res.addView(Ui.glow(this, "COULDN'T CHECK", 18, Ui.AMBER));
                res.addView(body(r.error));
            } else if (r.breaches > 0) {
                res.addView(Ui.glow(this, String.format(Locale.US, "FOUND IN %,d BREACHES", r.breaches), 18, Ui.RED));
                res.addView(body("Hackers try this password first. Stop using it and change it on every account "
                        + "that uses it, starting with GCash, banks and email."));
            } else {
                res.addView(Ui.glow(this, "NOT FOUND IN KNOWN BREACHES", 18, Ui.GREEN));
                res.addView(body("Good news: this password isn't in any known leak. That doesn't make it strong, so check "
                        + "the strength below."));
            }
            LinearLayout strength = Ui.hbox(this);
            strength.addView(Ui.text(this, "Strength", 13, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
            strength.addView(Ui.chip(this, r.strengthLabel(), r.strengthColor()));
            res.addView(strength);
            res.addView(body("• " + TextUtils.join("\n• ", r.tips)));
            card.addView(res);
        }
        return card;
    }

    private void checkPassword(String pw) {
        pwChecking = true;
        pwResult = null;
        show(TAB_CHECK);
        bg.execute(() -> {
            PasswordCheck.Result r = PasswordCheck.check(pw);
            runOnUiThread(() -> {
                pwChecking = false;
                pwResult = r;
                show(TAB_CHECK);
            });
        });
    }

    private void buildLinkChecker(LinearLayout col) {
        LinearLayout card = Ui.card(this, Ui.CYAN);
        card.addView(Ui.text(this, "Scam link & message checker", 16, Ui.TEXT, true));
        card.addView(body("Paste a suspicious link or a whole text message. SafeSphere looks for fake brand sites, "
                + "known threats and common scam tricks."));

        EditText input = new EditText(this);
        input.setText(checkText);
        input.setHint("Paste a link or text message here…");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        styleField(input);
        card.addView(input);

        LinearLayout row = twoButtons(
                Ui.button(this, checking ? "CHECKING…" : "CHECK", Ui.CYAN, v -> {
                    hideKeyboard(input);
                    runCheck(input.getText().toString(), null);
                }),
                Ui.button(this, "PASTE", Ui.VIOLET, v -> pasteAndCheck()));
        card.addView(row, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        card.addView(Ui.button(this, "CHECK A QR CODE IMAGE", Ui.AMBER, v -> pickQrImage()),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        TextView tip = Ui.text(this, "Faster: in your Messages app, select the suspicious text and tap \"Check with "
                + "SafeSphere\" in the menu, or use Share → SafeSphere. You can also share a QR code screenshot.", 11, Ui.MUTED, false);
        tip.setPadding(0, Ui.dp(this, 12), 0, 0);
        card.addView(tip);
        add(col, card);

        if (checkNote != null) {
            LinearLayout note = Ui.card(this, Ui.AMBER);
            note.addView(Ui.text(this, "QR code", 16, Ui.TEXT, true));
            note.addView(body(checkNote));
            add(col, note);
        }
        if (checkLinks == null) return;

        boolean anything = !checkLinks.isEmpty() || !checkWarnings.isEmpty();
        if (!anything) {
            if (checkNote == null) {
                LinearLayout none = Ui.card(this, Ui.MUTED);
                none.addView(Ui.text(this, "No links found", 16, Ui.TEXT, true));
                none.addView(body("Paste a full link (like https://example.com) or a whole text message that contains one."));
                add(col, none);
            }
            return;
        }

        int level = ScamDetector.SAFE;
        for (ScamDetector.LinkResult r : checkLinks) level = Math.max(level, r.level);
        if (checkWarnings.size() >= 2) level = Math.max(level, ScamDetector.SUSPICIOUS);
        else if (checkWarnings.size() == 1) level = Math.max(level, ScamDetector.CAUTION);

        int color = ScamDetector.color(level);
        LinearLayout verdict = Ui.card(this, color);
        verdict.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView big = Ui.glow(this, ScamDetector.label(level), 24, color);
        big.setLetterSpacing(0.1f);
        big.setGravity(Gravity.CENTER);
        verdict.addView(big);
        String summary;
        switch (level) {
            case ScamDetector.DANGEROUS: summary = "Do not open this. It's a known threat or a fake website."; break;
            case ScamDetector.SUSPICIOUS: summary = "This looks like a scam. Don't open the link, reply or send money."; break;
            case ScamDetector.CAUTION: summary = "Some warning signs. Only continue if you fully trust the sender."; break;
            default: summary = "No threats or warning signs found."; break;
        }
        TextView sum = body(summary);
        sum.setGravity(Gravity.CENTER);
        verdict.addView(sum);
        add(col, verdict);

        if (!checkWarnings.isEmpty()) {
            LinearLayout warn = Ui.card(this, Ui.PINK);
            warn.addView(Ui.text(this, "Scam signs in this message", 16, Ui.TEXT, true));
            TextView list = body("• " + TextUtils.join("\n• ", checkWarnings));
            warn.addView(list);
            add(col, warn);
        }

        for (ScamDetector.LinkResult r : checkLinks) {
            int c = ScamDetector.color(r.level);
            LinearLayout lc = Ui.card(this, c);
            LinearLayout head = Ui.hbox(this);
            TextView host = Ui.text(this, r.host, 15, Ui.TEXT, true);
            host.setSingleLine(true);
            host.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            head.addView(host, Ui.params(0, Ui.WRAP, 1f));
            LinearLayout.LayoutParams chipLp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            chipLp.leftMargin = Ui.dp(this, 8);
            head.addView(Ui.chip(this, ScamDetector.label(r.level), c), chipLp);
            lc.addView(head);
            TextView url = Ui.text(this, r.url, 11, Ui.MUTED, false);
            url.setSingleLine(true);
            url.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            lc.addView(url);
            lc.addView(body("• " + TextUtils.join("\n• ", r.reasons)));
            if (r.level >= ScamDetector.CAUTION && !RuleStore.blocked().contains(r.host)) {
                lc.addView(Ui.button(this, "BLOCK THIS SITE", Ui.PINK, v -> {
                    RuleStore.addBlock(r.host);
                    toast("Blocked " + r.host + " on this phone");
                    show(TAB_CHECK);
                }));
            }
            add(col, lc);
        }
    }

    private void runCheck(String text, String note) {
        checkText = text == null ? "" : text;
        checkNote = note;
        checking = true;
        show(TAB_CHECK);
        Context app = getApplicationContext();
        String input = checkText;
        bg.execute(() -> {
            RuleStore.init(app);
            ThreatDb.ensureLoaded(app);
            List<ScamDetector.LinkResult> results = new ArrayList<>();
            for (String l : ScamDetector.extractLinks(input)) results.add(ScamDetector.analyze(l));
            List<String> warnings = ScamDetector.messageWarnings(input);
            runOnUiThread(() -> {
                checking = false;
                checkLinks = results;
                checkWarnings = warnings;
                show(TAB_CHECK);
            });
        });
    }

    private void pasteAndCheck() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            toast("Nothing copied yet. Copy a link or message first.");
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.toString().trim().isEmpty()) {
            toast("Nothing copied yet. Copy a link or message first.");
            return;
        }
        runCheck(text.toString(), null);
    }

    private void pickQrImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Choose a QR code image"), REQ_QR);
        } catch (ActivityNotFoundException e) {
            toast("No gallery app found");
        }
    }

    private void readQr(Uri uri) {
        toast("Reading QR code…");
        Context app = getApplicationContext();
        bg.execute(() -> {
            String text = QrReader.read(app, uri);
            runOnUiThread(() -> {
                if (text == null) {
                    checkText = "";
                    checkNote = "No QR code found in that image. Try a clearer, closer screenshot of the code.";
                    checkLinks = new ArrayList<>();
                    checkWarnings = new ArrayList<>();
                    show(TAB_CHECK);
                } else if (QrReader.isPaymentCode(text)) {
                    checkText = "";
                    checkNote = "This is a QR Ph payment code (GCash, Maya or a bank). It contains no website link. "
                            + "Before paying, always check the recipient's name and the amount shown in your e-wallet.";
                    checkLinks = new ArrayList<>();
                    checkWarnings = new ArrayList<>();
                    show(TAB_CHECK);
                } else {
                    runCheck(text, "The QR code contains:\n" + text);
                }
            });
        });
    }

    // ------------------------------------------------------------------ Account security checkup

    private void buildCheckup(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.GREEN);
        TextView back = Ui.chip(this, "‹ BACK", Ui.CYAN);
        back.setOnClickListener(v -> {
            Ui.tap(v);
            show(TAB_SHIELD);
        });
        LinearLayout backRow = Ui.hbox(this);
        backRow.addView(back);
        head.addView(backRow);
        TextView title = Ui.glow(this, "Account Security Checkup", 20, Ui.GREEN);
        title.setPadding(0, Ui.dp(this, 12), 0, 0);
        head.addView(title);
        int done = Checkup.doneCount(this);
        head.addView(body(done + " of " + Checkup.ITEMS.length + " steps done. Tap OPEN to go straight to the right "
                + "settings page, then tap the circle when you've finished. Green items are detected automatically."));
        col.addView(head);

        String group = null;
        LinearLayout card = null;
        for (Checkup.Item item : Checkup.ITEMS) {
            if (!item.group.equals(group)) {
                group = item.group;
                card = Ui.card(this, Ui.VIOLET);
                card.addView(Ui.text(this, group, 16, Ui.TEXT, true));
                add(col, card);
            }
            card.addView(checkupRow(item));
        }
    }

    private View checkupRow(Checkup.Item item) {
        boolean done = Checkup.isDone(this, item);
        LinearLayout row = Ui.hbox(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);

        TextView box = Ui.text(this, done ? "✓" : "", 15, done ? Ui.BG : Ui.GREEN, true);
        box.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(done ? Ui.GREEN : 0x00000000);
        g.setStroke(Ui.dp(this, 2), Ui.GREEN);
        box.setBackground(g);
        int s = Ui.dp(this, 28);
        row.addView(box, new LinearLayout.LayoutParams(s, s));
        if (item.auto == Checkup.MANUAL) {
            box.setOnClickListener(v -> {
                Ui.tap(v);
                Checkup.setDone(this, item, !done);
                show(TAB_CHECKUP);
            });
        }

        LinearLayout texts = Ui.vbox(this);
        texts.setPadding(Ui.dp(this, 12), 0, 0, 0);
        texts.addView(Ui.text(this, item.title, 14, done ? Ui.GREEN : Ui.TEXT, true));
        String detail = item.detail + (item.auto != Checkup.MANUAL ? (done ? " (Detected automatically.)" : "") : "");
        TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
        d.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
        texts.addView(d);
        boolean showButton = !(done && item.auto != Checkup.MANUAL) && !(done && item.action == Checkup.ACT_NONE);
        if (showButton) {
            TextView btn = Ui.chip(this, item.button, Ui.CYAN);
            btn.setOnClickListener(v -> {
                Ui.tap(v);
                runCheckupAction(item);
            });
            LinearLayout btnRow = Ui.hbox(this);
            btnRow.addView(btn);
            texts.addView(btnRow);
        }
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private void runCheckupAction(Checkup.Item item) {
        switch (item.action) {
            case Checkup.ACT_PROTECT:
                toggleProtection();
                return;
            case Checkup.ACT_NONE:
                Checkup.setDone(this, item, true);
                show(TAB_CHECKUP);
                return;
            case Checkup.ACT_URL:
                open(new Intent(Intent.ACTION_VIEW, Uri.parse(item.targets[0])));
                return;
            case Checkup.ACT_DIAL:
                open(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + item.targets[0])));
                return;
            case Checkup.ACT_APP: {
                Intent launch = getPackageManager().getLaunchIntentForPackage(item.targets[0]);
                if (launch != null) open(launch);
                else open(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + item.targets[0])));
                return;
            }
            case Checkup.ACT_SETTINGS:
                for (String action : item.targets) {
                    try {
                        startActivity(new Intent(action));
                        return;
                    } catch (ActivityNotFoundException | SecurityException ignored) {
                        // try the next settings screen
                    }
                }
                toast("Open your phone's Settings app to do this step");
                return;
            default:
        }
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No app found to open this");
        }
    }

    // ------------------------------------------------------------------ Rules

    private void buildRules(LinearLayout col) {
        LinearLayout addCard = Ui.card(this, Ui.CYAN);
        addCard.addView(Ui.text(this, "Add a rule", 16, Ui.TEXT, true));
        addCard.addView(body("Type a domain or paste a link. Blocking a domain also blocks its subdomains."));

        EditText input = new EditText(this);
        input.setHint("example.com");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        styleField(input);
        addCard.addView(input);

        addCard.addView(twoButtons(
                Ui.button(this, "BLOCK", Ui.PINK, v -> saveRule(input, true)),
                Ui.button(this, "ALLOW", Ui.GREEN, v -> saveRule(input, false))),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        TextView note = Ui.text(this, "Changes apply instantly, no reinstall needed. Allowed domains always win over "
                + "blocklists and the fake-site detector. If a site you just blocked still opens, wait about a minute "
                + "for Android's DNS cache to clear.", 11, Ui.MUTED, false);
        note.setPadding(0, Ui.dp(this, 12), 0, 0);
        addCard.addView(note);
        col.addView(addCard);

        add(col, ruleList("Blocked domains", RuleStore.blocked(), Ui.PINK, "No custom blocked domains yet."));
        add(col, ruleList("Always allowed", RuleStore.allowed(), Ui.GREEN,
                "Nothing here. Add a domain if SafeSphere blocks something you trust."));
    }

    private void styleField(EditText input) {
        GradientDrawable field = new GradientDrawable();
        field.setColor(0xFF0A0816);
        field.setCornerRadius(Ui.dp(this, 14));
        field.setStroke(Ui.dp(this, 1.4f), Ui.alpha(Ui.CYAN, 0xAA));
        input.setBackground(field);
        int ip = Ui.dp(this, 14);
        input.setPadding(ip, ip, ip, ip);
    }

    private View ruleList(String title, List<String> items, int color, String emptyText) {
        LinearLayout c = Ui.card(this, color);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, String.valueOf(items.size()), color));
        c.addView(head);
        if (items.isEmpty()) {
            TextView e = Ui.text(this, emptyText, 12, Ui.MUTED, false);
            e.setPadding(0, Ui.dp(this, 8), 0, 0);
            c.addView(e);
        }
        for (String d : items) {
            LinearLayout row = Ui.hbox(this);
            row.setPadding(0, Ui.dp(this, 10), 0, 0);
            TextView name = Ui.text(this, d, 14, Ui.TEXT, false);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            row.addView(name, Ui.params(0, Ui.WRAP, 1f));
            TextView remove = Ui.chip(this, "REMOVE", Ui.MUTED);
            remove.setOnClickListener(v -> {
                Ui.tap(v);
                requirePin("Enter your PIN to change protection rules.", () -> {
                    RuleStore.remove(d);
                    toast("Removed " + d);
                    show(TAB_RULES);
                });
            });
            row.addView(remove);
            c.addView(row);
        }
        return c;
    }

    private void saveRule(EditText input, boolean block) {
        String domain = RuleStore.normalize(input.getText().toString());
        if (domain == null) {
            input.setError("Enter a valid domain, like example.com");
            Ui.shake(input);
            return;
        }
        hideKeyboard(input);
        if (block) {
            RuleStore.addBlock(domain);
            toast("Blocked " + domain);
            show(TAB_RULES);
            return;
        }
        requirePin("Enter your PIN to always allow a site.", () -> { // allowing a site lowers protection
            RuleStore.addAllow(domain);
            toast("Allowed " + domain);
            show(TAB_RULES);
        });
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ History

    private void buildHistory(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.PINK);
        head.addView(Ui.text(this, "Threat history", 16, Ui.TEXT, true));
        TextView sub = body("");
        head.addView(sub);
        head.addView(Ui.button(this, "CLEAR HISTORY", Ui.RED, v ->
                requirePin("Enter your PIN to clear the threat history.", () ->
                        new AlertDialog.Builder(this)
                                .setTitle("Clear threat history?")
                                .setMessage("This deletes every recorded blocked event on this phone.")
                                .setPositiveButton("Clear", (d, w) -> {
                                    EventLog.get(this).clear();
                                    toast("History cleared");
                                    show(TAB_HISTORY);
                                })
                                .setNegativeButton("Cancel", null)
                                .show())));
        col.addView(head);

        LinearLayout list = Ui.card(this, Ui.VIOLET);
        add(col, list);

        final long[] shownId = {-1};
        refresher = () -> {
            EventLog log = EventLog.get(this);
            long latest = log.latestId();
            if (latest == shownId[0]) return;
            shownId[0] = latest;
            sub.setText(log.count() + " blocked events · stored only on this phone. "
                    + "SafeSphere never records sites that were allowed.");
            list.removeAllViews();
            List<EventLog.Event> events = log.recent(300);
            if (events.isEmpty()) {
                list.addView(Ui.glow(this, "No threats blocked yet", 15, Ui.VIOLET));
                TextView t = Ui.text(this, "Turn protection on and run a live test on the Shield tab.", 12, Ui.MUTED, false);
                t.setPadding(0, Ui.dp(this, 6), 0, 0);
                list.addView(t);
                return;
            }
            for (EventLog.Event e : events) list.addView(eventRow(e, true));
        };
    }

    private View eventRow(EventLog.Event e, boolean full) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 12), 0, 0);
        LinearLayout texts = Ui.vbox(this);
        TextView d = Ui.text(this, e.domain, 14, Ui.TEXT, true);
        d.setSingleLine(true);
        d.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        texts.addView(d);
        String when = new SimpleDateFormat(full ? "MMM d · h:mm:ss a" : "h:mm a", Locale.getDefault()).format(new Date(e.time));
        texts.addView(Ui.text(this, when + " · " + e.reason, 11, Ui.MUTED, false));
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        lp.leftMargin = Ui.dp(this, 10);
        boolean warned = e.reason.startsWith("Scam message");
        row.addView(Ui.chip(this, warned ? "WARNED" : "BLOCKED", warned ? Ui.AMBER : Ui.PINK), lp);
        return row;
    }

    // ------------------------------------------------------------------ Device (audit + settings + app scan)

    private boolean auditing;

    private void runAudit() {
        if (auditing) return;
        auditing = true;
        Context app = getApplicationContext();
        bg.execute(() -> {
            DeviceAudit.run(app);
            runOnUiThread(() -> {
                auditing = false;
                if (currentTab == TAB_APPS) show(TAB_APPS);
            });
        });
    }

    private void buildDevice(LinearLayout col) {
        LinearLayout audit = Ui.card(this, Ui.CYAN);
        audit.addView(Ui.text(this, "Device security audit", 16, Ui.TEXT, true));
        List<DeviceAudit.Check> checks = DeviceAudit.last();
        if (checks == null) {
            audit.addView(body("Checking your phone's security settings…"));
            runAudit();
        } else {
            int score = DeviceAudit.lastScore();
            int sc = score >= 80 ? Ui.GREEN : score >= 60 ? Ui.AMBER : Ui.RED;
            LinearLayout scoreRow = Ui.hbox(this);
            scoreRow.setPadding(0, Ui.dp(this, 8), 0, 0);
            scoreRow.addView(Ui.glow(this, score + "/100", 30, sc));
            TextView word = Ui.text(this, score >= 80 ? "  Device is well secured" : score >= 60 ? "  Some settings need attention"
                    : "  Device is at risk", 13, Ui.MUTED, true);
            scoreRow.addView(word);
            audit.addView(scoreRow);
            for (DeviceAudit.Check ch : checks) audit.addView(auditRow(ch));
        }
        audit.addView(Ui.button(this, auditing ? "CHECKING…" : "RUN AUDIT AGAIN", Ui.CYAN, v -> runAudit()),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(audit);
        add(col, settingsCard());
        buildApps(col);
    }

    private View auditRow(DeviceAudit.Check ch) {
        int color = DeviceAudit.color(ch.level);
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);
        LinearLayout head = Ui.hbox(this);
        TextView t = Ui.text(this, ch.title, 14, ch.level == DeviceAudit.OK ? Ui.TEXT : color, true);
        head.addView(t, Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, ch.level == DeviceAudit.OK ? "OK" : ch.level == DeviceAudit.WARN ? "CHECK" : "RISK", color));
        row.addView(head);
        String detail = ch.detail;
        if (!ch.apps.isEmpty()) detail += "\nFound: " + TextUtils.join(", ", ch.apps);
        TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
        d.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 6));
        row.addView(d);
        if (ch.level != DeviceAudit.OK && ch.button != null) {
            TextView fix = Ui.chip(this, ch.button, Ui.CYAN);
            fix.setOnClickListener(v -> {
                Ui.tap(v);
                openSettings(ch.settings);
            });
            LinearLayout fr = Ui.hbox(this);
            fr.addView(fix);
            row.addView(fr);
        }
        return row;
    }

    private View settingsCard() {
        LinearLayout c = Ui.card(this, Ui.VIOLET);
        c.addView(Ui.text(this, "Protection settings", 16, Ui.TEXT, true));

        // Encrypted DNS
        boolean doh = Prefs.encryptedDns(this);
        c.addView(settingRow("Encrypted DNS (DNS-over-HTTPS)",
                "Hides which sites you look up from anyone on the same Wi-Fi. Uses Cloudflare 1.1.1.1 over HTTPS.",
                doh ? "ON" : "OFF", doh ? Ui.GREEN : Ui.MUTED, v -> {
                    if (doh) {
                        requirePin("Enter your PIN to turn off encrypted DNS.", () -> {
                            Prefs.setEncryptedDns(this, false);
                            show(TAB_APPS);
                        });
                    } else {
                        Prefs.setEncryptedDns(this, true);
                        show(TAB_APPS);
                    }
                }));

        // Protection lock
        boolean pin = Prefs.hasPin(this);
        c.addView(settingRow("Protection lock",
                pin ? "A PIN is needed to turn protection off, allow sites, remove rules or clear history."
                        : "Set a PIN so nobody else can switch protection off or change your rules.",
                pin ? "REMOVE PIN" : "SET PIN", pin ? Ui.PINK : Ui.CYAN, v -> {
                    if (pin) {
                        requirePin("Enter your current PIN to remove the lock.", () -> {
                            Prefs.clearPin(this);
                            refreshOngoingNotification();
                            toast("Protection lock removed");
                            show(TAB_APPS);
                        });
                    } else {
                        setPinFlow();
                    }
                }));

        // Auto-start
        c.addView(settingRow("Auto-start after restart",
                "Protection turns back on by itself after the phone restarts if you left it on. For the strongest setup, "
                        + "also turn on Always-on VPN for SafeSphere in Android's VPN settings.",
                "VPN SETTINGS", Ui.CYAN, v -> openSettings(Settings.ACTION_VPN_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS)));

        TextView note = Ui.text(this, "Android always lets the phone's owner disconnect a VPN from system settings. "
                + "The lock protects SafeSphere's own controls.", 11, Ui.MUTED, false);
        note.setPadding(0, Ui.dp(this, 12), 0, 0);
        c.addView(note);
        return c;
    }

    private View settingRow(String title, String detail, String action, int color, View.OnClickListener l) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 14, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        TextView chip = Ui.chip(this, action, color);
        chip.setOnClickListener(v -> {
            Ui.tap(v);
            l.onClick(v);
        });
        head.addView(chip);
        row.addView(head);
        TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
        d.setPadding(0, Ui.dp(this, 2), 0, 0);
        row.addView(d);
        return row;
    }

    // ------------------------------------------------------------------ protection lock

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        return e;
    }

    private View padded(View v) {
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 20);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(v);
        return f;
    }

    /** Runs the action right away, or after the correct PIN when a protection lock is set. */
    private void requirePin(String why, Runnable action) {
        if (!Prefs.hasPin(this)) {
            action.run();
            return;
        }
        EditText pin = pinField("PIN");
        new AlertDialog.Builder(this)
                .setTitle("Protection lock")
                .setMessage(why)
                .setView(padded(pin))
                .setPositiveButton("OK", (d, w) -> {
                    if (Prefs.checkPin(this, pin.getText().toString())) action.run();
                    else toast("Wrong PIN");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setPinFlow() {
        EditText first = pinField("4 to 8 digits");
        new AlertDialog.Builder(this)
                .setTitle("Set a protection PIN")
                .setMessage("You'll need this PIN to turn protection off, allow sites, remove rules or clear history.")
                .setView(padded(first))
                .setPositiveButton("Next", (d, w) -> {
                    String p1 = first.getText().toString();
                    if (p1.length() < 4 || p1.length() > 8) {
                        toast("Use 4 to 8 digits");
                        return;
                    }
                    EditText second = pinField("Type the same PIN again");
                    new AlertDialog.Builder(this)
                            .setTitle("Confirm PIN")
                            .setView(padded(second))
                            .setPositiveButton("Save", (d2, w2) -> {
                                if (!p1.equals(second.getText().toString())) {
                                    toast("PINs didn't match. Try again.");
                                    return;
                                }
                                Prefs.setPin(this, p1);
                                refreshOngoingNotification();
                                toast("Protection lock is on");
                                show(TAB_APPS);
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshOngoingNotification() {
        if (!SafeSphereVpnService.isRunning()) return;
        android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
        if (nm != null) nm.notify(Alerts.ONGOING_ID, Alerts.ongoing(this));
    }

    private void openSettings(String... actions) {
        for (String action : actions) {
            try {
                startActivity(new Intent(action));
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
                // try the next screen
            }
        }
        toast("Open your phone's Settings app to change this");
    }

    // ------------------------------------------------------------------ Apps

    private void buildApps(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.AMBER);
        head.addView(Ui.text(this, "App permission risk scan", 16, Ui.TEXT, true));
        head.addView(body("Finds installed apps holding sensitive access: SMS, call logs, microphone, camera, "
                + "location, screen reading and more. Only apps you installed are checked. A high score means broad "
                + "access, not that the app is malicious. Tap an app to review or remove its permissions."));
        head.addView(Ui.button(this, scanning ? "SCANNING…" : "SCAN INSTALLED APPS", Ui.AMBER, v -> scanApps()));
        add(col, head);
        if (lastScan == null) return;

        int high = 0, medium = 0, low = 0;
        for (AppScanner.AppRisk r : lastScan) {
            if (r.score >= 8) high++;
            else if (r.score >= 4) medium++;
            else low++;
        }
        LinearLayout summary = Ui.hbox(this);
        summary.addView(Ui.chip(this, high + " HIGH", Ui.RED));
        LinearLayout.LayoutParams gap = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, medium + " MEDIUM", Ui.AMBER), gap);
        LinearLayout.LayoutParams gap2 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap2.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, low + " LOW", Ui.GREEN), gap2);
        add(col, summary);

        if (lastScan.isEmpty()) {
            LinearLayout c = Ui.card(this, Ui.GREEN);
            c.addView(Ui.glow(this, "No risky apps found", 15, Ui.GREEN));
            add(col, c);
            return;
        }
        for (AppScanner.AppRisk r : lastScan) add(col, appCard(r));
    }

    private View appCard(AppScanner.AppRisk r) {
        LinearLayout c = Ui.card(this, r.color());
        LinearLayout top = Ui.hbox(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(r.icon);
        int s = Ui.dp(this, 40);
        top.addView(icon, new LinearLayout.LayoutParams(s, s));
        LinearLayout names = Ui.vbox(this);
        names.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        TextView label = Ui.text(this, r.label, 15, Ui.TEXT, true);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(label);
        TextView pkg = Ui.text(this, r.pkg, 10, Ui.MUTED, false);
        pkg.setSingleLine(true);
        pkg.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        names.addView(pkg);
        top.addView(names, Ui.params(0, Ui.WRAP, 1f));
        top.addView(Ui.chip(this, r.level() + " · " + r.score, r.color()));
        c.addView(top);
        TextView flags = Ui.text(this, "• " + TextUtils.join("\n• ", r.flags), 12, Ui.MUTED, false);
        flags.setPadding(0, Ui.dp(this, 10), 0, 0);
        c.addView(flags);
        c.setOnClickListener(v -> {
            Ui.tap(v);
            open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)));
        });
        return c;
    }

    private void scanApps() {
        if (scanning) return;
        scanning = true;
        show(TAB_APPS);
        Context app = getApplicationContext();
        bg.execute(() -> {
            List<AppScanner.AppRisk> result = AppScanner.scan(app);
            runOnUiThread(() -> {
                scanning = false;
                lastScan = result;
                if (currentTab == TAB_APPS) show(TAB_APPS);
                toast("Scan complete: " + result.size() + " apps hold sensitive access");
            });
        });
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static String compact(int n) {
        if (n >= 1_000_000) return String.format(Locale.US, "%.1fM", n / 1_000_000f);
        if (n >= 1_000) return String.format(Locale.US, "%.1fK", n / 1_000f);
        return String.valueOf(n);
    }
}
