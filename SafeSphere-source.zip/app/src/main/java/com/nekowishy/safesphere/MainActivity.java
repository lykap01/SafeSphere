package com.nekowishy.safesphere;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final String EXTRA_TAB = "tab";
    static final int TAB_SHIELD = 0, TAB_CHECK = 1, TAB_RULES = 2, TAB_HISTORY = 3, TAB_APPS = 4, TAB_CHECKUP = 5;

    private static final int REQ_VPN = 10;
    private static final int REQ_NOTIFY = 11;
    private static final int REQ_QR = 12;
    private static final int[] TAB_ICON_TYPES = {NavIcon.SHIELD, NavIcon.SEARCH, NavIcon.RULES, NavIcon.HISTORY, NavIcon.DEVICE};
    private static final String[] TAB_NAMES = {"Shield", "Check", "Rules", "History", "Device"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newCachedThreadPool();
    private final TextView[] tabs = new TextView[TAB_NAMES.length];
    private final FrameLayout[] tabHolders = new FrameLayout[TAB_NAMES.length];
    private final NavIcon[] tabIcons = new NavIcon[TAB_NAMES.length];
    private ScrollView scroll;
    private FrameLayout page;
    private int currentTab = -1;
    private Runnable refresher;
    private List<AppScanner.AppRisk> lastScan;
    private boolean scanning;

    // Check tab state (kept while switching tabs)
    private String checkText = "";
    private List<ScamDetector.LinkResult> checkLinks;
    private List<String> checkWarnings;
    private String checkNote;
    private boolean checking;

    // AI explainer state
    private AiClient.Result aiResult;
    private boolean aiLoading;

    // Password checker state (the password itself is never kept)
    private PasswordCheck.Result pwResult;
    private boolean pwChecking;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (refresher != null) refresher.run();
            handler.postDelayed(this, 1200);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        RuleStore.init(this);
        Alerts.channels(this);
        Context app = getApplicationContext();
        bg.execute(() -> ThreatDb.ensureLoaded(app));
        bg.execute(() -> DeviceAudit.run(app));
        WifiGuard.start(app);
        getWindow().setStatusBarColor(Ui.SKY);
        getWindow().setNavigationBarColor(Ui.BG);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR); // dark icons on the light bars

        LinearLayout root = Ui.vbox(this);
        root.setBackground(new Bevel.Page(Ui.dp(this, 2))); // soft gradient with embossed corner circles

        // Header: logo + wordmark on the left, round glass buttons on the right
        LinearLayout header = Ui.hbox(this);
        int p = Ui.dp(this, 20);
        header.setPadding(p, Ui.dp(this, 14), p, Ui.dp(this, 8));
        int ls = Ui.dp(this, 30);
        header.addView(new LogoView(this, Ui.TEXT), new LinearLayout.LayoutParams(ls, ls));
        LinearLayout brand = Ui.vbox(this);
        brand.setPadding(Ui.dp(this, 10), 0, 0, 0);
        TextView word = Ui.text(this, "SAFESPHERE", 19, Ui.TEXT, true);
        word.setLetterSpacing(0.16f);
        brand.addView(word);
        brand.addView(Ui.text(this, "Real-time online activity guardian", 11, Ui.MUTED, false));
        header.addView(brand, Ui.params(0, Ui.WRAP, 1f));
        int cs = Ui.dp(this, 48);
        header.addView(Ui.iconButton(this, NavIcon.HISTORY, Ui.TEXT, v -> show(TAB_HISTORY)), new LinearLayout.LayoutParams(cs, cs));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(cs, cs);
        mlp.leftMargin = Ui.dp(this, 10);
        header.addView(Ui.iconButton(this, NavIcon.MENU, Ui.TEXT, v -> show(TAB_APPS)), mlp);
        root.addView(header);

        page = new FrameLayout(this);
        root.addView(page, Ui.params(Ui.MATCH, 0, 1f));

        // Floating raised navigation bar with large drawn icons
        LinearLayout bar = Ui.hbox(this);
        bar.setBackground(Bevel.raised(Ui.dp(this, 30), Ui.dp(this, 1.6f)));
        Ui.shadow(bar, 10, Ui.SHADOW);
        int bp = Ui.dp(this, 8);
        bar.setPadding(bp, bp, bp, bp);
        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            LinearLayout item = Ui.vbox(this);
            item.setGravity(Gravity.CENTER_HORIZONTAL);
            FrameLayout holder = new FrameLayout(this);
            NavIcon icon = new NavIcon(this, TAB_ICON_TYPES[i], Ui.MUTED);
            int is = Ui.dp(this, 28);
            FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(is, is);
            ilp.gravity = Gravity.CENTER;
            holder.addView(icon, ilp);
            item.addView(holder, new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 44)));
            TextView t = Ui.text(this, TAB_NAMES[i], 11, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 4), 0, 0);
            item.addView(t);
            item.setOnClickListener(v -> {
                Ui.tap(holder);
                show(index);
            });
            tabs[i] = t;
            tabHolders[i] = holder;
            tabIcons[i] = icon;
            bar.addView(item, Ui.params(0, Ui.WRAP, 1f));
        }
        LinearLayout.LayoutParams barLp = Ui.params(Ui.MATCH, Ui.WRAP, 0f);
        barLp.leftMargin = Ui.dp(this, 14);
        barLp.rightMargin = Ui.dp(this, 14);
        barLp.bottomMargin = Ui.dp(this, 12);
        barLp.topMargin = Ui.dp(this, 4);
        root.addView(bar, barLp);
        setContentView(root);

        askNotificationPermission();
        if (!handleShared(getIntent())) show(getIntent().getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handleShared(intent)) return;
        if (intent.hasExtra(EXTRA_TAB)) show(intent.getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        if (currentTab == TAB_APPS || currentTab == TAB_CHECK) runAudit(); // the user may be back from fixing a setting
        refreshAlertsCard();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (currentTab == TAB_CHECKUP) {
            show(TAB_SHIELD);
            return;
        }
        super.onBackPressed();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
    }

    /** Text or images shared to SafeSphere, or text selected with "Check with SafeSphere". */
    private boolean handleShared(Intent intent) {
        if (intent == null || intent.getAction() == null) return false;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            String type = intent.getType();
            if (type != null && type.startsWith("image/")) {
                Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (uri != null) {
                    show(TAB_CHECK);
                    readQr(uri);
                    return true;
                }
            }
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null) {
                runCheck(text.toString(), null);
                return true;
            }
        }
        if (Intent.ACTION_PROCESS_TEXT.equals(action)) {
            CharSequence text = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
            if (text != null) {
                runCheck(text.toString(), null);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ navigation

    private void show(int tab) {
        if (tab < 0 || tab > TAB_CHECKUP) tab = TAB_SHIELD;
        // Re-drawing the screen you are already on (after Check, Save, Remove...) keeps your place.
        boolean refresh = tab == currentTab && scroll != null;
        int keepY = refresh ? scroll.getScrollY() : 0;
        currentTab = tab;
        for (int i = 0; i < tabs.length; i++) {
            boolean sel = i == tab;
            tabs[i].setTextColor(sel ? Ui.CYAN : Ui.MUTED);
            tabIcons[i].setColor(sel ? Ui.WHITE : Ui.MUTED);
            if (sel) {
                tabHolders[i].setBackground(Bevel.blue(Ui.dp(this, 16), Ui.dp(this, 1.2f)));
                Ui.shadow(tabHolders[i], 6, Ui.CYAN);
            } else {
                tabHolders[i].setBackground(null);
                tabHolders[i].setElevation(0);
            }
        }
        refresher = null;
        LinearLayout content = Ui.vbox(this);
        int p = Ui.dp(this, 18);
        content.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 32));
        switch (tab) {
            case TAB_CHECK: buildCheck(content); break;
            case TAB_RULES: buildRules(content); break;
            case TAB_HISTORY: buildHistory(content); break;
            case TAB_APPS: buildDevice(content); break;
            case TAB_CHECKUP: buildCheckup(content); break;
            default: buildShield(content); break;
        }
        // The page itself takes focus, so a text box never grabs it and makes the screen jump to it.
        content.setFocusableInTouchMode(true);
        content.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
        if (refresh) {
            // Same screen: swap the content inside the SAME scroll view and restore the position
            // before the first frame is drawn, so nothing flickers or jumps.
            ScrollView sv = scroll;
            sv.removeAllViews();
            sv.addView(content);
            content.requestFocus();
            ViewTreeObserver vto = sv.getViewTreeObserver();
            vto.addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
                @Override
                public boolean onPreDraw() {
                    sv.getViewTreeObserver().removeOnPreDrawListener(this);
                    sv.scrollTo(0, keepY);
                    return false; // skip this frame; the next one is drawn at the right place
                }
            });
        } else {
            for (int i = 0; i < content.getChildCount(); i++) Ui.enter(content.getChildAt(i), i);
            ScrollView sv = new ScrollView(this);
            sv.setFillViewport(true);
            sv.setVerticalScrollBarEnabled(false);
            sv.setClipToPadding(false);
            sv.addView(content);
            page.removeAllViews();
            page.addView(sv);
            scroll = sv;
            content.requestFocus();
        }
        if (refresher != null) refresher.run();
    }

    private void add(LinearLayout parent, View child) {
        parent.addView(child, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
    }

    private TextView body(String s) {
        TextView t = Ui.text(this, s, 12, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
        return t;
    }

    private LinearLayout twoButtons(TextView a, TextView b) {
        LinearLayout row = Ui.hbox(this);
        row.addView(a, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(this, 12);
        row.addView(b, lp);
        return row;
    }

    // ------------------------------------------------------------------ Shield (dashboard)

    private void buildShield(LinearLayout col) {
        // Blue hero card: status pill, power button, score dial with shield, headline, white pill button
        LinearLayout hero = Ui.vbox(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        hero.setBackground(new Bevel.Hero(Ui.dp(this, 32), Ui.dp(this, 1.6f))); // luminous blue glass
        Ui.shadow(hero, 12, Ui.CYAN);
        int hp = Ui.dp(this, 20);
        hero.setPadding(hp, hp, hp, hp);

        LinearLayout heroTop = Ui.hbox(this);
        TextView pill = Ui.chip(this, "", Ui.LIME);
        heroTop.addView(pill);
        heroTop.addView(new View(this), Ui.params(0, 1, 1f));
        PowerView power = new PowerView(this);
        power.setOnClickListener(v -> { Ui.tap(v); toggleProtection(); });
        int pw = Ui.dp(this, 44);
        heroTop.addView(power, new LinearLayout.LayoutParams(pw, pw));
        hero.addView(heroTop, Ui.params(Ui.MATCH, Ui.WRAP, 0f));

        ShieldView shield = new ShieldView(this);
        shield.setCameraDistance(12000 * getResources().getDisplayMetrics().density);
        int size = Ui.dp(this, 230);
        hero.addView(shield, new LinearLayout.LayoutParams(size, size));
        shield.setOnClickListener(v -> {
            v.animate().rotationYBy(360f).setDuration(900).setInterpolator(new AccelerateDecelerateInterpolator()).start();
            toggleProtection();
        });
        TextView status = Ui.glow(this, "", 28, Ui.WHITE);
        status.setGravity(Gravity.CENTER);
        hero.addView(status);
        TextView detail = Ui.text(this, "", 13, Ui.WHITE, false);
        detail.setGravity(Gravity.CENTER);
        detail.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 16));
        hero.addView(detail);
        TextView toggle = Ui.button(this, "", Ui.NAVY, v -> toggleProtection());
        Ui.solid(toggle, Ui.WHITE, Ui.NAVY);
        hero.addView(toggle, Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        col.addView(hero);

        // Private DNS warning (only shown when it bypasses the filter)
        LinearLayout dnsWarn = Ui.card(this, Ui.RED);
        dnsWarn.addView(Ui.glow(this, "⚠ Private DNS is skipping SafeSphere", 15, Ui.RED));
        dnsWarn.addView(body("Set Private DNS to Automatic or Off."));
        dnsWarn.addView(Ui.button(this, "OPEN NETWORK SETTINGS", Ui.RED,
                v -> openSettings(Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS)));
        add(col, dnsWarn);

        add(col, aiLauncher());

        // Security score
        LinearLayout scoreCard = Ui.card(this, Ui.CYAN);
        LinearLayout scoreRow = Ui.hbox(this);
        TextView scoreValue = Ui.glow(this, "--", 40, Ui.CYAN);
        scoreRow.addView(scoreValue);
        LinearLayout scoreTexts = Ui.vbox(this);
        scoreTexts.setPadding(Ui.dp(this, 16), 0, 0, 0);
        TextView scoreLabel = Ui.text(this, "SECURITY SCORE", 11, Ui.MUTED, true);
        scoreLabel.setLetterSpacing(0.12f);
        scoreTexts.addView(scoreLabel);
        TextView scoreWord = Ui.text(this, "", 16, Ui.TEXT, true);
        scoreTexts.addView(scoreWord);
        scoreRow.addView(scoreTexts, Ui.params(0, Ui.WRAP, 1f));
        scoreCard.addView(scoreRow);
        TextView scoreTips = body("");
        scoreCard.addView(scoreTips);
        TextView encLine = Ui.text(this, "", 11, Ui.MUTED, false);
        encLine.setPadding(0, 0, 0, Ui.dp(this, 12));
        scoreCard.addView(encLine);
        scoreCard.addView(Ui.button(this, "IMPROVE MY SCORE", Ui.CYAN, v -> show(TAB_APPS)));
        add(col, scoreCard);

        LinearLayout row1 = Ui.hbox(this);
        TextView vBlocked = stat(row1, "THREATS BLOCKED", Ui.PINK, false);
        TextView vToday = stat(row1, "BLOCKED TODAY", Ui.VIOLET, true);
        add(col, row1);
        LinearLayout row2 = Ui.hbox(this);
        TextView vRules = stat(row2, "CUSTOM RULES", Ui.GREEN, false);
        TextView vDb = stat(row2, "KNOWN THREATS", Ui.CYAN, true);
        add(col, row2);

        // Wi-Fi safety
        LinearLayout wifi = Ui.card(this, Ui.AMBER);
        wifi.addView(Ui.text(this, "Wi-Fi safety", 16, Ui.TEXT, true));
        TextView wifiStatus = Ui.glow(this, "", 17, Ui.GREEN);
        wifiStatus.setPadding(0, Ui.dp(this, 8), 0, 0);
        wifi.addView(wifiStatus);
        TextView wifiDetail = body("");
        wifi.addView(wifiDetail);
        add(col, wifi);

        // Account checkup summary
        LinearLayout checkup = Ui.card(this, Ui.GREEN);
        checkup.addView(Ui.text(this, "Account security checkup", 16, Ui.TEXT, true));
        TextView checkupInfo = body("");
        checkup.addView(checkupInfo);
        LinearLayout track = Ui.hbox(this);
        GradientDrawable trackBg = new GradientDrawable();
        trackBg.setColor(Ui.LINE);
        trackBg.setCornerRadius(Ui.dp(this, 8));
        track.setBackground(trackBg);
        View fill = new View(this);
        GradientDrawable fillBg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{Ui.CYAN, Ui.GREEN});
        fillBg.setCornerRadius(Ui.dp(this, 8));
        fill.setBackground(fillBg);
        View rest = new View(this);
        track.addView(fill, Ui.params(0, Ui.dp(this, 8), 0f));
        track.addView(rest, Ui.params(0, Ui.dp(this, 8), 1f));
        checkup.addView(track, Ui.params(Ui.MATCH, Ui.dp(this, 8), 0f));
        TextView openCheckup = Ui.button(this, "OPEN CHECKUP", Ui.GREEN, v -> show(TAB_CHECKUP));
        checkup.addView(openCheckup, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
        add(col, checkup);

        LinearLayout db = Ui.card(this, Ui.CYAN);
        db.addView(Ui.text(this, "Threat intelligence", 16, Ui.TEXT, true));
        TextView dbInfo = body("");
        db.addView(dbInfo);
        final TextView[] updateBtn = new TextView[1];
        updateBtn[0] = Ui.button(this, "UPDATE THREAT DATABASE", Ui.CYAN, v -> updateThreatDb(dbInfo, updateBtn[0]));
        db.addView(updateBtn[0]);
        add(col, db);

        LinearLayout test = Ui.card(this, Ui.PINK);
        test.addView(Ui.text(this, "Live protection test", 16, Ui.TEXT, true));
        test.addView(body("Safe simulation. Nothing is visited."));
        test.addView(twoButtons(
                Ui.button(this, "MALWARE", Ui.PINK, v -> runLiveTest(false)),
                Ui.button(this, "FAKE GCASH", Ui.AMBER, v -> runLiveTest(true))));
        add(col, test);

        LinearLayout recent = Ui.card(this, Ui.VIOLET);
        LinearLayout recentHead = Ui.hbox(this);
        recentHead.addView(Ui.text(this, "Threats blocked", 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        recentHead.addView(Ui.chip(this, "LAST 7 DAYS", Ui.VIOLET));
        recent.addView(recentHead);
        BarsView bars = new BarsView(this);
        LinearLayout.LayoutParams barsLp = Ui.margins(this, Ui.MATCH, Ui.dp(this, 170), 16);
        recent.addView(bars, barsLp);
        TextView recentTitle = Ui.text(this, "Recent activity", 14, Ui.TEXT, true);
        recentTitle.setPadding(0, Ui.dp(this, 18), 0, 0);
        recent.addView(recentTitle);
        LinearLayout recentList = Ui.vbox(this);
        recent.addView(recentList);
        add(col, recent);

        final long[] shownId = {-1};
        refresher = () -> {
            boolean on = SafeSphereVpnService.isRunning();
            String err = SafeSphereVpnService.lastError();
            shield.setActive(on);
            shield.setScore(DeviceAudit.securityScore(this));
            power.setColor(on ? Ui.LIME : Ui.WHITE);
            status.setText(on ? "Protection active" : "Protection off");
            pill.setText(on ? "STATUS · ACTIVE" : "STATUS · OFF");
            GradientDrawable pillBg = new GradientDrawable();
            pillBg.setCornerRadius(Ui.dp(this, 50));
            pillBg.setColor(on ? Ui.LIME : Ui.alpha(Ui.WHITE, 0x40));
            pill.setBackground(pillBg);
            pill.setTextColor(on ? Ui.NAVY : Ui.WHITE);
            if (on) {
                detail.setText("Checking every domain lookup from every app since "
                        + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(SafeSphereVpnService.startedAt())));
            } else if (err != null) {
                detail.setText("⚠ " + err);
            } else {
                detail.setText("Tap the shield to start protecting this phone");
            }
            toggle.setText(on ? "TURN OFF PROTECTION" : "TURN ON PROTECTION");

            dnsWarn.setVisibility(Prefs.privateDnsBypasses(this) ? View.VISIBLE : View.GONE);
            int score = DeviceAudit.securityScore(this);
            int sc = score >= 80 ? Ui.GREEN : score >= 60 ? Ui.AMBER : Ui.RED;
            scoreValue.setText(String.valueOf(score));
            setGlow(scoreValue, sc);
            scoreWord.setText(score >= 80 ? "Well protected" : score >= 60 ? "Needs attention" : "At risk");
            scoreTips.setText(scoreTips());
            long enc = SafeSphereVpnService.encryptedLookups, plain = SafeSphereVpnService.plainLookups;
            encLine.setText(!on ? "Turn on protection to start filtering."
                    : Prefs.encryptedDns(this)
                    ? "🔒 Encrypted DNS · " + enc + " lookups"
                    : "Encrypted DNS is off");

            EventLog log = EventLog.get(this);
            vBlocked.setText(String.valueOf(log.count()));
            vToday.setText(String.valueOf(log.countSince(startOfToday())));
            vRules.setText(String.valueOf(RuleStore.count()));
            vDb.setText(compact(ThreatDb.size()));
            if (!ThreatDb.isUpdating()) dbInfo.setText(ThreatDb.status(this));

            if (!WifiGuard.supported()) {
                wifiStatus.setText("Needs Android 12 or newer");
                setGlow(wifiStatus, Ui.MUTED);
                wifiDetail.setText("This phone's Android version doesn't report Wi-Fi security to apps.");
            } else {
                WifiGuard.Status ws = WifiGuard.current();
                if (ws == null) {
                    wifiStatus.setText("Not on Wi-Fi");
                    setGlow(wifiStatus, Ui.MUTED);
                    wifiDetail.setText("Not on Wi-Fi.");
                } else {
                    wifiStatus.setText((ws.level == WifiGuard.LEVEL_SAFE ? "✓ " : "⚠ ") + ws.title);
                    setGlow(wifiStatus, ws.level == WifiGuard.LEVEL_UNSAFE ? Ui.RED
                            : ws.level == WifiGuard.LEVEL_CAUTION ? Ui.AMBER : Ui.GREEN);
                    wifiDetail.setText(ws.detail);
                }
            }

            int done = Checkup.doneCount(this), total = Checkup.ITEMS.length;
            checkupInfo.setText(done + " of " + total + " steps done");
            ((LinearLayout.LayoutParams) fill.getLayoutParams()).weight = done;
            ((LinearLayout.LayoutParams) rest.getLayoutParams()).weight = total - done;
            track.requestLayout();

            long latest = log.latestId();
            if (latest != shownId[0]) {
                shownId[0] = latest;
                long today = startOfToday();
                String[] days = new String[7];
                SimpleDateFormat dayFmt = new SimpleDateFormat("EEE", Locale.getDefault());
                for (int i = 0; i < 7; i++) days[i] = i == 6 ? "Today" : dayFmt.format(new Date(today - (6L - i) * 86_400_000L));
                bars.setData(log.countsPerDay(7, today), days);
                recentList.removeAllViews();
                List<EventLog.Event> events = log.recent(5);
                if (events.isEmpty()) {
                    TextView empty = Ui.text(this, "No threats blocked yet. Run a live test to see one.", 12, Ui.MUTED, false);
                    empty.setPadding(0, Ui.dp(this, 8), 0, 0);
                    recentList.addView(empty);
                }
                for (EventLog.Event e : events) recentList.addView(eventRow(e, false));
            }
        };
    }

    private void setGlow(TextView t, int color) {
        t.setTextColor(color);
    }

    private TextView stat(LinearLayout row, String label, int color, boolean right) {
        LinearLayout c = Ui.card(this, color);
        TextView value = Ui.glow(this, "0", 28, color);
        c.addView(value);
        TextView l = Ui.text(this, label, 10, Ui.MUTED, true);
        l.setLetterSpacing(0.12f);
        c.addView(l);
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        if (right) lp.leftMargin = Ui.dp(this, 12);
        row.addView(c, lp);
        c.setOnClickListener(Ui::tap);
        return value;
    }

    /** Up to three things that would raise the security score most. */
    private String scoreTips() {
        List<String> tips = new ArrayList<>();
        if (!SafeSphereVpnService.isRunning()) tips.add("Turn on protection");
        List<DeviceAudit.Check> audit = DeviceAudit.last();
        if (audit != null) {
            for (DeviceAudit.Check ch : audit) if (ch.level == DeviceAudit.RISK && tips.size() < 3) tips.add(ch.title);
            for (DeviceAudit.Check ch : audit) if (ch.level == DeviceAudit.WARN && tips.size() < 3) tips.add(ch.title);
        }
        int left = Checkup.ITEMS.length - Checkup.doneCount(this);
        if (left > 0 && tips.size() < 3) tips.add("Finish the account checkup (" + left + " steps left)");
        if (tips.isEmpty()) return "Everything checks out. Keep protection on and your phone updated.";
        return "To improve:\n• " + TextUtils.join("\n• ", tips);
    }

    private void toggleProtection() {
        if (SafeSphereVpnService.isRunning()) {
            requirePin("Enter your PIN to turn protection off.", () -> {
                startService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_STOP));
                toast("Protection turned off");
                handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 400);
            });
            return;
        }
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            try {
                startActivityForResult(consent, REQ_VPN);
            } catch (ActivityNotFoundException e) {
                toast("This phone does not allow VPN apps");
            }
        } else {
            onActivityResult(REQ_VPN, RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_QR) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) readQr(data.getData());
            return;
        }
        if (requestCode != REQ_VPN) return;
        if (resultCode == RESULT_OK) {
            startForegroundService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_START));
            toast("Starting protection…");
            handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 600);
        } else {
            toast("Protection needs the VPN connection request to be allowed");
        }
    }

    private void updateThreatDb(TextView info, TextView button) {
        if (ThreatDb.isUpdating()) return;
        button.setEnabled(false);
        button.setText("UPDATING…");
        info.setText("Connecting…");
        Context app = getApplicationContext();
        bg.execute(() -> {
            String result = ThreatDb.update(app, msg -> runOnUiThread(() -> info.setText(msg)));
            runOnUiThread(() -> {
                button.setEnabled(true);
                button.setText("UPDATE THREAT DATABASE");
                info.setText(ThreatDb.status(this));
                toast(result);
            });
        });
    }

    private void runLiveTest(boolean fakeSite) {
        if (!SafeSphereVpnService.isRunning()) {
            toast("Turn protection on first, then run the test");
            return;
        }
        String id = Integer.toHexString(new Random().nextInt(0xFFFFFF));
        String domain = fakeSite ? "gcash-verify-login-" + id + ".example" : "t" + id + "." + RuleStore.TEST_ZONE;
        long started = System.currentTimeMillis();
        toast("Testing…");
        bg.execute(() -> {
            try {
                InetAddress.getByName(domain);
            } catch (Exception ignored) {
                // expected: the lookup is refused
            }
            try { Thread.sleep(700); } catch (InterruptedException ignored) { }
            boolean passed = domain.equals(SafeSphereVpnService.lastBlocked)
                    && SafeSphereVpnService.lastBlockedAt >= started;
            String why = RuleStore.check(domain);
            runOnUiThread(() -> {
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(passed ? "✅ Test passed" : "Test did not trigger")
                        .setMessage(passed
                                ? "SafeSphere caught the lookup for\n" + domain + "\nand blocked it before any connection was made.\n\n"
                                + "Reason: " + why + "\n\nCheck your notifications and the History tab."
                                : "The test lookup did not reach SafeSphere. Open Android Settings → Network → Private DNS and "
                                + "set it to Automatic or Off, then try again.")
                        .setPositiveButton("OK", null)
                        .show();
                if (refresher != null) refresher.run();
            });
        });
    }

    // ------------------------------------------------------------------ Check (scam link & message checker)

    private void buildCheck(LinearLayout col) {
        col.addView(messageAlertsHolder());
        add(col, aiLauncher());
        buildLinkChecker(col);
        add(col, passwordCard());
    }

    private FrameLayout alertsHolder;
    private boolean testingAlert;

    private View messageAlertsHolder() {
        alertsHolder = new FrameLayout(this);
        alertsHolder.addView(messageAlertsCard());
        return alertsHolder;
    }

    /** Rebuilds only the alerts card (e.g. after coming back from Android settings) so typed text elsewhere stays. */
    private void refreshAlertsCard() {
        if (alertsHolder == null || currentTab != TAB_CHECK) return;
        alertsHolder.removeAllViews();
        alertsHolder.addView(messageAlertsCard());
    }

    private View messageAlertsCard() {
        boolean on = ScamMessageWatcher.isEnabled(this);
        if (on && !ScamMessageWatcher.connected) ScamMessageWatcher.rebind(this);
        String blocked = Alerts.alertsBlockedReason(this);
        boolean ready = on && blocked == null;
        LinearLayout card = Ui.card(this, ready ? Ui.GREEN : on ? Ui.AMBER : Ui.PINK);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, "Automatic scam message alerts", 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, ready ? "ON" : on ? "CHECK" : "OFF", ready ? Ui.GREEN : on ? Ui.AMBER : Ui.MUTED));
        card.addView(head);

        // Live status: shows exactly which step is missing
        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.VERTICAL);
        status.setPadding(0, Ui.dp(this, 10), 0, 0);
        status.addView(statusLine(on, on ? "Notification access is on" : "Notification access is off"));
        status.addView(statusLine(blocked == null, blocked == null ? "SafeSphere can show alert pop-ups" : blocked));
        if (on) {
            android.content.SharedPreferences d = ScamMessageWatcher.diag(this);
            long seenAt = d.getLong("lastSeenAt", 0);
            if (seenAt == 0) {
                status.addView(statusLine(null, "No message received yet"));
            } else {
                String app = ScamMessageWatcher.appLabel(this, d.getString("lastSeenPkg", ""));
                String when = android.text.format.DateUtils.getRelativeTimeSpanString(seenAt, System.currentTimeMillis(),
                        android.text.format.DateUtils.MINUTE_IN_MILLIS).toString();
                boolean hadText = d.getBoolean("lastHadText", true);
                status.addView(statusLine(hadText, "Last message seen: " + app + ", " + when
                        + (hadText ? "" : " (text hidden: turn on message previews)")));
                long checkAt = d.getLong("lastCheckAt", 0);
                if (checkAt > 0) {
                    int lvl = d.getInt("lastCheckLevel", 0);
                    boolean alerted = lvl >= ScamDetector.SUSPICIOUS;
                    status.addView(statusLine(alerted ? Boolean.TRUE : null, "Last link: " + d.getString("lastCheckHost", "")
                            + " · " + ScamDetector.label(lvl) + (alerted ? " · alert sent" : " · no alert")));
                }
            }
        }
        card.addView(status);

        if (!on) {
            card.addView(Ui.button(this, "TURN ON", Ui.PINK, v ->
                    new AlertDialog.Builder(this)
                            .setTitle("Allow notification access")
                            .setMessage("On the next screen, find SafeSphere and switch it on.\n\n"
                                    + "If Android says \"Restricted setting\": go back, tap APP INFO below, tap ⋮ at the top right, "
                                    + "choose \"Allow restricted settings\", then try again. Android adds this step for apps "
                                    + "installed outside the Play Store.")
                            .setPositiveButton("Continue", (dd, w) ->
                                    openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS))
                            .setNegativeButton("Cancel", null)
                            .show()), Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        } else if (blocked != null) {
            card.addView(Ui.button(this, "ALLOW ALERT POP-UPS", Ui.AMBER, v -> openAlertSettings()),
                    Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        } else {
            TextView test = Ui.button(this, testingAlert ? "SENDING…" : "SEND TEST ALERT", Ui.WHITE, v -> sendTestAlert());
            Ui.primary(test);
            card.addView(test, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        }

        LinearLayout chips = Ui.hbox(this);
        chips.setPadding(0, Ui.dp(this, 10), 0, 0);
        TextView info = Ui.chip(this, "APP INFO", Ui.MUTED);
        info.setOnClickListener(v -> {
            Ui.tap(v);
            open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        });
        chips.addView(info);
        if (on) {
            TextView access = Ui.chip(this, "ACCESS", Ui.MUTED);
            access.setOnClickListener(v -> {
                Ui.tap(v);
                openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS);
            });
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.leftMargin = Ui.dp(this, 8);
            chips.addView(access, lp);
            TextView pop = Ui.chip(this, "POP-UPS", Ui.MUTED);
            pop.setOnClickListener(v -> {
                Ui.tap(v);
                openAlertSettings();
            });
            LinearLayout.LayoutParams lp2 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp2.leftMargin = Ui.dp(this, 8);
            chips.addView(pop, lp2);
            TextView battery = Ui.chip(this, "BATTERY", Ui.MUTED);
            battery.setOnClickListener(v -> {
                Ui.tap(v);
                toast("Set SafeSphere to \"Don't optimize\" or \"Allow background activity\"");
                openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, Settings.ACTION_SETTINGS);
            });
            LinearLayout.LayoutParams lp3 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp3.leftMargin = Ui.dp(this, 8);
            chips.addView(battery, lp3);
        }
        card.addView(chips);
        return card;
    }

    /** ok: true = green tick, false = red cross, null = neutral info. */
    private View statusLine(Boolean ok, String s) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 4), 0, 0);
        TextView mark = Ui.text(this, ok == null ? "•" : ok ? "✓" : "✕", 14,
                ok == null ? Ui.MUTED : ok ? Ui.GREEN : Ui.RED, true);
        mark.setMinWidth(Ui.dp(this, 20));
        row.addView(mark);
        row.addView(Ui.text(this, s, 13, ok == null || ok ? Ui.TEXT : Ui.RED, false), Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private void openAlertSettings() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && !Prefs.askedNotify(this)) {
            Prefs.setAskedNotify(this);
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            return;
        }
        open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
    }

    /** Runs the real detector on the sample parcel scam and posts the real alert, so the pop-up can be tested alone. */
    private void sendTestAlert() {
        if (testingAlert) return;
        testingAlert = true;
        refreshAlertsCard();
        Context app = getApplicationContext();
        bg.execute(() -> {
            boolean raised = ScamMessageWatcher.runTest(app);
            runOnUiThread(() -> {
                testingAlert = false;
                refreshAlertsCard();
                Toast.makeText(this, raised
                        ? "Test alert sent. Look at the top of your screen and in History."
                        : "The test message wasn't flagged. Please report this.", Toast.LENGTH_LONG).show();
            });
        });
    }

    private View passwordCard() {
        LinearLayout card = Ui.card(this, Ui.VIOLET);
        card.addView(Ui.text(this, "Leaked password checker", 16, Ui.TEXT, true));
        card.addView(body("Checked privately. Your password never leaves the phone."));

        EditText input = new EditText(this);
        input.setHint("Type a password to check");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        styleField(input);
        card.addView(input);

        final boolean[] visible = {false};
        TextView showBtn = Ui.button(this, "SHOW", Ui.MUTED, v -> {
            visible[0] = !visible[0];
            input.setInputType(InputType.TYPE_CLASS_TEXT | (visible[0]
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            input.setSelection(input.getText().length());
            ((TextView) v).setText(visible[0] ? "HIDE" : "SHOW");
        });
        TextView checkBtn = Ui.button(this, pwChecking ? "CHECKING…" : "CHECK PASSWORD", Ui.WHITE, v -> {
            String pw = input.getText().toString();
            if (pw.isEmpty()) {
                Ui.shake(input);
                return;
            }
            hideKeyboard(input);
            checkPassword(pw);
        });
        Ui.primary(checkBtn);
        LinearLayout row = Ui.hbox(this);
        row.addView(checkBtn, Ui.params(0, Ui.WRAP, 2f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(this, 12);
        row.addView(showBtn, lp);
        card.addView(row, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        PasswordCheck.Result r = pwResult;
        if (r != null) {
            LinearLayout res = Ui.vbox(this);
            res.setPadding(0, Ui.dp(this, 16), 0, 0);
            if (r.error != null) {
                res.addView(Ui.glow(this, "COULDN'T CHECK", 18, Ui.AMBER));
                res.addView(body(r.error));
            } else if (r.breaches > 0) {
                res.addView(Ui.glow(this, String.format(Locale.US, "FOUND IN %,d BREACHES", r.breaches), 18, Ui.RED));
                res.addView(body("Change it on every account that uses it."));
            } else {
                res.addView(Ui.glow(this, "NOT FOUND IN KNOWN BREACHES", 18, Ui.GREEN));
                res.addView(body("Not leaked. Check its strength below."));
            }
            LinearLayout strength = Ui.hbox(this);
            strength.addView(Ui.text(this, "Strength", 13, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
            strength.addView(Ui.chip(this, r.strengthLabel(), r.strengthColor()));
            res.addView(strength);
            res.addView(body("• " + TextUtils.join("\n• ", r.tips)));
            card.addView(res);
        }
        return card;
    }

    private void checkPassword(String pw) {
        pwChecking = true;
        pwResult = null;
        show(TAB_CHECK);
        bg.execute(() -> {
            PasswordCheck.Result r = PasswordCheck.check(pw);
            runOnUiThread(() -> {
                pwChecking = false;
                pwResult = r;
                show(TAB_CHECK);
            });
        });
    }

    private void buildLinkChecker(LinearLayout col) {
        LinearLayout card = Ui.card(this, Ui.CYAN);
        card.addView(Ui.text(this, "Scam link & message checker", 16, Ui.TEXT, true));

        EditText input = new EditText(this);
        input.setText(checkText);
        input.setHint("Paste a link or text message here…");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(false);
        input.setMinLines(3);
        input.setMaxLines(8);
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        styleField(input);
        card.addView(input);

        LinearLayout row = twoButtons(
                Ui.primary(Ui.button(this, checking ? "CHECKING…" : "CHECK", Ui.WHITE, v -> {
                    hideKeyboard(input);
                    runCheck(input.getText().toString(), null);
                })),
                Ui.button(this, "PASTE", Ui.VIOLET, v -> pasteAndCheck()));
        card.addView(row, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        card.addView(Ui.button(this, "CHECK A QR CODE IMAGE", Ui.AMBER, v -> pickQrImage()),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        add(col, card);

        if (checkNote != null) {
            LinearLayout note = Ui.card(this, Ui.AMBER);
            note.addView(Ui.text(this, "QR code", 16, Ui.TEXT, true));
            note.addView(body(checkNote));
            add(col, note);
        }
        if (checkLinks == null) return;

        boolean anything = !checkLinks.isEmpty() || !checkWarnings.isEmpty();
        if (!anything && !checkText.trim().isEmpty() && checkText.trim().length() > 12) add(col, aiCard());
        if (!anything) {
            if (checkNote == null) {
                LinearLayout none = Ui.card(this, Ui.MUTED);
                none.addView(Ui.text(this, "No links found", 16, Ui.TEXT, true));
                none.addView(body("Paste a full link or a message with a link."));
                add(col, none);
            }
            return;
        }

        int level = ScamDetector.SAFE;
        for (ScamDetector.LinkResult r : checkLinks) level = Math.max(level, r.level);
        if (checkWarnings.size() >= 2) level = Math.max(level, ScamDetector.SUSPICIOUS);
        else if (checkWarnings.size() == 1) level = Math.max(level, ScamDetector.CAUTION);

        int color = ScamDetector.color(level);
        LinearLayout verdict = Ui.card(this, color);
        verdict.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView big = Ui.glow(this, ScamDetector.label(level), 24, color);
        big.setLetterSpacing(0.1f);
        big.setGravity(Gravity.CENTER);
        verdict.addView(big);
        String summary;
        switch (level) {
            case ScamDetector.DANGEROUS: summary = "Don't open this link."; break;
            case ScamDetector.SUSPICIOUS: summary = "Looks like a scam. Don't open, reply or pay."; break;
            case ScamDetector.CAUTION: summary = "Some warning signs. Be careful."; break;
            default: summary = "No threats or warning signs found."; break;
        }
        TextView sum = body(summary);
        sum.setGravity(Gravity.CENTER);
        verdict.addView(sum);
        add(col, verdict);
        add(col, aiCard());

        if (!checkWarnings.isEmpty()) {
            LinearLayout warn = Ui.card(this, Ui.PINK);
            warn.addView(Ui.text(this, "Scam signs in this message", 16, Ui.TEXT, true));
            TextView list = body("• " + TextUtils.join("\n• ", checkWarnings));
            warn.addView(list);
            add(col, warn);
        }

        for (ScamDetector.LinkResult r : checkLinks) {
            int c = ScamDetector.color(r.level);
            LinearLayout lc = Ui.card(this, c);
            LinearLayout head = Ui.hbox(this);
            TextView host = Ui.text(this, r.host, 15, Ui.TEXT, true);
            host.setSingleLine(true);
            host.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            head.addView(host, Ui.params(0, Ui.WRAP, 1f));
            LinearLayout.LayoutParams chipLp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            chipLp.leftMargin = Ui.dp(this, 8);
            head.addView(Ui.chip(this, ScamDetector.label(r.level), c), chipLp);
            lc.addView(head);
            TextView url = Ui.text(this, r.url, 11, Ui.MUTED, false);
            url.setSingleLine(true);
            url.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            lc.addView(url);
            lc.addView(body("• " + TextUtils.join("\n• ", r.reasons)));
            if (r.level >= ScamDetector.CAUTION && !RuleStore.blocked().contains(r.host)) {
                lc.addView(Ui.button(this, "BLOCK THIS SITE", Ui.PINK, v -> {
                    RuleStore.addBlock(r.host);
                    toast("Blocked " + r.host + " on this phone");
                    show(TAB_CHECK);
                }));
            }
            add(col, lc);
        }
    }

    private void runCheck(String text, String note) {
        aiResult = null;
        aiLoading = false;
        checkText = text == null ? "" : text;
        checkNote = note;
        checking = true;
        show(TAB_CHECK);
        Context app = getApplicationContext();
        String input = checkText;
        bg.execute(() -> {
            RuleStore.init(app);
            ThreatDb.ensureLoaded(app);
            List<ScamDetector.LinkResult> results = new ArrayList<>();
            for (String l : ScamDetector.extractLinks(input)) results.add(ScamDetector.analyze(l));
            List<String> warnings = ScamDetector.messageWarnings(input);
            runOnUiThread(() -> {
                checking = false;
                checkLinks = results;
                checkWarnings = warnings;
                show(TAB_CHECK);
            });
        });
    }

    // ------------------------------------------------------------------ AI scam explainer

    private View aiCard() {
        LinearLayout c = Ui.card(this, Ui.CYAN);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, "Ask SafeSphere AI", 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, "AI", Ui.CYAN));
        c.addView(head);
        if (aiLoading) {
            c.addView(body("The AI is reading the message…"));
            return c;
        }
        AiClient.Result r = aiResult;
        if (r == null) {
            c.addView(Ui.primary(Ui.button(this, "EXPLAIN WITH AI", Ui.WHITE, v -> askAi())));
            return c;
        }
        if (r.error != null) {
            c.addView(body(r.error));
            c.addView(twoButtons(Ui.button(this, "TRY AGAIN", Ui.CYAN, v -> askAi()),
                    Ui.button(this, "AI SETUP", Ui.MUTED, v -> aiSetupDialog())));
            return c;
        }
        LinearLayout vr = Ui.hbox(this);
        vr.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 4));
        vr.addView(Ui.glow(this, r.label(), 26, r.color()), Ui.params(0, Ui.WRAP, 1f));
        vr.addView(Ui.chip(this, r.confidence.toUpperCase(Locale.ROOT) + " CONFIDENCE", Ui.VIOLET));
        c.addView(vr);
        if (!r.summary.isEmpty()) {
            TextView sm = Ui.text(this, r.summary, 14, Ui.TEXT, false);
            sm.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 8));
            c.addView(sm);
        }
        if (!r.reasons.isEmpty()) {
            c.addView(Ui.text(this, "Why", 13, Ui.TEXT, true));
            c.addView(body("• " + TextUtils.join("\n• ", r.reasons)));
        }
        if (!r.advice.isEmpty()) {
            c.addView(Ui.text(this, "What to do", 13, Ui.TEXT, true));
            c.addView(body("• " + TextUtils.join("\n• ", r.advice)));
        }
        c.addView(Ui.text(this, "AI can make mistakes.", 11, Ui.MUTED, false));
        c.addView(Ui.button(this, "ASK A FOLLOW-UP IN AI CHAT", Ui.VIOLET, v -> openAiChat()),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));
        return c;
    }

    /** SafeSphere's own findings, sent along so the AI starts from what the phone already found. */
    private String localFindings() {
        StringBuilder sb = new StringBuilder();
        if (checkLinks != null) {
            for (ScamDetector.LinkResult l : checkLinks) {
                sb.append("Link ").append(l.host).append(": ").append(ScamDetector.label(l.level));
                if (!l.reasons.isEmpty()) sb.append(" (").append(l.reasons.get(0)).append(")");
                sb.append("\n");
            }
        }
        if (checkWarnings != null) for (String w : checkWarnings) sb.append("Message sign: ").append(w).append("\n");
        return sb.toString();
    }

    private void askAi() {
        AiSetup.ensureReady(this, this::doAskAi);
    }

    private void doAskAi() {
        aiLoading = true;
        aiResult = null;
        show(TAB_CHECK);
        Context app = getApplicationContext();
        String text = checkText, local = localFindings();
        bg.execute(() -> {
            AiClient.Result r = AiClient.explain(app, text, local);
            runOnUiThread(() -> {
                aiLoading = false;
                aiResult = r;
                if (currentTab == TAB_CHECK) show(TAB_CHECK);
            });
        });
    }

    private void aiSetupDialog() {
        AiSetup.setupDialog(this, () -> { if (currentTab == TAB_APPS) show(TAB_APPS); });
    }

    private void openAiChat() {
        startActivity(new Intent(this, AiChatActivity.class));
    }

    /** Dark "AI mode" card with the live orb that opens the SafeSphere AI chat. */
    private View aiLauncher() {
        LinearLayout card = Ui.hbox(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{AiChatActivity.BG_TOP, 0xFF132257, 0xFF2A1E6E});
        g.setCornerRadius(Ui.dp(this, 26));
        g.setStroke(Ui.dp(this, 1), 0x33FFFFFF);
        card.setBackground(g);
        Ui.shadow(card, 10, OrbView.VIOLET);
        int p = Ui.dp(this, 14);
        card.setPadding(p, p, Ui.dp(this, 16), p);
        int os = Ui.dp(this, 70);
        card.addView(new OrbView(this, true, 14), new LinearLayout.LayoutParams(os, os));
        LinearLayout txt = Ui.vbox(this);
        txt.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        txt.addView(Ui.text(this, "SafeSphere AI", 17, AiChatActivity.INK, true));
        txt.addView(Ui.text(this, "Ask about any text, link or scam",
                12, AiChatActivity.SOFT, false));
        card.addView(txt, Ui.params(0, Ui.WRAP, 1f));
        FrameLayout go = new FrameLayout(this);
        GradientDrawable gg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{OrbView.CYAN, OrbView.BLUE, OrbView.VIOLET, OrbView.PINK});
        gg.setShape(GradientDrawable.OVAL);
        go.setBackground(gg);
        int is = Ui.dp(this, 20);
        go.addView(new NavIcon(this, NavIcon.SPARKLE, Ui.WHITE), new FrameLayout.LayoutParams(is, is, Gravity.CENTER));
        int gs = Ui.dp(this, 44);
        card.addView(go, new LinearLayout.LayoutParams(gs, gs));
        card.setOnClickListener(v -> { Ui.tap(v); openAiChat(); });
        return card;
    }

    private void pasteAndCheck() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            toast("Nothing copied yet. Copy a link or message first.");
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text == null || text.toString().trim().isEmpty()) {
            toast("Nothing copied yet. Copy a link or message first.");
            return;
        }
        runCheck(text.toString(), null);
    }

    private void pickQrImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
        try {
            startActivityForResult(Intent.createChooser(i, "Choose a QR code image"), REQ_QR);
        } catch (ActivityNotFoundException e) {
            toast("No gallery app found");
        }
    }

    private void readQr(Uri uri) {
        toast("Reading QR code…");
        Context app = getApplicationContext();
        bg.execute(() -> {
            String text = QrReader.read(app, uri);
            runOnUiThread(() -> {
                if (text == null) {
                    checkText = "";
                    checkNote = "No QR code found in that image. Try a clearer, closer screenshot of the code.";
                    checkLinks = new ArrayList<>();
                    checkWarnings = new ArrayList<>();
                    show(TAB_CHECK);
                } else if (QrReader.isPaymentCode(text)) {
                    checkText = "";
                    checkNote = "This is a QR Ph payment code (GCash, Maya or a bank). It contains no website link. "
                            + "Before paying, always check the recipient's name and the amount shown in your e-wallet.";
                    checkLinks = new ArrayList<>();
                    checkWarnings = new ArrayList<>();
                    show(TAB_CHECK);
                } else {
                    runCheck(text, "The QR code contains:\n" + text);
                }
            });
        });
    }

    // ------------------------------------------------------------------ Account security checkup

    private void buildCheckup(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.GREEN);
        TextView back = Ui.chip(this, "‹ BACK", Ui.CYAN);
        back.setOnClickListener(v -> {
            Ui.tap(v);
            show(TAB_SHIELD);
        });
        LinearLayout backRow = Ui.hbox(this);
        backRow.addView(back);
        head.addView(backRow);
        TextView title = Ui.glow(this, "Account Security Checkup", 20, Ui.GREEN);
        title.setPadding(0, Ui.dp(this, 12), 0, 0);
        head.addView(title);
        int done = Checkup.doneCount(this);
        head.addView(body(done + " of " + Checkup.ITEMS.length + " steps done"));
        col.addView(head);

        String group = null;
        LinearLayout card = null;
        for (Checkup.Item item : Checkup.ITEMS) {
            if (!item.group.equals(group)) {
                group = item.group;
                card = Ui.card(this, Ui.VIOLET);
                card.addView(Ui.text(this, group, 16, Ui.TEXT, true));
                add(col, card);
            }
            card.addView(checkupRow(item));
        }
    }

    private View checkupRow(Checkup.Item item) {
        boolean done = Checkup.isDone(this, item);
        LinearLayout row = Ui.hbox(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);

        TextView box = Ui.text(this, done ? "✓" : "", 15, done ? Ui.WHITE : Ui.GREEN, true);
        box.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(done ? Ui.GREEN : 0x00000000);
        g.setStroke(Ui.dp(this, 2), Ui.GREEN);
        box.setBackground(g);
        int s = Ui.dp(this, 28);
        row.addView(box, new LinearLayout.LayoutParams(s, s));
        if (item.auto == Checkup.MANUAL) {
            box.setOnClickListener(v -> {
                Ui.tap(v);
                Checkup.setDone(this, item, !done);
                show(TAB_CHECKUP);
            });
        }

        LinearLayout texts = Ui.vbox(this);
        texts.setPadding(Ui.dp(this, 12), 0, 0, 0);
        texts.addView(Ui.text(this, item.title, 14, done ? Ui.GREEN : Ui.TEXT, true));
        String detail = item.detail + (item.auto != Checkup.MANUAL ? (done ? " (Detected automatically.)" : "") : "");
        TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
        d.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 8));
        texts.addView(d);
        boolean showButton = !(done && item.auto != Checkup.MANUAL) && !(done && item.action == Checkup.ACT_NONE);
        if (showButton) {
            TextView btn = Ui.chip(this, item.button, Ui.CYAN);
            btn.setOnClickListener(v -> {
                Ui.tap(v);
                runCheckupAction(item);
            });
            LinearLayout btnRow = Ui.hbox(this);
            btnRow.addView(btn);
            texts.addView(btnRow);
        }
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private void runCheckupAction(Checkup.Item item) {
        switch (item.action) {
            case Checkup.ACT_PROTECT:
                toggleProtection();
                return;
            case Checkup.ACT_NONE:
                Checkup.setDone(this, item, true);
                show(TAB_CHECKUP);
                return;
            case Checkup.ACT_URL:
                open(new Intent(Intent.ACTION_VIEW, Uri.parse(item.targets[0])));
                return;
            case Checkup.ACT_DIAL:
                open(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + item.targets[0])));
                return;
            case Checkup.ACT_APP: {
                Intent launch = getPackageManager().getLaunchIntentForPackage(item.targets[0]);
                if (launch != null) open(launch);
                else open(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=" + item.targets[0])));
                return;
            }
            case Checkup.ACT_SETTINGS:
                for (String action : item.targets) {
                    try {
                        startActivity(new Intent(action));
                        return;
                    } catch (ActivityNotFoundException | SecurityException ignored) {
                        // try the next settings screen
                    }
                }
                toast("Open your phone's Settings app to do this step");
                return;
            default:
        }
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No app found to open this");
        }
    }

    // ------------------------------------------------------------------ Rules

    private void buildRules(LinearLayout col) {
        LinearLayout addCard = Ui.card(this, Ui.CYAN);
        addCard.addView(Ui.text(this, "Add a rule", 16, Ui.TEXT, true));

        EditText input = new EditText(this);
        input.setHint("example.com");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        styleField(input);
        addCard.addView(input);

        addCard.addView(twoButtons(
                Ui.button(this, "BLOCK", Ui.PINK, v -> saveRule(input, true)),
                Ui.button(this, "ALLOW", Ui.GREEN, v -> saveRule(input, false))),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        col.addView(addCard);

        add(col, ruleList("Blocked domains", RuleStore.blocked(), Ui.PINK, "No custom blocked domains yet."));
        add(col, ruleList("Always allowed", RuleStore.allowed(), Ui.GREEN,
                "Nothing here. Add a domain if SafeSphere blocks something you trust."));
    }

    private void styleField(EditText input) {
        input.setBackground(Bevel.pressed(Ui.dp(this, 18), Ui.dp(this, 1.6f))); // pressed-in (debossed) box
        int ip = Ui.dp(this, 16);
        input.setPadding(ip + 2, ip, ip, ip);
    }

    private View ruleList(String title, List<String> items, int color, String emptyText) {
        LinearLayout c = Ui.card(this, color);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, String.valueOf(items.size()), color));
        c.addView(head);
        if (items.isEmpty()) {
            TextView e = Ui.text(this, emptyText, 12, Ui.MUTED, false);
            e.setPadding(0, Ui.dp(this, 8), 0, 0);
            c.addView(e);
        }
        for (String d : items) {
            LinearLayout row = Ui.hbox(this);
            row.setPadding(0, Ui.dp(this, 10), 0, 0);
            TextView name = Ui.text(this, d, 14, Ui.TEXT, false);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            row.addView(name, Ui.params(0, Ui.WRAP, 1f));
            TextView remove = Ui.chip(this, "REMOVE", Ui.MUTED);
            remove.setOnClickListener(v -> {
                Ui.tap(v);
                requirePin("Enter your PIN to change protection rules.", () -> {
                    RuleStore.remove(d);
                    toast("Removed " + d);
                    show(TAB_RULES);
                });
            });
            row.addView(remove);
            c.addView(row);
        }
        return c;
    }

    private void saveRule(EditText input, boolean block) {
        String domain = RuleStore.normalize(input.getText().toString());
        if (domain == null) {
            input.setError("Enter a valid domain, like example.com");
            Ui.shake(input);
            return;
        }
        hideKeyboard(input);
        if (block) {
            RuleStore.addBlock(domain);
            toast("Blocked " + domain);
            show(TAB_RULES);
            return;
        }
        requirePin("Enter your PIN to always allow a site.", () -> { // allowing a site lowers protection
            RuleStore.addAllow(domain);
            toast("Allowed " + domain);
            show(TAB_RULES);
        });
    }

    private void hideKeyboard(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    // ------------------------------------------------------------------ History

    private void buildHistory(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.PINK);
        head.addView(Ui.text(this, "Threat history", 16, Ui.TEXT, true));
        TextView sub = body("");
        head.addView(sub);
        head.addView(Ui.button(this, "CLEAR HISTORY", Ui.RED, v ->
                requirePin("Enter your PIN to clear the threat history.", () ->
                        new AlertDialog.Builder(this)
                                .setTitle("Clear threat history?")
                                .setMessage("This deletes every recorded blocked event on this phone.")
                                .setPositiveButton("Clear", (d, w) -> {
                                    EventLog.get(this).clear();
                                    toast("History cleared");
                                    show(TAB_HISTORY);
                                })
                                .setNegativeButton("Cancel", null)
                                .show())));
        col.addView(head);

        LinearLayout list = Ui.card(this, Ui.VIOLET);
        add(col, list);

        final long[] shownId = {-1};
        refresher = () -> {
            EventLog log = EventLog.get(this);
            long latest = log.latestId();
            if (latest == shownId[0]) return;
            shownId[0] = latest;
            sub.setText(log.count() + " events · saved on this phone only");
            list.removeAllViews();
            List<EventLog.Event> events = log.recent(300);
            if (events.isEmpty()) {
                list.addView(Ui.glow(this, "No threats blocked yet", 15, Ui.VIOLET));
                TextView t = Ui.text(this, "Turn protection on and run a live test on the Shield tab.", 12, Ui.MUTED, false);
                t.setPadding(0, Ui.dp(this, 6), 0, 0);
                list.addView(t);
                return;
            }
            for (EventLog.Event e : events) list.addView(eventRow(e, true));
        };
    }

    private View eventRow(EventLog.Event e, boolean full) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 12), 0, 0);
        LinearLayout texts = Ui.vbox(this);
        TextView d = Ui.text(this, e.domain, 14, Ui.TEXT, true);
        d.setSingleLine(true);
        d.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        texts.addView(d);
        String when = new SimpleDateFormat(full ? "MMM d · h:mm:ss a" : "h:mm a", Locale.getDefault()).format(new Date(e.time));
        texts.addView(Ui.text(this, when + " · " + e.reason, 11, Ui.MUTED, false));
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        lp.leftMargin = Ui.dp(this, 10);
        boolean warned = e.reason.startsWith("Scam message");
        row.addView(Ui.chip(this, warned ? "WARNED" : "BLOCKED", warned ? Ui.AMBER : Ui.PINK), lp);
        return row;
    }

    // ------------------------------------------------------------------ Device (audit + settings + app scan)

    private boolean auditing;

    private void runAudit() {
        if (auditing) return;
        auditing = true;
        Context app = getApplicationContext();
        bg.execute(() -> {
            DeviceAudit.run(app);
            runOnUiThread(() -> {
                auditing = false;
                if (currentTab == TAB_APPS) show(TAB_APPS);
            });
        });
    }

    private void buildDevice(LinearLayout col) {
        LinearLayout audit = Ui.card(this, Ui.CYAN);
        audit.addView(Ui.text(this, "Device security audit", 16, Ui.TEXT, true));
        List<DeviceAudit.Check> checks = DeviceAudit.last();
        if (checks == null) {
            audit.addView(body("Checking your phone's security settings…"));
            runAudit();
        } else {
            int score = DeviceAudit.lastScore();
            int sc = score >= 80 ? Ui.GREEN : score >= 60 ? Ui.AMBER : Ui.RED;
            LinearLayout scoreRow = Ui.hbox(this);
            scoreRow.setPadding(0, Ui.dp(this, 8), 0, 0);
            scoreRow.addView(Ui.glow(this, score + "/100", 30, sc));
            TextView word = Ui.text(this, score >= 80 ? "  Device is well secured" : score >= 60 ? "  Some settings need attention"
                    : "  Device is at risk", 13, Ui.MUTED, true);
            scoreRow.addView(word);
            audit.addView(scoreRow);
            for (DeviceAudit.Check ch : checks) audit.addView(auditRow(ch));
        }
        audit.addView(Ui.button(this, auditing ? "CHECKING…" : "RUN AUDIT AGAIN", Ui.CYAN, v -> runAudit()),
                Ui.margins(this, Ui.MATCH, Ui.WRAP, 16));
        col.addView(audit);
        add(col, settingsCard());
        buildApps(col);
    }

    private View auditRow(DeviceAudit.Check ch) {
        int color = DeviceAudit.color(ch.level);
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);
        LinearLayout head = Ui.hbox(this);
        TextView t = Ui.text(this, ch.title, 14, ch.level == DeviceAudit.OK ? Ui.TEXT : color, true);
        head.addView(t, Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, ch.level == DeviceAudit.OK ? "OK" : ch.level == DeviceAudit.WARN ? "CHECK" : "RISK", color));
        row.addView(head);
        if (ch.level != DeviceAudit.OK) {
            String detail = ch.detail;
            if (!ch.apps.isEmpty()) detail += "\nFound: " + TextUtils.join(", ", ch.apps);
            TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
            d.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 6));
            row.addView(d);
        }
        if (ch.level != DeviceAudit.OK && ch.button != null) {
            TextView fix = Ui.chip(this, ch.button, Ui.CYAN);
            fix.setOnClickListener(v -> {
                Ui.tap(v);
                openSettings(ch.settings);
            });
            LinearLayout fr = Ui.hbox(this);
            fr.addView(fix);
            row.addView(fr);
        }
        return row;
    }

    private View settingsCard() {
        LinearLayout c = Ui.card(this, Ui.VIOLET);
        c.addView(Ui.text(this, "Protection settings", 16, Ui.TEXT, true));

        // Encrypted DNS
        boolean doh = Prefs.encryptedDns(this);
        c.addView(settingRow("Encrypted DNS (DNS-over-HTTPS)",
                "Hides your lookups on public Wi-Fi",
                doh ? "ON" : "OFF", doh ? Ui.GREEN : Ui.MUTED, v -> {
                    if (doh) {
                        requirePin("Enter your PIN to turn off encrypted DNS.", () -> {
                            Prefs.setEncryptedDns(this, false);
                            show(TAB_APPS);
                        });
                    } else {
                        Prefs.setEncryptedDns(this, true);
                        show(TAB_APPS);
                    }
                }));

        // Protection lock
        boolean pin = Prefs.hasPin(this);
        c.addView(settingRow("Protection lock",
                pin ? "PIN needed to change protection" : "Stop others turning protection off",
                pin ? "REMOVE PIN" : "SET PIN", pin ? Ui.PINK : Ui.CYAN, v -> {
                    if (pin) {
                        requirePin("Enter your current PIN to remove the lock.", () -> {
                            Prefs.clearPin(this);
                            refreshOngoingNotification();
                            toast("Protection lock removed");
                            show(TAB_APPS);
                        });
                    } else {
                        setPinFlow();
                    }
                }));

        // AI explainer
        boolean aiReady = AiClient.isSetUp(this);
        c.addView(settingRow("SafeSphere AI",
                aiReady ? "Ready" : "Not set up",
                aiReady ? "CHANGE" : "SET UP", aiReady ? Ui.GREEN : Ui.CYAN, v -> aiSetupDialog()));

        // Auto-start
        c.addView(settingRow("Auto-start after restart",
                "Turns back on after a restart",
                "VPN SETTINGS", Ui.CYAN, v -> openSettings(Settings.ACTION_VPN_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS)));

        return c;
    }

    private View settingRow(String title, String detail, String action, int color, View.OnClickListener l) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 14), 0, 0);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 14, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        TextView chip = Ui.chip(this, action, color);
        chip.setOnClickListener(v -> {
            Ui.tap(v);
            l.onClick(v);
        });
        head.addView(chip);
        row.addView(head);
        TextView d = Ui.text(this, detail, 12, Ui.MUTED, false);
        d.setPadding(0, Ui.dp(this, 2), 0, 0);
        row.addView(d);
        return row;
    }

    // ------------------------------------------------------------------ protection lock

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        return e;
    }

    private View padded(View v) {
        FrameLayout f = new FrameLayout(this);
        int p = Ui.dp(this, 20);
        f.setPadding(p, Ui.dp(this, 8), p, 0);
        f.addView(v);
        return f;
    }

    /** Runs the action right away, or after the correct PIN when a protection lock is set. */
    private void requirePin(String why, Runnable action) {
        if (!Prefs.hasPin(this)) {
            action.run();
            return;
        }
        EditText pin = pinField("PIN");
        new AlertDialog.Builder(this)
                .setTitle("Protection lock")
                .setMessage(why)
                .setView(padded(pin))
                .setPositiveButton("OK", (d, w) -> {
                    if (Prefs.checkPin(this, pin.getText().toString())) action.run();
                    else toast("Wrong PIN");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setPinFlow() {
        EditText first = pinField("4 to 8 digits");
        new AlertDialog.Builder(this)
                .setTitle("Set a protection PIN")
                .setMessage("You'll need this PIN to turn protection off, allow sites, remove rules or clear history.")
                .setView(padded(first))
                .setPositiveButton("Next", (d, w) -> {
                    String p1 = first.getText().toString();
                    if (p1.length() < 4 || p1.length() > 8) {
                        toast("Use 4 to 8 digits");
                        return;
                    }
                    EditText second = pinField("Type the same PIN again");
                    new AlertDialog.Builder(this)
                            .setTitle("Confirm PIN")
                            .setView(padded(second))
                            .setPositiveButton("Save", (d2, w2) -> {
                                if (!p1.equals(second.getText().toString())) {
                                    toast("PINs didn't match. Try again.");
                                    return;
                                }
                                Prefs.setPin(this, p1);
                                refreshOngoingNotification();
                                toast("Protection lock is on");
                                show(TAB_APPS);
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshOngoingNotification() {
        if (!SafeSphereVpnService.isRunning()) return;
        android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
        if (nm != null) nm.notify(Alerts.ONGOING_ID, Alerts.ongoing(this));
    }

    private void openSettings(String... actions) {
        for (String action : actions) {
            try {
                startActivity(new Intent(action));
                return;
            } catch (ActivityNotFoundException | SecurityException ignored) {
                // try the next screen
            }
        }
        toast("Open your phone's Settings app to change this");
    }

    // ------------------------------------------------------------------ Apps

    private void buildApps(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.AMBER);
        head.addView(Ui.text(this, "App permission risk scan", 16, Ui.TEXT, true));
        head.addView(body("Finds apps with risky permissions"));
        head.addView(Ui.button(this, scanning ? "SCANNING…" : "SCAN INSTALLED APPS", Ui.AMBER, v -> scanApps()));
        add(col, head);
        if (lastScan == null) return;

        int high = 0, medium = 0, low = 0;
        for (AppScanner.AppRisk r : lastScan) {
            if (r.score >= 8) high++;
            else if (r.score >= 4) medium++;
            else low++;
        }
        LinearLayout summary = Ui.hbox(this);
        summary.addView(Ui.chip(this, high + " HIGH", Ui.RED));
        LinearLayout.LayoutParams gap = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, medium + " MEDIUM", Ui.AMBER), gap);
        LinearLayout.LayoutParams gap2 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap2.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, low + " LOW", Ui.GREEN), gap2);
        add(col, summary);

        if (lastScan.isEmpty()) {
            LinearLayout c = Ui.card(this, Ui.GREEN);
            c.addView(Ui.glow(this, "No risky apps found", 15, Ui.GREEN));
            add(col, c);
            return;
        }
        for (AppScanner.AppRisk r : lastScan) add(col, appCard(r));
    }

    private View appCard(AppScanner.AppRisk r) {
        LinearLayout c = Ui.card(this, r.color());
        LinearLayout top = Ui.hbox(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(r.icon);
        int s = Ui.dp(this, 40);
        top.addView(icon, new LinearLayout.LayoutParams(s, s));
        LinearLayout names = Ui.vbox(this);
        names.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        TextView label = Ui.text(this, r.label, 15, Ui.TEXT, true);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(label);
        TextView pkg = Ui.text(this, r.pkg, 10, Ui.MUTED, false);
        pkg.setSingleLine(true);
        pkg.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        names.addView(pkg);
        top.addView(names, Ui.params(0, Ui.WRAP, 1f));
        top.addView(Ui.chip(this, r.level() + " · " + r.score, r.color()));
        c.addView(top);
        TextView flags = Ui.text(this, "• " + TextUtils.join("\n• ", r.flags), 12, Ui.MUTED, false);
        flags.setPadding(0, Ui.dp(this, 10), 0, 0);
        c.addView(flags);
        c.setOnClickListener(v -> {
            Ui.tap(v);
            open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)));
        });
        return c;
    }

    private void scanApps() {
        if (scanning) return;
        scanning = true;
        show(TAB_APPS);
        Context app = getApplicationContext();
        bg.execute(() -> {
            List<AppScanner.AppRisk> result = AppScanner.scan(app);
            runOnUiThread(() -> {
                scanning = false;
                lastScan = result;
                if (currentTab == TAB_APPS) show(TAB_APPS);
                toast("Scan complete: " + result.size() + " apps hold sensitive access");
            });
        });
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static String compact(int n) {
        if (n >= 1_000_000) return String.format(Locale.US, "%.1fM", n / 1_000_000f);
        if (n >= 1_000) return String.format(Locale.US, "%.1fK", n / 1_000f);
        return String.valueOf(n);
    }
}
