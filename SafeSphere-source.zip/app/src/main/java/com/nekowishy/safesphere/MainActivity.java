package com.nekowishy.safesphere;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    static final String EXTRA_TAB = "tab";
    static final int TAB_SHIELD = 0, TAB_RULES = 1, TAB_HISTORY = 2, TAB_APPS = 3;

    private static final int REQ_VPN = 10;
    private static final int REQ_NOTIFY = 11;
    private static final String[] TAB_ICONS = {"◈", "☰", "◷", "▣"};
    private static final String[] TAB_NAMES = {"Shield", "Rules", "History", "Apps"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newCachedThreadPool();
    private final TextView[] tabs = new TextView[4];
    private FrameLayout page;
    private int currentTab = -1;
    private Runnable refresher;
    private List<AppScanner.AppRisk> lastScan;
    private boolean scanning;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (refresher != null) refresher.run();
            handler.postDelayed(this, 1200);
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        RuleStore.init(this);
        Alerts.channels(this);
        Context app = getApplicationContext();
        bg.execute(() -> ThreatDb.ensureLoaded(app));
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = Ui.vbox(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF140A2E, Ui.BG, 0xFF04030B}));

        LinearLayout header = Ui.vbox(this);
        int p = Ui.dp(this, 20);
        header.setPadding(p, p, p, Ui.dp(this, 6));
        TextView logo = Ui.glow(this, "SAFESPHERE", 26, Ui.CYAN);
        logo.setLetterSpacing(0.22f);
        header.addView(logo);
        header.addView(Ui.text(this, "Real-time online activity guardian", 12, Ui.MUTED, false));
        root.addView(header);

        page = new FrameLayout(this);
        root.addView(page, Ui.params(Ui.MATCH, 0, 1f));

        LinearLayout bar = Ui.hbox(this);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(0xF00B0919);
        barBg.setStroke(Ui.dp(this, 1), Ui.alpha(Ui.CYAN, 0x33));
        bar.setBackground(barBg);
        int bp = Ui.dp(this, 8);
        bar.setPadding(bp, bp, bp, bp);
        for (int i = 0; i < 4; i++) {
            final int index = i;
            TextView t = Ui.text(this, TAB_ICONS[i] + "\n" + TAB_NAMES[i], 12, Ui.MUTED, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            t.setOnClickListener(v -> {
                Ui.tap(v);
                show(index);
            });
            tabs[i] = t;
            bar.addView(t, Ui.params(0, Ui.WRAP, 1f));
        }
        root.addView(bar, Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        setContentView(root);

        askNotificationPermission();
        show(getIntent().getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.hasExtra(EXTRA_TAB)) show(intent.getIntExtra(EXTRA_TAB, TAB_SHIELD));
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
        }
    }

    // ------------------------------------------------------------------ navigation

    private void show(int tab) {
        if (tab < 0 || tab > 3) tab = TAB_SHIELD;
        currentTab = tab;
        for (int i = 0; i < 4; i++) {
            TextView t = tabs[i];
            if (i == tab) {
                t.setTextColor(Ui.CYAN);
                t.setShadowLayer(Ui.dp(this, 10), 0, 0, Ui.CYAN);
                GradientDrawable g = new GradientDrawable();
                g.setColor(Ui.alpha(Ui.CYAN, 0x1C));
                g.setCornerRadius(Ui.dp(this, 14));
                t.setBackground(g);
            } else {
                t.setTextColor(Ui.MUTED);
                t.setShadowLayer(0, 0, 0, 0);
                t.setBackground(null);
            }
        }
        refresher = null;
        LinearLayout content = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        content.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 28));
        switch (tab) {
            case TAB_RULES: buildRules(content); break;
            case TAB_HISTORY: buildHistory(content); break;
            case TAB_APPS: buildApps(content); break;
            default: buildShield(content); break;
        }
        for (int i = 0; i < content.getChildCount(); i++) Ui.enter(content.getChildAt(i), i);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(content);
        page.removeAllViews();
        page.addView(scroll);
        if (refresher != null) refresher.run();
    }

    private void add(LinearLayout parent, View child) {
        parent.addView(child, Ui.margins(this, Ui.MATCH, Ui.WRAP, 14));
    }

    // ------------------------------------------------------------------ Shield (dashboard)

    private void buildShield(LinearLayout col) {
        LinearLayout hero = Ui.vbox(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        ShieldView shield = new ShieldView(this);
        shield.setCameraDistance(12000 * getResources().getDisplayMetrics().density);
        int size = Ui.dp(this, 240);
        hero.addView(shield, new LinearLayout.LayoutParams(size, size));
        shield.setOnClickListener(v -> {
            v.animate().rotationYBy(360f).setDuration(900).setInterpolator(new AccelerateDecelerateInterpolator()).start();
            toggleProtection();
        });
        TextView status = Ui.glow(this, "", 22, Ui.CYAN);
        status.setLetterSpacing(0.1f);
        status.setGravity(Gravity.CENTER);
        hero.addView(status);
        TextView detail = Ui.text(this, "", 13, Ui.MUTED, false);
        detail.setGravity(Gravity.CENTER);
        detail.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 14));
        hero.addView(detail);
        TextView toggle = Ui.button(this, "", Ui.CYAN, v -> toggleProtection());
        hero.addView(toggle, Ui.params(Ui.MATCH, Ui.WRAP, 0f));
        col.addView(hero);

        LinearLayout row1 = Ui.hbox(this);
        TextView vBlocked = stat(row1, "THREATS BLOCKED", Ui.PINK, false);
        TextView vToday = stat(row1, "BLOCKED TODAY", Ui.VIOLET, true);
        add(col, row1);
        LinearLayout row2 = Ui.hbox(this);
        TextView vRules = stat(row2, "CUSTOM RULES", Ui.GREEN, false);
        TextView vDb = stat(row2, "KNOWN THREATS", Ui.CYAN, true);
        add(col, row2);

        LinearLayout db = Ui.card(this, Ui.CYAN);
        db.addView(Ui.text(this, "Threat intelligence", 16, Ui.TEXT, true));
        TextView dbInfo = Ui.text(this, "", 12, Ui.MUTED, false);
        dbInfo.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
        db.addView(dbInfo);
        final TextView[] updateBtn = new TextView[1];
        updateBtn[0] = Ui.button(this, "UPDATE THREAT DATABASE", Ui.CYAN, v -> updateThreatDb(dbInfo, updateBtn[0]));
        db.addView(updateBtn[0]);
        add(col, db);

        LinearLayout test = Ui.card(this, Ui.PINK);
        test.addView(Ui.text(this, "Live protection test", 16, Ui.TEXT, true));
        TextView testInfo = Ui.text(this,
                "Safely simulates a phone trying to reach a malware domain. If protection works, SafeSphere blocks it, "
                        + "sends an alert and records it in History.", 12, Ui.MUTED, false);
        testInfo.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 12));
        test.addView(testInfo);
        test.addView(Ui.button(this, "RUN LIVE TEST", Ui.PINK, v -> runLiveTest()));
        add(col, test);

        LinearLayout recent = Ui.card(this, Ui.VIOLET);
        recent.addView(Ui.text(this, "Recent activity", 16, Ui.TEXT, true));
        LinearLayout recentList = Ui.vbox(this);
        recent.addView(recentList);
        add(col, recent);

        final long[] shownId = {-1};
        refresher = () -> {
            boolean on = SafeSphereVpnService.isRunning();
            String err = SafeSphereVpnService.lastError();
            shield.setActive(on);
            status.setText(on ? "PROTECTION ACTIVE" : "PROTECTION OFF");
            int color = on ? Ui.CYAN : Ui.PINK;
            status.setTextColor(color);
            status.setShadowLayer(Ui.dp(this, 12), 0, 0, color);
            if (on) {
                detail.setText("Checking every domain lookup from every app since "
                        + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(SafeSphereVpnService.startedAt())));
            } else if (err != null) {
                detail.setText("⚠ " + err);
            } else {
                detail.setText("Tap the shield to start protecting this phone");
            }
            toggle.setText(on ? "TURN OFF PROTECTION" : "TURN ON PROTECTION");
            Ui.restyle(toggle, on ? Ui.PINK : Ui.CYAN);

            EventLog log = EventLog.get(this);
            vBlocked.setText(String.valueOf(log.count()));
            vToday.setText(String.valueOf(log.countSince(startOfToday())));
            vRules.setText(String.valueOf(RuleStore.count()));
            vDb.setText(compact(ThreatDb.size()));
            if (!ThreatDb.isUpdating()) dbInfo.setText(ThreatDb.status(this));

            long latest = log.latestId();
            if (latest != shownId[0]) {
                shownId[0] = latest;
                recentList.removeAllViews();
                List<EventLog.Event> events = log.recent(5);
                if (events.isEmpty()) {
                    TextView empty = Ui.text(this, "No threats blocked yet. Run the live test to see one.", 12, Ui.MUTED, false);
                    empty.setPadding(0, Ui.dp(this, 8), 0, 0);
                    recentList.addView(empty);
                }
                for (EventLog.Event e : events) recentList.addView(eventRow(e, false));
            }
        };
    }

    private TextView stat(LinearLayout row, String label, int color, boolean right) {
        LinearLayout c = Ui.card(this, color);
        TextView value = Ui.glow(this, "0", 28, color);
        c.addView(value);
        TextView l = Ui.text(this, label, 10, Ui.MUTED, true);
        l.setLetterSpacing(0.12f);
        c.addView(l);
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        if (right) lp.leftMargin = Ui.dp(this, 12);
        row.addView(c, lp);
        c.setOnClickListener(Ui::tap);
        return value;
    }

    private void toggleProtection() {
        if (SafeSphereVpnService.isRunning()) {
            startService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_STOP));
            toast("Protection turned off");
            handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 400);
            return;
        }
        Intent consent = VpnService.prepare(this);
        if (consent != null) {
            try {
                startActivityForResult(consent, REQ_VPN);
            } catch (ActivityNotFoundException e) {
                toast("This phone does not allow VPN apps");
            }
        } else {
            onActivityResult(REQ_VPN, RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_VPN) return;
        if (resultCode == RESULT_OK) {
            startForegroundService(new Intent(this, SafeSphereVpnService.class).setAction(SafeSphereVpnService.ACTION_START));
            toast("Starting protection…");
            handler.postDelayed(() -> { if (refresher != null) refresher.run(); }, 600);
        } else {
            toast("Protection needs the VPN connection request to be allowed");
        }
    }

    private void updateThreatDb(TextView info, TextView button) {
        if (ThreatDb.isUpdating()) return;
        button.setEnabled(false);
        button.setText("UPDATING…");
        info.setText("Connecting…");
        Context app = getApplicationContext();
        bg.execute(() -> {
            String result = ThreatDb.update(app, msg -> runOnUiThread(() -> info.setText(msg)));
            runOnUiThread(() -> {
                button.setEnabled(true);
                button.setText("UPDATE THREAT DATABASE");
                info.setText(ThreatDb.status(this));
                toast(result);
            });
        });
    }

    private void runLiveTest() {
        if (!SafeSphereVpnService.isRunning()) {
            toast("Turn protection on first, then run the test");
            return;
        }
        String domain = "t" + Integer.toHexString(new Random().nextInt(0xFFFFFF)) + "." + RuleStore.TEST_ZONE;
        long started = System.currentTimeMillis();
        toast("Testing…");
        bg.execute(() -> {
            try {
                InetAddress.getByName(domain);
            } catch (Exception ignored) {
                // expected: the lookup is refused
            }
            try { Thread.sleep(700); } catch (InterruptedException ignored) { }
            boolean passed = domain.equals(SafeSphereVpnService.lastBlocked)
                    && SafeSphereVpnService.lastBlockedAt >= started;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                new AlertDialog.Builder(this)
                        .setTitle(passed ? "✅ Test passed" : "Test did not trigger")
                        .setMessage(passed
                                ? "SafeSphere caught the lookup for\n" + domain + "\nand blocked it before any connection was made. "
                                + "Check your notifications and the History tab."
                                : "The test lookup did not reach SafeSphere. Open Android Settings → Network → Private DNS and "
                                + "set it to Automatic or Off, then try again.")
                        .setPositiveButton("OK", null)
                        .show();
                if (refresher != null) refresher.run();
            });
        });
    }

    // ------------------------------------------------------------------ Rules

    private void buildRules(LinearLayout col) {
        LinearLayout addCard = Ui.card(this, Ui.CYAN);
        addCard.addView(Ui.text(this, "Add a rule", 16, Ui.TEXT, true));
        TextView hint = Ui.text(this, "Type a domain or paste a link. Blocking a domain also blocks its subdomains.",
                12, Ui.MUTED, false);
        hint.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        addCard.addView(hint);

        EditText input = new EditText(this);
        input.setHint("example.com");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        GradientDrawable field = new GradientDrawable();
        field.setColor(0xFF0A0816);
        field.setCornerRadius(Ui.dp(this, 14));
        field.setStroke(Ui.dp(this, 1.4f), Ui.alpha(Ui.CYAN, 0xAA));
        input.setBackground(field);
        int ip = Ui.dp(this, 14);
        input.setPadding(ip, ip, ip, ip);
        addCard.addView(input);

        LinearLayout actions = Ui.hbox(this);
        TextView blockBtn = Ui.button(this, "BLOCK", Ui.PINK, v -> saveRule(input, true));
        TextView allowBtn = Ui.button(this, "ALLOW", Ui.GREEN, v -> saveRule(input, false));
        actions.addView(blockBtn, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(this, 12);
        actions.addView(allowBtn, lp);
        addCard.addView(actions, Ui.margins(this, Ui.MATCH, Ui.WRAP, 12));

        TextView note = Ui.text(this, "Changes apply instantly, no reinstall needed. Allowed domains always win over "
                + "blocklists. If a site you just blocked still opens, wait about a minute for Android's DNS cache to clear.",
                11, Ui.MUTED, false);
        note.setPadding(0, Ui.dp(this, 12), 0, 0);
        addCard.addView(note);
        col.addView(addCard);

        add(col, ruleList("Blocked domains", RuleStore.blocked(), Ui.PINK, "No custom blocked domains yet."));
        add(col, ruleList("Always allowed", RuleStore.allowed(), Ui.GREEN,
                "Nothing here. Add a domain if SafeSphere blocks something you trust."));
    }

    private View ruleList(String title, List<String> items, int color, String emptyText) {
        LinearLayout c = Ui.card(this, color);
        LinearLayout head = Ui.hbox(this);
        head.addView(Ui.text(this, title, 16, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.chip(this, String.valueOf(items.size()), color));
        c.addView(head);
        if (items.isEmpty()) {
            TextView e = Ui.text(this, emptyText, 12, Ui.MUTED, false);
            e.setPadding(0, Ui.dp(this, 8), 0, 0);
            c.addView(e);
        }
        for (String d : items) {
            LinearLayout row = Ui.hbox(this);
            row.setPadding(0, Ui.dp(this, 10), 0, 0);
            TextView name = Ui.text(this, d, 14, Ui.TEXT, false);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            row.addView(name, Ui.params(0, Ui.WRAP, 1f));
            TextView remove = Ui.chip(this, "REMOVE", Ui.MUTED);
            remove.setOnClickListener(v -> {
                Ui.tap(v);
                RuleStore.remove(d);
                toast("Removed " + d);
                show(TAB_RULES);
            });
            row.addView(remove);
            c.addView(row);
        }
        return c;
    }

    private void saveRule(EditText input, boolean block) {
        String domain = RuleStore.normalize(input.getText().toString());
        if (domain == null) {
            input.setError("Enter a valid domain, like example.com");
            Ui.shake(input);
            return;
        }
        if (block) RuleStore.addBlock(domain);
        else RuleStore.addAllow(domain);
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        toast((block ? "Blocked " : "Allowed ") + domain);
        show(TAB_RULES);
    }

    // ------------------------------------------------------------------ History

    private void buildHistory(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.PINK);
        head.addView(Ui.text(this, "Threat history", 16, Ui.TEXT, true));
        TextView sub = Ui.text(this, "", 12, Ui.MUTED, false);
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        head.addView(sub);
        head.addView(Ui.button(this, "CLEAR HISTORY", Ui.RED, v ->
                new AlertDialog.Builder(this)
                        .setTitle("Clear threat history?")
                        .setMessage("This deletes every recorded blocked event on this phone.")
                        .setPositiveButton("Clear", (d, w) -> {
                            EventLog.get(this).clear();
                            toast("History cleared");
                            show(TAB_HISTORY);
                        })
                        .setNegativeButton("Cancel", null)
                        .show()));
        col.addView(head);

        LinearLayout list = Ui.card(this, Ui.VIOLET);
        add(col, list);

        final long[] shownId = {-1};
        refresher = () -> {
            EventLog log = EventLog.get(this);
            long latest = log.latestId();
            if (latest == shownId[0]) return;
            shownId[0] = latest;
            sub.setText(log.count() + " blocked events · stored only on this phone. "
                    + "SafeSphere never records sites that were allowed.");
            list.removeAllViews();
            List<EventLog.Event> events = log.recent(300);
            if (events.isEmpty()) {
                TextView e = Ui.glow(this, "No threats blocked yet", 15, Ui.VIOLET);
                list.addView(e);
                TextView t = Ui.text(this, "Turn protection on and run the live test on the Shield tab.", 12, Ui.MUTED, false);
                t.setPadding(0, Ui.dp(this, 6), 0, 0);
                list.addView(t);
                return;
            }
            for (EventLog.Event e : events) list.addView(eventRow(e, true));
        };
    }

    private View eventRow(EventLog.Event e, boolean full) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 12), 0, 0);
        LinearLayout texts = Ui.vbox(this);
        TextView d = Ui.text(this, e.domain, 14, Ui.TEXT, true);
        d.setSingleLine(true);
        d.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        texts.addView(d);
        String when = new SimpleDateFormat(full ? "MMM d · h:mm:ss a" : "h:mm a", Locale.getDefault()).format(new Date(e.time));
        texts.addView(Ui.text(this, when + " · " + e.reason, 11, Ui.MUTED, false));
        row.addView(texts, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        lp.leftMargin = Ui.dp(this, 10);
        row.addView(Ui.chip(this, "BLOCKED", Ui.PINK), lp);
        return row;
    }

    // ------------------------------------------------------------------ Apps

    private void buildApps(LinearLayout col) {
        LinearLayout head = Ui.card(this, Ui.AMBER);
        head.addView(Ui.text(this, "App permission risk scan", 16, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Finds installed apps holding sensitive access: SMS, call logs, microphone, camera, "
                + "location, screen reading and more. Tap an app to review or remove its permissions.", 12, Ui.MUTED, false);
        sub.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 12));
        head.addView(sub);
        TextView scanBtn = Ui.button(this, scanning ? "SCANNING…" : "SCAN INSTALLED APPS", Ui.AMBER, v -> scanApps());
        head.addView(scanBtn);
        col.addView(head);
        if (lastScan == null) return;

        int high = 0, medium = 0, low = 0;
        for (AppScanner.AppRisk r : lastScan) {
            if (r.score >= 8) high++;
            else if (r.score >= 4) medium++;
            else low++;
        }
        LinearLayout summary = Ui.hbox(this);
        summary.addView(Ui.chip(this, high + " HIGH", Ui.RED));
        LinearLayout.LayoutParams gap = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, medium + " MEDIUM", Ui.AMBER), gap);
        LinearLayout.LayoutParams gap2 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        gap2.leftMargin = Ui.dp(this, 8);
        summary.addView(Ui.chip(this, low + " LOW", Ui.GREEN), gap2);
        add(col, summary);

        if (lastScan.isEmpty()) {
            LinearLayout c = Ui.card(this, Ui.GREEN);
            c.addView(Ui.glow(this, "No risky apps found", 15, Ui.GREEN));
            add(col, c);
            return;
        }
        for (AppScanner.AppRisk r : lastScan) add(col, appCard(r));
    }

    private View appCard(AppScanner.AppRisk r) {
        LinearLayout c = Ui.card(this, r.color());
        LinearLayout top = Ui.hbox(this);
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(r.icon);
        int s = Ui.dp(this, 40);
        top.addView(icon, new LinearLayout.LayoutParams(s, s));
        LinearLayout names = Ui.vbox(this);
        names.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        TextView label = Ui.text(this, r.label, 15, Ui.TEXT, true);
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        names.addView(label);
        TextView pkg = Ui.text(this, r.pkg, 10, Ui.MUTED, false);
        pkg.setSingleLine(true);
        pkg.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        names.addView(pkg);
        top.addView(names, Ui.params(0, Ui.WRAP, 1f));
        top.addView(Ui.chip(this, r.level() + " · " + r.score, r.color()));
        c.addView(top);
        TextView flags = Ui.text(this, "• " + TextUtils.join("\n• ", r.flags), 12, Ui.MUTED, false);
        flags.setPadding(0, Ui.dp(this, 10), 0, 0);
        c.addView(flags);
        c.setOnClickListener(v -> {
            Ui.tap(v);
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + r.pkg)));
            } catch (ActivityNotFoundException e) {
                toast("Could not open settings for this app");
            }
        });
        return c;
    }

    private void scanApps() {
        if (scanning) return;
        scanning = true;
        show(TAB_APPS);
        Context app = getApplicationContext();
        bg.execute(() -> {
            List<AppScanner.AppRisk> result = AppScanner.scan(app);
            runOnUiThread(() -> {
                scanning = false;
                lastScan = result;
                if (currentTab == TAB_APPS) show(TAB_APPS);
                toast("Scan complete: " + result.size() + " apps hold sensitive access");
            });
        });
    }

    // ------------------------------------------------------------------ helpers

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    private static String compact(int n) {
        if (n >= 1_000_000) return String.format(Locale.US, "%.1fM", n / 1_000_000f);
        if (n >= 1_000) return String.format(Locale.US, "%.1fK", n / 1_000f);
        return String.valueOf(n);
    }
}
