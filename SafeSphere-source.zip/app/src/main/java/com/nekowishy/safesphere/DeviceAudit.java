package com.nekowishy.safesphere;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/** Checks the phone's own security settings and gives a 0-100 device score. */
final class DeviceAudit {

    static final int OK = 0, WARN = 1, RISK = 2;

    static final class Check {
        String title;
        String detail;
        int level;
        int weight;
        String button;      // null = no fix button
        String[] settings;  // settings screens to try, in order
        final List<String> apps = new ArrayList<>();
    }

    /** Apps that let another person see and control the phone remotely. Scammers posing as bank staff ask victims to install them. */
    static final Set<String> REMOTE_APPS = new HashSet<>(Arrays.asList(
            "com.anydesk.anydeskandroid", "com.teamviewer.quicksupport.market", "com.teamviewer.teamviewer.market.mobile",
            "com.teamviewer.host.market", "com.carriez.flutter_hbb", "com.rustdesk.rustdesk", "com.realvnc.viewer.android",
            "com.sand.airdroid", "com.sand.airdroidbiz", "com.sand.airmirror", "com.splashtop.remote.pad.v2",
            "com.splashtop.sos", "com.logmein.rescuemobile"));

    /** Official app stores; apps from anywhere else were installed from outside a store. */
    private static final Set<String> STORES = new HashSet<>(Arrays.asList(
            "com.android.vending", "com.google.android.feedback", "com.sec.android.app.samsungapps",
            "com.huawei.appmarket", "com.heytap.market", "com.oppo.market", "com.oplus.market", "com.xiaomi.market",
            "com.xiaomi.mipicks", "com.vivo.appstore", "com.bbk.appstore", "com.amazon.venezia"));

    private static final String[] SU_PATHS = {
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sd/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/app/Superuser.apk"};

    private static final Set<String> ROOT_APPS = new HashSet<>(Arrays.asList(
            "com.topjohnwu.magisk", "eu.chainfire.supersu", "com.koushikdutta.superuser", "com.noshufou.android.su",
            "me.weishu.kernelsu"));

    private static volatile List<Check> lastResult;
    private static volatile int lastScore = -1;

    private DeviceAudit() {}

    static List<Check> last() { return lastResult; }
    static int lastScore() { return lastScore; }

    static String installer(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo info = pm.getInstallSourceInfo(pkg);
                return info.getInstallingPackageName();
            }
            //noinspection deprecation
            return pm.getInstallerPackageName(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean fromOutsideStore(Context c, PackageManager pm, String pkg) {
        if (pkg.equals(c.getPackageName())) return false; // SafeSphere itself is installed from GitHub
        String inst = installer(pm, pkg);
        return inst == null || !STORES.contains(inst);
    }

    static List<Check> run(Context c) {
        List<Check> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();

        // 1. Screen lock
        Check lock = new Check();
        KeyguardManager km = c.getSystemService(KeyguardManager.class);
        boolean secure = km != null && km.isDeviceSecure();
        lock.title = secure ? "Screen lock is on" : "No screen lock";
        lock.detail = secure ? "A PIN, pattern, password or fingerprint protects the phone."
                : "Anyone who picks up this phone can open your e-wallet, chats and email.";
        lock.level = secure ? OK : RISK;
        lock.weight = 20;
        lock.button = "SET SCREEN LOCK";
        lock.settings = new String[]{Settings.ACTION_SECURITY_SETTINGS};
        out.add(lock);

        // 2. Security update age
        Check patch = new Check();
        patch.weight = 15;
        patch.button = "CHECK FOR UPDATES";
        patch.settings = new String[]{"android.settings.SYSTEM_UPDATE_SETTINGS", Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_SETTINGS};
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH);
            long days = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - d.getTime());
            String when = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(d);
            patch.level = days > 180 ? RISK : days > 90 ? WARN : OK;
            patch.title = patch.level == OK ? "Security updates are recent" : "Security updates are out of date";
            patch.detail = "Last Android security update: " + when + " (" + days + " days ago). "
                    + (patch.level == OK ? "Good." : "Old updates leave known security holes open. Install any available update.");
        } catch (Exception e) {
            patch.level = OK;
            patch.title = "Security update date unknown";
            patch.detail = "This phone did not report its security update date.";
        }
        out.add(patch);

        // 3. Android version
        Check ver = new Check();
        ver.weight = 10;
        ver.level = Build.VERSION.SDK_INT < 31 ? RISK : OK;
        ver.title = ver.level == OK ? "Android " + Build.VERSION.RELEASE : "Old Android version (" + Build.VERSION.RELEASE + ")";
        ver.detail = ver.level == OK ? "This Android version is recent enough to receive security fixes."
                : "Android 11 and older no longer receive security fixes. Consider a newer phone for banking apps.";
        out.add(ver);

        // 4. USB debugging
        Check adb = new Check();
        boolean adbOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
        adb.title = adbOn ? "USB debugging is ON" : "USB debugging is off";
        adb.detail = adbOn ? "A connected computer can install apps and read data. Turn it off unless you are a developer."
                : "Computers can't control this phone over USB.";
        adb.level = adbOn ? RISK : OK;
        adb.weight = 10;
        adb.button = "OPEN DEVELOPER OPTIONS";
        adb.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(adb);

        // 5. Developer options
        Check dev = new Check();
        boolean devOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        dev.title = devOn ? "Developer options are ON" : "Developer options are off";
        dev.detail = devOn ? "These hidden settings can weaken security. Turn them off if you don't use them."
                : "Hidden developer settings are not enabled.";
        dev.level = devOn ? WARN : OK;
        dev.weight = 5;
        dev.button = "OPEN DEVELOPER OPTIONS";
        dev.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(dev);

        // 6. Root
        Check root = new Check();
        boolean rooted = Build.TAGS != null && Build.TAGS.contains("test-keys");
        for (String p : SU_PATHS) if (new File(p).exists()) rooted = true;
        List<PackageInfo> pkgs = pm.getInstalledPackages(0);
        for (PackageInfo p : pkgs) if (ROOT_APPS.contains(p.packageName)) rooted = true;
        root.title = rooted ? "Phone appears to be rooted" : "Phone is not rooted";
        root.detail = rooted ? "Root access removes Android's built-in protections; malware with root can read everything."
                : "Android's built-in app separation is intact.";
        root.level = rooted ? RISK : OK;
        root.weight = 15;
        out.add(root);

        // 7. Remote-control apps and 8. apps from outside a store
        Check remote = new Check();
        Check outside = new Check();
        for (PackageInfo p : pkgs) {
            ApplicationInfo ai = p.applicationInfo;
            if (ai == null || (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
            String label = String.valueOf(ai.loadLabel(pm));
            if (REMOTE_APPS.contains(p.packageName)) remote.apps.add(label);
            else if (fromOutsideStore(c, pm, p.packageName)) outside.apps.add(label);
        }
        remote.level = remote.apps.isEmpty() ? OK : RISK;
        remote.weight = 10;
        remote.title = remote.apps.isEmpty() ? "No remote-control apps" : "Remote-control app installed";
        remote.detail = remote.apps.isEmpty() ? "No apps that let someone else control this phone."
                : "Scammers posing as bank or GCash staff ask victims to install these, then empty their accounts. "
                + "Uninstall unless you set it up yourself.";
        out.add(remote);

        outside.level = outside.apps.isEmpty() ? OK : WARN;
        outside.weight = 10;
        outside.title = outside.apps.isEmpty() ? "All apps came from app stores" : "Apps installed from outside an app store";
        outside.detail = outside.apps.isEmpty() ? "Apps from official stores are scanned for malware."
                : "Most Android malware arrives as APK files from links or chats. Keep these only if you trust where they came from.";
        out.add(outside);

        // 9. Private DNS
        Check dns = new Check();
        boolean bypass = Prefs.privateDnsBypasses(c);
        dns.title = bypass ? "Private DNS skips SafeSphere" : "Private DNS works with SafeSphere";
        dns.detail = bypass ? "Private DNS is set to a specific provider, so apps go around SafeSphere's filter. "
                + "Set it to Automatic or Off." : "Website lookups pass through SafeSphere's filter.";
        dns.level = bypass ? RISK : OK;
        dns.weight = 5;
        dns.button = "OPEN NETWORK SETTINGS";
        dns.settings = new String[]{Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(dns);

        lastResult = out;
        lastScore = score(out);
        return out;
    }

    static int score(List<Check> checks) {
        int total = 0, lost = 0;
        for (Check ch : checks) {
            total += ch.weight;
            if (ch.level == RISK) lost += ch.weight;
            else if (ch.level == WARN) lost += ch.weight / 2;
        }
        return total == 0 ? 100 : Math.round(100f * (total - lost) / total);
    }

    static int color(int level) {
        return level == RISK ? Ui.RED : level == WARN ? Ui.AMBER : Ui.GREEN;
    }

    /** Overall score shown on the dashboard: protection, device audit, account checkup and threat data. */
    static int securityScore(Context c) {
        int device = lastScore < 0 ? 50 : lastScore;
        int checkup = Math.round(100f * Checkup.doneCount(c) / Checkup.ITEMS.length);
        int protect = SafeSphereVpnService.isRunning() ? 100 : 0;
        int data = ThreatDb.size() > 0 ? 100 : 0;
        return Math.round(0.35f * protect + 0.35f * device + 0.20f * checkup + 0.10f * data);
    }
}
