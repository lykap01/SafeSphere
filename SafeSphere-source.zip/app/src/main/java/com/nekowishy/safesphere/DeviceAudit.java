package com.nekowishy.safesphere;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Protection Gap Analyzer: which protections this phone already has, which need attention, and how
 * SafeSphere fits in. It complements Android's own security (Play Protect, Safe Browsing, updates);
 * it does not replace it.
 *
 * Every check says how its result was obtained. Some settings (Play Protect, Chrome Safe Browsing)
 * are not readable by other apps, so SafeSphere shows a guide and lets the user confirm them; those are
 * labelled "Confirmed by you", never "Verified".
 */
final class DeviceAudit {

    static final int VERIFIED = 0, ATTENTION = 1, CONFIRMED = 2, UNAVAILABLE = 3, NOT_CHECKED = 4;
    private static final long CONFIRM_VALID_MS = TimeUnit.DAYS.toMillis(90);

    static final class Check {
        String id;
        String group;
        String title;
        String detail;
        String guide;          // how to check it yourself (for settings Android doesn't expose)
        String how;            // how SafeSphere got this result
        int state = NOT_CHECKED;
        boolean high;          // a serious gap (shown in red instead of amber)
        boolean confirmable;   // the user can confirm it after checking
        long confirmedAt;
        String button;
        String[] settings;     // settings screens to try, in order
        String launchPkg;      // or an app to open
        final List<String> apps = new ArrayList<>();
    }

    static final String G_PHONE = "Phone security", G_ANDROID = "Android protections", G_APPS = "Apps",
            G_SAFESPHERE = "SafeSphere";

    /** Apps that let another person see and control the phone remotely. */
    static final Set<String> REMOTE_APPS = new HashSet<>(Arrays.asList(
            "com.anydesk.anydeskandroid", "com.teamviewer.quicksupport.market", "com.teamviewer.teamviewer.market.mobile",
            "com.teamviewer.host.market", "com.carriez.flutter_hbb", "com.rustdesk.rustdesk", "com.realvnc.viewer.android",
            "com.sand.airdroid", "com.sand.airdroidbiz", "com.sand.airmirror", "com.splashtop.remote.pad.v2",
            "com.splashtop.sos", "com.logmein.rescuemobile"));

    /** Official app stores; apps from anywhere else were installed from outside a store. */
    private static final Set<String> STORES = new HashSet<>(Arrays.asList(
            "com.android.vending", "com.google.android.feedback", "com.sec.android.app.samsungapps",
            "com.huawei.appmarket", "com.heytap.market", "com.oppo.market", "com.oplus.market", "com.xiaomi.market",
            "com.xiaomi.mipicks", "com.vivo.appstore", "com.bbk.appstore", "com.amazon.venezia"));

    private static final String[] SU_PATHS = {
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sd/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/app/Superuser.apk"};

    private static final Set<String> ROOT_APPS = new HashSet<>(Arrays.asList(
            "com.topjohnwu.magisk", "eu.chainfire.supersu", "com.koushikdutta.superuser", "com.noshufou.android.su",
            "me.weishu.kernelsu"));

    private static volatile List<Check> lastResult;

    private DeviceAudit() {}

    static List<Check> last() { return lastResult; }

    static String installer(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo info = pm.getInstallSourceInfo(pkg);
                return info.getInstallingPackageName();
            }
            //noinspection deprecation
            return pm.getInstallerPackageName(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean fromOutsideStore(Context c, PackageManager pm, String pkg) {
        if (pkg.equals(c.getPackageName())) return false; // SafeSphere itself is installed from GitHub
        String inst = installer(pm, pkg);
        return inst == null || !STORES.contains(inst);
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("gap_analyzer", Context.MODE_PRIVATE);
    }

    static void confirm(Context c, String id, boolean yes) {
        if (yes) prefs(c).edit().putLong("confirm_" + id, System.currentTimeMillis()).apply();
        else prefs(c).edit().remove("confirm_" + id).apply();
    }

    private static Check check(String id, String group) {
        Check ch = new Check();
        ch.id = id;
        ch.group = group;
        return ch;
    }

    @SuppressWarnings("deprecation")
    static List<Check> run(Context c) {
        List<Check> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();

        // ---------------------------------------------------------------- phone security
        Check lock = check("lock", G_PHONE);
        KeyguardManager km = c.getSystemService(KeyguardManager.class);
        boolean secure = km != null && km.isDeviceSecure();
        lock.title = "Screen lock";
        lock.state = secure ? VERIFIED : ATTENTION;
        lock.high = true;
        lock.detail = secure ? "A PIN, pattern, password or biometric protects this phone."
                : "Anyone holding this phone can open your e-wallet, chats and e-mail.";
        lock.how = "Read from Android (KeyguardManager).";
        lock.button = "Set screen lock";
        lock.settings = new String[]{Settings.ACTION_SECURITY_SETTINGS};
        out.add(lock);

        Check patch = check("patch", G_PHONE);
        patch.title = "Security update";
        patch.button = "Check for updates";
        patch.settings = new String[]{"android.settings.SYSTEM_UPDATE_SETTINGS", Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_SETTINGS};
        patch.how = "Read from Android (security patch date).";
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH);
            long days = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - d.getTime());
            String when = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(d);
            patch.state = days > 90 ? ATTENTION : VERIFIED;
            patch.high = days > 180;
            patch.detail = "Last security patch: " + when + " (" + days + " days ago). " + (days > 90
                    ? "Older patches leave known holes open. Install any update your phone offers."
                    : "Recent enough.");
        } catch (Exception e) {
            patch.state = UNAVAILABLE;
            patch.detail = "This phone did not report its security patch date.";
        }
        out.add(patch);

        Check ver = check("android", G_PHONE);
        ver.title = "Android version";
        ver.how = "Read from Android.";
        ver.state = Build.VERSION.SDK_INT < 31 ? ATTENTION : VERIFIED;
        ver.detail = "Android " + Build.VERSION.RELEASE + ". " + (Build.VERSION.SDK_INT < 31
                ? "Many phones on this version no longer receive security updates. Check with your phone maker."
                : "A recent Android version.");
        out.add(ver);

        Check root = check("root", G_PHONE);
        boolean rooted = Build.TAGS != null && Build.TAGS.contains("test-keys");
        for (String p : SU_PATHS) if (new File(p).exists()) rooted = true;
        List<PackageInfo> pkgs = pm.getInstalledPackages(0);
        for (PackageInfo p : pkgs) if (ROOT_APPS.contains(p.packageName)) rooted = true;
        root.title = "Root access";
        root.state = rooted ? ATTENTION : VERIFIED;
        root.high = true;
        root.detail = rooted ? "Signs of rooting were found. Root removes Android's app separation, so malware could read everything."
                : "No signs of rooting found. (Well-hidden root tools can't always be detected.)";
        root.how = "Looked for su files, root-manager apps and test-keys.";
        out.add(root);

        Check adb = check("adb", G_PHONE);
        boolean adbOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
        adb.title = "USB debugging";
        adb.state = adbOn ? ATTENTION : VERIFIED;
        adb.high = adbOn;
        adb.detail = adbOn ? "On. A connected computer can install apps and read data. Turn it off unless you develop apps."
                : "Off. Computers can't control this phone over USB.";
        adb.how = "Read from Android settings.";
        adb.button = "Developer options";
        adb.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(adb);

        Check dev = check("devopts", G_PHONE);
        boolean devOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        dev.title = "Developer options";
        dev.state = devOn ? ATTENTION : VERIFIED;
        dev.detail = devOn ? "On. These hidden settings can weaken security. Turn them off if you don't use them."
                : "Off.";
        dev.how = "Read from Android settings.";
        dev.button = "Developer options";
        dev.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(dev);

        // ---------------------------------------------------------------- Android's own protections
        Check pp = check("playprotect", G_ANDROID);
        pp.title = "Google Play Protect";
        pp.confirmable = true;
        pp.how = "Android does not let other apps read this setting, so SafeSphere can't verify it.";
        pp.guide = "Open Play Protect and make sure \"Scan apps with Play Protect\" is on.";
        pp.detail = "Scans installed apps for malware. SafeSphere does not replace it.";
        pp.button = "Open Play Protect";
        pp.settings = new String[]{"com.google.android.gms.settings.VERIFY_APPS_SETTINGS", Settings.ACTION_SECURITY_SETTINGS};
        applyConfirmation(c, pp, isInstalled(pm, "com.android.vending") || isInstalled(pm, "com.google.android.gms"));
        out.add(pp);

        Check sb = check("safebrowsing", G_ANDROID);
        sb.title = "Chrome Safe Browsing";
        sb.confirmable = true;
        sb.how = "Chrome does not let other apps read this setting, so SafeSphere can't verify it.";
        sb.guide = "In Chrome: ⋮ → Settings → Privacy and security → Safe Browsing → choose Standard or Enhanced protection.";
        sb.detail = "Warns about dangerous pages inside Chrome, including ones not yet on SafeSphere's lists.";
        sb.button = "Open Chrome";
        sb.launchPkg = "com.android.chrome";
        applyConfirmation(c, sb, isInstalled(pm, "com.android.chrome"));
        if (sb.state == UNAVAILABLE) sb.detail = "Chrome isn't installed. If you use another browser, turn on its phishing protection.";
        out.add(sb);

        Check pdns = check("privatedns", G_ANDROID);
        String mode = Prefs.privateDnsMode(c);
        pdns.title = "Private DNS";
        pdns.how = "Read from Android settings.";
        pdns.button = "Network settings";
        pdns.settings = new String[]{Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS};
        if (mode == null) {
            pdns.state = UNAVAILABLE;
            pdns.detail = "This phone doesn't report its Private DNS setting.";
        } else if ("hostname".equals(mode)) {
            pdns.state = ATTENTION;
            pdns.high = true;
            pdns.detail = "Set to a specific provider. Apps send lookups there directly, skipping SafeSphere's filter. "
                    + "Choose Automatic or Off to use SafeSphere.";
        } else {
            pdns.state = VERIFIED;
            pdns.detail = "Automatic or Off: lookups pass through SafeSphere while protection is on.";
        }
        out.add(pdns);

        // ---------------------------------------------------------------- apps
        Check remote = check("remote", G_APPS);
        Check outside = check("outside", G_APPS);
        Check installers = check("installers", G_APPS);
        Check access = check("accessibility", G_APPS);
        String enabledA11y = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        List<PackageInfo> withPerms;
        try {
            withPerms = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
        } catch (RuntimeException e) {
            withPerms = pkgs;
        }
        for (PackageInfo p : withPerms) {
            ApplicationInfo ai = p.applicationInfo;
            if (ai == null || p.packageName.equals(c.getPackageName())) continue;
            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            String label = String.valueOf(ai.loadLabel(pm));
            if (!system && REMOTE_APPS.contains(p.packageName)) remote.apps.add(label);
            else if (!system && fromOutsideStore(c, pm, p.packageName)) outside.apps.add(label);
            if (!system && p.requestedPermissions != null
                    && Arrays.asList(p.requestedPermissions).contains("android.permission.REQUEST_INSTALL_PACKAGES")) {
                installers.apps.add(label);
            }
            if (!system && enabledA11y != null && enabledA11y.contains(p.packageName + "/")) access.apps.add(label);
        }
        remote.title = "Remote-control apps";
        remote.state = remote.apps.isEmpty() ? VERIFIED : ATTENTION;
        remote.high = true;
        remote.detail = remote.apps.isEmpty() ? "None installed."
                : "Installed. Scammers posing as bank or e-wallet staff ask victims to install these. Uninstall unless you set it up yourself.";
        remote.how = "Compared installed apps with a list of remote-access tools.";
        out.add(remote);

        access.title = "Accessibility access";
        access.state = access.apps.isEmpty() ? VERIFIED : ATTENTION;
        access.detail = access.apps.isEmpty() ? "No downloaded app can read or control your screen."
                : "These apps can read your screen and tap for you. Banking malware abuses this. Keep only apps you trust.";
        access.how = "Read from Android's list of enabled accessibility services.";
        access.button = "Accessibility settings";
        access.settings = new String[]{Settings.ACTION_ACCESSIBILITY_SETTINGS};
        out.add(access);

        outside.title = "Apps from outside app stores";
        outside.state = outside.apps.isEmpty() ? VERIFIED : ATTENTION;
        outside.detail = outside.apps.isEmpty() ? "All downloaded apps came from an app store."
                : "Most Android malware arrives as APK files from links or chats. Keep these only if you trust where they came from.";
        outside.how = "Read each app's installer from Android.";
        out.add(outside);

        installers.title = "Install unknown apps";
        installers.confirmable = true;
        installers.how = "Android doesn't show other apps whether this is switched on, only which apps can ask for it.";
        installers.guide = "Open the setting and switch it off for apps that don't need it, especially browsers and chat apps.";
        installers.detail = installers.apps.isEmpty() ? "No downloaded app can ask to install other apps."
                : installers.apps.size() + " app(s) can be allowed to install other apps.";
        installers.button = "Open setting";
        installers.settings = new String[]{Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Settings.ACTION_SECURITY_SETTINGS};
        if (installers.apps.isEmpty()) installers.state = VERIFIED;
        else applyConfirmation(c, installers, true);
        out.add(installers);

        // ---------------------------------------------------------------- SafeSphere
        Check prot = check("protection", G_SAFESPHERE);
        prot.title = "SafeSphere DNS protection";
        ProtectionState ps = ProtectionState.compute(c);
        prot.state = ps.state == ProtectionState.ACTIVE ? VERIFIED : ATTENTION;
        prot.high = ps.state == ProtectionState.INTERRUPTED;
        prot.detail = ps.title + ". " + (ps.gaps.isEmpty() ? ps.detail : ps.gaps.get(0));
        prot.how = "Read from SafeSphere's own VPN service.";
        out.add(prot);

        Check vpn = check("vpn", G_SAFESPHERE);
        vpn.title = "Other VPN apps";
        vpn.how = "Read from Android's network list.";
        boolean other = ProtectionState.otherVpnActive(c);
        vpn.state = other ? ATTENTION : VERIFIED;
        vpn.detail = other ? "Another VPN is connected. Only one VPN can run at a time, so SafeSphere's filter can't run with it."
                : SafeSphereVpnService.isRunning() ? "SafeSphere is the active VPN." : "No other VPN is connected.";
        vpn.button = "VPN settings";
        vpn.settings = new String[]{Settings.ACTION_VPN_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS};
        out.add(vpn);

        Check notif = check("notification", G_SAFESPHERE);
        boolean listener = ScamMessageWatcher.isEnabled(c);
        notif.title = "Scam message alerts";
        notif.how = "Read from Android's notification-access list.";
        notif.state = listener ? VERIFIED : NOT_CHECKED;
        notif.detail = listener ? "On. SafeSphere reads new message notifications on the phone and never stores their text."
                : "Optional and off. Turn it on in Check if you want automatic warnings about scam messages.";
        out.add(notif);

        Check battery = check("battery", G_SAFESPHERE);
        battery.title = "Background running";
        battery.how = "Read from Android's battery and background settings.";
        PowerManager pmgr = c.getSystemService(PowerManager.class);
        boolean optimized = pmgr != null && !pmgr.isIgnoringBatteryOptimizations(c.getPackageName());
        boolean restricted = false;
        ActivityManager am = c.getSystemService(ActivityManager.class);
        if (am != null && Build.VERSION.SDK_INT >= 28) restricted = am.isBackgroundRestricted();
        battery.state = restricted ? ATTENTION : VERIFIED;
        battery.detail = restricted ? "Background activity is restricted, so Android may stop protection and alerts."
                : optimized ? "Battery optimisation is on. Most phones keep the VPN running anyway; if protection keeps "
                + "stopping, set SafeSphere to \"Unrestricted\"." : "SafeSphere may run in the background.";
        battery.button = "Battery settings";
        battery.settings = new String[]{Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(battery);

        recordChanges(c, out);
        lastResult = out;
        return out;
    }

    private static boolean isInstalled(PackageManager pm, String pkg) {
        try {
            pm.getApplicationInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void applyConfirmation(Context c, Check ch, boolean applicable) {
        if (!applicable) {
            ch.state = UNAVAILABLE;
            ch.confirmable = false;
            return;
        }
        long at = prefs(c).getLong("confirm_" + ch.id, 0);
        ch.confirmedAt = at;
        ch.state = at > 0 && System.currentTimeMillis() - at < CONFIRM_VALID_MS ? CONFIRMED : NOT_CHECKED;
    }

    /** Writes "found" / "resolved" device events to History when a check changes state. */
    private static void recordChanges(Context c, List<Check> checks) {
        SharedPreferences p = prefs(c);
        Set<String> before = new HashSet<>(p.getStringSet("open_issues", new HashSet<>()));
        Set<String> now = new HashSet<>();
        long t = System.currentTimeMillis();
        for (Check ch : checks) {
            if (ch.state != ATTENTION || ch.id.equals("protection")) continue;
            now.add(ch.id);
            if (!before.contains(ch.id)) EventLog.get(c).record(EventLog.CAT_DEVICE, "", "Needs attention: " + ch.title, t);
        }
        for (String id : before) {
            if (now.contains(id)) continue;
            for (Check ch : checks) if (ch.id.equals(id)) EventLog.get(c).record(EventLog.CAT_DEVICE, "", "Resolved: " + ch.title, t);
        }
        p.edit().putStringSet("open_issues", now).apply();
    }

    // ------------------------------------------------------------------ setup progress

    static final class Progress {
        int done, applicable, attention;
    }

    /**
     * Security setup progress = checks that are Verified or Confirmed by you, out of all checks that can
     * apply on this phone (Unavailable ones are left out). It counts completed setup steps; it is NOT a
     * measured level of security.
     */
    static Progress progress(List<Check> checks) {
        Progress p = new Progress();
        if (checks == null) return p;
        for (Check ch : checks) {
            if (ch.state == UNAVAILABLE) continue;
            if (ch.id.equals("notification")) continue; // optional feature, not a gap
            p.applicable++;
            if (ch.state == VERIFIED || ch.state == CONFIRMED) p.done++;
            if (ch.state == ATTENTION) p.attention++;
        }
        return p;
    }

    static String stateLabel(int state) {
        switch (state) {
            case VERIFIED: return "Verified";
            case ATTENTION: return "Needs attention";
            case CONFIRMED: return "Confirmed by you";
            case UNAVAILABLE: return "Unavailable";
            default: return "Not checked";
        }
    }

    static int tone(Check ch) {
        switch (ch.state) {
            case VERIFIED: return Ui.T_SUCCESS;
            case ATTENTION: return ch.high ? Ui.T_DANGER : Ui.T_WARNING;
            case CONFIRMED: return Ui.T_INFO;
            default: return Ui.T_NEUTRAL;
        }
    }
}
