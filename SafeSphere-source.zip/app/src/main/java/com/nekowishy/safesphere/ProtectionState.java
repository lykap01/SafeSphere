package com.nekowishy.safesphere;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.util.ArrayList;
import java.util.List;

/**
 * The real protection status shown on the Shield screen. It never says "Protected" unless the DNS
 * filter is actually running, and it lists every known gap in coverage.
 */
final class ProtectionState {

    static final int OFF = 0, ACTIVE = 1, PARTIAL = 2, INTERRUPTED = 3;

    int state;
    int tone;
    String title;
    String detail;
    final List<String> gaps = new ArrayList<>();   // shown as warnings under the status

    /** What the DNS filter covers and does not cover, in plain words. */
    static final String COVERS = "Checks the website names (DNS lookups) that apps look up through Android while "
            + "protection is on, and refuses known dangerous ones.";
    static final String NOT_COVERED = "It does not read page content or messages, cannot see inside encrypted connections, "
            + "and cannot filter apps that use their own encrypted DNS or connect straight to an IP address. "
            + "It is off whenever another VPN app is active.";

    private ProtectionState() {}

    static ProtectionState compute(Context c) {
        ProtectionState p = new ProtectionState();
        boolean running = SafeSphereVpnService.isRunning();
        String err = SafeSphereVpnService.lastError();
        if (!running) {
            if (err != null || Prefs.protectionWanted(c)) {
                p.state = INTERRUPTED;
                p.tone = Ui.T_DANGER;
                p.title = "Protection stopped";
                p.detail = err != null ? err : "Protection was on but is no longer running. Turn it on again.";
            } else {
                p.state = OFF;
                p.tone = Ui.T_NEUTRAL;
                p.title = "Protection is off";
                p.detail = "Dangerous websites are not being blocked.";
            }
            if (otherVpnActive(c)) {
                p.gaps.add("Another VPN app is connected. Android allows one VPN at a time, so turning SafeSphere on "
                        + "will disconnect it.");
            }
            return p;
        }

        p.state = ACTIVE;
        p.tone = Ui.T_SUCCESS;
        p.title = "Protection is on";
        p.detail = "Website lookups are checked against " + (ThreatDb.size() > 0
                ? String.format(java.util.Locale.US, "%,d known threats", ThreatDb.size()) : "your rules")
                + " and SafeSphere's fake-site patterns.";

        if (Prefs.privateDnsBypasses(c)) {
            p.gaps.add("Private DNS is set to a specific provider, so most apps skip SafeSphere's filter. "
                    + "Set Private DNS to Automatic or Off.");
        }
        if (ThreatDb.size() == 0) {
            p.gaps.add(ThreatDb.isUpdating() ? "Threat lists are downloading. Until then only your rules and fake-site "
                    + "patterns are active." : "Threat lists aren't downloaded, so only your rules and fake-site patterns are active.");
        } else if (ThreatDb.freshness(c) == ThreatDb.STALE) {
            p.gaps.add("Threat lists are more than a week old. Update them to catch new scam sites.");
        }
        if (SafeSphereVpnService.dnsFailures >= 5) {
            p.gaps.add("SafeSphere can't reach DNS servers right now, so websites may not load. Check your connection.");
        }
        if (!p.gaps.isEmpty()) {
            p.state = PARTIAL;
            p.tone = Ui.T_WARNING;
            p.title = "Protection is on, with gaps";
        }
        return p;
    }

    /** True when a VPN other than SafeSphere is connected. Only meaningful while SafeSphere itself is off. */
    @SuppressWarnings("deprecation")
    static boolean otherVpnActive(Context c) {
        if (SafeSphereVpnService.isRunning()) return false;
        try {
            ConnectivityManager cm = c.getSystemService(ConnectivityManager.class);
            if (cm == null) return false;
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
        } catch (RuntimeException ignored) {
        }
        return false;
    }
}
