package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** "Threats blocked, last 7 days" bar chart: slate bars, today's bar in lime, values and weekdays under each. */
final class BarsView extends View {

    private long[] values = new long[7];
    private String[] labels = new String[7];
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float grow = 0f;

    BarsView(Context c) {
        super(c);
        num.setTextAlign(Paint.Align.CENTER);
        num.setColor(Ui.TEXT);
        num.setTextSize(Ui.dp(c, 12));
        num.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        lab.setTextAlign(Paint.Align.CENTER);
        lab.setColor(Ui.MUTED);
        lab.setTextSize(Ui.dp(c, 10));
        ghost.setColor(Ui.FIELD);
    }

    void setData(long[] v, String[] l) {
        values = v;
        labels = l;
        grow = 0f;
        animate().cancel();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (grow < 1f) {
            grow = Math.min(1f, grow + 0.06f);
            postInvalidateOnAnimation();
        }
        int n = values.length;
        float w = getWidth(), h = getHeight();
        float bottomText = Ui.dp(getContext(), 34);
        float chartH = h - bottomText;
        float slot = w / n;
        float bw = slot * 0.62f;
        long max = 1;
        for (long v : values) max = Math.max(max, v);
        float radius = Ui.dp(getContext(), 10);
        for (int i = 0; i < n; i++) {
            float left = i * slot + (slot - bw) / 2f;
            rect.set(left, 0, left + bw, chartH);
            canvas.drawRoundRect(rect, radius, radius, ghost);
            float bh = Math.max(Ui.dp(getContext(), 6), chartH * values[i] / max) * easeOut(grow);
            if (values[i] == 0) bh = Ui.dp(getContext(), 6) * easeOut(grow);
            rect.set(left, chartH - bh, left + bw, chartH);
            bar.setColor(i == n - 1 ? Ui.LIME : Ui.SLATE_BAR);
            canvas.drawRoundRect(rect, radius, radius, bar);
            float x = left + bw / 2f;
            canvas.drawText(String.valueOf(values[i]), x, chartH + Ui.dp(getContext(), 16), num);
            canvas.drawText(labels[i] == null ? "" : labels[i], x, chartH + Ui.dp(getContext(), 30), lab);
        }
    }

    private static float easeOut(float t) {
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }
}
