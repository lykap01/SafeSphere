package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Threats per day for the last 7 days: flat bars, today in the brand colour, value and weekday under each. */
final class BarsView extends View {

    private long[] values = new long[7];
    private String[] labels = new String[7];
    private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghost = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint lab = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private float grow = 0f;

    BarsView(Context c) {
        super(c);
        num.setTextAlign(Paint.Align.CENTER);
        num.setColor(Ui.TEXT);
        num.setTextSize(Ui.dp(c, 12));
        num.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        lab.setTextAlign(Paint.Align.CENTER);
        lab.setColor(Ui.TEXT2);
        lab.setTextSize(Ui.dp(c, 10));
        ghost.setColor(Ui.SURFACE_MUTED);
    }

    void setData(long[] v, String[] l) {
        StringBuilder d = new StringBuilder("Threats per day, last 7 days: ");
        for (int i = 0; i < v.length; i++) d.append(l[i]).append(' ').append(v[i]).append(i < v.length - 1 ? ", " : "");
        setContentDescription(d.toString());
        values = v;
        labels = l;
        grow = 0f;
        animate().cancel();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        grow = 1f; // no animation: values are shown as they are
        int n = values.length;
        float w = getWidth(), h = getHeight();
        float bottomText = Ui.dp(getContext(), 34);
        float chartH = h - bottomText;
        float slot = w / n;
        float bw = slot * 0.5f;
        long max = 1;
        for (long v : values) max = Math.max(max, v);
        float radius = Ui.dp(getContext(), 3);
        for (int i = 0; i < n; i++) {
            float left = i * slot + (slot - bw) / 2f;
            float bh = Math.max(Ui.dp(getContext(), 2), chartH * values[i] / max);
            if (values[i] == 0) bh = Ui.dp(getContext(), 2);
            rect.set(left, chartH - bh, left + bw, chartH);
            bar.setColor(i == n - 1 ? Ui.PRIMARY : 0xFF9DB1D6); // Build 15 chart colours
            canvas.drawRoundRect(rect, radius, radius, bar);
            float x = left + bw / 2f;
            canvas.drawText(String.valueOf(values[i]), x, chartH + Ui.dp(getContext(), 16), num);
            canvas.drawText(labels[i] == null ? "" : labels[i], x, chartH + Ui.dp(getContext(), 30), lab);
        }
    }

    private static float easeOut(float t) {
        return 1f - (1f - t) * (1f - t) * (1f - t);
    }
}
