package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Call Guard: warnings for calls from numbers that aren't in the user's contacts, and blocking of numbers
 * the user chose to block. It uses Android's call-screening role (Android 10+), so SafeSphere needs no
 * phone, call-log or contacts permission: Android only asks SafeSphere about calls from non-contacts.
 *
 * Deliberately not included: caller-ID names (would need a shared database of everyone's call numbers on a
 * server) and deepfake video detection (apps can't see another app's video call). Numbers never leave the phone.
 */
final class CallGuard {

    static final int HIDDEN = 0, BLOCKED = 1, INTERNATIONAL = 2, UNKNOWN = 3;
    static final String HOME_PREFIX = "+63"; // Philippines

    private static final String PREFS = "call_guard";
    private static final String KEY_BLOCKED = "blocked";
    private static final String KEY_WARN = "warn";
    private static final String KEY_SILENCE_HIDDEN = "silenceHidden";

    private CallGuard() {}

    // ------------------------------------------------------------------ pure logic (unit-tested)

    /**
     * Puts a phone number in one form so "0917 123 4567", "+63 917-123-4567" and "639171234567" match.
     * Returns null when it isn't a usable number.
     */
    static String normalize(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        if (s.startsWith("tel:")) s = s.substring(4);
        boolean plus = s.startsWith("+");
        StringBuilder d = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') d.append(ch);
            else if (ch == ' ' || ch == '-' || ch == '(' || ch == ')' || ch == '.' || (ch == '+' && i == 0)) continue;
            else if (ch == '%' && s.startsWith("%2B", i)) { plus = true; i += 2; }
            else return null; // letters, *, # (codes, not numbers)
        }
        String n = d.toString();
        if (n.length() < 3 || n.length() > 15) return null;
        if (plus) return "+" + n;
        if (n.startsWith("00") && n.length() > 4) return "+" + n.substring(2);
        if (n.startsWith("09") && n.length() == 11) return HOME_PREFIX + n.substring(1);      // 0917 123 4567
        if (n.startsWith("639") && n.length() == 12) return "+" + n;                           // 639171234567
        if (n.startsWith("9") && n.length() == 10) return HOME_PREFIX + n;                    // 917 123 4567
        return n; // short codes and landlines stay as dialled
    }

    /** What kind of call this is. {@code number} may be null for a hidden number. */
    static int classify(String number, Set<String> blocked) {
        String n = normalize(number);
        if (n == null) return HIDDEN;
        if (blocked != null && blocked.contains(n)) return BLOCKED;
        if (n.startsWith("+") && !n.startsWith(HOME_PREFIX)) return INTERNATIONAL;
        return UNKNOWN;
    }

    /** "+639171234567" → "+63917 ••• 4567", so History and notifications don't show the full number. */
    static String mask(String number) {
        String n = normalize(number);
        if (n == null) return "Hidden number";
        if (n.length() <= 7) return n;
        return n.substring(0, n.length() - 7 < 6 ? n.length() - 7 : 6) + " ••• " + n.substring(n.length() - 4);
    }

    static String title(int kind, String number) {
        switch (kind) {
            case HIDDEN: return "Hidden number calling";
            case INTERNATIONAL: return "International call · " + mask(number);
            case BLOCKED: return "Blocked call · " + mask(number);
            default: return "Unknown caller · " + mask(number);
        }
    }

    static String advice(int kind) {
        String base = "Banks, GCash and Maya never ask for your OTP, MPIN or password on a call. If they do, hang up.";
        if (kind == INTERNATIONAL) return "Not a Philippine number. " + base;
        if (kind == HIDDEN) return "The caller hid their number. " + base;
        return base;
    }

    // ------------------------------------------------------------------ settings and block list (on this phone only)

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Set<String> blocked(Context c) {
        return new HashSet<>(prefs(c).getStringSet(KEY_BLOCKED, Collections.emptySet()));
    }

    static List<String> blockedSorted(Context c) {
        List<String> l = new ArrayList<>(blocked(c));
        Collections.sort(l);
        return l;
    }

    /** Returns the stored form, or null if the number isn't valid. */
    static String block(Context c, String raw) {
        String n = normalize(raw);
        if (n == null) return null;
        Set<String> s = blocked(c);
        s.add(n);
        prefs(c).edit().putStringSet(KEY_BLOCKED, s).apply();
        return n;
    }

    static void unblock(Context c, String number) {
        Set<String> s = blocked(c);
        s.remove(number);
        prefs(c).edit().putStringSet(KEY_BLOCKED, s).apply();
    }

    static boolean warnings(Context c) { return prefs(c).getBoolean(KEY_WARN, true); }

    static void setWarnings(Context c, boolean on) { prefs(c).edit().putBoolean(KEY_WARN, on).apply(); }

    static boolean silenceHidden(Context c) { return prefs(c).getBoolean(KEY_SILENCE_HIDDEN, false); }

    static void setSilenceHidden(Context c, boolean on) { prefs(c).edit().putBoolean(KEY_SILENCE_HIDDEN, on).apply(); }

    // ------------------------------------------------------------------ Android role

    /** Call screening by a non-dialer app needs Android 10 or newer. */
    static boolean supported() {
        return Build.VERSION.SDK_INT >= 29;
    }

    /** True when the user has made SafeSphere the call-screening app. */
    static boolean enabled(Context c) {
        if (!supported()) return false;
        android.app.role.RoleManager rm = c.getSystemService(android.app.role.RoleManager.class);
        return rm != null && rm.isRoleHeld(android.app.role.RoleManager.ROLE_CALL_SCREENING);
    }
}
