package com.nekowishy.safesphere;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Automatic scam message alerts: reads the text of new message notifications (SMS, Messenger, Viber,
 * Telegram, WhatsApp, email) ON THE PHONE and warns when a message contains a dangerous link.
 * Messages are never stored or sent anywhere; only the warning is recorded in History.
 */
public class ScamMessageWatcher extends NotificationListenerService {

    private static final Set<String> MESSAGING_APPS = new HashSet<>(Arrays.asList(
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
            "com.oneplus.mms", "com.facebook.orca", "com.facebook.mlite", "com.viber.voip", "org.telegram.messenger",
            "com.whatsapp", "com.whatsapp.w4b", "jp.naver.line.android", "com.google.android.gm",
            "com.microsoft.office.outlook", "com.instagram.android", "com.discord",
            // phone-brand and popular third-party SMS apps
            "com.android.messaging", "com.coloros.mms", "com.oplus.mms", "com.oppo.mms", "com.realme.mms",
            "com.vivo.mms", "com.miui.mms", "com.xiaomi.mms", "com.huawei.message", "com.hihonor.mms",
            "com.motorola.messaging", "com.sonyericsson.conversations", "com.asus.message", "com.transsion.message",
            "com.truecaller", "com.textra", "com.p1.chompsms", "com.facebook.katana", "com.zhiliaoapp.musically",
            "com.snapchat.android", "com.skype.raider", "com.microsoft.teams", "com.yahoo.mobile.client.android.mail"));

    /** Sample used by the in-app "Send test alert" button (same as the classroom test message). */
    static final String TEST_MESSAGE = "Your parcel is on hold. Pay the fee: http://lbc-parcel-fee.example/pay";

    /** True while Android has SafeSphere's listener running (can be false right after an update or on battery savers). */
    static volatile boolean connected;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Map<Integer, Long> seen = new LinkedHashMap<Integer, Long>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Integer, Long> eldest) {
            return size() > 200;
        }
    };

    /** True when the user has given SafeSphere notification access. */
    static boolean isEnabled(Context c) {
        String list = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return list != null && list.contains(c.getPackageName() + "/");
    }

    @Override
    public void onListenerConnected() {
        connected = true;
        diag(this).edit().putLong("connectedAt", System.currentTimeMillis()).apply();
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
        rebind(this); // ask Android to start the listener again
    }

    /** Asks Android to reconnect the listener (fixes alerts stopping after an app update on some phones). */
    static void rebind(Context c) {
        try {
            requestRebind(new ComponentName(c, ScamMessageWatcher.class));
        } catch (Exception ignored) {
        }
    }

    private static boolean isMessaging(String pkg, Notification n) {
        if (MESSAGING_APPS.contains(pkg)) return true;
        if (Notification.CATEGORY_MESSAGE.equals(n.category) || Notification.CATEGORY_EMAIL.equals(n.category)) return true;
        if (n.extras != null && n.extras.getParcelableArray(Notification.EXTRA_MESSAGES) != null) return true; // chat-style
        String p = pkg.toLowerCase(java.util.Locale.ROOT);
        return p.contains("mms") || p.contains("sms") || p.contains("messag") || p.contains("mail");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
        connected = true;
        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return; // "3 new messages" summaries repeat the real ones
        String pkg = sbn.getPackageName();
        if (!isMessaging(pkg, n)) return;
        String text = messageText(n.extras);
        // Only the app name and time are kept (for the status line in the Check tab), never the message
        diag(this).edit().putLong("lastSeenAt", System.currentTimeMillis()).putString("lastSeenPkg", pkg)
                .putBoolean("lastHadText", text != null && text.length() >= 6).apply();
        if (text == null || text.length() < 6) return;
        int key = (sbn.getPackageName() + "|" + text).hashCode();
        synchronized (seen) {
            if (seen.containsKey(key)) return; // the same message is often re-posted
            seen.put(key, System.currentTimeMillis());
        }
        worker.execute(() -> check(getApplicationContext(), pkg, text));
    }

    private static String messageText(Bundle e) {
        if (e == null) return null;
        StringBuilder sb = new StringBuilder();
        Parcelable[] msgs = e.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (msgs != null && msgs.length > 0 && msgs[msgs.length - 1] instanceof Bundle) {
            CharSequence t = ((Bundle) msgs[msgs.length - 1]).getCharSequence("text"); // newest message only
            if (t != null) sb.append(t);
        }
        if (sb.length() == 0) {
            CharSequence big = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
            CharSequence txt = e.getCharSequence(Notification.EXTRA_TEXT);
            if (big != null) sb.append(big);
            else if (txt != null) sb.append(txt);
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    /** Runs the full check + alert on the sample message, without needing anyone to send it. Background thread only. */
    static boolean runTest(Context c) {
        return check(c.getApplicationContext(), null, TEST_MESSAGE);
    }

    static SharedPreferences diag(Context c) {
        return c.getApplicationContext().getSharedPreferences("msg_alerts", Context.MODE_PRIVATE);
    }

    /** Returns true when an alert was raised. pkg == null means the in-app test. */
    private static boolean check(Context app, String pkg, String text) {
        List<String> links = ScamDetector.extractLinks(text);
        if (links.isEmpty()) return false; // only messages with links: avoids false alarms on normal chats and promos
        RuleStore.init(app);
        ThreatDb.ensureLoaded(app);
        ScamDetector.LinkResult worst = null;
        for (String l : links) {
            ScamDetector.LinkResult r = ScamDetector.analyze(l);
            if (worst == null || r.level > worst.level) worst = r;
        }
        int warnings = ScamDetector.messageWarnings(text).size();
        int level = worst.level;
        // A risky-looking link plus scam wording ("you won", "verify now", "pay the fee") is treated as a scam
        if (warnings >= 1 && level >= ScamDetector.CAUTION) level = Math.max(level, ScamDetector.SUSPICIOUS);
        if (pkg != null) {
            // Remember only the last link's address and verdict, for the status line in the Check tab
            diag(app).edit().putString("lastCheckHost", worst.host).putInt("lastCheckLevel", level)
                    .putLong("lastCheckAt", System.currentTimeMillis()).apply();
        }
        if (level < ScamDetector.SUSPICIOUS) return false;

        String appName = pkg == null ? "SafeSphere test" : appLabel(app, pkg);
        String why = worst.reasons.isEmpty() ? "Scam signs in the message" : firstSentence(worst.reasons.get(0));
        String reason = "Scam message in " + appName + ": " + why;
        EventLog.get(app).record(worst.host, reason, System.currentTimeMillis());
        Alerts.scamMessage(app, appName, worst.host, level == ScamDetector.DANGEROUS, why);
        if (pkg != null) diag(app).edit().putLong("lastAlertAt", System.currentTimeMillis()).apply();
        return true;
    }

    private static String firstSentence(String s) {
        int dot = s.indexOf(". ");
        return dot > 0 ? s.substring(0, dot) : s;
    }

    static String appLabel(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return "a message";
        }
    }

    @Override
    public void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }

    static List<String> watchedAppsForDisplay() {
        return new ArrayList<>(Arrays.asList("Messages", "Messenger", "Viber", "Telegram", "WhatsApp", "Gmail"));
    }
}
