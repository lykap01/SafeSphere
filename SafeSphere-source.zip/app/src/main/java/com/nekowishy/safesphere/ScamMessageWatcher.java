package com.nekowishy.safesphere;

import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Automatic scam message alerts: reads the text of new message notifications (SMS, Messenger, Viber,
 * Telegram, WhatsApp, email) ON THE PHONE and warns when a message contains a dangerous link.
 * Messages are never stored or sent anywhere; only the warning is recorded in History.
 */
public class ScamMessageWatcher extends NotificationListenerService {

    private static final Set<String> MESSAGING_APPS = new HashSet<>(Arrays.asList(
            "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.android.mms",
            "com.oneplus.mms", "com.facebook.orca", "com.facebook.mlite", "com.viber.voip", "org.telegram.messenger",
            "com.whatsapp", "com.whatsapp.w4b", "jp.naver.line.android", "com.google.android.gm",
            "com.microsoft.office.outlook", "com.instagram.android", "com.discord"));

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Map<Integer, Long> seen = new LinkedHashMap<Integer, Long>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Integer, Long> eldest) {
            return size() > 200;
        }
    };

    /** True when the user has given SafeSphere notification access. */
    static boolean isEnabled(Context c) {
        String list = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return list != null && list.contains(c.getPackageName() + "/");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;
        boolean messaging = MESSAGING_APPS.contains(sbn.getPackageName())
                || Notification.CATEGORY_MESSAGE.equals(n.category) || Notification.CATEGORY_EMAIL.equals(n.category);
        if (!messaging) return;
        String text = messageText(n.extras);
        if (text == null || text.length() < 6) return;
        int key = (sbn.getPackageName() + "|" + text).hashCode();
        synchronized (seen) {
            if (seen.containsKey(key)) return; // the same message is often re-posted
            seen.put(key, System.currentTimeMillis());
        }
        String pkg = sbn.getPackageName();
        worker.execute(() -> check(pkg, text));
    }

    private static String messageText(Bundle e) {
        if (e == null) return null;
        StringBuilder sb = new StringBuilder();
        Parcelable[] msgs = e.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (msgs != null && msgs.length > 0 && msgs[msgs.length - 1] instanceof Bundle) {
            CharSequence t = ((Bundle) msgs[msgs.length - 1]).getCharSequence("text"); // newest message only
            if (t != null) sb.append(t);
        }
        if (sb.length() == 0) {
            CharSequence big = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
            CharSequence txt = e.getCharSequence(Notification.EXTRA_TEXT);
            if (big != null) sb.append(big);
            else if (txt != null) sb.append(txt);
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private void check(String pkg, String text) {
        Context app = getApplicationContext();
        List<String> links = ScamDetector.extractLinks(text);
        if (links.isEmpty()) return; // only messages with links: avoids false alarms on normal chats and promos
        RuleStore.init(app);
        ThreatDb.ensureLoaded(app);
        ScamDetector.LinkResult worst = null;
        for (String l : links) {
            ScamDetector.LinkResult r = ScamDetector.analyze(l);
            if (worst == null || r.level > worst.level) worst = r;
        }
        int warnings = ScamDetector.messageWarnings(text).size();
        int level = worst.level;
        if (warnings >= 2 && level >= ScamDetector.CAUTION) level = Math.max(level, ScamDetector.SUSPICIOUS);
        if (level < ScamDetector.SUSPICIOUS) return;

        String appName = appLabel(app, pkg);
        String why = worst.reasons.isEmpty() ? "Scam signs in the message" : firstSentence(worst.reasons.get(0));
        String reason = "Scam message in " + appName + ": " + why;
        EventLog.get(app).record(worst.host, reason, System.currentTimeMillis());
        Alerts.scamMessage(app, appName, worst.host, level == ScamDetector.DANGEROUS, why);
    }

    private static String firstSentence(String s) {
        int dot = s.indexOf(". ");
        return dot > 0 ? s.substring(0, dot) : s;
    }

    private static String appLabel(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception e) {
            return "a message";
        }
    }

    @Override
    public void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }

    static List<String> watchedAppsForDisplay() {
        return new ArrayList<>(Arrays.asList("Messages", "Messenger", "Viber", "Telegram", "WhatsApp", "Gmail"));
    }
}
