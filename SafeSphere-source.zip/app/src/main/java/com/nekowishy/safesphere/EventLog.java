package com.nekowishy.safesphere;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Local security activity log and Recovery Center incidents (safesphere.db).
 *
 * Privacy: only security events are stored (time, domain, short reason, category). No browsing history
 * and no message text is ever written here. Everything stays on the phone and can be cleared.
 *
 * Schema history:
 *   v1 (Build 15): events(_id, ts, domain, reason)
 *   v2 (Build 16): + events.category, + incidents table. Upgrade keeps every existing row.
 */
final class EventLog extends SQLiteOpenHelper {

    static final int VERSION = 2;

    // Event categories
    static final String CAT_BLOCKED = "blocked";       // DNS filter refused a domain
    static final String CAT_MESSAGE = "message";       // automatic scam-message warning
    static final String CAT_CHECK = "check";           // a check the user ran in the Check tab
    static final String CAT_PROTECTION = "protection"; // protection turned on / off / interrupted
    static final String CAT_DEVICE = "device";         // device setting found or resolved
    static final String CAT_RECOVERY = "recovery";     // Recovery Center activity
    static final String CAT_CALL = "call";             // Call Guard warning or rejected call (number masked)
    static final String CAT_TEST = "test";             // live protection test

    static final class Event {
        long id;
        long time;
        String domain;
        String reason;
        String category;
    }

    static final class Incident {
        long id;
        String type;          // RecoveryGuide incident id
        long created;
        long occurredAt;
        String sender = "";   // suspicious domain, number or account name (optional)
        String description = "";
        String actionsTaken = "";
        String stepsDone = ""; // comma-separated step indexes
        long updated;
    }

    private static EventLog instance;
    private int writes;

    static synchronized EventLog get(Context c) {
        if (instance == null) instance = new EventLog(c.getApplicationContext());
        return instance;
    }

    private EventLog(Context c) {
        super(c, "safesphere.db", null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (_id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, domain TEXT NOT NULL, "
                + "reason TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'blocked')");
        createV2Tables(db);
    }

    private static void createV2Tables(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS events_ts ON events(ts)");
        db.execSQL("CREATE TABLE IF NOT EXISTS incidents (_id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, "
                + "created INTEGER NOT NULL, occurred_at INTEGER NOT NULL, sender TEXT NOT NULL DEFAULT '', "
                + "description TEXT NOT NULL DEFAULT '', actions_taken TEXT NOT NULL DEFAULT '', "
                + "steps_done TEXT NOT NULL DEFAULT '', updated INTEGER NOT NULL)");
    }

    /** Migrates without deleting anything (Build 15's upgrade dropped the table). */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE events ADD COLUMN category TEXT NOT NULL DEFAULT 'blocked'");
            db.execSQL("UPDATE events SET category = 'message' WHERE reason LIKE 'Scam message%'");
            db.execSQL("UPDATE events SET category = 'test' WHERE reason = 'SafeSphere live test'");
            createV2Tables(db);
        }
    }

    // ------------------------------------------------------------------ events

    /** Build 15 call sites: a DNS block. */
    synchronized void record(String domain, String reason, long time) {
        record(RuleStore.REASON_TEST.equals(reason) ? CAT_TEST : CAT_BLOCKED, domain, reason, time);
    }

    synchronized void record(String category, String domain, String reason, long time) {
        ContentValues v = new ContentValues();
        v.put("ts", time);
        v.put("domain", domain == null ? "" : domain);
        v.put("reason", reason == null ? "" : reason);
        v.put("category", category);
        SQLiteDatabase db = getWritableDatabase();
        db.insert("events", null, v);
        if (++writes % 50 == 0) {
            db.execSQL("DELETE FROM events WHERE _id NOT IN (SELECT _id FROM events ORDER BY _id DESC LIMIT 3000)");
        }
    }

    synchronized List<Event> recent(int limit) {
        return recent(limit, null);
    }

    /** Most recent events, optionally only one category. */
    synchronized List<Event> recent(int limit, String category) {
        List<Event> out = new ArrayList<>();
        String where = category == null ? null : "category = ?";
        String[] args = category == null ? null : new String[]{category};
        try (Cursor c = getReadableDatabase().query("events", new String[]{"_id", "ts", "domain", "reason", "category"},
                where, args, null, null, "_id DESC", String.valueOf(limit))) {
            while (c.moveToNext()) {
                Event e = new Event();
                e.id = c.getLong(0);
                e.time = c.getLong(1);
                e.domain = c.getString(2);
                e.reason = c.getString(3);
                e.category = c.getString(4);
                out.add(e);
            }
        }
        return out;
    }

    synchronized long count() {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events");
    }

    /** Threats: DNS blocks and message warnings (not tests, checks or setting changes). */
    synchronized long threatCount() {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events", "category IN ('blocked','message')", null);
    }

    synchronized long countSince(long time) {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events",
                "ts >= ? AND category IN ('blocked','message')", new String[]{String.valueOf(time)});
    }

    synchronized long countSince(String category, long time) {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events", "ts >= ? AND category = ?",
                new String[]{String.valueOf(time), category});
    }

    /** Threats per day for the last {@code days} days, oldest first, today last. */
    synchronized long[] countsPerDay(int days, long startOfToday) {
        long[] out = new long[days];
        long dayMs = 24L * 60 * 60 * 1000;
        for (int i = 0; i < days; i++) {
            long from = startOfToday - (long) (days - 1 - i) * dayMs;
            long to = from + dayMs;
            out[i] = DatabaseUtils.queryNumEntries(getReadableDatabase(), "events",
                    "ts >= ? AND ts < ? AND category IN ('blocked','message')",
                    new String[]{String.valueOf(from), String.valueOf(to)});
        }
        return out;
    }

    static final class DomainCount {
        String domain;
        long count;
    }

    /** Domains that were blocked or warned about more than once since {@code since}, most frequent first. */
    synchronized List<DomainCount> repeatedDomains(long since, int limit) {
        List<DomainCount> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT domain, COUNT(*) AS n FROM events WHERE ts >= ? AND domain != '' AND category IN ('blocked','message') "
                        + "GROUP BY domain HAVING n >= 2 ORDER BY n DESC, MAX(ts) DESC LIMIT " + limit,
                new String[]{String.valueOf(since)})) {
            while (c.moveToNext()) {
                DomainCount d = new DomainCount();
                d.domain = c.getString(0);
                d.count = c.getLong(1);
                out.add(d);
            }
        }
        return out;
    }

    synchronized long latestId() {
        return DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT IFNULL(MAX(_id), 0) FROM events", null);
    }

    synchronized void clear() {
        getWritableDatabase().delete("events", null, null);
    }

    // ------------------------------------------------------------------ incidents (Recovery Center)

    synchronized long saveIncident(Incident i) {
        ContentValues v = new ContentValues();
        v.put("type", i.type);
        v.put("occurred_at", i.occurredAt);
        v.put("sender", i.sender == null ? "" : i.sender);
        v.put("description", i.description == null ? "" : i.description);
        v.put("actions_taken", i.actionsTaken == null ? "" : i.actionsTaken);
        v.put("steps_done", i.stepsDone == null ? "" : i.stepsDone);
        v.put("updated", System.currentTimeMillis());
        SQLiteDatabase db = getWritableDatabase();
        if (i.id > 0) {
            db.update("incidents", v, "_id = ?", new String[]{String.valueOf(i.id)});
        } else {
            i.created = System.currentTimeMillis();
            v.put("created", i.created);
            i.id = db.insert("incidents", null, v);
        }
        return i.id;
    }

    synchronized List<Incident> incidents() {
        List<Incident> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("incidents", new String[]{"_id", "type", "created", "occurred_at",
                "sender", "description", "actions_taken", "steps_done", "updated"}, null, null, null, null, "updated DESC")) {
            while (c.moveToNext()) out.add(readIncident(c));
        }
        return out;
    }

    synchronized Incident incident(long id) {
        try (Cursor c = getReadableDatabase().query("incidents", new String[]{"_id", "type", "created", "occurred_at",
                "sender", "description", "actions_taken", "steps_done", "updated"}, "_id = ?",
                new String[]{String.valueOf(id)}, null, null, null)) {
            return c.moveToNext() ? readIncident(c) : null;
        }
    }

    private static Incident readIncident(Cursor c) {
        Incident i = new Incident();
        i.id = c.getLong(0);
        i.type = c.getString(1);
        i.created = c.getLong(2);
        i.occurredAt = c.getLong(3);
        i.sender = c.getString(4);
        i.description = c.getString(5);
        i.actionsTaken = c.getString(6);
        i.stepsDone = c.getString(7);
        i.updated = c.getLong(8);
        return i;
    }

    synchronized void deleteIncident(long id) {
        getWritableDatabase().delete("incidents", "_id = ?", new String[]{String.valueOf(id)});
    }

    synchronized long openIncidentCount() {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "incidents");
    }
}
