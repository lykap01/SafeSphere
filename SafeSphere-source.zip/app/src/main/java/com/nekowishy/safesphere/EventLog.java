package com.nekowishy.safesphere;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/** Stores only blocked events (domain, reason, time) on the phone. No browsing history is kept. */
final class EventLog extends SQLiteOpenHelper {

    static final class Event {
        long id;
        long time;
        String domain;
        String reason;
    }

    private static EventLog instance;
    private int writes;

    static synchronized EventLog get(Context c) {
        if (instance == null) instance = new EventLog(c.getApplicationContext());
        return instance;
    }

    private EventLog(Context c) {
        super(c, "safesphere.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE events (_id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, domain TEXT NOT NULL, reason TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS events");
        onCreate(db);
    }

    synchronized void record(String domain, String reason, long time) {
        ContentValues v = new ContentValues();
        v.put("ts", time);
        v.put("domain", domain);
        v.put("reason", reason);
        SQLiteDatabase db = getWritableDatabase();
        db.insert("events", null, v);
        if (++writes % 50 == 0) {
            db.execSQL("DELETE FROM events WHERE _id NOT IN (SELECT _id FROM events ORDER BY _id DESC LIMIT 2000)");
        }
    }

    synchronized List<Event> recent(int limit) {
        List<Event> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query("events", new String[]{"_id", "ts", "domain", "reason"},
                null, null, null, null, "_id DESC", String.valueOf(limit))) {
            while (c.moveToNext()) {
                Event e = new Event();
                e.id = c.getLong(0);
                e.time = c.getLong(1);
                e.domain = c.getString(2);
                e.reason = c.getString(3);
                out.add(e);
            }
        }
        return out;
    }

    synchronized long count() {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events");
    }

    synchronized long countSince(long time) {
        return DatabaseUtils.queryNumEntries(getReadableDatabase(), "events", "ts >= ?", new String[]{String.valueOf(time)});
    }

    /** Number of events per day for the last {@code days} days, oldest first, today last. */
    synchronized long[] countsPerDay(int days, long startOfToday) {
        long[] out = new long[days];
        long dayMs = 24L * 60 * 60 * 1000;
        for (int i = 0; i < days; i++) {
            long from = startOfToday - (long) (days - 1 - i) * dayMs;
            long to = from + dayMs;
            out[i] = DatabaseUtils.queryNumEntries(getReadableDatabase(), "events", "ts >= ? AND ts < ?",
                    new String[]{String.valueOf(from), String.valueOf(to)});
        }
        return out;
    }

    synchronized long latestId() {
        return DatabaseUtils.longForQuery(getReadableDatabase(), "SELECT IFNULL(MAX(_id), 0) FROM events", null);
    }

    synchronized void clear() {
        getWritableDatabase().delete("events", null, null);
    }
}
