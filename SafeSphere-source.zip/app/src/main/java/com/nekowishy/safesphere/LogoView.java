package com.nekowishy.safesphere;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** SafeSphere mark: a shield outline with a small burst of rays, drawn so it looks the same on every phone. */
final class LogoView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final android.graphics.Path shield = new android.graphics.Path();
    private int color;

    LogoView(Context c, int color) {
        super(c);
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f, s = Math.min(w, h) / 2f;
        p.setColor(color);
        p.setStrokeWidth(s * 0.13f);
        for (int i = 0; i < 8; i++) { // burst
            double a = Math.toRadians(i * 45 - 90);
            float x1 = cx + (float) Math.cos(a) * s * 0.62f, y1 = cy + (float) Math.sin(a) * s * 0.62f;
            float x2 = cx + (float) Math.cos(a) * s * 0.95f, y2 = cy + (float) Math.sin(a) * s * 0.95f;
            canvas.drawLine(x1, y1, x2, y2, p);
        }
        float k = s * 0.42f; // small shield in the middle
        shield.reset();
        shield.moveTo(cx, cy - k);
        shield.lineTo(cx + k * 0.8f, cy - k * 0.62f);
        shield.lineTo(cx + k * 0.8f, cy + k * 0.05f);
        shield.quadTo(cx + k * 0.7f, cy + k * 0.75f, cx, cy + k);
        shield.quadTo(cx - k * 0.7f, cy + k * 0.75f, cx - k * 0.8f, cy + k * 0.05f);
        shield.lineTo(cx - k * 0.8f, cy - k * 0.62f);
        shield.close();
        p.setStrokeWidth(s * 0.11f);
        canvas.drawPath(shield, p);
    }
}
