package com.nekowishy.safesphere;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * "Before you act" (the Check tab): explains what a message, link or QR code is asking the user to do,
 * the warning signs, why they matter and what to do. Local analysis first; AI only if the user asks
 * and agrees to the exact text being sent.
 */
final class CheckPage {

    private final MainActivity a;

    // State kept while switching tabs (in memory only, never saved)
    private String text = "";       // the text that was analysed
    private String draft = "";      // what is in the box now (kept when the page is redrawn)
    private String qrNote;
    private ActionAnalyzer.Report report;
    private boolean checking;
    private AiClient.Result aiResult;
    private boolean aiLoading;
    private PasswordCheck.Result pwResult;
    private boolean pwChecking;
    private FrameLayout alertsHolder;
    private boolean testingAlert;

    CheckPage(MainActivity a) { this.a = a; }

    // ------------------------------------------------------------------ entry points

    /** Text or images shared to SafeSphere, or text selected with "Check with SafeSphere". */
    boolean handleShared(Intent intent) {
        if (intent == null || intent.getAction() == null) return false;
        String action = intent.getAction();
        if (Intent.ACTION_SEND.equals(action)) {
            String type = intent.getType();
            if (type != null && type.startsWith("image/")) {
                Uri uri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (uri != null) {
                    a.show(MainActivity.TAB_CHECK);
                    readQr(uri);
                    return true;
                }
            }
            CharSequence t = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (t != null) {
                runCheck(t.toString(), null);
                return true;
            }
        }
        if (Intent.ACTION_PROCESS_TEXT.equals(action)) {
            CharSequence t = intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
            if (t != null) {
                runCheck(t.toString(), null);
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ screen

    void build(LinearLayout col) {
        LinearLayout input = Ui.card(a);
        input.addView(Ui.body(a, "Paste a message, link, e-mail or payment instruction. SafeSphere shows what it asks "
                + "you to do and whether that's risky. Checked on this phone; nothing is saved or sent."));
        EditText field = new EditText(a);
        field.setText(draft);
        field.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {}
            public void afterTextChanged(android.text.Editable e) { draft = e.toString(); }
        });
        field.setHint("Paste or type the message here");
        field.setMinLines(4);
        field.setMaxLines(10);
        field.setGravity(Gravity.TOP | Gravity.START);
        field.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        Ui.field(field);
        field.setContentDescription("Message or link to check");
        input.addView(field, Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        input.addView(Ui.primary(a, checking ? "Checking…" : "Check", v -> {
            a.hideKeyboard(field);
            String t = field.getText().toString();
            if (t.trim().isEmpty()) {
                field.setError("Paste a message or link first");
                Ui.shake(field);
                return;
            }
            runCheck(t, null);
        }), Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        input.addView(Ui.pair(a,
                Ui.secondary(a, "Paste", v -> pasteAndCheck()),
                Ui.secondary(a, "QR code image", v -> pickQrImage())), Ui.margins(a, Ui.MATCH, Ui.WRAP, 8));
        input.addView(Ui.link(a, "Message is in a screenshot?", v -> a.info("Checking a screenshot",
                "SafeSphere can read QR codes in images, but not other text in a screenshot.\n\n"
                        + "To check the message: open the screenshot, long-press the text to select it (or use Google Lens "
                        + "→ Text), copy it, then tap Paste here. You can also select text in any app and choose "
                        + "\"Check with SafeSphere\".")));
        col.addView(input, Ui.margins(a, Ui.MATCH, Ui.WRAP, 8));

        if (qrNote != null) {
            a.add(col, Ui.banner(a, Ui.T_INFO, "QR code", qrNote));
        }
        if (report != null && !checking) buildResult(col);

        a.section(col, "Automatic alerts");
        alertsHolder = new FrameLayout(a);
        alertsHolder.addView(alertsCard());
        col.addView(alertsHolder);

        a.section(col, "Password leak check");
        col.addView(passwordCard());

    }

    // ------------------------------------------------------------------ result

    private void buildResult(LinearLayout col) {
        ActionAnalyzer.Report r = report;
        if (text.trim().isEmpty() && r.links.isEmpty()) return;

        // 1. Risk assessment
        a.section(col, "Risk assessment");
        int tone = ScamDetector.tone(r.level);
        String head;
        switch (r.level) {
            case ScamDetector.DANGEROUS: head = "Dangerous"; break;
            case ScamDetector.SUSPICIOUS: head = "Suspicious indicators found"; break;
            case ScamDetector.CAUTION: head = "Requires caution"; break;
            default: head = "No risky requests found"; break;
        }
        col.addView(Ui.banner(a, tone, head, r.summary));
        if (r.note != null) a.add(col, Ui.banner(a, Ui.T_INFO, "Looks like a normal code message", r.note));

        // 2. Requested action
        a.section(col, "What it asks you to do");
        LinearLayout acts = Ui.card(a);
        List<ActionAnalyzer.Finding> actions = r.actions();
        boolean linkOnly = !r.links.isEmpty() && text.trim().split("\\s+").length <= r.links.size();
        if (actions.isEmpty() && linkOnly) {
            acts.addView(Ui.body(a, "This is a link on its own, so there is no request to judge. See the link check below."));
        } else if (actions.isEmpty()) {
            acts.addView(Ui.body(a, "No risky action found (such as sharing a code, paying, logging in or installing an app)."));
        } else {
            List<String> lines = new ArrayList<>();
            for (ActionAnalyzer.Finding f : actions) lines.add(f.title);
            acts.addView(Ui.bullets(a, lines));
        }
        col.addView(acts);

        // 3. Warning signs (exact words, links)
        List<ActionAnalyzer.Finding> all = r.findings;
        boolean anyLinks = !r.links.isEmpty();
        if (!all.isEmpty() || anyLinks) {
            a.section(col, "Warning signs");
            LinearLayout signs = Ui.listCard(a);
            int n = 0;
            for (ActionAnalyzer.Finding f : all) {
                if (n++ > 0) signs.addView(Ui.divider(a));
                int t = f.action ? (f.weight >= ActionAnalyzer.HIGH ? Ui.T_SUSPICIOUS : Ui.T_WARNING) : Ui.T_WARNING;
                String quote = f.evidence.isEmpty() ? null : "Found: “" + TextUtils.join("”, “", f.evidence) + "”";
                signs.addView(Ui.row(a, Ui.statusDot(a, t), f.title, quote, null, null));
            }
            for (ScamDetector.LinkResult l : r.links) {
                if (n++ > 0) signs.addView(Ui.divider(a));
                signs.addView(linkRow(l));
            }
            col.addView(signs);
        }

        // 4. Why it matters
        List<String> why = new ArrayList<>();
        for (ActionAnalyzer.Finding f : all) if (f.action || r.level >= ScamDetector.CAUTION) why.add(f.why);
        if (!why.isEmpty()) {
            a.section(col, "Why it matters");
            LinearLayout w = Ui.card(a);
            w.addView(Ui.bullets(a, dedupe(why)));
            col.addView(w);
        }

        // 5. Recommended action
        if (!r.advice.isEmpty() || r.level >= ScamDetector.CAUTION) {
            a.section(col, "What to do");
            LinearLayout adv = Ui.card(a);
            adv.addView(Ui.bullets(a, r.advice.isEmpty()
                    ? java.util.Collections.singletonList("Confirm with the sender through a channel you already trust before acting.")
                    : r.advice));
            col.addView(adv);
        }

        if (r.level >= ScamDetector.CAUTION) {
            LinearLayout rec = Ui.listCard(a);
            rec.addView(Ui.row(a, Ui.statusDot(a, Ui.T_INFO), "Already acted on it?",
                    "Clicked, paid, shared a code or installed something: open Recovery Center for a checklist.",
                    Ui.chevron(a), v -> a.open(MainActivity.PAGE_RECOVERY)));
            a.add(col, rec);
        }

        // Optional AI explanation
        a.section(col, "AI explanation (optional)");
        col.addView(aiCard());
    }

    private View linkRow(ScamDetector.LinkResult l) {
        LinearLayout row = Ui.vbox(a);
        row.setPadding(Ui.dp(a, 16), Ui.dp(a, 12), Ui.dp(a, 16), Ui.dp(a, 12));
        LinearLayout head = Ui.hbox(a);
        String shown = l.hostUnicode != null && !l.hostUnicode.isEmpty() && !l.hostUnicode.equals(l.host)
                ? l.hostUnicode + "  (" + l.host + ")" : (l.host.isEmpty() ? l.url : l.host);
        TextView host = Ui.text(a, shown, Ui.BODY, Ui.TEXT, true);
        host.setSingleLine(true);
        host.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        head.addView(host, Ui.params(0, Ui.WRAP, 1f));
        LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        lp.leftMargin = Ui.dp(a, 8);
        head.addView(Ui.badge(a, ScamDetector.tone(l.level), ScamDetector.label(l.level)), lp);
        row.addView(head);
        String basis = l.confirmed ? "Confirmed match on a threat list or your rules"
                : l.blockedByFilter ? "SafeSphere's own judgment (fake-site pattern), not a threat-list match"
                : l.level > ScamDetector.SAFE ? "Warning signs only. Not on any threat list" : null;
        if (basis != null) {
            TextView b = Ui.text(a, basis, Ui.LABEL, l.confirmed ? Ui.DANGER : Ui.TEXT2, true);
            b.setPadding(0, Ui.dp(a, 4), 0, 0);
            row.addView(b);
        }
        TextView reasons = Ui.support(a, "•  " + TextUtils.join("\n•  ", l.reasons));
        reasons.setPadding(0, Ui.dp(a, 6), 0, 0);
        row.addView(reasons);
        if (l.level >= ScamDetector.CAUTION && !l.host.isEmpty() && !RuleStore.blocked().contains(l.host)) {
            TextView block = Ui.primary(a, "Block this site", v -> a.blockWithUndo(l.host, MainActivity.TAB_CHECK));
            block.setContentDescription("Block " + l.host + " on this phone");
            row.addView(block, Ui.margins(a, Ui.MATCH, Ui.WRAP, 14));
        }
        return row;
    }

    private static List<String> dedupe(List<String> in) {
        return new ArrayList<>(new java.util.LinkedHashSet<>(in));
    }

    void runCheck(String input, String note) {
        aiResult = null;
        aiLoading = false;
        text = input == null ? "" : input;
        draft = text;
        qrNote = note;
        checking = true;
        report = null;
        a.show(MainActivity.TAB_CHECK);
        Context app = a.getApplicationContext();
        String t = text;
        a.bg.execute(() -> {
            RuleStore.init(app);
            ThreatDb.ensureLoaded(app);
            ActionAnalyzer.Report rep = ActionAnalyzer.analyzeText(t);
            // History keeps only the verdict, the request types and the worst website name. Never the text.
            String worstHost = "";
            int worst = -1;
            for (ScamDetector.LinkResult l : rep.links) if (l.level > worst) { worst = l.level; worstHost = l.host; }
            List<String> ids = new ArrayList<>();
            for (ActionAnalyzer.Finding f : rep.actions()) ids.add(lowerFirst(f.title));
            String summary = "Checked " + (rep.links.isEmpty() ? "a message" : rep.links.size() == 1 && t.trim().equals(rep.links.get(0).url) ? "a link" : "a message with links")
                    + ": " + ScamDetector.label(rep.level) + (ids.isEmpty() ? "" : " · asks to " + TextUtils.join("; ", ids));
            try {
                EventLog.get(app).record(EventLog.CAT_CHECK, worstHost, summary, System.currentTimeMillis());
            } catch (RuntimeException ignored) {
            }
            a.runOnUiThread(() -> {
                checking = false;
                report = rep;
                if (a.currentPage() == MainActivity.TAB_CHECK) a.show(MainActivity.TAB_CHECK);
            });
        });
    }

    private static String lowerFirst(String s) {
        return s.isEmpty() ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
    }

    private void pasteAndCheck() {
        ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        CharSequence t = clip == null || clip.getItemCount() == 0 ? null : clip.getItemAt(0).coerceToText(a);
        if (t == null || t.toString().trim().isEmpty()) {
            a.toast("Nothing copied yet. Copy a message or link first.");
            return;
        }
        runCheck(t.toString(), null);
    }

    private void pickQrImage() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE);
        try {
            a.startActivityForResult(Intent.createChooser(i, "Choose a QR code image"), MainActivity.REQ_QR);
        } catch (ActivityNotFoundException e) {
            a.toast("No gallery app found");
        }
    }

    void readQr(Uri uri) {
        a.toast("Reading QR code…");
        Context app = a.getApplicationContext();
        a.bg.execute(() -> {
            String t = QrReader.read(app, uri);
            a.runOnUiThread(() -> {
                if (t == null) {
                    text = "";
                    draft = "";
                    report = null;
                    qrNote = "No QR code found in that image. Try a clearer, closer picture of the code.";
                    a.show(MainActivity.TAB_CHECK);
                } else if (QrReader.isPaymentCode(t)) {
                    text = "";
                    draft = "";
                    report = null;
                    qrNote = "This is a payment QR code (EMVCo / QR Ph format). It contains no website link. Before paying, "
                            + "check the recipient's name and the amount shown in your banking or e-wallet app.";
                    a.show(MainActivity.TAB_CHECK);
                } else {
                    runCheck(t, "The QR code contains:\n" + t);
                }
            });
        });
    }

    // ------------------------------------------------------------------ AI (optional, with consent)

    private View aiCard() {
        LinearLayout c = Ui.card(a);
        if (aiLoading) {
            c.addView(Ui.body(a, "Waiting for the AI's answer…"));
            return c;
        }
        AiClient.Result r = aiResult;
        if (r == null) {
            c.addView(Ui.support(a, "SafeSphere's result above was made on this phone. For a second opinion in plain words, "
                    + "you can send a cleaned-up copy of the text to an external AI. You'll see exactly what is sent first."));
            c.addView(Ui.secondary(a, "Get AI explanation", v -> askAi()), Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
            return c;
        }
        if (r.error != null) {
            c.addView(Ui.banner(a, Ui.T_NEUTRAL, "AI explanation unavailable", r.error));
            c.addView(Ui.pair(a, Ui.secondary(a, "Try again", v -> askAi()),
                    Ui.secondary(a, "AI setup", v -> AiSetup.setupDialog(a, null))), Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
            return c;
        }
        LinearLayout head = Ui.hbox(a);
        head.addView(Ui.badge(a, r.tone(), r.label()));
        c.addView(head);
        TextView note = Ui.text(a, "AI opinion, not a verified verdict. It does not change SafeSphere's result or block anything.",
                Ui.LABEL, Ui.TEXT2, false);
        note.setPadding(0, Ui.dp(a, 6), 0, 0);
        c.addView(note);
        if (!r.summary.isEmpty()) {
            TextView sm = Ui.body(a, r.summary);
            sm.setPadding(0, Ui.dp(a, 10), 0, 0);
            c.addView(sm);
        }
        if (!r.reasons.isEmpty()) {
            TextView h = Ui.text(a, "Why", Ui.BODY, Ui.TEXT, true);
            h.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
            c.addView(h);
            c.addView(Ui.bullets(a, r.reasons));
        }
        if (!r.advice.isEmpty()) {
            TextView h = Ui.text(a, "What to do", Ui.BODY, Ui.TEXT, true);
            h.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
            c.addView(h);
            c.addView(Ui.bullets(a, r.advice));
        }
        return c;
    }

    private String localFindings() {
        StringBuilder sb = new StringBuilder();
        ActionAnalyzer.Report r = report;
        if (r == null) return "";
        sb.append("SafeSphere local result: ").append(ScamDetector.label(r.level)).append('\n');
        for (ActionAnalyzer.Finding f : r.findings) sb.append("Sign: ").append(f.title).append('\n');
        for (ScamDetector.LinkResult l : r.links) {
            sb.append("Link ").append(l.host).append(": ").append(ScamDetector.label(l.level));
            if (!l.reasons.isEmpty()) sb.append(" (").append(l.reasons.get(0)).append(")");
            sb.append('\n');
        }
        return sb.toString();
    }

    private void askAi() {
        Redactor.Result red = Redactor.redact(text);
        AiSetup.confirmSend(a, red, "SafeSphere's own result (risk level and warning signs) is sent too.", () -> {
            aiLoading = true;
            aiResult = null;
            a.show(MainActivity.TAB_CHECK);
            Context app = a.getApplicationContext();
            String toSend = red.text, local = localFindings();
            a.bg.execute(() -> {
                AiClient.Result r = AiClient.explain(app, toSend, local);
                a.runOnUiThread(() -> {
                    aiLoading = false;
                    aiResult = r;
                    if (a.currentPage() == MainActivity.TAB_CHECK) a.show(MainActivity.TAB_CHECK);
                });
            });
        });
    }

    // ------------------------------------------------------------------ automatic scam message alerts

    void refreshAlertsCard() {
        if (alertsHolder == null || a.currentPage() != MainActivity.TAB_CHECK) return;
        alertsHolder.removeAllViews();
        alertsHolder.addView(alertsCard());
    }

    private View statusLine(int tone, String s) {
        LinearLayout row = Ui.hbox(a);
        row.setPadding(0, Ui.dp(a, 8), 0, 0);
        TextView dot = Ui.statusDot(a, tone);
        row.addView(dot);
        TextView t = Ui.body(a, s);
        t.setPadding(Ui.dp(a, 10), 0, 0, 0);
        row.addView(t, Ui.params(0, Ui.WRAP, 1f));
        return row;
    }

    private View alertsCard() {
        boolean on = ScamMessageWatcher.isEnabled(a);
        if (on && !ScamMessageWatcher.connected) ScamMessageWatcher.rebind(a);
        String blocked = Alerts.alertsBlockedReason(a);
        boolean ready = on && blocked == null;
        LinearLayout card = Ui.card(a);
        LinearLayout head = Ui.hbox(a);
        head.addView(Ui.cardTitle(a, "Scam message alerts"), Ui.params(0, Ui.WRAP, 1f));
        head.addView(Ui.badge(a, ready ? Ui.T_SUCCESS : on ? Ui.T_WARNING : Ui.T_NEUTRAL, ready ? "On" : on ? "Needs attention" : "Off"));
        card.addView(head);
        card.addView(Ui.support(a, "Warns when a new message notification contains a dangerous link or asks for a code, "
                + "password or remote access. Text is checked on the phone and never saved."));

        card.addView(statusLine(on ? Ui.T_SUCCESS : Ui.T_NEUTRAL, on ? "Notification access is on" : "Notification access is off"));
        if (on) {
            card.addView(statusLine(ScamMessageWatcher.connected ? Ui.T_SUCCESS : Ui.T_WARNING, ScamMessageWatcher.connected
                    ? "Listening for new messages" : "Android hasn't started the listener yet. Reopen SafeSphere or restart the phone."));
        }
        card.addView(statusLine(blocked == null ? Ui.T_SUCCESS : Ui.T_WARNING, blocked == null ? "Alerts can pop up" : blocked));
        PowerManager pm = a.getSystemService(PowerManager.class);
        boolean restricted = false;
        if (Build.VERSION.SDK_INT >= 28) {
            android.app.ActivityManager am = a.getSystemService(android.app.ActivityManager.class);
            restricted = am != null && am.isBackgroundRestricted();
        }
        if (restricted) card.addView(statusLine(Ui.T_WARNING, "Background activity is restricted, so alerts may stop."));
        else if (pm != null && !pm.isIgnoringBatteryOptimizations(a.getPackageName())) {
            card.addView(statusLine(Ui.T_NEUTRAL, "Battery optimisation is on. If alerts stop, set SafeSphere to Unrestricted."));
        }
        if (on) {
            android.content.SharedPreferences d = ScamMessageWatcher.diag(a);
            long seenAt = d.getLong("lastSeenAt", 0);
            if (seenAt == 0) {
                card.addView(statusLine(Ui.T_NEUTRAL, "No message notification seen yet"));
            } else {
                String app = ScamMessageWatcher.appLabel(a, d.getString("lastSeenPkg", ""));
                boolean hadText = d.getBoolean("lastHadText", true);
                card.addView(statusLine(hadText ? Ui.T_SUCCESS : Ui.T_WARNING, "Last message: " + app + ", " + MainActivity.ago(seenAt)
                        + (hadText ? "" : ". Its text was hidden, so it couldn't be checked. Turn on message previews in that app.")));
            }
        }
        if (!on) {
            card.addView(Ui.primary(a, "Turn on", v -> new AlertDialog.Builder(a)
                    .setTitle("Allow notification access")
                    .setMessage("On the next screen, find SafeSphere and switch it on.\n\nIf Android says \"Restricted setting\": "
                            + "open App info, tap ⋮ at the top right, choose \"Allow restricted settings\", then try again. "
                            + "Android adds this step for apps installed outside the Play Store.")
                    .setPositiveButton("Continue", (dd, w) -> a.openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS, Settings.ACTION_SETTINGS))
                    .setNegativeButton("Cancel", null)
                    .show()), Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        } else if (blocked != null) {
            card.addView(Ui.primary(a, "Allow alert pop-ups", v -> openAlertSettings()), Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        } else {
            card.addView(Ui.secondary(a, testingAlert ? "Sending…" : "Send a test alert", v -> sendTestAlert()),
                    Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        }
        LinearLayout links = Ui.hbox(a);
        links.addView(Ui.link(a, "App info", v -> a.open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.getPackageName())))));
        if (on) {
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.leftMargin = Ui.dp(a, 16);
            links.addView(Ui.link(a, "Battery", v -> a.openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS,
                    Settings.ACTION_SETTINGS)), lp);
            LinearLayout.LayoutParams lp2 = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp2.leftMargin = Ui.dp(a, 16);
            links.addView(Ui.link(a, "Turn off", v -> a.openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS,
                    Settings.ACTION_SETTINGS)), lp2);
        }
        card.addView(links);
        return card;
    }

    private void openAlertSettings() {
        if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED && !Prefs.askedNotify(a)) {
            Prefs.setAskedNotify(a);
            a.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
            return;
        }
        a.open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName()));
    }

    private void sendTestAlert() {
        if (testingAlert) return;
        testingAlert = true;
        refreshAlertsCard();
        Context app = a.getApplicationContext();
        a.bg.execute(() -> {
            boolean raised = ScamMessageWatcher.runTest(app);
            a.runOnUiThread(() -> {
                testingAlert = false;
                refreshAlertsCard();
                a.toast(raised ? "Test alert sent. Check the top of your screen and History." : "The test message wasn't flagged.");
            });
        });
    }

    // ------------------------------------------------------------------ password leak check

    private View passwordCard() {
        LinearLayout card = Ui.card(a);
        card.addView(Ui.support(a, "Checks whether a password appears in known data breaches (Have I Been Pwned). Only the first "
                + "5 characters of the password's SHA-1 hash are sent; the password itself never leaves the phone."));
        EditText input = new EditText(a);
        input.setHint("Password to check");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Ui.field(input);
        input.setContentDescription("Password to check");
        card.addView(input, Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));
        final boolean[] visible = {false};
        TextView showBtn = Ui.secondary(a, "Show", null);
        showBtn.setOnClickListener(v -> {
            visible[0] = !visible[0];
            input.setInputType(InputType.TYPE_CLASS_TEXT | (visible[0]
                    ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            input.setSelection(input.getText().length());
            showBtn.setText(visible[0] ? "Hide" : "Show");
        });
        TextView check = Ui.primary(a, pwChecking ? "Checking…" : "Check password", v -> {
            String pw = input.getText().toString();
            if (pw.isEmpty()) {
                Ui.shake(input);
                return;
            }
            a.hideKeyboard(input);
            input.setText("");
            pwChecking = true;
            pwResult = null;
            a.show(MainActivity.TAB_CHECK);
            a.bg.execute(() -> {
                PasswordCheck.Result r = PasswordCheck.check(pw);
                a.runOnUiThread(() -> {
                    pwChecking = false;
                    pwResult = r;
                    if (a.currentPage() == MainActivity.TAB_CHECK) a.show(MainActivity.TAB_CHECK);
                });
            });
        });
        LinearLayout row = Ui.hbox(a);
        row.addView(check, Ui.params(0, Ui.WRAP, 2f));
        LinearLayout.LayoutParams lp = Ui.params(0, Ui.WRAP, 1f);
        lp.leftMargin = Ui.dp(a, 8);
        row.addView(showBtn, lp);
        card.addView(row, Ui.margins(a, Ui.MATCH, Ui.WRAP, 12));

        PasswordCheck.Result r = pwResult;
        if (r != null) {
            View b;
            if (r.error != null) b = Ui.banner(a, Ui.T_NEUTRAL, "Couldn't check", r.error);
            else if (r.breaches > 0) b = Ui.banner(a, Ui.T_DANGER, String.format(Locale.US, "Found in %,d breaches", r.breaches),
                    "Stop using this password. Change it on every account that uses it.");
            else b = Ui.banner(a, Ui.T_SUCCESS, "Not found in known breaches", "That doesn't make it strong. See below.");
            card.addView(b, Ui.margins(a, Ui.MATCH, Ui.WRAP, 16));
            LinearLayout s = Ui.hbox(a);
            s.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
            s.addView(Ui.text(a, "Strength", Ui.BODY, Ui.TEXT, true), Ui.params(0, Ui.WRAP, 1f));
            s.addView(Ui.badge(a, r.strengthTone(), r.strengthLabel()));
            card.addView(s);
            card.addView(Ui.bullets(a, r.tips));
        }
        return card;
    }
}
