package com.nekowishy.safesphere;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** SafeSphere AI: a chat assistant for scams and online safety, with the animated AI orb. */
public class AiChatActivity extends Activity {

    // Dark "AI mode" palette (deep navy, not black)
    static final int BG_TOP = 0xFF070C24, BG_BOTTOM = 0xFF0C1538, INK = 0xFFF3F6FF, SOFT = 0xFF9AA6D6,
            GLASS = 0x17FFFFFF, GLASS_LINE = 0x26FFFFFF, OK = 0xFF3EE6A0, WARN = 0xFFFFB547, BAD = 0xFFFF5C7A;

    /** One line in the chat. */
    private static final class Msg {
        final boolean user;
        final String text;
        final String local;   // SafeSphere's own link check, shown under the user's message
        final int localLevel;
        final boolean error;
        Msg(boolean user, String text, String local, int localLevel, boolean error) {
            this.user = user; this.text = text; this.local = local; this.localLevel = localLevel; this.error = error;
        }
    }

    /** Kept while the app is open, so leaving and coming back keeps the conversation. */
    private static final List<Msg> chat = new ArrayList<>();
    private static boolean busy;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private FrameLayout body;
    private LinearLayout list;
    private ScrollView scroll;
    private OrbView bigOrb;
    private EditText input;
    private FrameLayout sendBtn;
    private LinearLayout chipsBox;
    private View thinkingRow;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG_TOP);
        getWindow().setNavigationBarColor(BG_BOTTOM);
        getWindow().getDecorView().setSystemUiVisibility(0); // light icons on the dark bars

        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Backdrop());
        LinearLayout col = Ui.vbox(this);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // Top bar: back · "SafeSphere AI" pill · new chat
        LinearLayout top = Ui.hbox(this);
        int p = Ui.dp(this, 16);
        top.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 6));
        top.setGravity(Gravity.CENTER_VERTICAL);
        int cb = Ui.dp(this, 46);
        top.addView(glassCircle(NavIcon.BACK, v -> finish()), new LinearLayout.LayoutParams(cb, cb));
        FrameLayout mid = new FrameLayout(this);
        mid.addView(titlePill(), new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        top.addView(mid, Ui.params(0, Ui.WRAP, 1f));
        top.addView(glassCircle(NavIcon.REFRESH, v -> newChat()), new LinearLayout.LayoutParams(cb, cb));
        col.addView(top);

        body = new FrameLayout(this);
        col.addView(body, Ui.params(Ui.MATCH, 0, 1f));

        chipsBox = Ui.vbox(this);
        chipsBox.addView(chipRow(new Object[][]{
                {NavIcon.SEARCH, "Check a message", "MSG"},
                {NavIcon.LINK, "Is this link safe?", "LINK"},
                {NavIcon.WALLET, "GCash & Maya safety", "How do I keep my GCash and Maya accounts safe from scammers?"},
                {NavIcon.ALERT, "I clicked a bad link", "I clicked a suspicious link. What should I do now?"}}));
        chipsBox.addView(chipRow(new Object[][]{
                {NavIcon.LOCK, "I shared my OTP", "I accidentally shared my OTP with someone. What should I do right away?"},
                {NavIcon.WORK, "Job & task scams", "How do I spot online job or \"task\" scams?"},
                {NavIcon.KEY, "Strong password tips", "How do I make a strong password that I can still remember?"},
                {NavIcon.FLAG, "Report a scam", "How and where do I report a scam in the Philippines?"}}));
        col.addView(chipsBox);

        col.addView(inputBar());
        setContentView(root);
        render();
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ screens

    private void render() {
        body.removeAllViews();
        thinkingRow = null;
        boolean empty = chat.isEmpty();
        chipsBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        if (empty) {
            LinearLayout hello = Ui.vbox(this);
            hello.setGravity(Gravity.CENTER);
            bigOrb = new OrbView(this, true, 30);
            int os = Ui.dp(this, 250);
            hello.addView(bigOrb, new LinearLayout.LayoutParams(os, os));
            TextView hi = Ui.text(this, "Hi, I'm SafeSphere AI!", 15, SOFT, false);
            hi.setGravity(Gravity.CENTER);
            hello.addView(hi);
            TextView ask = Ui.text(this, "How can I keep you\nsafe today?", 28, INK, true);
            ask.setGravity(Gravity.CENTER);
            ask.setLineSpacing(0, 1.08f);
            ask.setPadding(0, Ui.dp(this, 8), 0, 0);
            hello.addView(ask);
            TextView sub = Ui.text(this, "Paste a text, link or story. I'll tell you if it's a scam and what to do.",
                    12, SOFT, false);
            sub.setGravity(Gravity.CENTER);
            sub.setPadding(Ui.dp(this, 36), Ui.dp(this, 10), Ui.dp(this, 36), 0);
            hello.addView(sub);
            body.addView(hello, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
            for (int i = 0; i < hello.getChildCount(); i++) Ui.enter(hello.getChildAt(i), i);
            bigOrb.setThinking(busy);
            return;
        }
        bigOrb = null;
        scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipToPadding(false);
        list = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        list.setPadding(p, Ui.dp(this, 6), p, Ui.dp(this, 16));

        // Small live orb at the top of the conversation
        OrbView mini = new OrbView(this, true, 14);
        mini.setThinking(busy);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(Ui.dp(this, 92), Ui.dp(this, 92));
        mlp.gravity = Gravity.CENTER_HORIZONTAL;
        list.addView(mini, mlp);
        TextView cap = Ui.text(this, "Answers come from AI and can be wrong. Never share OTPs or passwords.", 11, SOFT, false);
        cap.setGravity(Gravity.CENTER);
        cap.setPadding(0, 0, 0, Ui.dp(this, 10));
        list.addView(cap);

        for (int i = 0; i < chat.size(); i++) {
            View b = bubble(chat.get(i));
            list.addView(b);
            if (i == chat.size() - 1) Ui.enter(b, 0); // only the newest message slides in
        }
        if (busy) addThinking();
        scroll.addView(list);
        body.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        scrollToEnd();
    }

    private void newChat() {
        if (busy) return;
        chat.clear();
        render();
    }

    // ------------------------------------------------------------------ sending

    private void send(String text) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty() || busy) {
            if (t.isEmpty()) Ui.shake(input);
            return;
        }
        AiSetup.ensureReady(this, () -> doSend(t));
    }

    private void doSend(String text) {
        // SafeSphere checks any links on the phone first and passes that to the AI
        StringBuilder local = new StringBuilder();
        int worst = -1;
        String worstLine = null;
        List<String> links = ScamDetector.extractLinks(text);
        if (!links.isEmpty()) {
            RuleStore.init(this);
            for (String l : links) {
                ScamDetector.LinkResult r = ScamDetector.analyze(l);
                local.append("Link ").append(r.host).append(": ").append(ScamDetector.label(r.level));
                if (!r.reasons.isEmpty()) local.append(" (").append(r.reasons.get(0)).append(")");
                local.append("\n");
                if (r.level > worst) {
                    worst = r.level;
                    worstLine = ScamDetector.label(r.level) + " · " + r.host;
                }
            }
        }
        input.setText("");
        hideKeyboard();
        chat.add(new Msg(true, text, worstLine, worst, false));
        busy = true;
        render();

        List<AiClient.Turn> turns = new ArrayList<>();
        for (Msg m : chat) if (!m.error) turns.add(new AiClient.Turn(m.user ? "user" : "assistant", m.text));
        Context app = getApplicationContext();
        String findings = local.toString();
        bg.execute(() -> {
            if (!links.isEmpty()) ThreatDb.ensureLoaded(app);
            AiClient.ChatResult r = AiClient.chat(app, turns, findings);
            handler.post(() -> {
                busy = false;
                chat.add(r.error != null ? new Msg(false, r.error, null, -1, true) : new Msg(false, r.reply, null, -1, false));
                if (!isFinishing()) render();
            });
        });
    }

    private void retryLast() {
        if (busy) return;
        // drop the error and resend the last question
        if (!chat.isEmpty() && chat.get(chat.size() - 1).error) chat.remove(chat.size() - 1);
        if (chat.isEmpty() || !chat.get(chat.size() - 1).user) return;
        Msg last = chat.remove(chat.size() - 1);
        doSend(last.text);
    }

    // ------------------------------------------------------------------ chat bubbles

    private View bubble(Msg m) {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        int maxW = (int) (getResources().getDisplayMetrics().widthPixels * 0.78f);
        if (m.user) {
            row.setGravity(Gravity.END);
            LinearLayout stack = Ui.vbox(this);
            stack.setGravity(Gravity.END);
            TextView t = Ui.text(this, m.text, 14, 0xFFFFFFFF, false);
            t.setMaxWidth(maxW);
            t.setLineSpacing(0, 1.12f);
            int px = Ui.dp(this, 14), py = Ui.dp(this, 10);
            t.setPadding(px, py, px, py);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{0xFF2F6BFF, 0xFF6A5CFF});
            float r = Ui.dp(this, 20), s = Ui.dp(this, 6);
            g.setCornerRadii(new float[]{r, r, r, r, s, s, r, r});
            t.setBackground(g);
            Ui.shadow(t, 8, 0xFF2F6BFF);
            copyOnLongPress(t, m.text);
            stack.addView(t);
            if (m.local != null) {
                TextView lc = Ui.text(this, "SafeSphere check: " + m.local, 11, levelColor(m.localLevel), true);
                lc.setPadding(0, Ui.dp(this, 6), Ui.dp(this, 4), 0);
                stack.addView(lc);
            }
            row.addView(stack);
            return row;
        }
        int bs = Ui.dp(this, 30);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(bs, bs);
        blp.rightMargin = Ui.dp(this, 8);
        blp.topMargin = Ui.dp(this, 2);
        row.addView(new OrbView.Badge(this), blp);
        LinearLayout card = Ui.vbox(this);
        int px = Ui.dp(this, 14), py = Ui.dp(this, 12);
        card.setPadding(px, py, px, py);
        GradientDrawable g = new GradientDrawable();
        float r = Ui.dp(this, 20), s = Ui.dp(this, 6);
        g.setCornerRadii(new float[]{s, s, r, r, r, r, r, r});
        g.setColor(m.error ? 0x22FF5C7A : GLASS);
        g.setStroke(Ui.dp(this, 1), m.error ? 0x55FF5C7A : GLASS_LINE);
        card.setBackground(g);

        String text = m.text;
        if (!m.error) {
            // "Verdict: SCAM" on the first line becomes a coloured badge
            String first = text.split("\n", 2)[0].trim();
            String low = first.toLowerCase(Locale.ROOT);
            if (low.startsWith("verdict:")) {
                String v = first.substring(8).trim().toUpperCase(Locale.ROOT);
                int col = v.contains("SCAM") ? BAD : v.contains("SAFE") ? OK : WARN;
                TextView badge = Ui.text(this, v.replace("_", " "), 12, col, true);
                badge.setLetterSpacing(0.12f);
                int bx = Ui.dp(this, 10), by = Ui.dp(this, 4);
                badge.setPadding(bx, by, bx, by);
                GradientDrawable bgd = new GradientDrawable();
                bgd.setCornerRadius(Ui.dp(this, 20));
                bgd.setColor(Ui.alpha(col, 40));
                bgd.setStroke(Ui.dp(this, 1), Ui.alpha(col, 140));
                badge.setBackground(bgd);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.bottomMargin = Ui.dp(this, 8);
                card.addView(badge, lp);
                text = text.contains("\n") ? text.substring(text.indexOf('\n') + 1).trim() : "";
            }
        }
        if (!text.isEmpty()) {
            TextView t = Ui.text(this, text, 14, m.error ? 0xFFFFC2CC : INK, false);
            t.setLineSpacing(0, 1.18f);
            card.addView(t);
            copyOnLongPress(card, m.text);
        }
        if (m.error) {
            TextView again = Ui.text(this, "TRY AGAIN", 12, 0xFFFFFFFF, true);
            again.setLetterSpacing(0.12f);
            again.setPadding(0, Ui.dp(this, 10), 0, 0);
            again.setOnClickListener(v -> { Ui.tap(v); retryLast(); });
            card.addView(again);
            TextView setup = Ui.text(this, "AI SETUP", 12, SOFT, true);
            setup.setLetterSpacing(0.12f);
            setup.setPadding(0, Ui.dp(this, 8), 0, 0);
            setup.setOnClickListener(v -> { Ui.tap(v); AiSetup.setupDialog(this, null); });
            card.addView(setup);
        }
        // keep long answers from running under the edge
        for (int i = 0; i < card.getChildCount(); i++) {
            View c = card.getChildAt(i);
            if (c instanceof TextView) ((TextView) c).setMaxWidth(maxW - Ui.dp(this, 40));
        }
        row.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return row;
    }

    private void addThinking() {
        LinearLayout row = Ui.hbox(this);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        int bs = Ui.dp(this, 30);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(bs, bs);
        blp.rightMargin = Ui.dp(this, 8);
        row.addView(new OrbView.Badge(this), blp);
        TextView dots = Ui.text(this, "Thinking", 14, SOFT, false);
        int px = Ui.dp(this, 14), py = Ui.dp(this, 10);
        dots.setPadding(px, py, px, py);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(Ui.dp(this, 20));
        g.setColor(GLASS);
        g.setStroke(Ui.dp(this, 1), GLASS_LINE);
        dots.setBackground(g);
        row.addView(dots);
        list.addView(row);
        thinkingRow = row;
        final int[] n = {0};
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (thinkingRow != row || !busy) return;
                n[0] = (n[0] + 1) % 4;
                dots.setText("Thinking" + "...".substring(0, n[0]));
                handler.postDelayed(this, 380);
            }
        });
    }

    private void copyOnLongPress(View v, String text) {
        v.setOnLongClickListener(x -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("SafeSphere AI", text));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private static int levelColor(int level) {
        if (level >= ScamDetector.DANGEROUS) return BAD;
        if (level >= ScamDetector.CAUTION) return WARN;
        return OK;
    }

    private void scrollToEnd() {
        if (scroll == null) return;
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    // ------------------------------------------------------------------ chips and input

    private View chipRow(Object[][] items) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setClipToPadding(false);
        LinearLayout row = Ui.hbox(this);
        int p = Ui.dp(this, 16);
        row.setPadding(p, Ui.dp(this, 4), p, Ui.dp(this, 4));
        for (Object[] it : items) {
            LinearLayout chip = Ui.hbox(this);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            int cx = Ui.dp(this, 14), cy = Ui.dp(this, 9);
            chip.setPadding(cx, cy, cx + Ui.dp(this, 2), cy);
            chip.setBackground(glass(Ui.dp(this, 22)));
            int is = Ui.dp(this, 16);
            chip.addView(new NavIcon(this, (Integer) it[0], INK), new LinearLayout.LayoutParams(is, is));
            TextView t = Ui.text(this, (String) it[1], 13, INK, false);
            t.setPadding(Ui.dp(this, 8), 0, 0, 0);
            chip.addView(t);
            String action = (String) it[2];
            chip.setOnClickListener(v -> { Ui.tap(v); chipTapped(action); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(this, 8);
            row.addView(chip, lp);
        }
        hs.addView(row);
        return hs;
    }

    private void chipTapped(String action) {
        if ("MSG".equals(action) || "LINK".equals(action)) {
            String clip = clipboardText();
            if (clip != null) {
                send(("MSG".equals(action) ? "Is this message a scam?\n\n" : "Is this link safe?\n\n") + clip);
            } else {
                input.setText("MSG".equals(action) ? "Is this message a scam? " : "Is this link safe? ");
                input.setSelection(input.getText().length());
                input.requestFocus();
                showKeyboard();
                Toast.makeText(this, "Paste the message or link after the question", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        send(action);
    }

    private View inputBar() {
        LinearLayout bar = Ui.hbox(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 14);
        bar.setPadding(p, Ui.dp(this, 10), p, Ui.dp(this, 14));

        int cs = Ui.dp(this, 48);
        bar.addView(glassCircle(NavIcon.PLUS, v -> {
            String clip = clipboardText();
            if (clip == null) {
                Toast.makeText(this, "Copy a message or link first, then tap + to paste it", Toast.LENGTH_SHORT).show();
                return;
            }
            Editable e = input.getText();
            e.insert(input.getSelectionStart() < 0 ? e.length() : input.getSelectionStart(), clip);
        }), new LinearLayout.LayoutParams(cs, cs));

        input = new EditText(this);
        input.setHint("Message SafeSphere AI…");
        input.setHintTextColor(0xFF7F8BBE);
        input.setTextColor(INK);
        input.setTextSize(15);
        input.setMaxLines(5);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        int ix = Ui.dp(this, 18), iy = Ui.dp(this, 12);
        input.setPadding(ix, iy, ix, iy);
        input.setBackground(glass(Ui.dp(this, 26)));
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                if (sendBtn != null) sendBtn.setAlpha(s.toString().trim().isEmpty() ? 0.55f : 1f);
            }
        });
        LinearLayout.LayoutParams ilp = Ui.params(0, Ui.WRAP, 1f);
        ilp.leftMargin = Ui.dp(this, 10);
        ilp.rightMargin = Ui.dp(this, 10);
        bar.addView(input, ilp);

        sendBtn = new FrameLayout(this);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{OrbView.CYAN, OrbView.BLUE, OrbView.VIOLET, OrbView.PINK});
        sg.setShape(GradientDrawable.OVAL);
        sendBtn.setBackground(sg);
        Ui.shadow(sendBtn, 12, OrbView.VIOLET);
        int is = Ui.dp(this, 22);
        sendBtn.addView(new NavIcon(this, NavIcon.SEND, 0xFFFFFFFF), new FrameLayout.LayoutParams(is, is, Gravity.CENTER));
        sendBtn.setAlpha(0.55f);
        sendBtn.setOnClickListener(v -> { Ui.tap(v); send(input.getText().toString()); });
        int ss = Ui.dp(this, 54);
        bar.addView(sendBtn, new LinearLayout.LayoutParams(ss, ss));
        return bar;
    }

    private View titlePill() {
        LinearLayout pill = Ui.hbox(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        int px = Ui.dp(this, 8), py = Ui.dp(this, 6);
        pill.setPadding(px, py, Ui.dp(this, 16), py);
        pill.setBackground(glass(Ui.dp(this, 24)));
        int bs = Ui.dp(this, 30);
        pill.addView(new OrbView.Badge(this), new LinearLayout.LayoutParams(bs, bs));
        LinearLayout txt = Ui.vbox(this);
        txt.setPadding(Ui.dp(this, 8), 0, 0, 0);
        txt.addView(Ui.text(this, "SafeSphere AI", 14, INK, true));
        txt.addView(Ui.text(this, "Scam & safety assistant", 10, SOFT, false));
        pill.addView(txt);
        return pill;
    }

    private FrameLayout glassCircle(int icon, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x24FFFFFF, 0x0DFFFFFF});
        g.setShape(GradientDrawable.OVAL);
        g.setStroke(Ui.dp(this, 1), GLASS_LINE);
        f.setBackground(g);
        int is = Ui.dp(this, 20);
        f.addView(new NavIcon(this, icon, INK), new FrameLayout.LayoutParams(is, is, Gravity.CENTER));
        f.setOnClickListener(v -> { Ui.tap(v); l.onClick(v); });
        return f;
    }

    private GradientDrawable glass(float radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x1FFFFFFF, 0x0FFFFFFF});
        g.setCornerRadius(radius);
        g.setStroke(Ui.dp(this, 1), GLASS_LINE);
        return g;
    }

    private String clipboardText() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = cm == null ? null : cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return null;
        CharSequence t = clip.getItemAt(0).coerceToText(this);
        return t == null || t.toString().trim().isEmpty() ? null : t.toString().trim();
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
    }

    private void showKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
    }

    /** Deep navy background with a soft blue-violet glow behind the orb and a faint glow at the bottom. */
    private static final class Backdrop extends Drawable {
        private final Paint base = new Paint();
        private final Paint glowTop = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glowBottom = new Paint(Paint.ANTI_ALIAS_FLAG);

        @Override
        protected void onBoundsChange(android.graphics.Rect b) {
            float w = b.width(), h = b.height();
            base.setShader(new LinearGradient(0, 0, 0, h, new int[]{BG_TOP, 0xFF0A1233, BG_BOTTOM}, null, Shader.TileMode.CLAMP));
            glowTop.setShader(new RadialGradient(w / 2f, h * 0.36f, w * 0.75f,
                    new int[]{0x402F6BFF, 0x188B5CF6, 0x00000000}, new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
            glowBottom.setShader(new RadialGradient(w / 2f, h * 1.05f, w * 0.8f,
                    new int[]{0x388B5CF6, 0x14FF4FA3, 0x00000000}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        }

        @Override
        public void draw(Canvas c) {
            android.graphics.Rect b = getBounds();
            c.drawRect(b, base);
            c.drawRect(b, glowTop);
            c.drawRect(b, glowBottom);
        }

        @Override public void setAlpha(int a) {}
        @Override public void setColorFilter(ColorFilter cf) {}
        @Override public int getOpacity() { return PixelFormat.OPAQUE; }
    }
}
