package com.nekowishy.safesphere;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SafeSphere AI: an optional chat about scams and online safety, answered by an external AI service.
 * Before each message is sent, codes, numbers, e-mail addresses and link paths are removed, and the
 * user sees what was removed. Answers are labelled as AI opinions.
 */
public class AiChatActivity extends Activity {

    private static final class Msg {
        final boolean user;
        final String text;
        final String local;     // SafeSphere's own link check, shown under the user's message
        final int localLevel;
        final String removed;   // what Redactor removed before sending
        final boolean error;
        Msg(boolean user, String text, String local, int localLevel, String removed, boolean error) {
            this.user = user; this.text = text; this.local = local; this.localLevel = localLevel;
            this.removed = removed; this.error = error;
        }
    }

    /** Kept while the app is open (memory only), so leaving and coming back keeps the conversation. */
    private static final List<Msg> chat = new ArrayList<>();
    private static boolean busy;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final java.util.concurrent.ExecutorService bg = java.util.concurrent.Executors.newSingleThreadExecutor();
    private FrameLayout body;
    private LinearLayout list;
    private ScrollView scroll;
    private EditText input;
    private TextView sendBtn;
    private View chipsBox;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF0D1333);
        getWindow().setNavigationBarColor(Ui.SURFACE);

        LinearLayout col = Ui.vbox(this);
        col.setBackground(new Bevel.Page(Ui.dp(this, 1.5f)));

        LinearLayout top = Ui.hbox(this);
        top.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        top.setMinimumHeight(Ui.dp(this, 56));
        top.addView(iconButton(NavIcon.BACK, "Back", v -> finish()), new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        OrbView mini = new OrbView(this, true, 12);
        mini.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        top.addView(mini, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
        LinearLayout titles = Ui.vbox(this);
        titles.setPadding(Ui.dp(this, 8), 0, 0, 0);
        titles.addView(Ui.display(this, "SafeSphere *AI*", 20, Ui.TEXT));
        titles.addView(Ui.text(this, "Optional · answers come from an external AI", Ui.LABEL, Ui.TEXT2, false));
        top.addView(titles, Ui.params(0, Ui.WRAP, 1f));
        top.addView(iconButton(NavIcon.REFRESH, "New conversation", v -> newChat()), new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)));
        col.addView(top);
        col.addView(Ui.divider(this));

        body = new FrameLayout(this);
        col.addView(body, Ui.params(Ui.MATCH, 0, 1f));

        chipsBox = chipRow(new String[][]{
                {"Is this message a scam?", "MSG"},
                {"Is this link safe?", "LINK"},
                {"I clicked a bad link", "I clicked a suspicious link. What should I do now?"},
                {"I shared my OTP", "I accidentally shared my OTP with someone. What should I do right away?"},
                {"Job and task scams", "How do I spot online job or \"task\" scams?"},
                {"Strong passwords", "How do I make a strong password that I can still remember?"}});
        col.addView(chipsBox);
        col.addView(Ui.divider(this));
        col.addView(inputBar());
        setContentView(col);
        render();
    }

    private FrameLayout iconButton(int icon, String desc, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        f.addView(new NavIcon(this, icon, Ui.TEXT), Ui.frame(Ui.dp(this, 24), Ui.dp(this, 24), Gravity.CENTER));
        android.graphics.drawable.GradientDrawable mask = new android.graphics.drawable.GradientDrawable();
        mask.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        mask.setColor(Ui.WHITE);
        f.setBackground(Ui.ripple(null, mask));
        f.setClickable(true);
        f.setContentDescription(desc);
        f.setOnClickListener(l);
        return f;
    }

    @Override
    protected void onDestroy() {
        bg.shutdown();
        super.onDestroy();
    }

    private void render() {
        body.removeAllViews();
        boolean empty = chat.isEmpty();
        chipsBox.setVisibility(empty ? View.VISIBLE : View.GONE);
        if (empty) {
            LinearLayout hello = Ui.vbox(this);
            hello.setGravity(Gravity.CENTER);
            int p = Ui.dp(this, 32);
            hello.setPadding(p, p, p, p);
            OrbView orb = new OrbView(this, true, 28);
            orb.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            hello.addView(orb, new LinearLayout.LayoutParams(Ui.dp(this, 150), Ui.dp(this, 150)));
            TextView ask = Ui.display(this, "Ask before you *act*.", 26, Ui.TEXT);
            ask.setGravity(Gravity.CENTER);
            ask.setPadding(0, Ui.dp(this, 16), 0, 0);
            hello.addView(ask);
            TextView sub = Ui.support(this, "Before sending, SafeSphere removes codes, card and phone numbers, e-mail addresses "
                    + "and the hidden part of links. Names can't be removed automatically, so leave them out.\n\n"
                    + "AI answers are opinions and can be wrong. For a check made on your phone, use the Check tab.");
            sub.setGravity(Gravity.CENTER);
            sub.setPadding(0, Ui.dp(this, 12), 0, 0);
            hello.addView(sub);
            body.addView(hello, Ui.frame(-1, -1, Gravity.CENTER));
            return;
        }
        scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        list = Ui.vbox(this);
        int p = Ui.dp(this, 16);
        list.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 16));
        for (Msg m : chat) list.addView(bubble(m));
        if (busy) {
            TextView t = Ui.support(this, "Waiting for the AI…");
            t.setPadding(0, Ui.dp(this, 8), 0, 0);
            list.addView(t);
        }
        scroll.addView(list);
        body.addView(scroll, Ui.frame(-1, -1, Gravity.TOP));
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void newChat() {
        if (busy) return;
        chat.clear();
        render();
    }

    private void send(String text) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty() || busy) {
            if (t.isEmpty()) Ui.shake(input);
            return;
        }
        AiSetup.ensureReady(this, () -> doSend(t));
    }

    private void doSend(String original) {
        Redactor.Result red = Redactor.redact(original);
        String text = red.text;
        // SafeSphere checks any links on the phone first and passes that to the AI
        StringBuilder local = new StringBuilder();
        int worst = -1;
        String worstLine = null;
        List<String> links = ScamDetector.extractLinks(original);
        if (!links.isEmpty()) {
            RuleStore.init(this);
            ThreatDb.ensureLoaded(this);
            for (String l : links) {
                ScamDetector.LinkResult r = ScamDetector.analyze(l);
                local.append("Link ").append(r.host).append(": ").append(ScamDetector.label(r.level));
                if (!r.reasons.isEmpty()) local.append(" (").append(r.reasons.get(0)).append(")");
                local.append("\n");
                if (r.level > worst) {
                    worst = r.level;
                    worstLine = ScamDetector.label(r.level) + " · " + r.host;
                }
            }
        }
        String removed = red.total() == 0 ? null : "Removed before sending: " + red.total() + " item"
                + (red.total() == 1 ? "" : "s") + " (codes, numbers, e-mails or link paths)";
        input.setText("");
        hideKeyboard();
        chat.add(new Msg(true, text, worstLine, worst, removed, false));
        busy = true;
        render();

        List<AiClient.Turn> turns = new ArrayList<>();
        for (Msg m : chat) if (!m.error) turns.add(new AiClient.Turn(m.user ? "user" : "assistant", m.text));
        Context app = getApplicationContext();
        String findings = local.toString();
        bg.execute(() -> {
            AiClient.ChatResult r = AiClient.chat(app, turns, findings);
            handler.post(() -> {
                busy = false;
                chat.add(r.error != null ? new Msg(false, r.error, null, -1, null, true) : new Msg(false, r.reply, null, -1, null, false));
                if (!isFinishing()) render();
            });
        });
    }

    private void retryLast() {
        if (busy) return;
        if (!chat.isEmpty() && chat.get(chat.size() - 1).error) chat.remove(chat.size() - 1);
        if (chat.isEmpty() || !chat.get(chat.size() - 1).user) return;
        Msg last = chat.remove(chat.size() - 1);
        doSend(last.text);
    }

    private View bubble(Msg m) {
        LinearLayout row = Ui.vbox(this);
        row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        int maxW = (int) (getResources().getDisplayMetrics().widthPixels * 0.82f);
        if (m.user) {
            row.setGravity(Gravity.END);
            TextView t = Ui.body(this, m.text);
            t.setTextColor(Ui.WHITE);
            t.setMaxWidth(maxW);
            int px = Ui.dp(this, 14), py = Ui.dp(this, 10);
            t.setPadding(px, py, px, py);
            t.setBackground(Bevel.blue(Ui.dp(this, 18), Ui.dp(this, 1)));
            copyOnLongPress(t, m.text);
            row.addView(t, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
            if (m.removed != null) {
                TextView r = Ui.text(this, m.removed, Ui.LABEL, Ui.TEXT2, false);
                r.setPadding(0, Ui.dp(this, 4), 0, 0);
                row.addView(r);
            }
            if (m.local != null) {
                TextView lc = Ui.badge(this, ScamDetector.tone(m.localLevel), "SafeSphere check: " + m.local);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
                lp.topMargin = Ui.dp(this, 4);
                row.addView(lc, lp);
            }
            return row;
        }
        LinearLayout card = Ui.vbox(this);
        int px = Ui.dp(this, 14), py = Ui.dp(this, 12);
        card.setPadding(px, py, px, py);
        card.setBackground(Bevel.raised(Ui.dp(this, 18), Ui.dp(this, 1.2f)));
        TextView who = Ui.text(this, m.error ? "Couldn't get an answer" : "AI opinion", Ui.LABEL, m.error ? Ui.WARNING : Ui.TEXT2, true);
        card.addView(who);
        String text = m.text;
        if (!m.error) {
            String first = text.split("\n", 2)[0].trim();
            if (first.toLowerCase(Locale.ROOT).startsWith("verdict:")) {
                String v = first.substring(8).trim().toUpperCase(Locale.ROOT);
                int tone = v.contains("SCAM") ? Ui.T_DANGER : v.contains("SAFE") ? Ui.T_SUCCESS : Ui.T_WARNING;
                String label = v.contains("SCAM") ? "AI thinks: likely a scam" : v.contains("SAFE") ? "AI thinks: likely safe" : "AI thinks: suspicious";
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP);
                lp.topMargin = Ui.dp(this, 6);
                card.addView(Ui.badge(this, tone, label), lp);
                text = text.contains("\n") ? text.substring(text.indexOf('\n') + 1).trim() : "";
            }
        }
        if (!text.isEmpty()) {
            TextView t = Ui.body(this, text);
            t.setPadding(0, Ui.dp(this, 6), 0, 0);
            t.setMaxWidth(maxW);
            card.addView(t);
            copyOnLongPress(card, m.text);
        }
        if (m.error) {
            LinearLayout actions = Ui.hbox(this);
            actions.addView(Ui.link(this, "Try again", v -> retryLast()));
            LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
            lp.leftMargin = Ui.dp(this, 16);
            actions.addView(Ui.link(this, "AI setup", v -> AiSetup.setupDialog(this, null)), lp);
            card.addView(actions);
        }
        row.addView(card, new LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP));
        return row;
    }

    private void copyOnLongPress(View v, String text) {
        v.setOnLongClickListener(x -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("SafeSphere AI", text));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            return true;
        });
    }

    private View chipRow(String[][] items) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.hbox(this);
        int p = Ui.dp(this, 16);
        row.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 8));
        for (String[] it : items) {
            TextView chip = Ui.text(this, it[0], Ui.SUPPORT, Ui.TEXT, true);
            chip.setGravity(Gravity.CENTER);
            chip.setMinHeight(Ui.dp(this, 40));
            chip.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
            chip.setBackground(Ui.ripple(Bevel.raised(Ui.dp(this, 20), Ui.dp(this, 1)), null));
            chip.setClickable(true);
            String action = it[1];
            chip.setOnClickListener(v -> chipTapped(action));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = Ui.dp(this, 8);
            row.addView(chip, lp);
        }
        hs.addView(row);
        return hs;
    }

    private void chipTapped(String action) {
        if ("MSG".equals(action) || "LINK".equals(action)) {
            input.setText("MSG".equals(action) ? "Is this message a scam? " : "Is this link safe? ");
            input.setSelection(input.getText().length());
            input.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
            Toast.makeText(this, "Paste the message or link after the question", Toast.LENGTH_SHORT).show();
            return;
        }
        send(action);
    }

    private View inputBar() {
        LinearLayout bar = Ui.hbox(this);
        bar.setBackgroundColor(Ui.alpha(Ui.SURFACE, 0xF2));
        int p = Ui.dp(this, 12);
        bar.setPadding(p, Ui.dp(this, 8), p, Ui.dp(this, 8));
        input = new EditText(this);
        input.setHint("Message SafeSphere AI");
        input.setMaxLines(5);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setImeOptions(EditorInfo.IME_ACTION_SEND);
        Ui.field(input);
        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable s) {
                boolean on = !s.toString().trim().isEmpty();
                if (sendBtn != null) { sendBtn.setEnabled(on); sendBtn.setAlpha(on ? 1f : 0.5f); }
            }
        });
        bar.addView(input, Ui.params(0, Ui.WRAP, 1f));
        sendBtn = Ui.primary(this, "Send", v -> send(input.getText().toString()));
        sendBtn.setEnabled(false);
        sendBtn.setAlpha(0.5f);
        LinearLayout.LayoutParams lp = Ui.params(Ui.WRAP, Ui.WRAP, 0f);
        lp.leftMargin = Ui.dp(this, 8);
        bar.addView(sendBtn, lp);
        return bar;
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
    }
}
