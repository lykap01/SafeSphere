package com.nekowishy.safesphere;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Removes secrets and identifying details from text BEFORE it may be sent to the optional AI service.
 * The user sees the redacted text and must agree before anything is sent.
 *
 * Removed: OTP-like codes, PINs, passwords written as "password: …", card/account/phone numbers,
 * e-mail addresses, and the path/query part of links (which can carry tokens or personal data).
 * Kept: the wording of the message and each link's website name, which the AI needs to judge it.
 * Names of people cannot be detected reliably and are NOT removed; the consent screen says so.
 */
final class Redactor {

    static final class Result {
        String text;
        int codes, numbers, emails, secrets, links;

        int total() { return codes + numbers + emails + secrets + links; }
    }

    private Redactor() {}

    private static final Pattern SECRET = Pattern.compile(
            "(?i)\\b(password|passwd|pass|pwd|passcode|mpin|pin|otp|code|cvv|cvc)\\b(\\s*(?:is|:|=|-)\\s*)(\\S+)");
    private static final Pattern EMAIL = Pattern.compile("[\\p{L}0-9._%+-]+@[\\p{L}0-9.-]+\\.[\\p{L}]{2,}");
    private static final Pattern URL = Pattern.compile("(?i)\\b((?:https?://)?(?:[\\p{L}0-9-]+\\.)+[\\p{L}]{2,}(?::\\d+)?)([/?#][^\\s]*)");
    /** Phone numbers: +63 917 123 4567, 0917-123-4567, (02) 8123 4567, +1 415 555 0100 */
    private static final Pattern PHONE = Pattern.compile("(?<![\\w])(\\+?\\d[\\d ()-]{8,}\\d)(?![\\w])");
    /** Long digit runs: card and account numbers (with optional spaces or dashes). */
    private static final Pattern LONG_NUMBER = Pattern.compile("(?<![\\w])\\d(?:[ -]?\\d){8,}(?![\\w])");
    /** Short standalone codes (OTP / PIN): 4 to 8 digits. */
    private static final Pattern CODE = Pattern.compile("(?<![\\w.,₱$])\\d{4,8}(?![\\w.,])");

    static Result redact(String input) {
        Result r = new Result();
        String s = input == null ? "" : input;

        Matcher m = SECRET.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String value = m.group(3);
            // Keep "pin is required" style sentences readable: only redact values that look like secrets
            boolean looksSecret = value.matches(".*\\d.*") || value.length() >= 6;
            if (looksSecret) {
                r.secrets++;
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + m.group(2) + "[REMOVED]"));
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
            }
        }
        m.appendTail(sb);
        s = sb.toString();

        m = EMAIL.matcher(s);
        sb = new StringBuffer();
        while (m.find()) { r.emails++; m.appendReplacement(sb, "[EMAIL]"); }
        m.appendTail(sb);
        s = sb.toString();

        m = URL.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            if (m.group(2).length() > 1) {
                r.links++;
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + "/[path removed]"));
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
            }
        }
        m.appendTail(sb);
        s = sb.toString();

        m = LONG_NUMBER.matcher(s);
        sb = new StringBuffer();
        while (m.find()) { r.numbers++; m.appendReplacement(sb, "[NUMBER]"); }
        m.appendTail(sb);
        s = sb.toString();

        m = PHONE.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            String digits = m.group(1).replaceAll("\\D", "");
            if (digits.length() >= 9) { r.numbers++; m.appendReplacement(sb, "[NUMBER]"); }
            else m.appendReplacement(sb, Matcher.quoteReplacement(m.group(0)));
        }
        m.appendTail(sb);
        s = sb.toString();

        m = CODE.matcher(s);
        sb = new StringBuffer();
        while (m.find()) { r.codes++; m.appendReplacement(sb, "[CODE]"); }
        m.appendTail(sb);
        s = sb.toString();

        r.text = s;
        return r;
    }
}
