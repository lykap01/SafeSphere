package com.nekowishy.safesphere;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Talks to the SafeSphere AI server (a small Cloudflare Worker that holds the real AI provider key).
 *
 * Privacy and security notes (Build 16):
 *  - Nothing is sent without the user's consent; the Check tab shows the exact text first.
 *  - All user text passes through Redactor here as well (codes, numbers, e-mails, link paths removed).
 *  - The "app token" only identifies the app to the Worker. Anything compiled into an APK can be
 *    extracted, so it is NOT a secret: the Worker must enforce its own rate limits, and the token
 *    should be rotated if abused. The AI provider key itself is never in the app.
 *  - A client-side limit (6 requests per minute) avoids accidental floods.
 *  - The AI's answer is shown as an opinion. It never blocks a site or changes SafeSphere's verdict.
 */
final class AiClient {

    static final class Result {
        String verdict;      // SCAM, SUSPICIOUS, LIKELY_SAFE
        String confidence;   // high, medium, low
        String summary;
        final List<String> reasons = new ArrayList<>();
        final List<String> advice = new ArrayList<>();
        String error;

        String label() {
            if ("SCAM".equals(verdict)) return "AI thinks: likely a scam";
            if ("LIKELY_SAFE".equals(verdict)) return "AI thinks: likely safe";
            return "AI thinks: suspicious";
        }

        int tone() {
            if ("SCAM".equals(verdict)) return Ui.T_DANGER;
            if ("LIKELY_SAFE".equals(verdict)) return Ui.T_SUCCESS;
            return Ui.T_WARNING;
        }
    }

    private AiClient() {}

    private static final java.util.ArrayDeque<Long> recent = new java.util.ArrayDeque<>();
    private static final int MAX_PER_MINUTE = 6;

    /** Returns an error message when the client-side limit is reached, otherwise records the request. */
    private static synchronized String rateLimit() {
        long now = System.currentTimeMillis();
        while (!recent.isEmpty() && now - recent.peekFirst() > 60_000) recent.pollFirst();
        if (recent.size() >= MAX_PER_MINUTE) return "Too many AI requests in a minute. Please wait a moment and try again.";
        recent.addLast(now);
        return null;
    }

    static String url(Context c) {
        String u = Prefs.aiUrl(c);
        return u.isEmpty() ? BuildConfig.AI_URL : u;
    }

    static String token(Context c) {
        String t = Prefs.aiToken(c);
        return t.isEmpty() ? BuildConfig.AI_TOKEN : t;
    }

    static boolean isSetUp(Context c) {
        return url(c).startsWith("https://") && !token(c).isEmpty();
    }

    /** One chat turn: role is "user" or "assistant". */
    static final class Turn {
        final String role, text;
        Turn(String role, String text) { this.role = role; this.text = text; }
    }

    static final class ChatResult {
        String reply;
        String error;
    }

    /** Sends the message (and SafeSphere's own findings) to the AI server. Call from a background thread. */
    static Result explain(Context c, String text, String localFindings) {
        Result r = new Result();
        String limited = rateLimit();
        if (limited != null) {
            r.error = limited;
            return r;
        }
        text = Redactor.redact(text).text; // defence in depth: the caller already redacted and showed it
        try {
            JSONObject body = new JSONObject();
            body.put("text", text.length() > 2000 ? text.substring(0, 2000) : text);
            body.put("local", localFindings);
            JSONObject o = post(c, body);
            if (o.has("error")) {
                r.error = o.optString("error");
                return r;
            }
            r.verdict = o.optString("verdict", "SUSPICIOUS");
            r.confidence = o.optString("confidence", "low");
            r.summary = o.optString("summary", "");
            JSONArray reasons = o.optJSONArray("reasons");
            if (reasons != null) for (int i = 0; i < reasons.length(); i++) r.reasons.add(reasons.optString(i));
            JSONArray advice = o.optJSONArray("advice");
            if (advice != null) for (int i = 0; i < advice.length(); i++) r.advice.add(advice.optString(i));
        } catch (Exception e) {
            r.error = "Couldn't reach the AI server. Check your internet connection and try again.";
        }
        return r;
    }

    /** Chat with SafeSphere AI. Sends the last 12 turns. Call from a background thread. */
    static ChatResult chat(Context c, List<Turn> turns, String localFindings) {
        ChatResult r = new ChatResult();
        String limited = rateLimit();
        if (limited != null) {
            r.error = limited;
            return r;
        }
        try {
            JSONArray msgs = new JSONArray();
            int from = Math.max(0, turns.size() - 12);
            for (int i = from; i < turns.size(); i++) {
                Turn t = turns.get(i);
                JSONObject m = new JSONObject();
                m.put("role", t.role);
                String clean = "user".equals(t.role) ? Redactor.redact(t.text).text : t.text;
                m.put("text", clean.length() > 2000 ? clean.substring(0, 2000) : clean);
                msgs.put(m);
            }
            JSONObject body = new JSONObject();
            body.put("mode", "chat");
            body.put("messages", msgs);
            if (localFindings != null && !localFindings.isEmpty()) body.put("local", localFindings);
            JSONObject o = post(c, body);
            if (o.has("error")) r.error = o.optString("error");
            else r.reply = o.optString("reply", "").trim();
            if (r.error == null && r.reply.isEmpty()) r.error = "The AI gave an empty answer. Please ask again.";
        } catch (Exception e) {
            r.error = "Couldn't reach the AI server. Check your internet connection and try again.";
        }
        return r;
    }

    /** POSTs JSON to the AI server; on HTTP errors returns {"error": "..."} with the server's own explanation. */
    private static JSONObject post(Context c, JSONObject body) throws Exception {
        HttpURLConnection con = null;
        try {
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            con = (HttpURLConnection) new URL(url(c)).openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(45000);
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("X-SafeSphere-Token", token(c));
            con.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream o = con.getOutputStream()) { o.write(bytes); }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (in != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line).append('\n');
                }
            }
            JSONObject o;
            try {
                o = new JSONObject(sb.length() == 0 ? "{}" : sb.toString());
            } catch (Exception notJson) {
                o = new JSONObject();
            }
            if (code >= 400 && !o.has("error")) {
                o.put("error", code == 401 ? "The AI server rejected the app token. Check AI setup."
                        : code == 404 ? "AI server address not found. Check the Worker address in AI setup."
                        : "The AI service is not available right now (" + code + ").");
            }
            return o;
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
