package com.nekowishy.safesphere;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Talks to the SafeSphere AI server (a small Cloudflare Worker that holds the AI key). */
final class AiClient {

    static final class Result {
        String verdict;      // SCAM, SUSPICIOUS, LIKELY_SAFE
        String confidence;   // high, medium, low
        String summary;
        final List<String> reasons = new ArrayList<>();
        final List<String> advice = new ArrayList<>();
        String error;

        String label() {
            if ("SCAM".equals(verdict)) return "SCAM";
            if ("LIKELY_SAFE".equals(verdict)) return "LIKELY SAFE";
            return "SUSPICIOUS";
        }

        int color() {
            if ("SCAM".equals(verdict)) return Ui.RED;
            if ("LIKELY_SAFE".equals(verdict)) return Ui.GREEN;
            return Ui.AMBER;
        }
    }

    private AiClient() {}

    static String url(Context c) {
        String u = Prefs.aiUrl(c);
        return u.isEmpty() ? BuildConfig.AI_URL : u;
    }

    static String token(Context c) {
        String t = Prefs.aiToken(c);
        return t.isEmpty() ? BuildConfig.AI_TOKEN : t;
    }

    static boolean isSetUp(Context c) {
        return url(c).startsWith("https://") && !token(c).isEmpty();
    }

    /** Sends the message (and SafeSphere's own findings) to the AI server. Call from a background thread. */
    static Result explain(Context c, String text, String localFindings) {
        Result r = new Result();
        HttpURLConnection con = null;
        try {
            JSONObject body = new JSONObject();
            body.put("text", text.length() > 2000 ? text.substring(0, 2000) : text);
            body.put("local", localFindings);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            con = (HttpURLConnection) new URL(url(c)).openConnection();
            con.setConnectTimeout(10000);
            con.setReadTimeout(30000);
            con.setDoOutput(true);
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("X-SafeSphere-Token", token(c));
            con.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream o = con.getOutputStream()) { o.write(bytes); }
            int code = con.getResponseCode();
            InputStream in = code >= 400 ? con.getErrorStream() : con.getInputStream();
            StringBuilder sb = new StringBuilder();
            if (in != null) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
            }
            JSONObject o = new JSONObject(sb.length() == 0 ? "{}" : sb.toString());
            if (code >= 400 || o.has("error")) {
                r.error = o.optString("error", code == 401 ? "The AI server rejected the app token. Check AI setup."
                        : "The AI service is not available right now (" + code + ").");
                return r;
            }
            r.verdict = o.optString("verdict", "SUSPICIOUS");
            r.confidence = o.optString("confidence", "low");
            r.summary = o.optString("summary", "");
            JSONArray reasons = o.optJSONArray("reasons");
            if (reasons != null) for (int i = 0; i < reasons.length(); i++) r.reasons.add(reasons.optString(i));
            JSONArray advice = o.optJSONArray("advice");
            if (advice != null) for (int i = 0; i < advice.length(); i++) r.advice.add(advice.optString(i));
        } catch (Exception e) {
            r.error = "Couldn't reach the AI server. Check your internet connection and try again.";
        } finally {
            if (con != null) con.disconnect();
        }
        return r;
    }
}
