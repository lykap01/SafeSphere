package com.nekowishy.safesphere;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/** Shared AI dialogs: server setup and the one-time privacy notice. */
final class AiSetup {

    private AiSetup() {}

    static void setupDialog(Activity a, Runnable onSaved) {
        LinearLayout box = Ui.vbox(a);
        int p = Ui.dp(a, 20);
        box.setPadding(p, Ui.dp(a, 8), p, 0);
        EditText url = new EditText(a);
        url.setHint("https://safesphere-ai.yourname.workers.dev");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(Prefs.aiUrl(a));
        EditText token = new EditText(a);
        token.setHint("App token");
        token.setSingleLine(true);
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(Prefs.aiToken(a));
        box.addView(url);
        box.addView(token);
        new AlertDialog.Builder(a)
                .setTitle("AI server")
                .setMessage("Paste the Worker address and the app token from your AI setup. "
                        + "Leave both empty to use the ones built into the app.")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String u = url.getText().toString().trim();
                    while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
                    if (!u.isEmpty() && !u.startsWith("https://")) {
                        Toast.makeText(a, "The address must start with https://", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Prefs.setAi(a, u, token.getText().toString());
                    Toast.makeText(a, AiClient.isSetUp(a) ? "SafeSphere AI is ready" : "AI settings saved",
                            Toast.LENGTH_SHORT).show();
                    if (onSaved != null) onSaved.run();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Runs {@code go} once the AI is set up and the user has agreed to the privacy notice. */
    static void ensureReady(Activity a, Runnable go) {
        if (!AiClient.isSetUp(a)) {
            new AlertDialog.Builder(a)
                    .setTitle("AI isn't set up yet")
                    .setMessage("SafeSphere AI needs the AI server address. Your group adds it once, "
                            + "either in GitHub (for everyone who downloads the app) or here on this phone.")
                    .setPositiveButton("Set up", (d, w) -> setupDialog(a, () -> ensureReady(a, go)))
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        if (!Prefs.aiConsent(a)) {
            new AlertDialog.Builder(a)
                    .setTitle("Send this to AI?")
                    .setMessage("To answer, SafeSphere sends what you type to an AI service (Google Gemini or "
                            + "Anthropic Claude, depending on setup). SafeSphere does not store it.\n\n"
                            + "On Google's free Gemini plan, Google may use the text to improve its products.\n\n"
                            + "Never type passwords, OTPs, PINs or account numbers.")
                    .setPositiveButton("I agree", (d, w) -> {
                        Prefs.setAiConsent(a, true);
                        go.run();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        go.run();
    }
}
