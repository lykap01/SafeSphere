package com.nekowishy.safesphere;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

/** Shared AI dialogs: server setup and the one-time privacy notice. */
final class AiSetup {

    private AiSetup() {}

    static void setupDialog(Activity a, Runnable onSaved) {
        LinearLayout box = Ui.vbox(a);
        int p = Ui.dp(a, 20);
        box.setPadding(p, Ui.dp(a, 8), p, 0);
        EditText url = new EditText(a);
        url.setHint("https://safesphere-ai.yourname.workers.dev");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(Prefs.aiUrl(a));
        EditText token = new EditText(a);
        token.setHint("App token");
        token.setSingleLine(true);
        token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        token.setText(Prefs.aiToken(a));
        box.addView(url);
        box.addView(token);
        new AlertDialog.Builder(a)
                .setTitle("AI server")
                .setMessage("Paste the Worker address and the app token from your AI setup. "
                        + "Leave both empty to use the ones built into the app.")
                .setView(box)
                .setPositiveButton("Save", (d, w) -> {
                    String u = url.getText().toString().trim();
                    while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
                    if (!u.isEmpty() && !u.startsWith("https://")) {
                        Toast.makeText(a, "The address must start with https://", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Prefs.setAi(a, u, token.getText().toString());
                    Toast.makeText(a, AiClient.isSetUp(a) ? "SafeSphere AI is ready" : "AI settings saved",
                            Toast.LENGTH_SHORT).show();
                    if (onSaved != null) onSaved.run();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static String serverHost(Activity a) {
        try {
            return new java.net.URL(AiClient.url(a)).getHost();
        } catch (Exception e) {
            return "not set up";
        }
    }

    /**
     * Per-request consent: shows exactly what will be sent (already redacted) and what was removed.
     * Nothing is sent unless the user taps Send.
     */
    static void confirmSend(Activity a, Redactor.Result r, String extra, Runnable go) {
        String preview = r.text.length() > 700 ? r.text.substring(0, 700) + "…" : r.text;
        StringBuilder removed = new StringBuilder();
        if (r.codes > 0) removed.append(r.codes).append(r.codes == 1 ? " code, " : " codes, ");
        if (r.numbers > 0) removed.append(r.numbers).append(r.numbers == 1 ? " number, " : " numbers, ");
        if (r.emails > 0) removed.append(r.emails).append(r.emails == 1 ? " e-mail address, " : " e-mail addresses, ");
        if (r.secrets > 0) removed.append(r.secrets).append(r.secrets == 1 ? " password or PIN, " : " passwords or PINs, ");
        if (r.links > 0) removed.append(r.links).append(r.links == 1 ? " link path, " : " link paths, ");
        String rem = removed.length() == 0 ? "Nothing needed removing." : "Removed: " + removed.substring(0, removed.length() - 2) + ".";
        ensureReady(a, () -> new AlertDialog.Builder(a)
                .setTitle("Send to SafeSphere AI?")
                .setMessage("This text will be sent to " + serverHost(a) + " and an external AI service:\n\n\""
                        + preview + "\"\n\n" + rem + (extra == null ? "" : "\n" + extra)
                        + "\nCheck it doesn't contain names or details you want to keep private.")
                .setPositiveButton("Send", (d, w) -> go.run())
                .setNegativeButton("Cancel", null)
                .show());
    }

    /** Runs {@code go} once the AI is set up and the user has agreed to the privacy notice. */
    static void ensureReady(Activity a, Runnable go) {
        if (!AiClient.isSetUp(a)) {
            new AlertDialog.Builder(a)
                    .setTitle("AI isn't set up yet")
                    .setMessage("SafeSphere AI needs the AI server address. Your group adds it once, "
                            + "either in GitHub (for everyone who downloads the app) or here on this phone.")
                    .setPositiveButton("Set up", (d, w) -> setupDialog(a, () -> ensureReady(a, go)))
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        if (!Prefs.aiConsent(a)) {
            new AlertDialog.Builder(a)
                    .setTitle("About SafeSphere AI")
                    .setMessage("SafeSphere AI is optional. When you use it, the text you choose is sent to SafeSphere's AI "
                            + "server (" + serverHost(a) + ") and processed by an external AI service (Google Gemini or "
                            + "Anthropic Claude, depending on the server's setup). SafeSphere does not store it.\n\n"
                            + "Before sending, SafeSphere removes codes, card and phone numbers, e-mail addresses and the "
                            + "hidden part of links. Names can't be removed automatically.\n\n"
                            + "On Google's free Gemini plan, Google may use the text to improve its products.\n\n"
                            + "AI answers are opinions and can be wrong. They never block websites.")
                    .setPositiveButton("I understand", (d, w) -> {
                        Prefs.setAiConsent(a, true);
                        go.run();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        go.run();
    }
}
