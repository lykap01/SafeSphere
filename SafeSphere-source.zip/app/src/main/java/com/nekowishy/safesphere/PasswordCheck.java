package com.nekowishy.safesphere;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Checks a password against Have I Been Pwned's breach database using k-anonymity:
 * only the first 5 characters of the password's SHA-1 hash leave the phone, never the password.
 */
final class PasswordCheck {

    static final class Result {
        long breaches = -1;       // -1 = could not check
        String error;
        int strength;             // 0..4
        final List<String> tips = new ArrayList<>();

        String strengthLabel() {
            switch (strength) {
                case 4: return "STRONG";
                case 3: return "GOOD";
                case 2: return "FAIR";
                default: return "WEAK";
            }
        }

        int strengthColor() {
            return strength >= 4 ? Ui.GREEN : strength == 3 ? Ui.CYAN : strength == 2 ? Ui.AMBER : Ui.RED;
        }
    }

    private static final String[] COMMON = {
            "password", "123456", "qwerty", "iloveyou", "admin", "welcome", "abc123", "111111", "letmein",
            "mahalkita", "iloveu", "000000", "monkey", "dragon", "princess", "sunshine"
    };

    private PasswordCheck() {}

    static String sha1Hex(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-1").digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format(Locale.US, "%02X", b));
        return sb.toString();
    }

    /** Looks for the hash suffix in a range response. Returns the breach count, or 0 if not listed. */
    static long findCount(String suffix, BufferedReader body) throws Exception {
        String line;
        while ((line = body.readLine()) != null) {
            int colon = line.indexOf(':');
            if (colon <= 0) continue;
            if (line.substring(0, colon).trim().equalsIgnoreCase(suffix)) {
                return Long.parseLong(line.substring(colon + 1).trim()); // padded fake entries have count 0
            }
        }
        return 0;
    }

    static Result check(String password) {
        Result r = new Result();
        rateStrength(password, r);
        HttpURLConnection con = null;
        try {
            String hash = sha1Hex(password);
            String prefix = hash.substring(0, 5);
            String suffix = hash.substring(5);
            con = (HttpURLConnection) new URL("https://api.pwnedpasswords.com/range/" + prefix).openConnection();
            con.setConnectTimeout(12000);
            con.setReadTimeout(15000);
            con.setRequestProperty("User-Agent", "SafeSphere-Android-App");
            con.setRequestProperty("Add-Padding", "true");
            int code = con.getResponseCode();
            if (code != 200) throw new Exception("HTTP " + code);
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                r.breaches = findCount(suffix, in);
            }
        } catch (Exception e) {
            r.error = "Couldn't reach the breach database. Check your internet connection and try again.";
        } finally {
            if (con != null) con.disconnect();
        }
        return r;
    }

    static void rateStrength(String p, Result r) {
        boolean lower = false, upper = false, digit = false, symbol = false;
        for (int i = 0; i < p.length(); i++) {
            char c = p.charAt(i);
            if (Character.isLowerCase(c)) lower = true;
            else if (Character.isUpperCase(c)) upper = true;
            else if (Character.isDigit(c)) digit = true;
            else symbol = true;
        }
        int variety = (lower ? 1 : 0) + (upper ? 1 : 0) + (digit ? 1 : 0) + (symbol ? 1 : 0);
        int score = 0;
        if (p.length() >= 8) score++;
        if (p.length() >= 12) score++;
        if (p.length() >= 16) score++;
        if (variety >= 3) score++;
        String low = p.toLowerCase(Locale.ROOT);
        boolean common = false;
        for (String c : COMMON) if (low.contains(c)) common = true;
        if (common) score = Math.min(score, 1);
        if (p.matches("(.)\\1{3,}.*") || p.matches("\\d+")) score = Math.min(score, 1);
        r.strength = Math.max(0, Math.min(4, score));

        if (p.length() < 12) r.tips.add("Use at least 12 characters. A short sentence is easy to remember and hard to crack.");
        if (variety < 3) r.tips.add("Mix lowercase, UPPERCASE, numbers and symbols.");
        if (common) r.tips.add("Contains a very common word or pattern that hackers try first.");
        if (p.matches("\\d+")) r.tips.add("Numbers only (like a birthday) are guessed in seconds.");
        r.tips.add("Never reuse the same password for GCash, email and social media.");
    }
}
