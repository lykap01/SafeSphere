package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** The user's own blocklist and allowlist, plus the decision of whether a domain gets blocked. */
final class RuleStore {

    /** Reserved test zone (.example can never be a real website). */
    static final String TEST_ZONE = "malware-test.safesphere.example";

    static final String REASON_CUSTOM = "Your custom blocklist rule";
    static final String REASON_THREAT = "Known malware / phishing domain";
    static final String REASON_TEST = "SafeSphere live test";

    private static final Pattern DOMAIN = Pattern.compile(
            "^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$");

    private static volatile Set<String> block = Collections.emptySet();
    private static volatile Set<String> allow = Collections.emptySet();
    private static SharedPreferences prefs;

    private RuleStore() {}

    static synchronized void init(Context c) {
        if (prefs != null) return;
        prefs = c.getApplicationContext().getSharedPreferences("rules", Context.MODE_PRIVATE);
        block = new HashSet<>(prefs.getStringSet("block", new HashSet<>()));
        allow = new HashSet<>(prefs.getStringSet("allow", new HashSet<>()));
    }

    /** Cleans what the user typed (links, www, paths) into a bare domain, or null if invalid. */
    static String normalize(String raw) {
        if (raw == null) return null;
        String d = raw.trim().toLowerCase(Locale.ROOT);
        int scheme = d.indexOf("://");
        if (scheme >= 0) d = d.substring(scheme + 3);
        int cut = indexOfAny(d, "/?#");
        if (cut >= 0) d = d.substring(0, cut);
        int at = d.lastIndexOf('@');
        if (at >= 0) d = d.substring(at + 1);
        int colon = d.indexOf(':');
        if (colon >= 0) d = d.substring(0, colon);
        if (d.startsWith("*.")) d = d.substring(2);
        while (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        return DOMAIN.matcher(d).matches() ? d : null;
    }

    private static int indexOfAny(String s, String chars) {
        for (int i = 0; i < s.length(); i++) if (chars.indexOf(s.charAt(i)) >= 0) return i;
        return -1;
    }

    /** Returns why this domain should be blocked, or null to let it through. */
    static String check(String domain) {
        Set<String> a = allow, b = block;
        for (String s = domain; s != null; s = parent(s)) if (a.contains(s)) return null;
        for (String s = domain; s != null; s = parent(s)) {
            if (b.contains(s)) return REASON_CUSTOM;
            if (s.equals(TEST_ZONE)) return REASON_TEST;
            if (ThreatDb.contains(s)) return REASON_THREAT;
        }
        return null;
    }

    private static String parent(String s) {
        int i = s.indexOf('.');
        return i < 0 ? null : s.substring(i + 1);
    }

    static synchronized void addBlock(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        b.add(d);
        a.remove(d);
        save(b, a);
    }

    static synchronized void addAllow(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        a.add(d);
        b.remove(d);
        save(b, a);
    }

    static synchronized void remove(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        b.remove(d);
        a.remove(d);
        save(b, a);
    }

    private static void save(Set<String> b, Set<String> a) {
        block = b;
        allow = a;
        prefs.edit().putStringSet("block", new HashSet<>(b)).putStringSet("allow", new HashSet<>(a)).apply();
    }

    static List<String> blocked() { return sorted(block); }
    static List<String> allowed() { return sorted(allow); }
    static int count() { return block.size() + allow.size(); }

    private static List<String> sorted(Set<String> s) {
        List<String> l = new ArrayList<>(s);
        Collections.sort(l);
        return l;
    }
}
