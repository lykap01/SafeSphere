package com.nekowishy.safesphere;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** The user's own blocklist and allowlist, plus the decision of whether a domain gets blocked. */
final class RuleStore {

    /** Reserved test zone (.example can never be a real website). */
    static final String TEST_ZONE = "malware-test.safesphere.example";

    static final String REASON_CUSTOM = "Your custom blocklist rule";
    static final String REASON_THREAT = "Known malware / phishing domain";
    static final String REASON_TEST = "SafeSphere live test";
    static final String REASON_BYPASS = "Encrypted DNS bypass blocked";
    /** Heuristic fake-brand blocks start with this text, so they can be told apart from threat-list matches. */
    static final String REASON_FAKE_PREFIX = "Possible fake ";

    /**
     * Public encrypted-DNS services that apps and browsers can use to skip SafeSphere's filter.
     * Blocking their names makes those apps fall back to the phone's normal (filtered) lookups.
     * "use-application-dns.net" is Firefox's official signal to turn its own encrypted DNS off.
     */
    private static final Set<String> BYPASS = new HashSet<>(java.util.Arrays.asList(
            "dns.google", "dns.google.com", "cloudflare-dns.com", "one.one.one.one", "dns.quad9.net",
            "dns9.quad9.net", "dns10.quad9.net", "dns11.quad9.net", "doh.opendns.com", "dns.adguard.com",
            "dns.adguard-dns.com", "doh.cleanbrowsing.org", "dns.nextdns.io", "doh.dns.sb", "dns.alidns.com",
            "doh.pub", "dns.mullvad.net", "doh.mullvad.net", "freedns.controld.com", "dns.controld.com",
            "use-application-dns.net"));

    private static final Pattern DOMAIN = Pattern.compile(
            "^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$");

    private static volatile Set<String> block = Collections.emptySet();
    private static volatile Set<String> allow = Collections.emptySet();
    private static SharedPreferences prefs;

    private RuleStore() {}

    static synchronized void init(Context c) {
        loadDetectionData(c);
        if (prefs != null) return;
        prefs = c.getApplicationContext().getSharedPreferences("rules", Context.MODE_PRIVATE);
        block = new HashSet<>(prefs.getStringSet("block", new HashSet<>()));
        allow = new HashSet<>(prefs.getStringSet("allow", new HashSet<>()));
    }

    /** Loads the bundled Public Suffix List and brand catalogue once (used by the DNS filter and the Check tab). */
    static void loadDetectionData(Context c) {
        android.content.res.AssetManager am = c.getApplicationContext().getAssets();
        if (!PublicSuffix.isLoaded()) {
            try (java.io.InputStream in = am.open("public_suffix_list.dat")) {
                PublicSuffix.load(in);
                ScamDetector.clearCache();
            } catch (java.io.IOException ignored) {
                // the heuristic fallback inside PublicSuffix keeps working
            }
        }
        if (!BrandCatalog.isLoaded()) {
            try (java.io.InputStream in = am.open("brands.tsv")) {
                BrandCatalog.load(in);
                ScamDetector.clearCache();
            } catch (java.io.IOException ignored) {
                // without the catalogue, brand-impersonation checks are skipped; threat lists still work
            }
        }
    }

    /** Cleans what the user typed (links, www, paths) into a bare domain, or null if invalid. */
    static String normalize(String raw) {
        if (raw == null) return null;
        String d = raw.trim().toLowerCase(Locale.ROOT);
        int scheme = d.indexOf("://");
        if (scheme >= 0) d = d.substring(scheme + 3);
        int cut = indexOfAny(d, "/?#");
        if (cut >= 0) d = d.substring(0, cut);
        int at = d.lastIndexOf('@');
        if (at >= 0) d = d.substring(at + 1);
        int colon = d.indexOf(':');
        if (colon >= 0) d = d.substring(0, colon);
        if (d.startsWith("*.")) d = d.substring(2);
        while (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        return DOMAIN.matcher(d).matches() ? d : null;
    }

    private static int indexOfAny(String s, String chars) {
        for (int i = 0; i < s.length(); i++) if (chars.indexOf(s.charAt(i)) >= 0) return i;
        return -1;
    }

    /** Returns why this domain should be blocked, or null to let it through. */
    static String check(String domain) {
        Set<String> a = allow, b = block;
        for (String s = domain; s != null; s = parent(s)) if (a.contains(s)) return null;
        for (String s = domain; s != null; s = parent(s)) {
            if (BYPASS.contains(s)) return REASON_BYPASS;
            if (b.contains(s)) return REASON_CUSTOM;
            if (s.equals(TEST_ZONE)) return REASON_TEST;
            if (ThreatDb.contains(s)) return REASON_THREAT;
        }
        String brand = ScamDetector.fakeBrand(domain);
        if (brand != null) return REASON_FAKE_PREFIX + brand + " website";
        return null;
    }

    static boolean isAllowed(String domain) {
        Set<String> a = allow;
        for (String s = domain; s != null; s = parent(s)) if (a.contains(s)) return true;
        return false;
    }

    private static String parent(String s) {
        int i = s.indexOf('.');
        return i < 0 ? null : s.substring(i + 1);
    }

    static synchronized void addBlock(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        b.add(d);
        a.remove(d);
        save(b, a);
    }

    static synchronized void addAllow(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        a.add(d);
        b.remove(d);
        save(b, a);
    }

    static synchronized void remove(String d) {
        Set<String> b = new HashSet<>(block);
        Set<String> a = new HashSet<>(allow);
        b.remove(d);
        a.remove(d);
        save(b, a);
    }

    private static void save(Set<String> b, Set<String> a) {
        block = b;
        allow = a;
        prefs.edit().putStringSet("block", new HashSet<>(b)).putStringSet("allow", new HashSet<>(a)).apply();
    }

    static List<String> blocked() { return sorted(block); }
    static List<String> allowed() { return sorted(allow); }
    static int count() { return block.size() + allow.size(); }

    private static List<String> sorted(Set<String> s) {
        List<String> l = new ArrayList<>(s);
        Collections.sort(l);
        return l;
    }
}
