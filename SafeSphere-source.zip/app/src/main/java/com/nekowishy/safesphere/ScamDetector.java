package com.nekowishy.safesphere;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Detects scam patterns: fake brand websites (used automatically by the DNS filter),
 * suspicious links and scam-style text messages (used by the Check tab).
 */
final class ScamDetector {

    private ScamDetector() {}

    // ------------------------------------------------------------------ brands

    private static final class Brand {
        final String name;
        final String key;          // word to look for in the address
        final boolean exactToken;  // short keys must be a whole word (e.g. "bdo")
        final boolean typos;       // also catch one-letter misspellings (e.g. "gcassh")
        final String[] official;

        Brand(String name, String key, boolean exactToken, boolean typos, String... official) {
            this.name = name;
            this.key = key;
            this.exactToken = exactToken;
            this.typos = typos;
            this.official = official;
        }
    }

    private static final Brand[] BRANDS = {
            new Brand("GCash", "gcash", false, true, "gcash.com", "gcash.ph", "globe.com.ph", "mynt.xyz"),
            new Brand("Maya", "paymaya", false, true, "paymaya.com", "maya.ph"),
            new Brand("Maya", "maya", true, false, "maya.ph", "paymaya.com"),
            new Brand("BDO", "bdo", true, false, "bdo.com.ph"),
            new Brand("BPI", "bpi", true, false, "bpi.com.ph"),
            new Brand("Metrobank", "metrobank", false, true, "metrobank.com.ph"),
            new Brand("Landbank", "landbank", false, true, "landbank.com"),
            new Brand("UnionBank", "unionbank", false, true, "unionbankph.com"),
            new Brand("Security Bank", "securitybank", false, false, "securitybank.com"),
            new Brand("RCBC", "rcbc", true, false, "rcbc.com"),
            new Brand("PNB", "pnb", true, false, "pnb.com.ph"),
            new Brand("China Bank", "chinabank", false, false, "chinabank.ph"),
            new Brand("SSS", "sss", true, false, "sss.gov.ph"),
            new Brand("PhilHealth", "philhealth", false, true, "philhealth.gov.ph"),
            new Brand("Pag-IBIG", "pagibig", false, false, "pagibigfund.gov.ph"),
            new Brand("LBC", "lbc", true, false, "lbcexpress.com"),
            new Brand("J&T Express", "jtexpress", false, false, "jtexpress.ph"),
            new Brand("Shopee", "shopee", false, false, "shopee.ph", "shopee.com", "shopee.sg", "shopeemobile.com", "shopee.io"),
            new Brand("Lazada", "lazada", false, true, "lazada.com.ph", "lazada.com", "lazada.sg"),
            new Brand("Facebook", "facebook", false, true, "facebook.com", "facebook.net", "fb.com", "fbcdn.net"),
            new Brand("PayPal", "paypal", false, true, "paypal.com", "paypal.me", "paypalobjects.com"),
            new Brand("Netflix", "netflix", false, true, "netflix.com", "netflix.net"),
    };

    /** Words scammers put in fake addresses. */
    private static final String[] SCAM_WORDS = {
            "login", "signin", "logon", "verify", "verif", "secure", "account", "update", "claim", "reward",
            "prize", "bonus", "promo", "gift", "free", "wallet", "unlock", "kyc", "confirm", "refund", "otp",
            "support", "helpdesk", "auth", "recover", "suspend", "alert", "billing", "loan", "cashout",
            "winner", "rebate", "voucher", "payout", "reactivate", "validate", "unblock", "limited",
            "fee", "parcel", "delivery", "redeliver", "customs", "tracking"
    };

    private static final Set<String> RISKY_TLDS = new HashSet<>(Arrays.asList(
            "top", "xyz", "icu", "cyou", "cfd", "sbs", "click", "link", "buzz", "rest", "monster", "gq", "tk",
            "ml", "cf", "ga", "zip", "mov", "lol", "bond", "work", "quest", "support", "cam", "loan", "win",
            "vip", "online", "site", "live", "shop", "store"));

    private static final Set<String> SHORTENERS = new HashSet<>(Arrays.asList(
            "bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc", "ow.ly",
            "s.id", "rebrand.ly", "t.ly", "bit.do", "goo.su", "shorturl.asia", "tinylink.onl", "v.gd", "qr.ae"));

    /** Cloud/CDN providers that companies use for their own app servers; never auto-blocked as fakes. */
    private static final String[] INFRASTRUCTURE = {
            "amazonaws.com", "cloudfront.net", "akamaized.net", "akamaihd.net", "akamaiedge.net", "edgekey.net",
            "edgesuite.net", "googleapis.com", "gstatic.com", "azureedge.net", "azurewebsites.net", "fastly.net",
            "alicdn.com", "fbcdn.net", "fbsbx.com", "cloudflare.net", "appsflyer.com", "branch.io", "adjust.com"
    };

    private static final Set<String> TRUSTED =new HashSet<>(Arrays.asList(
            "google.com", "google.com.ph", "youtube.com", "gmail.com", "apple.com", "microsoft.com", "live.com",
            "instagram.com", "whatsapp.com", "messenger.com", "tiktok.com", "x.com", "twitter.com", "github.com",
            "gov.ph", "wikipedia.org"));

    /**
     * Returns the brand being impersonated (e.g. "GCash") when this domain looks like a fake copy of it,
     * otherwise null. Requires a brand name plus a scam signal, so real company servers are not blocked.
     */
    static String fakeBrand(String domain) {
        if (domain == null || domain.isEmpty()) return null;
        String d = domain.toLowerCase(Locale.ROOT);
        for (String infra : INFRASTRUCTURE) if (d.endsWith("." + infra)) return null; // real apps' cloud servers
        String[] tokens = d.split("[.\\-]");
        String tld = tokens[tokens.length - 1];
        boolean signal = RISKY_TLDS.contains(tld) || d.contains("xn--") || hasScamWord(d) != null;

        for (Brand b : BRANDS) {
            if (isOfficial(d, b)) continue;
            boolean mentions = false;
            boolean typo = false;
            for (String t : tokens) {
                if (b.exactToken ? t.equals(b.key) : t.contains(b.key)) mentions = true;
                else if (b.typos && Math.abs(t.length() - b.key.length()) <= 1 && t.length() >= 5
                        && editDistanceAtMostOne(t, b.key)) typo = true;
            }
            if (!b.exactToken) {
                for (String label : d.split("\\.")) if (label.replace("-", "").contains(b.key)) mentions = true;
            }
            if (typo || (mentions && signal)) return b.name;
        }
        return null;
    }

    /** A brand name used anywhere in an address that is not that brand's official site. */
    static String brandMention(String domain) {
        String d = domain.toLowerCase(Locale.ROOT);
        String[] tokens = d.split("[.\\-]");
        for (Brand b : BRANDS) {
            if (isOfficial(d, b)) continue;
            for (String t : tokens) if (b.exactToken ? t.equals(b.key) : t.contains(b.key)) return b.name;
        }
        return null;
    }

    private static boolean isOfficial(String d, Brand b) {
        for (String o : b.official) if (d.equals(o) || d.endsWith("." + o)) return true;
        return false;
    }

    private static boolean isOfficialAnyBrand(String d) {
        for (Brand b : BRANDS) if (isOfficial(d, b)) return true;
        String base = registrable(d);
        if (TRUSTED.contains(base)) return true;
        return d.endsWith(".gov.ph") || d.endsWith(".edu.ph");
    }

    private static String hasScamWord(String s) {
        for (String w : SCAM_WORDS) if (s.contains(w)) return w;
        return null;
    }

    private static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == c) n++;
        return n;
    }

    /** True when a and b differ by one inserted, deleted or replaced letter (and are not identical). */
    static boolean editDistanceAtMostOne(String a, String b) {
        if (a.equals(b)) return false;
        int la = a.length(), lb = b.length();
        if (Math.abs(la - lb) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < la && j < lb) {
            if (a.charAt(i) == b.charAt(j)) { i++; j++; continue; }
            if (++edits > 1) return false;
            if (la > lb) i++;
            else if (lb > la) j++;
            else { i++; j++; }
        }
        edits += (la - i) + (lb - j);
        return edits == 1;
    }

    /** example.com, or example.com.ph for country second-level domains. */
    static String registrable(String host) {
        String[] p = host.split("\\.");
        if (p.length <= 2) return host;
        String sld = p[p.length - 2];
        boolean ccSecond = p[p.length - 1].length() == 2
                && (sld.equals("com") || sld.equals("gov") || sld.equals("edu") || sld.equals("net") || sld.equals("org") || sld.equals("co"));
        int keep = ccSecond ? 3 : 2;
        StringBuilder sb = new StringBuilder();
        for (int i = p.length - keep; i < p.length; i++) {
            if (sb.length() > 0) sb.append('.');
            sb.append(p[i]);
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ link checker

    static final int SAFE = 0, CAUTION = 1, SUSPICIOUS = 2, DANGEROUS = 3;

    static final class LinkResult {
        String url;
        String host;
        int level;
        final List<String> reasons = new ArrayList<>();
    }

    static String label(int level) {
        switch (level) {
            case DANGEROUS: return "DANGEROUS";
            case SUSPICIOUS: return "SUSPICIOUS";
            case CAUTION: return "BE CAREFUL";
            default: return "NO THREATS FOUND";
        }
    }

    static int color(int level) {
        switch (level) {
            case DANGEROUS: return Ui.RED;
            case SUSPICIOUS: return Ui.PINK;
            case CAUTION: return Ui.AMBER;
            default: return Ui.GREEN;
        }
    }

    private static final Pattern LINK = Pattern.compile(
            "(?i)\\b((?:https?://)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+(?:[a-z]{2,24}|xn--[a-z0-9-]{2,30})(?::\\d{2,5})?(?:[/?#][^\\s<>\"']*)?)");
    private static final Pattern IP_LINK = Pattern.compile(
            "(?i)\\b((?:https?://)?\\d{1,3}(?:\\.\\d{1,3}){3}(?::\\d{2,5})?(?:[/?#][^\\s<>\"']*)?)");

    /** Finds up to 10 web links (with or without http://) inside any text. Skips email addresses. */
    static List<String> extractLinks(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return new ArrayList<>(out);
        for (Pattern p : new Pattern[]{IP_LINK, LINK}) {
            Matcher m = p.matcher(text);
            while (m.find() && out.size() < 10) {
                int s = m.start(1);
                if (s > 0 && text.charAt(s - 1) == '@') continue; // email address
                String link = trimTrailing(m.group(1));
                String bare = link.replaceFirst("(?i)^https?://", "");
                if (p == LINK && bare.length() == link.length() && !knownEnding(bare)) continue; // e.g. "Mr.Smith"
                boolean dup = false;
                for (String o : out) if (o.replaceFirst("(?i)^https?://", "").startsWith(bare)) dup = true;
                if (!dup) out.add(link);
            }
        }
        return new ArrayList<>(out);
    }

    private static final Set<String> COMMON_TLDS = new HashSet<>(Arrays.asList(
            "com", "net", "org", "info", "biz", "io", "app", "dev", "me", "co", "gov", "edu", "asia", "page",
            "site", "online", "store", "shop", "live", "link", "click", "xyz", "top", "vip", "tv", "cc", "ly", "gl"));

    /** For links typed without http://, only accept real-looking endings so normal words aren't mistaken for links. */
    private static boolean knownEnding(String bare) {
        int end = bare.length();
        for (int i = 0; i < bare.length(); i++) {
            if ("/?#:".indexOf(bare.charAt(i)) >= 0) { end = i; break; }
        }
        String host = bare.substring(0, end).toLowerCase(Locale.ROOT);
        String tld = host.substring(host.lastIndexOf('.') + 1);
        return tld.length() == 2 || COMMON_TLDS.contains(tld) || RISKY_TLDS.contains(tld) || tld.startsWith("xn--");
    }

    private static String trimTrailing(String s) {
        while (!s.isEmpty() && ".,;:!?)]}'\"".indexOf(s.charAt(s.length() - 1)) >= 0) s = s.substring(0, s.length() - 1);
        return s;
    }

    private static boolean isIp(String host) {
        return host.matches("\\d{1,3}(\\.\\d{1,3}){3}");
    }

    static LinkResult analyze(String raw) {
        LinkResult r = new LinkResult();
        String u = trimTrailing(raw.trim());
        r.url = u;
        String lower = u.toLowerCase(Locale.ROOT);
        boolean http = lower.startsWith("http://");
        int schemeEnd = lower.indexOf("://");
        String rest = schemeEnd >= 0 ? u.substring(schemeEnd + 3) : u;
        int cut = -1;
        for (int i = 0; i < rest.length(); i++) {
            if ("/?#".indexOf(rest.charAt(i)) >= 0) { cut = i; break; }
        }
        String authority = cut < 0 ? rest : rest.substring(0, cut);
        String path = cut < 0 ? "" : rest.substring(cut).toLowerCase(Locale.ROOT);
        boolean at = authority.contains("@");
        if (at) authority = authority.substring(authority.lastIndexOf('@') + 1);
        String host = authority;
        int port = -1;
        int colon = host.lastIndexOf(':');
        if (colon > 0) {
            try { port = Integer.parseInt(host.substring(colon + 1)); } catch (NumberFormatException ignored) { }
            host = host.substring(0, colon);
        }
        host = host.toLowerCase(Locale.ROOT);
        while (host.endsWith(".")) host = host.substring(0, host.length() - 1);
        r.host = host;

        if (RuleStore.isAllowed(host)) {
            r.level = SAFE;
            r.reasons.add("On your Always allowed list");
            return r;
        }
        String blockReason = RuleStore.check(host);
        if (RuleStore.REASON_BYPASS.equals(blockReason)) {
            r.level = SAFE;
            r.reasons.add("A public encrypted-DNS service. SafeSphere blocks it on purpose so apps can't skip its filter.");
            return r;
        }
        if (blockReason != null) {
            r.level = DANGEROUS;
            r.reasons.add(blockReason + ". SafeSphere blocks this site automatically while protection is on.");
        }

        boolean official = isOfficialAnyBrand(host);
        int score = 0;
        if (isIp(host)) { score += 3; r.reasons.add("Uses a raw IP address instead of a website name"); }
        if (SHORTENERS.contains(registrable(host))) {
            score += 2;
            r.reasons.add("Short link that hides the real destination. Only open it if you trust the sender.");
        }
        if (host.contains("xn--")) { score += 3; r.reasons.add("Uses look-alike foreign characters to imitate a real address"); }
        String tld = host.substring(host.lastIndexOf('.') + 1);
        if (!official && RISKY_TLDS.contains(tld)) {
            score += 2;
            r.reasons.add("Ends in \"." + tld + "\", an ending often used by scam sites");
        }
        if (at) { score += 3; r.reasons.add("Contains \"@\", a trick that hides the real address"); }
        if (http) { score += 1; r.reasons.add("Not encrypted (http instead of https)"); }
        if (port > 0 && port != 80 && port != 443) { score += 1; r.reasons.add("Uses an unusual port number"); }
        if (!official && r.level != DANGEROUS) {
            String brand = brandMention(host);
            if (brand != null) {
                score += 3;
                r.reasons.add("Uses the name " + brand + " but is not an official " + brand + " website");
            }
        }
        if (!official) {
            String w = hasScamWord(host);
            if (w != null) { score += 2; r.reasons.add("Address contains \"" + w + "\", a word common in scam links"); }
            if (count(host, '-') >= 3) { score += 1; r.reasons.add("Long hyphenated address, common in fake sites"); }
            if (host.split("\\.").length >= 5) { score += 1; r.reasons.add("Many sub-levels in the address"); }
            if (host.length() > 45) { score += 1; r.reasons.add("Unusually long address"); }
            String pw = hasScamWord(path);
            if (pw != null) { score += 1; r.reasons.add("Link asks you to \"" + pw + "\", typical of phishing pages"); }
        }
        if (r.level != DANGEROUS) {
            r.level = score >= 4 ? SUSPICIOUS : score >= 1 ? CAUTION : SAFE;
            if (official && score == 0) r.reasons.add("Official website of a known company or the government");
            else if (score == 0) r.reasons.add("Not on any threat list and no warning signs found. Still, never enter passwords or OTPs from a link you didn't expect.");
        }
        return r;
    }

    // ------------------------------------------------------------------ message checker

    private static final String[][] MESSAGE_SIGNS = {
            {"Promises a prize, reward or winnings, a classic scam opener",
                    "congratulations", "congrats", "you won", "you have won", "winner", "nanalo", "prize", "premyo",
                    "reward", "raffle", "jackpot", "lucky"},
            {"Creates urgency or threatens to lock your account",
                    "urgent", "immediately", "within 24", "limited time", "expire", "suspended", "deactivated",
                    "naka-hold", "on hold", "blocked", "final notice", "agad", "ngayon na"},
            {"Asks for codes, PINs or account verification. GCash and banks never ask for your OTP or MPIN",
                    " otp", "mpin", "one-time", "verification code", "kyc", "verify your", "i-verify", "update your account",
                    "password"},
            {"Asks you to send money or pay a fee to receive something",
                    "processing fee", "padala", "send money", "cash out", "claim your", "i-claim", "loan approved",
                    "refund", "pay the fee", "bayaran"},
            {"Offers easy money or a job that sounds too good to be true",
                    "easy money", "earn up to", "per day", "commission", "part-time job", "work from home", "kumita"}
    };

    /** Scam-style language in a text message. */
    static List<String> messageWarnings(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String t = " " + text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ") + " ";
        String withoutLinks = t;
        for (String l : extractLinks(text)) withoutLinks = withoutLinks.replace(l.toLowerCase(Locale.ROOT), " ");
        if (withoutLinks.trim().split(" ").length < 3) return out; // only a link, not a message
        for (String[] sign : MESSAGE_SIGNS) {
            for (int i = 1; i < sign.length; i++) {
                if (t.contains(sign[i])) { out.add(sign[0]); break; }
            }
        }
        return out;
    }
}
