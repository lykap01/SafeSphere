package com.nekowishy.safesphere;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Link analysis used by the DNS filter (fakeBrand), the Check tab and automatic message alerts.
 *
 * Build 16 changes, after reviewing why international links were misjudged in Build 15:
 *  - Parsing: UrlInfo (Unicode/IDN hosts, numeric IPs, @-tricks, encoded hosts, backslashes).
 *  - Domain structure: Public Suffix List instead of a hard-coded com/net/org list.
 *  - Brand profiles: data-driven catalogue (assets/brands.tsv) with verified international brands.
 *  - False positives: scam words now match whole words (Build 15 matched "fee" inside "coffee",
 *    "otp" inside "hotpot"); a risky ending alone never blocks; one-letter brand typos alone
 *    (e.g. "metabank", a real bank) no longer auto-block.
 *  - Honesty: a confirmed threat-list match is reported separately from heuristic warnings.
 */
final class ScamDetector {

    private ScamDetector() {}

    static final int SAFE = 0, CAUTION = 1, SUSPICIOUS = 2, DANGEROUS = 3;

    /** Words that, next to a brand name, show a credential or payment trap. Strong enough for the DNS filter. */
    private static final Set<String> STRONG_WORDS = new HashSet<>(Arrays.asList(
            "login", "signin", "logon", "verify", "verification", "verif", "secure", "security", "account", "accounts",
            "update", "confirm", "unlock", "recover", "recovery", "suspend", "suspended", "reactivate", "validate",
            "unblock", "billing", "refund", "claim", "reward", "rewards", "prize", "wallet", "kyc", "otp", "auth",
            "helpdesk", "payment", "cashout", "payout", "rebate", "voucher", "winner", "fee", "redelivery",
            "customs", "password", "passcode", "authenticate", "restore", "renew", "renewal", "subscription",
            "invoice", "appeal", "unpaid", "refunds", "pay"));

    /** Words common in scam links but also in normal ones; they only raise warnings in manual checks. */
    private static final Set<String> SOFT_WORDS = new HashSet<>(Arrays.asList(
            "support", "promo", "gift", "bonus", "free", "delivery", "parcel", "tracking", "track", "alert",
            "notice", "service", "customer", "loan", "limited", "deal", "giveaway", "lucky"));

    /**
     * Endings that abuse reports (e.g. Spamhaus and Interisle domain-abuse studies) repeatedly list as
     * heavily abused. Many honest sites use them too, so this only adds a small weight.
     */
    private static final Set<String> OFTEN_ABUSED_TLDS = new HashSet<>(Arrays.asList(
            "top", "xyz", "icu", "cyou", "cfd", "sbs", "click", "buzz", "rest", "monster", "gq", "tk", "ml", "cf",
            "ga", "zip", "mov", "lol", "bond", "quest", "cam", "loan", "win", "vip", "shop", "online", "site",
            "live", "store", "support", "work", "life", "info"));

    private static final Set<String> SHORTENERS = new HashSet<>(Arrays.asList(
            "bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc", "ow.ly",
            "s.id", "rebrand.ly", "t.ly", "bit.do", "goo.su", "shorturl.asia", "tinylink.onl", "v.gd", "qr.ae",
            "buff.ly", "lnkd.in", "shorte.st", "adf.ly", "tiny.one", "u.to", "clck.ru", "urlz.fr", "surl.li"));

    /** Cloud/CDN providers that companies use for their own app servers; never auto-blocked as fakes. */
    private static final String[] INFRASTRUCTURE = {
            "amazonaws.com", "cloudfront.net", "akamaized.net", "akamaihd.net", "akamaiedge.net", "edgekey.net",
            "edgesuite.net", "googleapis.com", "gstatic.com", "azureedge.net", "azurewebsites.net", "fastly.net",
            "alicdn.com", "fbcdn.net", "fbsbx.com", "cloudflare.net", "appsflyer.com", "branch.io", "adjust.com",
            "googlevideo.com", "ytimg.com", "akamai.net", "trafficmanager.net", "msedge.net"};

    /** Well-known sites without a brand profile, kept from Build 15's trusted list. */
    private static final Set<String> TRUSTED = new HashSet<>(Arrays.asList(
            "tiktok.com", "x.com", "twitter.com", "github.com", "wikipedia.org", "telegram.org", "viber.com"));

    // ------------------------------------------------------------------ results

    static final class LinkResult {
        String url;
        String host = "";
        String hostUnicode = "";
        int level;
        boolean confirmed;        // on a downloaded threat list (or the user's own block list)
        boolean blockedByFilter;  // the DNS filter will refuse it while protection is on
        boolean official;         // verified official domain of a catalogued brand
        String brand;             // impersonated brand, if any
        String listedBy;          // threat feeds that list this domain
        boolean shortener;
        int score;
        final List<String> reasons = new ArrayList<>();
    }

    static String label(int level) {
        switch (level) {
            case DANGEROUS: return "Dangerous";
            case SUSPICIOUS: return "Suspicious";
            case CAUTION: return "Be careful";
            default: return "No known threats";
        }
    }

    static int color(int level) {
        switch (level) {
            case DANGEROUS: return Ui.DANGER;
            case SUSPICIOUS: return Ui.SUSPICIOUS;
            case CAUTION: return Ui.WARNING;
            default: return Ui.SUCCESS;
        }
    }

    static int tone(int level) {
        switch (level) {
            case DANGEROUS: return Ui.T_DANGER;
            case SUSPICIOUS: return Ui.T_SUSPICIOUS;
            case CAUTION: return Ui.T_WARNING;
            default: return Ui.T_SUCCESS;
        }
    }

    // ------------------------------------------------------------------ brand helpers

    static String registrable(String host) {
        return PublicSuffix.registrable(host);
    }

    private static boolean isInfrastructure(String d) {
        for (String infra : INFRASTRUCTURE) if (d.equals(infra) || d.endsWith("." + infra)) return true;
        return false;
    }

    /** The brand whose verified domain this is, or null. */
    static BrandCatalog.Brand officialBrand(String host) {
        String reg = registrable(host);
        for (BrandCatalog.Brand b : BrandCatalog.all()) if (b.isOfficial(host, reg)) return b;
        return null;
    }

    static boolean isTrustedNonBrand(String host) {
        String reg = registrable(host);
        if (TRUSTED.contains(reg)) return true;
        return host.endsWith(".gov.ph") || host.endsWith(".edu.ph") || host.equals("gov.ph");
    }

    /** Labels of the host without its public suffix ("secure-paypal.co.uk" → ["secure-paypal"]). */
    private static String[] ownerLabels(String host) {
        String suf = PublicSuffix.suffix(host);
        String left = host.length() > suf.length() ? host.substring(0, host.length() - suf.length() - 1) : host;
        return left.split("\\.");
    }

    private static List<String> tokens(String label) {
        List<String> out = new ArrayList<>();
        for (String t : label.split("[-_]")) if (!t.isEmpty()) out.add(t);
        return out;
    }

    static final class BrandHit {
        BrandCatalog.Brand brand;
        boolean literal, typo, disguised, homograph;
        String residue = ""; // rest of the label next to the brand name, e.g. "secure" in "paypalsecure"
    }

    /** Finds a brand named in a host that is NOT that brand's official domain. */
    static BrandHit brandHit(UrlInfo u) {
        String host = u.host;
        if (host.isEmpty() || u.ipv4 || u.ipv6) return null;
        String reg = registrable(host);
        // Homograph: the host only reads as a brand after look-alike letters are swapped.
        if (u.idn && u.skeleton != null && !u.skeleton.equals(u.hostUnicode)) {
            String skel = u.skeleton;
            for (BrandCatalog.Brand b : BrandCatalog.all()) {
                boolean hit = false;
                String uni = u.hostUnicode;
                for (String o : b.official) {
                    String oLabel = o.substring(0, o.indexOf('.'));
                    boolean looks = skel.equals(o) || skel.endsWith("." + o) || skel.contains(oLabel + ".");
                    if (looks && !uni.contains(oLabel)) hit = true; // only a match AFTER swapping look-alikes
                }
                for (BrandCatalog.Key k : b.keys) {
                    if (k.word.length() >= 4 && skel.contains(k.word) && !uni.contains(k.word)) hit = true;
                }
                if (hit && !b.isOfficial(host, reg)) {
                    BrandHit h = new BrandHit();
                    h.brand = b;
                    h.homograph = true;
                    return h;
                }
            }
        }
        String[] labels = ownerLabels(host);
        BrandHit best = null;
        for (BrandCatalog.Brand b : BrandCatalog.all()) {
            if (b.isOfficial(host, reg)) continue;
            boolean naturalSpaces = b.naturalSpaces;
            for (String label : labels) {
                List<String> toks = tokens(label);
                String flat = label.replace("-", "");
                for (BrandCatalog.Key k : b.keys) {
                    String w = k.word;
                    BrandHit h = null;
                    for (String t : toks) {
                        boolean m;
                        if (k.mode == BrandCatalog.MATCH_TOKEN) m = t.equals(w);
                        else if (k.mode == BrandCatalog.MATCH_EDGE) m = t.equals(w) || t.startsWith(w) || t.endsWith(w);
                        else m = t.contains(w);
                        if (m) {
                            h = new BrandHit();
                            h.literal = true;
                            h.residue = t.replace(w, "");
                        } else if (hasLetter(t) && hasDigitOrAt(t) && leetToLetters(t).contains(w)) {
                            h = new BrandHit(); // faceb00k, paypa1: a disguise, not an innocent typo
                            h.disguised = true;
                        } else if (k.typos && w.length() >= 5 && t.length() >= 5 && editDistanceAtMostOne(t, w)) {
                            h = new BrandHit();
                            h.typo = true;
                        }
                        if (h != null) break;
                    }
                    if (h == null && k.mode == BrandCatalog.MATCH_CONTAINS) {
                        // Split with hyphens (g-cash) or spelled with digits (faceb00k)
                        if (!naturalSpaces && !label.contains(w) && flat.contains(w)) { h = new BrandHit(); h.disguised = true; }
                        else if (!flat.contains(w) && leetToLetters(flat).contains(w)) { h = new BrandHit(); h.disguised = true; }
                    } else if (h == null) {
                        for (String t : toks) {
                            if (!t.equals(w) && hasLetter(t) && hasDigitOrAt(t) && leetToLetters(t).equals(w)) {
                                h = new BrandHit();
                                h.disguised = true;
                            }
                        }
                    }
                    if (h != null) {
                        h.brand = b;
                        if (best == null || (h.literal && !best.literal)) best = h;
                    }
                }
            }
            if (best != null && best.brand == b && best.literal) return best;
        }
        return best;
    }

    /**
     * A strong credential/payment word in the address. Without a brand name, only the owner's own label
     * counts ("secure-login.example"), not subdomains of an unrelated site ("accounts.spotify.com").
     */
    private static String strongWord(UrlInfo u, BrandHit h) {
        String[] labels = ownerLabels(u.host);
        int from = h == null ? labels.length - 1 : 0;
        for (int i = Math.max(0, from); i < labels.length; i++) {
            for (String t : tokens(labels[i])) if (STRONG_WORDS.contains(t)) return t;
        }
        if (h != null && h.residue.length() >= 3) {
            for (String w : STRONG_WORDS) if (w.length() >= 3 && h.residue.contains(w)) return w;
        }
        return null;
    }

    private static String softWord(UrlInfo u) {
        for (String label : ownerLabels(u.host)) {
            for (String t : tokens(label)) if (SOFT_WORDS.contains(t)) return t;
        }
        return null;
    }

    /**
     * DNS filter: returns the impersonated brand when this domain is very likely a fake copy, else null.
     * Requires a brand plus a strong scam signal, so real company servers and unrelated sites are not blocked.
     */
    private static final java.util.Map<String, String> FAKE_CACHE = new java.util.LinkedHashMap<String, String>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(java.util.Map.Entry<String, String> e) { return size() > 1024; }
    };
    private static final String NONE = "";

    static String fakeBrand(String domain) {
        if (domain == null || domain.isEmpty()) return null;
        String d = domain.toLowerCase(Locale.ROOT);
        synchronized (FAKE_CACHE) {
            String c = FAKE_CACHE.get(d);
            if (c != null) return c == NONE ? null : c;
        }
        String res = computeFakeBrand(d);
        synchronized (FAKE_CACHE) { FAKE_CACHE.put(d, res == null ? NONE : res); }
        return res;
    }

    /** Clears cached filter decisions (call after the brand catalogue or suffix list loads). */
    static void clearCache() {
        synchronized (FAKE_CACHE) { FAKE_CACHE.clear(); }
    }

    private static String computeFakeBrand(String d) {
        if (isInfrastructure(d)) return null;
        UrlInfo u = UrlInfo.parse(d);
        if (!u.valid) return null;
        BrandHit h = brandHit(u);
        if (h == null) return null;
        if (h.homograph || h.disguised) return h.brand.name;
        String strong = strongWord(u, h);
        if (h.literal && strong != null) return h.brand.name;
        if (h.typo && (strong != null || OFTEN_ABUSED_TLDS.contains(u.tld()))) return h.brand.name;
        return null;
    }

    /** Kept for older callers: a brand name used on a non-official domain. */
    static String brandMention(String domain) {
        UrlInfo u = UrlInfo.parse(domain);
        BrandHit h = u.valid ? brandHit(u) : null;
        return h == null ? null : h.brand.name;
    }

    private static boolean hasLetter(String t) {
        for (int i = 0; i < t.length(); i++) if (t.charAt(i) >= 'a' && t.charAt(i) <= 'z') return true;
        return false;
    }

    private static boolean hasDigitOrAt(String t) {
        for (int i = 0; i < t.length(); i++) if (Character.isDigit(t.charAt(i)) || t.charAt(i) == '@') return true;
        return false;
    }

    /** Reads look-alike numbers as letters: faceb00k → facebook. */
    static String leetToLetters(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '0': sb.append('o'); break;
                case '1': sb.append('l'); break;
                case '3': sb.append('e'); break;
                case '4': sb.append('a'); break;
                case '5': sb.append('s'); break;
                case '7': sb.append('t'); break;
                case '@': sb.append('a'); break;
                default: sb.append(ch);
            }
        }
        return sb.toString();
    }

    /** True when a and b differ by one inserted, deleted or replaced letter (and are not identical). */
    static boolean editDistanceAtMostOne(String a, String b) {
        if (a.equals(b)) return false;
        int la = a.length(), lb = b.length();
        if (Math.abs(la - lb) > 1) return false;
        int i = 0, j = 0, edits = 0;
        while (i < la && j < lb) {
            if (a.charAt(i) == b.charAt(j)) { i++; j++; continue; }
            if (++edits > 1) return false;
            if (la > lb) i++;
            else if (lb > la) j++;
            else { i++; j++; }
        }
        edits += (la - i) + (lb - j);
        return edits == 1;
    }

    // ------------------------------------------------------------------ link extraction

    /** Links with an explicit scheme: anything up to whitespace (catches @-tricks, numeric IPs, Unicode hosts). */
    private static final Pattern SCHEME_LINK = Pattern.compile("(?i)\\b((?:https?|ftp)://[^\\s<>\"']+)");
    /** Scheme-less domains, including Unicode (IDN) names. */
    private static final Pattern BARE_LINK = Pattern.compile(
            "(?i)(?<![\\p{L}\\p{N}@._-])((?:[\\p{L}\\p{N}](?:[\\p{L}\\p{N}-]{0,61}[\\p{L}\\p{N}])?\\.)+"
                    + "(?:\\p{L}{2,24}|xn--[a-z0-9-]{2,30})(?::\\d{2,5})?(?:[/?#\\\\][^\\s<>\"']*)?)");
    private static final Pattern IP_LINK = Pattern.compile(
            "(?<![\\d.])((?:\\d{1,3}\\.){3}\\d{1,3}(?::\\d{2,5})?(?:[/?#][^\\s<>\"']*)?)");

    private static final Set<String> COMMON_TLDS = new HashSet<>(Arrays.asList(
            "com", "net", "org", "info", "biz", "io", "app", "dev", "me", "co", "gov", "edu", "asia", "page",
            "site", "online", "store", "shop", "live", "link", "click", "xyz", "top", "vip", "tv", "cc", "ly", "gl"));

    /** Finds up to 10 web links (with or without http://) inside any text. Skips e-mail addresses. */
    static List<String> extractLinks(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return new ArrayList<>(out);
        List<int[]> taken = new ArrayList<>();
        for (Pattern p : new Pattern[]{SCHEME_LINK, IP_LINK, BARE_LINK}) {
            Matcher m = p.matcher(text);
            while (m.find() && out.size() < 10) {
                int s = m.start(1), e = m.end(1);
                boolean inside = false;
                for (int[] t : taken) if (s >= t[0] && s < t[1]) inside = true;
                if (inside) continue;
                if (p != SCHEME_LINK && s > 0 && text.charAt(s - 1) == '@') continue; // e-mail address
                String link = trimTrailing(m.group(1));
                if (link.isEmpty()) continue;
                if (p == BARE_LINK) {
                    // name@domain.com: skip e-mail addresses written without spaces
                    int after = e;
                    if (after < text.length() && text.charAt(after) == '@') continue;
                    if (!knownEnding(link)) continue; // e.g. "Mr.Smith", "salamat.po"
                }
                taken.add(new int[]{s, e});
                out.add(link);
            }
        }
        return new ArrayList<>(out);
    }

    /** For links typed without http://, only accept real top-level domains so normal words aren't mistaken for links. */
    private static boolean knownEnding(String bare) {
        UrlInfo u = UrlInfo.parse(bare);
        if (!u.valid || u.host.indexOf('.') < 0) return false;
        String tld = u.tld();
        Boolean known = PublicSuffix.isKnownTld(tld);
        if (known != null) return known;
        return tld.length() == 2 || COMMON_TLDS.contains(tld) || OFTEN_ABUSED_TLDS.contains(tld) || tld.startsWith("xn--");
    }

    private static String trimTrailing(String s) {
        while (!s.isEmpty() && ".,;:!?)]}'\"".indexOf(s.charAt(s.length() - 1)) >= 0) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ------------------------------------------------------------------ link analysis

    static LinkResult analyze(String raw) {
        LinkResult r = new LinkResult();
        UrlInfo u = UrlInfo.parse(raw);
        r.url = u.raw;
        r.host = u.host;
        r.hostUnicode = u.hostUnicode;
        if (!u.webScheme) {
            r.level = "javascript".equals(u.scheme) || "data".equals(u.scheme) ? SUSPICIOUS : CAUTION;
            r.reasons.add("Not a normal web link (" + u.scheme + ":). Don't open it unless you know exactly what it does.");
            return r;
        }
        if (!u.valid) {
            r.level = CAUTION;
            r.reasons.add("SafeSphere couldn't read this address. Malformed links are sometimes used to confuse people.");
            return r;
        }
        String host = u.host;
        BrandCatalog.Brand ob = u.ipv4 || u.ipv6 ? null : officialBrand(host);
        r.official = ob != null;
        boolean trusted = r.official || isTrustedNonBrand(host) || isInfrastructure(host);

        if (RuleStore.isAllowed(host)) {
            r.level = SAFE;
            r.reasons.add("On your Always allowed list");
            return r;
        }
        String ruleReason = RuleStore.check(host);
        if (RuleStore.REASON_BYPASS.equals(ruleReason)) {
            r.level = SAFE;
            r.reasons.add("A public encrypted-DNS service. SafeSphere blocks it on purpose so apps can't skip its filter.");
            return r;
        }
        if (RuleStore.REASON_THREAT.equals(ruleReason)) {
            r.level = DANGEROUS;
            r.confirmed = true;
            r.blockedByFilter = true;
            r.listedBy = ThreatDb.sourcesFor(host);
            r.reasons.add("Confirmed: listed as malicious by " + (r.listedBy == null ? "a downloaded threat feed" : r.listedBy)
                    + ". Blocked automatically while protection is on.");
        } else if (RuleStore.REASON_CUSTOM.equals(ruleReason) || RuleStore.REASON_TEST.equals(ruleReason)) {
            r.level = DANGEROUS;
            r.confirmed = true;
            r.blockedByFilter = true;
            r.reasons.add(RuleStore.REASON_CUSTOM.equals(ruleReason) ? "On your Blocked list" : "SafeSphere test address");
        }

        int score = 0;

        if (u.ipv4 || u.ipv6) {
            score += u.ipObfuscated ? 5 : 3;
            r.reasons.add(u.ipObfuscated
                    ? "Hides a numeric IP address (" + host + ") in an unusual form. Real companies don't do this."
                    : "Uses a raw IP address instead of a website name");
        }
        if (u.userInfo != null) {
            boolean looksLikeSite = u.userInfo.contains(".");
            score += looksLikeSite ? 5 : 3;
            r.reasons.add("Contains \"@\": everything before it is ignored, so the real site is " + host
                    + (looksLikeSite ? ", not \"" + shorten(u.userInfo) + "\"" : ""));
        }
        if (u.backslashes) {
            if (!trusted) score += 2;
            r.reasons.add("Contains backslashes, which browsers read as \"/\". The site it really opens is " + host + ".");
        }
        if (u.encodedHost) { score += 3; r.reasons.add("The site name is hidden with %-encoded characters"); }
        if (SHORTENERS.contains(registrable(host))) {
            score += 2;
            r.shortener = true;
            r.reasons.add("Short link that hides the real destination. Only open it if you trust the sender.");
        }
        String platform = PublicSuffix.sharedPlatform(host);

        BrandHit hit = trusted ? null : brandHit(u);
        if (hit != null) {
            r.brand = hit.brand.name;
            if (hit.homograph) {
                score += 6;
                r.reasons.add("Uses look-alike letters from another alphabet to imitate " + hit.brand.name
                        + " (reads as \"" + u.hostUnicode + "\")");
            } else if (hit.disguised) {
                score += 5;
                r.reasons.add("Spells " + hit.brand.name + " with numbers or hyphens to disguise a fake address");
            } else if (hit.typo) {
                score += 4;
                r.reasons.add("Looks like a misspelling of " + hit.brand.name + ". Check the spelling letter by letter.");
            } else {
                score += 3;
                r.reasons.add("Uses the name " + hit.brand.name + " but is not one of its verified domains");
            }
            if (platform != null) {
                score += 2;
                r.reasons.add("Hosted on " + platform + ", a platform where anyone can create a site, not on " + hit.brand.name + "'s own domain");
            }
        } else if (u.idn && !trusted) {
            if (u.mixedScript) {
                score += 4;
                r.reasons.add("Mixes letters from different alphabets in one name, a common look-alike trick");
            } else {
                score += 1;
                r.reasons.add("Uses international characters (" + u.hostUnicode + "). Fine for many real sites; check it's the one you expect.");
            }
        }

        String tld = u.tld();
        if (!trusted) {
            String strong = strongWord(u, hit);
            if (strong != null) {
                score += 2;
                r.reasons.add("Address contains \"" + strong + "\", a word often used in fake login and payment pages");
            } else {
                String soft = softWord(u);
                if (soft != null && hit != null) {
                    score += 1;
                    r.reasons.add("Address contains \"" + soft + "\" next to a brand name");
                }
            }
            if (OFTEN_ABUSED_TLDS.contains(tld) && !u.ipv4) {
                score += 1;
                r.reasons.add("Ends in \"." + tld + "\". Many honest sites use it, but it is also heavily used by scam sites.");
            }
            int hyphens = 0;
            String readable = u.hostUnicode.isEmpty() ? host : u.hostUnicode; // count in the readable form, not punycode
            for (int i = 0; i < readable.length(); i++) if (readable.charAt(i) == '-') hyphens++;
            if (hyphens >= 3) { score += 1; r.reasons.add("Long hyphenated address, common in fake sites"); }
            String reg = registrable(host);
            int depth = host.length() > reg.length() ? host.substring(0, host.length() - reg.length()).split("\\.").length : 0;
            if (depth >= 3) { score += 1; r.reasons.add("Many sub-levels before the real site name (" + reg + ")"); }
            if (host.length() > 50) { score += 1; r.reasons.add("Unusually long address"); }
            String pw = pathWord(u.pathAndQuery);
            if (pw != null && score > 0) { score += 1; r.reasons.add("The page path asks you to \"" + pw + "\""); }
        }
        if (u.port > 0 && u.port != 80 && u.port != 443) { score += 1; r.reasons.add("Uses an unusual port number (" + u.port + ")"); }
        if ("http".equals(u.scheme) && !trusted && score > 0) {
            score += 1;
            r.reasons.add("Not encrypted (http instead of https)");
        }

        r.score = score;
        if (r.level != DANGEROUS) {
            r.level = score >= 5 ? SUSPICIOUS : score >= 2 ? CAUTION : SAFE;
            String brand = ruleReason != null && ruleReason.startsWith(RuleStore.REASON_FAKE_PREFIX) ? fakeBrand(host) : null;
            if (brand != null) {
                r.blockedByFilter = true;
                if (r.level < SUSPICIOUS) r.level = SUSPICIOUS;
                r.reasons.add(0, "Matches SafeSphere's fake-" + brand + " pattern, so the filter blocks it while protection is on. "
                        + "This is SafeSphere's own judgment, not a threat-list match.");
            }
            if (r.level == SAFE) {
                if (ob != null) r.reasons.add("Verified official domain of " + ob.name);
                else if (trusted) r.reasons.add("A well-known website");
                else r.reasons.add("Not on any threat list and no warning signs found. This is not a guarantee: "
                        + "a padlock (https) doesn't make a site honest.");
            }
        }
        return r;
    }

    private static String shorten(String s) {
        return s.length() > 40 ? s.substring(0, 37) + "…" : s;
    }

    private static final Pattern PATH_WORD = Pattern.compile(
            "(?i)(?:^|[/?&=._-])(login|signin|verify|verification|confirm|unlock|update|secure|account|kyc|otp|claim|wallet|billing|refund|password)(?=$|[/?&=._-])");

    private static String pathWord(String path) {
        if (path == null || path.isEmpty()) return null;
        Matcher m = PATH_WORD.matcher(path);
        return m.find() ? m.group(1).toLowerCase(Locale.ROOT) : null;
    }

    // ------------------------------------------------------------------ message signs (compatibility)

    /** Scam-style language in a message: one line per sign. Uses the Before You Act analyzer. */
    static List<String> messageWarnings(String text) {
        List<String> out = new ArrayList<>();
        ActionAnalyzer.Report rep = ActionAnalyzer.analyzeText(text);
        for (ActionAnalyzer.Finding f : rep.findings) out.add(f.title);
        return out;
    }
}
