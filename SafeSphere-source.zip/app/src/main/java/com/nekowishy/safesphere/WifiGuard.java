package com.nekowishy.safesphere;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.TransportInfo;
import android.net.wifi.WifiInfo;
import android.os.Build;

/** Watches the Wi-Fi connection and warns when the network has no password or weak (WEP) security. */
final class WifiGuard {

    static final int LEVEL_SAFE = 0, LEVEL_CAUTION = 1, LEVEL_UNSAFE = 2;

    static final class Status {
        int level;
        String title;
        String detail;
        long networkId;
    }

    private static volatile Status current;
    private static ConnectivityManager.NetworkCallback callback;
    private static long lastAlerted = Long.MIN_VALUE;

    private WifiGuard() {}

    static boolean supported() {
        return Build.VERSION.SDK_INT >= 31;
    }

    /** Current Wi-Fi status, or null when not connected to Wi-Fi. */
    static Status current() {
        return current;
    }

    static synchronized void start(Context context) {
        if (callback != null || !supported()) return;
        Context app = context.getApplicationContext();
        ConnectivityManager cm = app.getSystemService(ConnectivityManager.class);
        if (cm == null) return;
        NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
        callback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                Status s = evaluate(caps);
                s.networkId = network.getNetworkHandle();
                current = s;
                if (s.level >= LEVEL_CAUTION) maybeAlert(app, s);
            }

            @Override
            public void onLost(Network network) {
                Status s = current;
                if (s != null && s.networkId == network.getNetworkHandle()) current = null;
            }
        };
        try {
            cm.registerNetworkCallback(request, callback);
        } catch (RuntimeException e) {
            callback = null;
        }
    }

    private static synchronized void maybeAlert(Context app, Status s) {
        if (s.networkId == lastAlerted) return; // once per Wi-Fi connection
        lastAlerted = s.networkId;
        Alerts.wifi(app, s.title, s.detail);
    }

    static Status evaluate(NetworkCapabilities caps) {
        Status s = new Status();
        boolean hotspotLogin = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL);
        int type = -1;
        if (Build.VERSION.SDK_INT >= 31) {
            TransportInfo info = caps.getTransportInfo();
            if (info instanceof WifiInfo) type = ((WifiInfo) info).getCurrentSecurityType();
        }
        switch (type) {
            case WifiInfo.SECURITY_TYPE_OPEN:
                s.level = LEVEL_UNSAFE;
                s.title = "Unsafe Wi-Fi: no password";
                s.detail = "This Wi-Fi is not encrypted, so others nearby can see your traffic. Avoid logging in to GCash, "
                        + "banks or email here. Use mobile data instead.";
                break;
            case WifiInfo.SECURITY_TYPE_WEP:
                s.level = LEVEL_UNSAFE;
                s.title = "Unsafe Wi-Fi: outdated security";
                s.detail = "This Wi-Fi uses WEP, an old security type that can be cracked in minutes. Avoid logging in "
                        + "to important accounts here.";
                break;
            case WifiInfo.SECURITY_TYPE_OWE:
                s.level = LEVEL_CAUTION;
                s.title = "Public Wi-Fi (Enhanced Open)";
                s.detail = "Encrypted, but anyone can join. Fine for browsing; be careful with banking.";
                break;
            case -1:
                s.level = LEVEL_SAFE;
                s.title = "Connected to Wi-Fi";
                s.detail = "This phone did not report the network's security type.";
                break;
            default:
                s.level = LEVEL_SAFE;
                s.title = "Secured Wi-Fi";
                s.detail = "This network uses password encryption (WPA2/WPA3).";
                break;
        }
        if (hotspotLogin && s.level == LEVEL_SAFE) {
            s.level = LEVEL_CAUTION;
            s.title = "Public hotspot with login page";
            s.detail = "Only enter details on the official login page of the place you're in. Never enter GCash or bank details.";
        }
        return s;
    }
}
