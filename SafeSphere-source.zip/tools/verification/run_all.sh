#!/bin/bash
# SafeSphere Build 16 verification suite. Needs only a JDK (17+) and Python 3. Run from the project root:
#   bash tools/verification/run_all.sh
# 1. Generates compile-only Android API stubs and type-checks every app source file against them.
# 2. Runs Build 15's original detector and Build 16's detector over the same test cases and scores both.
# 3. Runs unit tests (URL parsing, Public Suffix List, redaction, HIBP k-anonymity, DNS packets, reports).
set -e
unset JAVA_TOOL_OPTIONS
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
V="$ROOT/tools/verification"; OUT="$V/out"; APP="$ROOT/app/src/main/java/com/nekowishy/safesphere"; A="$ROOT/app/src/main/assets"
rm -rf "$OUT" && mkdir -p "$OUT/stubs" "$OUT/stub_classes" "$OUT/app" "$OUT/b15" "$OUT/b15src/com/nekowishy/safesphere"
echo "== 1. Compile check against Android API stubs"
python3 "$V/gen_stubs.py" "$OUT/stubs" >/dev/null
javac -nowarn -d "$OUT/stub_classes" $(find "$OUT/stubs" -name "*.java")
javac -nowarn -source 17 -target 17 -cp "$OUT/stub_classes" -d "$OUT/app" "$APP"/*.java 2>&1 | grep -v "^Note:\|warning: \[options\]\|^1 warning" || true
test -f "$OUT/app/com/nekowishy/safesphere/MainActivity.class" && echo "   all app sources compiled" | tee "$OUT/compile.txt"
echo "== 2. Detection test matrices (Build 15 vs Build 16)"
cp "$V/build15-baseline/"{ScamDetector,RuleStore,ThreatDb}.java "$OUT/b15src/com/nekowishy/safesphere/"
cp "$V/build15-baseline/Ui15Stub.java.txt" "$OUT/b15src/com/nekowishy/safesphere/Ui.java"
javac -nowarn -d "$OUT/b15" $(find "$V/stubs-min" -name "*.java") "$OUT/b15src/com/nekowishy/safesphere/"*.java "$V/harness/Harness15.java" 2>&1 | grep -v "^Note:" || true
javac -nowarn -cp "$OUT/app:$OUT/stub_classes" -d "$OUT/app" "$V/harness/Harness16.java" "$V/harness/UnitTests.java"
for set in "" "_holdout"; do
  java -cp "$OUT/b15" com.nekowishy.safesphere.Harness15 "$V/cases/urls$set.tsv" "$V/cases/messages$set.tsv" "$OUT/results15$set.tsv"
  java -cp "$OUT/app:$OUT/stub_classes" com.nekowishy.safesphere.Harness16 "$V/cases/urls$set.tsv" "$V/cases/messages$set.tsv" "$OUT/results16$set.tsv" "$A/public_suffix_list.dat" "$A/brands.tsv"
  echo "-- case set: main$set" | tee -a "$OUT/scores.txt"
  python3 "$V/score.py" "$V/cases/urls$set.tsv" "$V/cases/messages$set.tsv" "$OUT/results15$set.tsv" "$OUT/results16$set.tsv" | tee -a "$OUT/scores.txt"
done
echo "== 3. Unit tests"
java -cp "$OUT/app:$OUT/stub_classes" com.nekowishy.safesphere.UnitTests "$A/public_suffix_list.dat" "$A/brands.tsv" "$OUT/unit_results.tsv" | tee "$OUT/unit.txt"
grep -q " 0 failed" "$OUT/unit.txt"
