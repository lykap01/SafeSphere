import sys, csv
ORDER={"SAFE":0,"CAUTION":1,"SUSPICIOUS":2,"DANGEROUS":3}
def load_cases(p):
    out=[]
    for line in open(p,encoding='utf8'):
        if line.startswith('#') or not line.strip(): continue
        g,e,t=line.rstrip('\n').split('\t',2); out.append((g,e,t))
    return out
def load_res(p):
    r={}
    for line in open(p,encoding='utf8'):
        parts=line.rstrip('\n').split('\t')
        r[(parts[0],parts[1])]=parts
    return r
def judge(kind,exp,level,blocked):
    l=ORDER[level]
    if kind=='URL':
        if exp=='SAFE': return l==0 and not blocked
        if exp=='LOW': return l<=1 and not blocked
        if exp=='WARN': return l>=1
        if exp=='SUSP': return l>=2
        if exp=='BLOCK': return blocked and l>=2
    else:
        if exp=='SAFE': return l==0
        if exp=='LOW': return l<=1
        if exp=='WARN': return l>=1
        if exp=='SUSP': return l>=2
def run(urls,msgs,res,label,verbose):
    R=load_res(res); rows=[]
    for kind,cases in (('URL',load_cases(urls)),('MSG',load_cases(msgs))):
        for g,e,t in cases:
            p=R[(kind,t)]; level=p[2]; blocked=p[3].startswith('BLOCK') if kind=='URL' else False
            ok=judge(kind,e,level,blocked)
            rows.append((kind,g,e,t,level,p[3],ok,p[-1]))
    return rows
urls,msgs,r15,r16=sys.argv[1:5]
a=run(urls,msgs,r15,'B15',0); b=run(urls,msgs,r16,'B16',0)
for kind in ('URL','MSG'):
    pa=sum(1 for x in a if x[0]==kind and x[6]); pb=sum(1 for x in b if x[0]==kind and x[6]); n=sum(1 for x in a if x[0]==kind)
    print(f"{kind}: B15 {pa}/{n} pass   B16 {pb}/{n} pass")
mode=sys.argv[5] if len(sys.argv)>5 else 'fail'
for x,y in zip(a,b):
    if mode=='all' or not y[6]:
        print(f"{'PASS' if y[6] else 'FAIL'} [{y[1]}] exp={y[2]} B16={y[4]} {y[5][:30]} | B15={x[4]} {x[5][:20]} :: {y[3][:80]}\n      {y[7][:260]}")
