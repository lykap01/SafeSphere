package com.nekowishy.safesphere;
import java.nio.file.*; import java.util.*;
/** Runs Build 15's original detection code over the shared case files (unchanged logic). */
public class Harness15 {
  static String lv(int l){ return new String[]{"SAFE","CAUTION","SUSPICIOUS","DANGEROUS"}[l]; }
  public static void main(String[] a) throws Exception {
    StringBuilder out = new StringBuilder();
    for (String line : Files.readAllLines(Paths.get(a[0]))) {
      if (line.startsWith("#")||line.isBlank()) continue;
      String[] c=line.split("\t",3);
      ScamDetector.LinkResult r = ScamDetector.analyze(c[2]);
      String host = r.host;
      String fb = ScamDetector.fakeBrand(host);
      out.append("URL\t").append(c[2]).append('\t').append(lv(r.level)).append('\t').append(fb!=null?"BLOCK:"+fb:"-").append('\t').append(String.join(" | ", r.reasons)).append('\n');
    }
    for (String line : Files.readAllLines(Paths.get(a[1]))) {
      if (line.startsWith("#")||line.isBlank()) continue;
      String[] c=line.split("\t",3);
      String text=c[2];
      int level=0; List<String> links=ScamDetector.extractLinks(text);
      for (String l: links) level=Math.max(level, ScamDetector.analyze(l).level);
      List<String> w=ScamDetector.messageWarnings(text);
      if (w.size()>=2) level=Math.max(level,2); else if (w.size()==1) level=Math.max(level,1);
      out.append("MSG\t").append(text).append('\t').append(lv(level)).append('\t').append(links).append('\t').append(String.join(" | ", w)).append('\n');
    }
    Files.writeString(Paths.get(a[2]), out.toString());
  }
}
