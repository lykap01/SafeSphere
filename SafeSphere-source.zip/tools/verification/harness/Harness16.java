package com.nekowishy.safesphere;
import java.io.*; import java.nio.file.*; import java.util.*;
public class Harness16 {
  static String lv(int l){ return new String[]{"SAFE","CAUTION","SUSPICIOUS","DANGEROUS"}[l]; }
  public static void main(String[] a) throws Exception {
    PublicSuffix.load(new FileInputStream(a[3]));
    BrandCatalog.load(new FileInputStream(a[4]));
    StringBuilder out = new StringBuilder();
    for (String line : Files.readAllLines(Paths.get(a[0]))) {
      if (line.startsWith("#")||line.isBlank()) continue;
      String[] c=line.split("\t",3);
      ScamDetector.LinkResult r = ScamDetector.analyze(c[2]);
      String fb = r.host.isEmpty()?null:ScamDetector.fakeBrand(r.host);
      out.append("URL\t").append(c[2]).append('\t').append(lv(r.level)).append('\t').append(fb!=null?"BLOCK:"+fb:"-")
         .append('\t').append(r.host).append(r.hostUnicode.equals(r.host)?"":" ("+r.hostUnicode+")").append('\t').append(String.join(" | ", r.reasons)).append('\n');
    }
    for (String line : Files.readAllLines(Paths.get(a[1]))) {
      if (line.startsWith("#")||line.isBlank()) continue;
      String[] c=line.split("\t",3);
      ActionAnalyzer.Report rep = ActionAnalyzer.analyzeText(c[2]);
      List<String> f=new ArrayList<>(); for (ActionAnalyzer.Finding x: rep.findings) f.add(x.id+"("+x.weight+")"+x.evidence);
      out.append("MSG\t").append(c[2]).append('\t').append(lv(rep.level)).append('\t').append("pts="+rep.points).append('\t').append(String.join(" | ", f)).append('\n');
    }
    Files.writeString(Paths.get(a[2]), out.toString());
  }
}
