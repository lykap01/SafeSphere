package android.text.format;
public class DateUtils { public static final long MINUTE_IN_MILLIS = 60000;
  public static CharSequence getRelativeTimeSpanString(long a, long b, long c) { return "recently"; } }
