package android.content;
public interface SharedPreferences {
    interface Editor { Editor putString(String k, String v); Editor putLong(String k, long v); Editor putInt(String k, int v);
        Editor putBoolean(String k, boolean v); Editor putStringSet(String k, java.util.Set<String> v); Editor remove(String k); void apply(); boolean commit(); }
    String getString(String k, String d); long getLong(String k, long d); int getInt(String k, int d); boolean getBoolean(String k, boolean d);
    java.util.Set<String> getStringSet(String k, java.util.Set<String> d); Editor edit();
}
