package android.content;
public abstract class Context {
    public static final int MODE_PRIVATE = 0;
    public Context getApplicationContext() { return this; }
    public SharedPreferences getSharedPreferences(String n, int m) { return null; }
    public android.content.res.AssetManager getAssets() { return null; }
    public java.io.File getFilesDir() { return null; }
}
