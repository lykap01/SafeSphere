# SafeSphere Build 16 — Test Matrix

Results below are copied from actual runs of `tools/verification/run_all.sh` (JDK 21, Python 3, SQLite 3.53, no Android SDK).
**PASS / FAIL** = run and checked. **NOT VERIFIED** = could not be run in this environment (no Android SDK, emulator or device; network to Google servers blocked).

Reproduce: from the project root run `bash tools/verification/run_all.sh` (needs only a JDK 17+ and Python 3). The new `debug.yml` GitHub workflow runs the same suite on every pull request.

## 1. How the detection tests work

- **Inputs:** `tools/verification/cases/*.tsv`. Every simulated malicious domain uses the reserved `.example` TLD or documentation IP ranges (192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24), so no live malicious site is involved and nothing is fetched.
- **Build 15 baseline:** Build 15's original `ScamDetector`, `RuleStore` and `ThreatDb` are compiled unchanged and run on the same inputs (`Harness15`). For messages, Build 15's verdict is computed the way its Check tab did (worst link level; 2+ keyword signs = Suspicious, 1 = Be careful).
- **Build 16:** `Harness16` runs `ScamDetector.analyze` + `fakeBrand` (links) and `ActionAnalyzer` (messages) with the bundled PSL and brand catalogue.
- **Threat feeds are empty in these tests** (nothing downloaded), so results measure SafeSphere's own parsing and heuristics, not the feeds. Feed matching is covered by unit tests of the lookup path.
- **Expectations:** `SAFE` = No known threats and not blocked · `LOW` = at most Be careful, not blocked · `WARN` = at least Be careful · `SUSP` = Suspicious or worse · `BLOCK` = the DNS filter would block it and it is rated Suspicious or worse.
- **Main set** was used while developing the rules. **Holdout set** was written after tuning and run once before any further change:
  - Initial holdout run (as measured): `URL: B15 32/36 pass   B16 36/36 pass` · `MSG: B15 8/18 pass   B16 15/18 pass`
  - The 3 holdout message misses (Taglish "I-claim mo na" + short link; refund + screen-sharing; "forward it to me" with the code in another sentence) were then fixed, so the holdout figures below (18/18) are **after** that fix and are no longer a blind result.
- These are project-written test sets. They show the rules work as designed and compare the two builds fairly; they are **not** a measurement of real-world detection or false-positive rates.

## 2. Detection results summary

| Set | Type | Cases | Pass B15 | Pass B16 | Legit cases | False alarms* B15 | False alarms* B16 | Soft cautions B15 | Soft cautions B16 | Threat cases | Detected** B15 | Detected** B16 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Main | Links | 78 | 53 | 77 | 43 | 1 | 0 | 12 | 2 | 35 | 14 | 30 |
| Main | Messages | 30 | 17 | 30 | 13 | 0 | 0 | 2 | 1 | 17 | 5 | 15 |
| Holdout | Links | 36 | 32 | 36 | 19 | 0 | 0 | 2 | 0 | 17 | 11 | 13 |
| Holdout | Messages | 18 | 8 | 18 | 8 | 1 | 0 | 0 | 0 | 10 | 1 | 9 |

*False alarm = a legitimate case rated Suspicious/Dangerous or blocked by the DNS filter. Soft caution = legitimate case rated "Be careful".
**Detected = threat case rated Suspicious or Dangerous (or DNS-blocked).

### Main set (used while developing the rules): links (78 cases)

| # | Group | Input | Expected | Build 15 | Build 16 | B15 | B16 |
|---|---|---|---|---|---|---|---|
| 1 | legit-intl | `https://www.google.co.uk/` | SAFE | SAFE | SAFE | PASS | PASS |
| 2 | legit-intl | `https://accounts.google.com/signin` | SAFE | SAFE | SAFE | PASS | PASS |
| 3 | legit-intl | `https://www.google.com.au/maps` | SAFE | SAFE | SAFE | PASS | PASS |
| 4 | legit-intl | `https://www.amazon.co.jp/` | SAFE | SAFE | SAFE | PASS | PASS |
| 5 | legit-intl | `https://www.amazon.de/gp/your-account` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 6 | legit-intl | `https://www.amazon.com.mx/` | SAFE | SAFE | SAFE | PASS | PASS |
| 7 | legit-intl | `https://www.ebay.com.au/help` | SAFE | SAFE | SAFE | PASS | PASS |
| 8 | legit-intl | `https://www.dhl.com/ph-en/home/tracking.html` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 9 | legit-intl | `https://www.fedex.com/en-us/tracking.html` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 10 | legit-intl | `https://www.ups.com/track?loc=en_US` | SAFE | SAFE | SAFE | PASS | PASS |
| 11 | legit-intl | `https://login.microsoftonline.com/` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 12 | legit-intl | `https://outlook.cloud.microsoft/mail` | SAFE | SAFE | SAFE | PASS | PASS |
| 13 | legit-intl | `https://www.paypal.com/signin` | SAFE | SAFE | SAFE | PASS | PASS |
| 14 | legit-intl | `https://www.netflix.com/login` | SAFE | SAFE | SAFE | PASS | PASS |
| 15 | legit-intl | `https://www.instagram.com/accounts/login/` | SAFE | SAFE | SAFE | PASS | PASS |
| 16 | legit-intl | `https://appleid.apple.com/` | SAFE | SAFE | SAFE | PASS | PASS |
| 17 | legit-intl | `https://www.icloud.com/` | SAFE | SAFE | SAFE | PASS | PASS |
| 18 | legit-intl | `https://www.usps.com/` | SAFE | SAFE | SAFE | PASS | PASS |
| 19 | legit-intl | `https://www.bbc.co.uk/news` | SAFE | SAFE | SAFE | PASS | PASS |
| 20 | legit-intl | `https://www.abc.net.au/news` | SAFE | SAFE | SAFE | PASS | PASS |
| 21 | legit-intl | `https://www.spiegel.de/` | SAFE | SAFE | SAFE | PASS | PASS |
| 22 | legit-intl | `https://www.yahoo.co.jp/` | SAFE | SAFE | SAFE | PASS | PASS |
| 23 | legit-intl | `https://www.gov.sg/` | SAFE | SAFE | SAFE | PASS | PASS |
| 24 | legit-intl | `https://www.ox.ac.uk/` | SAFE | SAFE | SAFE | PASS | PASS |
| 25 | legit-intl | `https://accounts.spotify.com/en/login` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 26 | legit-intl | `https://www.paypal.de/` | LOW | CAUTION | CAUTION | PASS | PASS |
| 27 | legit-intl | `https://www.metabank.com/` | LOW | SAFE | SAFE | PASS | PASS |
| 28 | legit-intl | `https://coffeeshop.store/` | LOW | SUSPICIOUS | SAFE | FAIL | PASS |
| 29 | legit-intl | `https://hotpot-recipes.com/` | LOW | CAUTION | SAFE | PASS | PASS |
| 30 | legit-intl | `https://myshop.online/` | LOW | CAUTION | SAFE | PASS | PASS |
| 31 | legit-intl | `https://example.io/` | LOW | SAFE | SAFE | PASS | PASS |
| 32 | legit-intl | `https://my-site.app/` | LOW | SAFE | SAFE | PASS | PASS |
| 33 | legit-intl | `https://example.xyz/` | LOW | CAUTION | SAFE | PASS | PASS |
| 34 | legit-intl | `https://example.com:8443/` | LOW | CAUTION | SAFE | PASS | PASS |
| 35 | legit-ph | `https://www.lazada.com.ph/` | SAFE | SAFE | SAFE | PASS | PASS |
| 36 | legit-ph | `https://www.gcash.com/` | SAFE | SAFE | SAFE | PASS | PASS |
| 37 | legit-ph | `https://www.bdo.com.ph/` | SAFE | SAFE | SAFE | PASS | PASS |
| 38 | legit-ph | `https://www.sss.gov.ph/` | SAFE | SAFE | SAFE | PASS | PASS |
| 39 | legit-idn | `https://www.münchen.de/` | LOW | SAFE | SAFE | PASS | PASS |
| 40 | legit-idn | `https://bücher.de/` | LOW | SAFE | SAFE | PASS | PASS |
| 41 | legit-idn | `https://例え.jp/` | LOW | SAFE | SAFE | PASS | PASS |
| 42 | phish-ph | `https://gcash-verify-login.example/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 43 | phish-ph | `http://bdo-online-secure.example/login` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 44 | phish-ph | `https://maya-kyc-update.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 45 | phish-ph | `https://g-cash.example/claim` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 46 | phish-ph | `https://lazada-prize-claim.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 47 | phish-intl | `https://paypal-account-verify.example/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 48 | phish-intl | `https://appleid-verify.example/signin` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 49 | phish-intl | `https://amazon-prime-renewal.example/` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 50 | phish-intl | `https://microsoft-office365-login.example` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 51 | phish-intl | `https://dhl-parcel-redelivery.example/pay` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 52 | phish-intl | `https://usps.com-track-redelivery.example/` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 53 | phish-intl | `https://netflix-billing-update.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 54 | phish-intl | `https://instagram-copyright-appeal.example` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 55 | phish-intl | `https://fedex-customs-fee.example` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 56 | phish-intl | `https://ebay-signin.example` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 57 | phish-intl | `https://paypa1.example/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 58 | phish-intl | `https://faceb00k-login.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 59 | phish-intl | `https://upss.example/` | WARN | SAFE | SAFE | FAIL | FAIL |
| 60 | lookalike | `https://www.раураl.com/` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 61 | lookalike | `https://аррӏе.com/` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 62 | lookalike | `https://xn--80ak6aa92e.com/` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 63 | lookalike | `https://gооgle.com/` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 64 | subdomain | `https://paypal.com.account-security.example/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 65 | subdomain | `https://www.google.com.evil-login.example/` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 66 | userinfo | `https://www.usps.com@serviceyuwt.sbs/TrackConfirm/` | SUSP | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 67 | userinfo | `https://paypal.com@203.0.113.7/login` | SUSP | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 68 | backslash | `https://paypal.com\@evil.example/` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 69 | encoded | `https://%70aypal-login.example/` | SUSP | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 70 | shared-host | `https://paypal-login.web.app/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 71 | ip | `http://192.168.1.10/login` | WARN | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 72 | ip | `http://3232235777/` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 73 | ip | `http://0x7f.0.0.1/` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 74 | shortener | `https://bit.ly/3abcXYZ` | WARN | CAUTION | CAUTION | PASS | PASS |
| 75 | shortener | `https://tinyurl.com/y7abc` | WARN | CAUTION | CAUTION | PASS | PASS |
| 76 | port | `http://example.com:8081/` | LOW | CAUTION | CAUTION | PASS | PASS |
| 77 | malformed | `http://` | WARN | CAUTION | CAUTION | PASS | PASS |
| 78 | malformed | `https://-bad-.com/` | WARN | SAFE | CAUTION | FAIL | PASS |

### Main set (used while developing the rules): messages (30 cases)

| # | Group | Input | Expected | Build 15 | Build 16 | B15 | B16 |
|---|---|---|---|---|---|---|---|
| 1 | scam-otp | `Good day! This is BDO customer service. To cancel the unauthorized transaction please s…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 2 | scam-otp | `Hello po, taga GCash support ito. Pakisend po yung 6-digit code na natanggap nyo para m…` | SUSP | SAFE | SUSPICIOUS | FAIL | PASS |
| 3 | scam-bank | `BPI: Your account has been locked. Verify now at https://bpi-secure-verify.example/logi…` | SUSP | DANGEROUS | SUSPICIOUS | PASS | PASS |
| 4 | scam-delivery | `LBC: Your parcel is on hold due to unpaid delivery fee. Pay PHP 45 here: https://lbc-pa…` | SUSP | DANGEROUS | SUSPICIOUS | PASS | PASS |
| 5 | scam-delivery | `USPS: The package is held at our warehouse due to an incomplete address. Update here wi…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 6 | scam-advance-fee | `Congratulations! You won ₱50,000 in the Shopee anniversary raffle. To claim, pay the ₱5…` | SUSP | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 7 | scam-job | `Hiring! Part-time job, earn ₱3,000 per day just by liking YouTube videos. Message our H…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 8 | scam-remote | `This is Maya fraud department. For your security please install AnyDesk and share the 9…` | SUSP | SAFE | SUSPICIOUS | FAIL | PASS |
| 9 | scam-apk | `Mag-update na ng app para sa bagong features. Download here: https://gcash-update.examp…` | SUSP | DANGEROUS | SUSPICIOUS | PASS | PASS |
| 10 | scam-verify | `Your Netflix membership is on hold. Please update your payment details: https://netflix…` | SUSP | DANGEROUS | SUSPICIOUS | PASS | PASS |
| 11 | scam-impostor | `Hi Ma, this is my new number. Nawala yung phone ko. Pa-send naman 3,000 sa GCash na ito…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 12 | scam-personal | `To continue your loan application please send a selfie holding your valid ID and your m…` | WARN | SAFE | CAUTION | FAIL | PASS |
| 13 | scam-giftcard | `Boss, I need you to buy 5 Google Play gift cards urgently for a client. Send me the codes.` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 14 | scam-shortlink | `You have a pending reward. Claim at https://bit.ly/3xYz12` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 15 | scam-threat | `FINAL NOTICE: A warrant will be issued for your arrest unless you settle your tax balan…` | WARN | CAUTION | CAUTION | PASS | PASS |
| 16 | scam-crypto | `Invest ₱5,000 in our crypto platform and earn 30% daily guaranteed! Send USDT to this w…` | SUSP | SAFE | SUSPICIOUS | FAIL | PASS |
| 17 | scam-nolink-intl | `Amazon security: we detected a suspicious purchase. Reply with the verification code we…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 18 | legit-otp | `Your BDO One-Time PIN is 482913. Never share this code with anyone. BDO will never ask …` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 19 | legit-otp | `482913 is your GCash authentication code. Do not share this with anyone.` | SAFE | SAFE | SAFE | PASS | PASS |
| 20 | legit-promo | `Lazada 11.11 Mega Sale is LIVE! Up to 90% off. Shop now: https://www.lazada.com.ph` | SAFE | SAFE | SAFE | PASS | PASS |
| 21 | legit-promo | `Get 20% off your next ride with Grab! Use code RIDE20. T&Cs apply.` | SAFE | SAFE | SAFE | PASS | PASS |
| 22 | legit-personal | `Uy, nasaan ka na? Kain tayo mamaya sa Jollibee, 7pm. Dala ka payong, uulan daw.` | SAFE | SAFE | SAFE | PASS | PASS |
| 23 | legit-personal | `Ma, pa-send naman po ng 500 pambili ng load. Salamat!` | LOW | SAFE | CAUTION | PASS | PASS |
| 24 | legit-work | `Hi team, the meeting is moved to 3pm. Please update the slides before then.` | SAFE | SAFE | SAFE | PASS | PASS |
| 25 | legit-advisory | `BPI advisory: We will never ask for your password or OTP via SMS, email or call. Stay s…` | SAFE | CAUTION | SAFE | FAIL | PASS |
| 26 | legit-delivery | `Your Shopee order 2311ABC is out for delivery today. Track it in the Shopee app.` | SAFE | SAFE | SAFE | PASS | PASS |
| 27 | legit-link | `Check this out haha https://www.youtube.com/watch?v=dQw4w9WgXcQ` | SAFE | SAFE | SAFE | PASS | PASS |
| 28 | legit-bill | `Reminder: your Meralco bill of PHP 2,345 is due on Nov 20. Pay via the Meralco app or a…` | LOW | SAFE | SAFE | PASS | PASS |
| 29 | legit-2fa | `To finish setting up 2-step verification, enter the code shown in your authenticator app.` | SAFE | SAFE | SAFE | PASS | PASS |
| 30 | legit-intl | `Your DHL Express shipment 1234567890 is on its way. Track it at https://www.dhl.com/` | SAFE | SAFE | SAFE | PASS | PASS |

### Holdout set (written after tuning): links (36 cases)

| # | Group | Input | Expected | Build 15 | Build 16 | B15 | B16 |
|---|---|---|---|---|---|---|---|
| 1 | legit-intl | `https://www.amazon.in/` | SAFE | SAFE | SAFE | PASS | PASS |
| 2 | legit-intl | `https://www.google.co.in/search?q=weather` | SAFE | SAFE | SAFE | PASS | PASS |
| 3 | legit-intl | `https://www.dhl.de/de/privatkunden.html` | SAFE | SAFE | SAFE | PASS | PASS |
| 4 | legit-intl | `https://support.microsoft.com/en-us/account-billing` | SAFE | SAFE | SAFE | PASS | PASS |
| 5 | legit-intl | `https://www.ebay.co.uk/` | SAFE | SAFE | SAFE | PASS | PASS |
| 6 | legit-intl | `https://www.theguardian.com/uk` | SAFE | SAFE | SAFE | PASS | PASS |
| 7 | legit-intl | `https://www.nhs.uk/conditions/` | SAFE | SAFE | SAFE | PASS | PASS |
| 8 | legit-intl | `https://www.rakuten.co.jp/` | SAFE | SAFE | SAFE | PASS | PASS |
| 9 | legit-intl | `https://www.straitstimes.com/singapore` | SAFE | SAFE | SAFE | PASS | PASS |
| 10 | legit-intl | `https://www.canada.ca/en.html` | SAFE | SAFE | SAFE | PASS | PASS |
| 11 | legit-intl | `https://shop.example-bakery.com.au/order` | LOW | SAFE | SAFE | PASS | PASS |
| 12 | legit-intl | `https://www.wikipedia.org/` | LOW | SAFE | SAFE | PASS | PASS |
| 13 | legit-intl | `https://news.ycombinator.com/` | LOW | SAFE | SAFE | PASS | PASS |
| 14 | legit-intl | `https://www.free-tutorials.net/` | LOW | CAUTION | SAFE | PASS | PASS |
| 15 | legit-intl | `https://www.mailchimp.com/` | LOW | SAFE | SAFE | PASS | PASS |
| 16 | legit-intl | `https://www.delivery-hero.com/` | LOW | CAUTION | SAFE | PASS | PASS |
| 17 | legit-ph | `https://www.philhealth.gov.ph/` | SAFE | SAFE | SAFE | PASS | PASS |
| 18 | legit-ph | `https://www.bpi.com.ph/` | SAFE | SAFE | SAFE | PASS | PASS |
| 19 | legit-ph | `https://www.rappler.com/` | LOW | SAFE | SAFE | PASS | PASS |
| 20 | phish | `https://secure-netflix-account.example/update` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 21 | phish | `https://gcash-rewards-claim.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 22 | phish | `https://dhlexpress-customs-payment.example` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 23 | phish | `https://apple-icloud-unlock.example` | BLOCK | CAUTION | SUSPICIOUS + DNS block | FAIL | PASS |
| 24 | phish | `https://office365-password-expiry.example` | BLOCK | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 25 | phish | `https://bpi-online-verification.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 26 | phish | `https://landbank-otp-update.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 27 | phish | `https://shopee-voucher-claim.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 28 | phish | `https://amaz0n-orders.example` | SUSP | SAFE | SUSPICIOUS + DNS block | FAIL | PASS |
| 29 | phish | `https://www.paypal.com.secure-login.example` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 30 | phish | `https://fedex-delivery.example` | WARN | CAUTION | CAUTION | PASS | PASS |
| 31 | phish | `https://paypal-gifts.example` | WARN | DANGEROUS + DNS block | CAUTION | PASS | PASS |
| 32 | lookalike | `https://www.fаcebook.com/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 33 | lookalike | `https://netflіx.com/` | BLOCK | DANGEROUS + DNS block | SUSPICIOUS + DNS block | PASS | PASS |
| 34 | structure | `https://apple.com@198.51.100.20/` | SUSP | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 35 | structure | `https://203.0.113.50:8080/pay` | WARN | SUSPICIOUS | CAUTION | PASS | PASS |
| 36 | structure | `https://rb.gy/abc123` | WARN | CAUTION | CAUTION | PASS | PASS |

### Holdout set (written after tuning): messages (18 cases)

| # | Group | Input | Expected | Build 15 | Build 16 | B15 | B16 |
|---|---|---|---|---|---|---|---|
| 1 | scam | `Metrobank Alert: Suspicious login detected. If this wasn't you, reply with the OTP sent…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 2 | scam | `Dear customer your SSS benefit of P15,000 is approved. Pay the release fee of P350 to r…` | SUSP | SAFE | SUSPICIOUS | FAIL | PASS |
| 3 | scam | `Congrats! Napili ka bilang winner ng ₱20,000. I-claim mo na bago mag-expire: https://bi…` | SUSP | SUSPICIOUS | SUSPICIOUS | PASS | PASS |
| 4 | scam | `Hi, I'm from Lazada HR. We offer a home-based job: rate products and earn ₱500 per task…` | SUSP | SAFE | SUSPICIOUS | FAIL | PASS |
| 5 | scam | `Your Apple ID has been locked for security reasons. Confirm your identity here: https:/…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 6 | scam | `Customs notice: your package from DHL needs a clearance fee of $2.99 before delivery. P…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 7 | scam | `To process your refund, please download our support app and allow screen sharing so our…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 8 | scam | `Please send a copy of your passport and your date of birth to complete the verification.` | WARN | SAFE | CAUTION | FAIL | PASS |
| 9 | scam | `URGENT: your GCash account will be deactivated today. Log in via this link to keep it a…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 10 | scam | `Hello, I accidentally sent my verification code to your number. Can you forward it to m…` | SUSP | CAUTION | SUSPICIOUS | FAIL | PASS |
| 11 | legit | `Your Maya verification code is 731920. It expires in 5 minutes. Never share it with any…` | SAFE | SUSPICIOUS | SAFE | FAIL | PASS |
| 12 | legit | `Hi! Your order #88231 from Shopee has been delivered. Thank you for shopping!` | SAFE | SAFE | SAFE | PASS | PASS |
| 13 | legit | `Happy birthday tita! Ingat palagi and see you sa Christmas party.` | SAFE | SAFE | SAFE | PASS | PASS |
| 14 | legit | `Your Netflix subscription will renew on Dec 1. Manage your plan anytime in the Netflix …` | SAFE | SAFE | SAFE | PASS | PASS |
| 15 | legit | `Reminder: Dental appointment tomorrow at 10:00 AM. Reply C to confirm.` | SAFE | SAFE | SAFE | PASS | PASS |
| 16 | legit | `Can you pay me back the 250 for lunch yesterday? GCash is fine.` | LOW | SAFE | SAFE | PASS | PASS |
| 17 | legit | `The class will be online today. Link is in our Google Classroom.` | SAFE | SAFE | SAFE | PASS | PASS |
| 18 | legit | `PLDT advisory: scheduled maintenance on Nov 12, 1AM-4AM. We apologize for the inconveni…` | SAFE | SAFE | SAFE | PASS | PASS |

## 3. Unit tests (122 run, 122 pass)

| # | Test | Result |
|---|---|---|
| 1 | PSL registrable www.example.co.uk | PASS |
| 2 | PSL registrable shop.example.com.au | PASS |
| 3 | PSL registrable a.b.example.ne.jp | PASS |
| 4 | PSL registrable www.ox.ac.uk | PASS |
| 5 | PSL registrable user.github.io | PASS |
| 6 | PSL registrable paypal-login.web.app | PASS |
| 7 | PSL registrable www.bdo.com.ph | PASS |
| 8 | PSL registrable login.microsoftonline.com | PASS |
| 9 | PSL registrable outlook.cloud.microsoft | PASS |
| 10 | PSL registrable x.example | PASS |
| 11 | PSL registrable www.gov.sg | PASS |
| 12 | PSL registrable www.amazon.com.mx | PASS |
| 13 | PSL registrable sub.domain.example.com.br | PASS |
| 14 | PSL shared platform web.app | PASS |
| 15 | PSL known TLD museum | PASS |
| 16 | PSL unknown TLD po | PASS |
| 17 | URL userinfo host | PASS |
| 18 | URL userinfo text | PASS |
| 19 | URL integer IP | PASS |
| 20 | URL integer IP obfuscated | PASS |
| 21 | URL hex IP | PASS |
| 22 | URL port | PASS |
| 23 | URL IPv6 | PASS |
| 24 | URL IDN punycode | PASS |
| 25 | URL IDN skeleton | PASS |
| 26 | URL IDN legit skeleton | PASS |
| 27 | URL legit IDN not mixed | PASS |
| 28 | URL mixed-script detected | PASS |
| 29 | URL encoded host decoded | PASS |
| 30 | URL backslash -> real host | PASS |
| 31 | URL scheme-less host:port | PASS |
| 32 | URL scheme-less port | PASS |
| 33 | URL non-web scheme | PASS |
| 34 | URL Japanese IDN not mixed | PASS |
| 35 | URL case+trailing dot | PASS |
| 36 | extract skips email | PASS |
| 37 | extract www link | PASS |
| 38 | extract shortener | PASS |
| 39 | extract skips Salamat.po / Mr.Smith | PASS |
| 40 | extract Unicode domain | PASS |
| 41 | extract integer-IP link | PASS |
| 42 | DNS no block metabank.com | PASS |
| 43 | DNS no block coffee | PASS |
| 44 | DNS no block amazonaws | PASS |
| 45 | DNS no block official | PASS |
| 46 | DNS no block brand+risky TLD only | PASS |
| 47 | DNS block gcash-login | PASS |
| 48 | redact OTP | PASS |
| 49 | redact password | PASS |
| 50 | redact phone | PASS |
| 51 | redact email | PASS |
| 52 | redact card | PASS |
| 53 | redact link path keeps host | PASS |
| 54 | redact keeps short amounts | PASS |
| 55 | redact idempotent | PASS |
| 56 | SHA-1 of 'password' | PASS |
| 57 | HIBP suffix match | PASS |
| 58 | HIBP suffix lowercase match | PASS |
| 59 | HIBP padded zero entry | PASS |
| 60 | HIBP prefix length | PASS |
| 61 | feed hosts line | PASS |
| 62 | feed adblock line | PASS |
| 63 | feed wildcard | PASS |
| 64 | feed comment | PASS |
| 65 | feed bare IP | PASS |
| 66 | feed localhost | PASS |
| 67 | DNS parse name | PASS |
| 68 | DNS NXDOMAIN rcode | PASS |
| 69 | DNS reply swaps ports | PASS |
| 70 | DNS IPv4 header checksum valid | PASS |
| 71 | report has title | PASS |
| 72 | report has progress 2 of 7 | PASS |
| 73 | report marks done | PASS |
| 74 | report disclaimer | PASS |
| 75 | doneCsv sorted | PASS |
| 76 | guide has steps clicked_link | PASS |
| 77 | guide has steps entered_password | PASS |
| 78 | guide has steps shared_otp | PASS |
| 79 | guide has steps installed_apk | PASS |
| 80 | guide has steps granted_permissions | PASS |
| 81 | guide has steps sent_money | PASS |
| 82 | guide has steps account_compromised | PASS |
| 83 | guide has steps sim_compromised | PASS |
| 84 | 8 incident types | PASS |
| 85 | catalogue loaded | PASS |
| 86 | brand has source Google | PASS |
| 87 | brand has source Microsoft | PASS |
| 88 | brand has source Apple | PASS |
| 89 | brand has source Amazon | PASS |
| 90 | brand has source PayPal | PASS |
| 91 | brand has source Facebook | PASS |
| 92 | brand has source Meta | PASS |
| 93 | brand has source Instagram | PASS |
| 94 | brand has source WhatsApp | PASS |
| 95 | brand has source Netflix | PASS |
| 96 | brand has source DHL | PASS |
| 97 | brand has source FedEx | PASS |
| 98 | brand has source UPS | PASS |
| 99 | brand has source USPS | PASS |
| 100 | brand has source eBay | PASS |
| 101 | brand has source GCash | PASS |
| 102 | brand has source Maya | PASS |
| 103 | brand has source BDO | PASS |
| 104 | brand has source BPI | PASS |
| 105 | brand has source Metrobank | PASS |
| 106 | brand has source Landbank | PASS |
| 107 | brand has source UnionBank | PASS |
| 108 | brand has source Security Bank | PASS |
| 109 | brand has source RCBC | PASS |
| 110 | brand has source PNB | PASS |
| 111 | brand has source China Bank | PASS |
| 112 | brand has source SSS | PASS |
| 113 | brand has source PhilHealth | PASS |
| 114 | brand has source Pag-IBIG | PASS |
| 115 | brand has source LBC | PASS |
| 116 | brand has source J&T Express | PASS |
| 117 | brand has source Shopee | PASS |
| 118 | brand has source Lazada | PASS |
| 119 | negation: do not share OTP not a request | PASS |
| 120 | request: send me the OTP | PASS |
| 121 | APK from Play Store not flagged | PASS |
| 122 | evidence quotes exact words | PASS |

## 4. Database migration test

Executed with Python's `sqlite3` (SQLite 3.53.1), using the exact SQL strings extracted from Build 15's `EventLog.onCreate` and Build 16's `EventLog.onUpgrade`/`createV2Tables`.

| Step | Result |
|---|---|
| Create Build 15 schema, insert 4 events (threat-list block, scam-message warning, live test, fake-brand block) | PASS |
| Run Build 16 upgrade v1→v2 | PASS |
| Row count before/after | PASS (4 → 4) |
| Original columns unchanged | PASS |
| Category backfill: block→`blocked`, "Scam message…"→`message`, live test→`test`, fake-brand→`blocked` | PASS |
| `incidents` table and `events_ts` index created | PASS |
| Fresh-install (v2 `onCreate`) schema accepts categorised events | PASS |
| `repeatedDomains` SQL returns the repeated domain | PASS |
| Same migration through Android's `SQLiteOpenHelper` on a device | NOT VERIFIED |

## 5. Functional test matrix

| Area | Test | Result | Evidence / note |
|---|---|---|---|
| Build | All 35 Java sources compile against Android API stubs | PASS | `out/compile.txt` |
| Build | XML resources well-formed | PASS | Python XML parser |
| Build | Gradle `assembleDebug` / `assembleRelease` | NOT VERIFIED | No Android SDK; run `debug.yml` / `build.yml` |
| DNS protection | Blocked name → NXDOMAIN packet, ports swapped, valid IPv4 checksum | PASS | Unit tests |
| DNS protection | VPN starts, filters live lookups, live-test dialog passes | NOT VERIFIED | Needs device |
| DNS protection | Status shows Stopped after VPN revoked / another VPN started | NOT VERIFIED | Logic reviewed; needs device |
| DNS protection | Private DNS (hostname) shown as coverage gap | NOT VERIFIED | Reads `private_dns_mode`; needs device |
| Threat DB | Feed line parsing (hosts, adblock, wildcard, comments, IPs) | PASS | Unit tests |
| Threat DB | Download, per-feed last-known-good, failure keeps old copy | NOT VERIFIED | Network to feeds blocked here; logic reviewed |
| Link check | International / PH / IDN / look-alike / structure cases | PASS (113/114) | §2; 1 known limitation (`upss.example`) |
| Message check | Scam and legitimate messages, EN + Taglish | PASS (48/48 after fixes; 45/48 including initial holdout) | §2 |
| Message check | Negation, official-store APK exception, evidence quoting | PASS | Unit tests |
| QR | Decode image, payment-QR detection | NOT VERIFIED | Unchanged ZXing code from Build 15 |
| Automatic alerts | Link messages and high-risk no-link requests raise alert | NOT VERIFIED | Logic reviewed; needs notification access on device |
| Password check | SHA-1, 5-char prefix, suffix compare incl. lowercase and padded zero entries | PASS | Unit tests (no network call made) |
| Password check | Live HIBP request | NOT VERIFIED | Network blocked |
| Device audit / Gap Analyzer | Checks, states, confirmations, progress | NOT VERIFIED | Needs device; compile-checked |
| Protection PIN | Set, verify, 5-try lockout | NOT VERIFIED | Needs device |
| Custom rules | Normalise, block, allow, remove | NOT VERIFIED | Code unchanged except UI |
| History | Categories, filters, weekly summary, clear | PASS (SQL) / NOT VERIFIED (UI) | Migration + query test |
| Recovery Center | Guides complete (8 types, ≥4 steps each), report text, step CSV | PASS | Unit tests |
| Recovery Center | Save, share, delete, secrets guard on device | NOT VERIFIED | Needs device |
| AI privacy | Redaction of codes, passwords, phones, e-mails, cards, link paths; idempotent | PASS | Unit tests |
| AI privacy | Consent dialog shows redacted text; chat shows removed count | NOT VERIFIED | Needs device |
| AI | Worker communication, errors, rate limit | NOT VERIFIED | Worker not in repository |

## 6. UI test matrix

| Check | Result |
|---|---|
| Single navigation system; no duplicate History shortcut; no hamburger | PASS (code review: header has back + title + ⋮ only) |
| Overflow menu holds only pages not reachable elsewhere | PASS (code review) |
| No decorative-only buttons left (Build 15 stat cards removed) | PASS (code review) |
| Status always symbol + word + colour | PASS (code review: `Ui.badge`, `Ui.banner`, `Ui.statusDot`) |
| Status text contrast ≥ 4.5:1 on white, page background and tints | PASS (computed, 4.75–7.03) |
| All text sizes in sp; touch targets ≥ 48 dp | PASS (code review) |
| Layout on small screens, font scale 1.3–2.0, TalkBack reading order, keyboard behaviour, no clipping/overlap | NOT VERIFIED (needs device) |
| Screenshots of redesigned screens | NOT PRODUCED (no emulator) |

### Device test checklist (run after the CI build)
1. Install over Build 15 (release build, same key): history, rules, PIN and settings still present.
2. Shield: turn on → *Protection is on*; set Private DNS to a provider → *On, with gaps*; start another VPN → *Protection stopped*.
3. Run *Malware test* and *Fake-site test*.
4. Check tab: paste each message from `cases/messages.tsv`; confirm the five result sections and quoted evidence.
5. Device tab: toggle USB debugging and confirm the state changes after returning to the app; confirm/undo Play Protect.
6. Recovery Center: create a report, tick steps, share it, delete it.
7. Font size at maximum and display size at largest: no clipped text on every tab.
8. TalkBack: navigate each tab; badges read as words.
9. Capture screenshots of Shield, Check (a Suspicious result), Device, History and a Recovery checklist.
