# SafeSphere Build 16 — Manuscript Consistency and Defense Preparation

## A. Manuscript status

The manuscript was **not included** in the uploaded files (only the Build 15 source as `.tar.gz` and an identical `.zip`, and the APK). Nothing in the manuscript has been changed, and no experimental findings have been written. The items below are based on the application itself and on the inconsistency you described.

### A.1 Reported scope inconsistency

You noted that the **Out of Scope** section excludes the integrated AI assistant and third-party application-lock functionality, while other sections describe them as implemented.

What the code shows (Build 15 and Build 16):
- **AI assistant: implemented.** `AiClient`, `AiSetup`, `AiChatActivity`; Check tab "AI explanation (optional)". It depends on an external Cloudflare Worker that is not part of the repository.
- **App lock for other apps: implemented.** `AppLock`, `AppLockService`, `LockActivity`; Device → App lock. It uses Usage access and Display-over-other-apps.

So the Out of Scope statement is the part that disagrees with the implementation. Options for the authors: (a) move both into scope and describe them as optional/supporting features, or (b) keep them out of the evaluated scope but say they exist as supplementary features that were not formally evaluated. Either way the manuscript should say one thing consistently.

### A.2 Sections that will likely need updating for Build 16

Check each against your manuscript's actual headings:

| Topic | What changed in Build 16 |
|---|---|
| Title page / abstract / objectives | Before You Act (requested-action analysis), Protection Gap Analyzer, Recovery Center, international brand detection, Security Activity. |
| Scope and limitations | Resolve A.1. Add: DNS-only coverage, IPv4 UDP DNS, no OCR, user-confirmed settings, catalogue-limited brand detection, rule-based message analysis, no on-device test in Build 16 yet. |
| Review of related systems | Position SafeSphere as complementing Play Protect / Safe Browsing (see Q1–Q2), not replacing them. |
| System architecture / block diagram | New components: `UrlInfo`, `PublicSuffix` (+PSL asset), `BrandCatalog` (+brands.tsv), `ActionAnalyzer`, `Redactor`, `ProtectionState`, `RecoveryGuide`/`RecoveryPage`, `CheckPage`; per-feed threat storage; `incidents` table. |
| Algorithms | Link scoring rewritten (weights and thresholds in `ScamDetector.analyze`); DNS fake-brand rule now needs a brand plus a strong signal; message analysis now identifies requested actions with negation handling. |
| Data dictionary / ERD | `events.category` column; new `incidents` table; DB version 2 with migration. |
| Security score | Renamed **Security setup progress**; formula: (Verified + Confirmed by you) ÷ applicable checks. Remove any claim that it measures security. |
| UI design / screenshots | Replace all Build 15 screenshots; describe the colour system, status labels and single navigation. |
| Privacy and ethics | AI consent with preview, redaction list, what leaves the phone, local-only storage, no message text stored. |
| Testing methodology and results | Use only results you actually ran. The Build 16 JVM test matrices are internal verification, not user evaluation. Any ISO 25010 / user-acceptance results must come from your own testing of Build 16 on devices. |
| Threat intelligence | Per-feed last-known-good copies, freshness levels, feed attribution. |
| Recommendations / future work | OCR for screenshots, more brands (verified), additional languages, server-side AI rate limiting and token rotation, Play Store permission declaration. |

---

## B. Likely panel questions — answers based on the actual implementation

**1. How is SafeSphere different from Google Play Protect?**
Play Protect scans **apps** for malware (Google Play services, cloud-backed). SafeSphere does not scan app code. It works on a different layer: it filters **website name lookups (DNS)** through a local VPN against downloaded threat lists and its own fake-brand patterns, explains **risky requests in messages** before the user acts, reviews the phone's **protection settings** (including whether Play Protect is on, which the user confirms), and guides **recovery** after an incident. The app says it complements Play Protect and never claims to replace it.

**2. Why would users need SafeSphere when Android already has built-in security?**
Built-in tools mostly catch malicious apps and, inside Chrome, malicious pages. Most scams in our target setting are social engineering: an SMS or chat asking for an OTP, a "release fee", or a remote-access app, often with no link at all. Android has no built-in feature that reads a pasted message and explains "this asks you to share an OTP; banks never do that". SafeSphere also applies DNS filtering to **all apps** (not only Chrome), shows which protections are actually on, and gives a recovery checklist after something goes wrong.

**3. How are international phishing links detected?**
In layers (`ScamDetector.analyze`):
1. The link is parsed like a browser would (`UrlInfo`): the real host after `@` tricks, numeric/hex IPs, percent-encoded hosts, backslashes, Unicode names converted with `java.net.IDN`.
2. The registrable domain is found with the Mozilla **Public Suffix List**, so `example.co.uk`, `example.com.au`, `user.web.app` are read correctly.
3. **Threat lists** (URLhaus, Phishing Army, HaGeZi TIF) are checked for the host and its parent domains — a confirmed match.
4. **Brand impersonation**: 33 brands with verified official domains in `assets/brands.tsv` (e.g. Microsoft's endpoint list, DHL/FedEx/UPS/PayPal/eBay fraud pages, Google's published country-domain list). A brand name on a non-official domain, a disguised spelling (`faceb00k`), a typo (`paypall`) or a homograph (`раураl.com` with Cyrillic letters, detected by mixed-script and look-alike "skeleton" checks) raises the score.
5. Structure signals: shorteners, unusual ports, many sub-levels, long hyphenated names, often-abused endings (small weight only).
The DNS filter blocks automatically only on a threat-list match, the user's rule, or a brand plus a strong credential/payment word (e.g. `paypal-account-verify.example`).

**4. How are false positives controlled?**
- Official domains of catalogued brands are recognised, including documented country sites (`google.co.jp`, `amazon.de`).
- Scam words must be whole words (Build 15 flagged "coffee" for "fee").
- Without a brand name, only the domain owner's own label counts, so `accounts.spotify.com` isn't flagged.
- A foreign or unfamiliar ending is never enough to warn strongly or block; "often abused" endings add one point only.
- One-letter brand typos no longer auto-block (Build 15 blocked the real bank `metabank.com`).
- Messages: negation handling ("Do not share this OTP" is not a request); app-store download instructions are not treated as APK requests.
- Results separate **Confirmed** (threat list) from **SafeSphere's judgment** and **warning signs only**; users can allow a site (PIN-protected).
- Measured on our test sets: 0 false alarms on 83 legitimate cases in Build 16 vs 2 in Build 15 (internal test sets, not field data).

**5. How does the DNS firewall work?**
`SafeSphereVpnService` creates a local VPN with one route: a virtual DNS server address (10.111.222.2), set as the phone's DNS server. Only DNS packets enter the tunnel; normal app traffic goes straight to the internet. For each IPv4/UDP DNS query, `DnsPacket` reads the name and `RuleStore.check` decides: allowed list → forward; DoH-bypass hostname, user block, test zone, threat list or fake-brand pattern → reply **NXDOMAIN** ("doesn't exist") so the app never connects. Allowed queries go to Cloudflare DNS-over-HTTPS (1.1.1.1), falling back to plain DNS 1.1.1.1 / 8.8.8.8 / 9.9.9.9 through a protected socket.

**6. Why does it need VPN permission?**
Android only lets an ordinary app see DNS lookups from other apps through the VpnService API. The system shows a consent dialog and a key icon while it is active. SafeSphere uses it only to receive DNS packets; it does not route, store or inspect other traffic.

**7. What happens when another VPN is active?**
Android allows one VPN at a time. Before starting, SafeSphere checks for an active VPN network and warns that starting will disconnect it. If another VPN takes over while SafeSphere runs, Android calls `onRevoke`; SafeSphere logs it, stops, and the Shield shows **Protection stopped** — never a false "Protected". The Device tab also reports "Other VPN apps".

**8. How does notification access affect privacy?**
It is optional and off until the user grants it in Android settings. The listener reads the text of new **message** notifications (SMS, chat, e-mail apps) on the phone, runs the same local checks, and alerts only on a dangerous link or a clear high-risk request (OTP, password, remote access, APK). Message text is never saved or sent; History stores only the app name, website name and a short reason; the status card keeps only the last app name, website name and verdict. Limits: hidden previews, muted chats and cut-off long messages can't be checked.

**9. What information is sent to external AI services?**
Nothing unless the user taps "Get AI explanation" (or uses the optional AI chat) **and** agrees. Before sending, `Redactor` removes OTP-like codes, PINs/passwords written in the text, card/account/phone numbers, e-mail addresses and link paths (the website name is kept). The consent dialog shows the exact text and what was removed. SafeSphere's own local verdict is sent with it. The request goes to the SafeSphere AI server (a Cloudflare Worker holding the provider key) and on to Google Gemini or Anthropic Claude depending on the server's setup. Names can't be removed automatically, and the dialog says so. The AI answer is labelled an opinion and never changes the local result or blocks anything. Note: the app token used to reach the Worker is compiled into the APK and is therefore not a secret; the server must rate-limit.

**10. How does password breach checking protect the original password?**
`PasswordCheck` computes the SHA-1 hash on the phone and sends only the **first 5 hex characters** to `api.pwnedpasswords.com/range/{prefix}` with the `Add-Padding` header. The service returns all hash suffixes in that bucket (hundreds, padded with fake zero-count entries); the phone compares the remaining 35 characters locally. The password and full hash never leave the phone, and the typed password is cleared from the field.

**11. How does the Recovery Center work?**
The user picks one of 8 situations (clicked a link, entered a password, shared an OTP/MPIN, installed an APK, granted permissions, sent money, account compromised, SIM compromised). SafeSphere shows an ordered checklist with shortcuts to the right Android settings, tracks completed steps, and lets the user write an incident report (time, sender/website, description, actions taken, steps done). It is stored only on the phone and can be shared as text. SafeSphere never contacts banks or authorities. It lists no bank numbers; the only hotline shown is the Philippines' I-ARC 1326.

**12. How does SafeSphere verify built-in phone protections?**
It reads what Android exposes — screen lock (`KeyguardManager`), patch date, Android version, USB debugging and developer options, Private DNS mode, installed remote-control apps, enabled accessibility services, app installers, VPN state, battery/background restriction — and labels those **Verified**. Play Protect, Chrome Safe Browsing and per-app "Install unknown apps" are **not readable by other apps**, so SafeSphere shows a guide and a settings shortcut and records them as **Confirmed by you** (expires after 90 days), never as Verified. "Security setup progress" counts Verified + Confirmed out of the applicable checks and is explained as a checklist, not a security score.

**13. What happens when threat feeds are unavailable?**
Each feed is saved separately. If a download fails, that feed's previous copy stays in use and its error is shown on the Threat intelligence page. If nothing was ever downloaded, protection still runs with the user's rules, DoH-bypass blocking and the fake-brand patterns, and the Shield shows *On, with gaps*. Lists older than 7 days are flagged as out of date.

**14. What can't the application detect?**
Content of web pages; anything inside encrypted connections; apps using their own encrypted DNS or connecting by IP; traffic while another VPN is active or protection is off; malicious app code (that's Play Protect's job); brands not in the catalogue until a feed lists the site; well-paraphrased or non-English/Filipino scam messages; text inside screenshots (QR only); messages whose notification preview is hidden; root that is deliberately hidden. The in-app *About & limitations* page lists these.

**15. How was the application tested?**
Be precise about which build each result belongs to.
- **Build 16 (internal verification, `tools/verification/run_all.sh`):** compile check of all sources against Android API stubs; 122 unit tests (all pass); SQLite migration test from the Build 15 schema; link and message matrices comparing Build 15 and Build 16 on the same inputs (main set: links 53→77 of 78, messages 17→30 of 30; holdout run once before changes: links 32→36 of 36, messages 8→15 of 18, then the 3 gaps were fixed). All malicious examples use reserved `.example` domains.
- **Not yet done for Build 16:** building the APK, on-device functional and UI testing, usability or acceptance testing. Report only results you actually obtain from those tests.
