# SafeSphere Build 16 — Engineering Report

Package `com.nekowishy.safesphere` · versionCode 16 · versionName 1.16 · minSdk 26 · targetSdk 33 · Java, native Android Views (no framework change)

This report covers what was inspected in Build 15, what was changed in Build 16, how it was verified, and what is still unverified. Every claim about testing refers to a test that was actually run; anything that could not be run is marked **NOT VERIFIED**.

---

## 0. Build environment and what could not be done here

| Item | Status |
|---|---|
| Build 16 source code | Delivered (`SafeSphere-build-16-source.zip`, same repository layout as Build 15). |
| Compile check of all 35 Java files | **Done** against compile-only Android API stubs (`tools/verification/gen_stubs.py`). Zero errors. |
| Debug APK | **NOT BUILT.** This workspace has no Android SDK, and its network blocks Google's Maven/SDK servers (HTTP 403), so Gradle/AAPT2/D8 could not run. A new GitHub Actions workflow (`.github/workflows/debug.yml`) builds a debug APK without secrets; the existing `build.yml` still builds the signed release. |
| Running on a phone/emulator | **NOT VERIFIED.** No emulator or device was available. |
| Screenshots | **Not produced.** Without an emulator there are no real screenshots, and mock-ups would misrepresent the app. Capture them after the CI build (Shield, Check result, Device, History, Recovery Center). |
| Manuscript | **Not received.** Only the Build 15 `.tar.gz`, an identical `.zip`, and the APK were uploaded. See §9. |

The stub compile check proves the code is type-correct Java against the Android API signatures it uses; it does not prove resources link, that layouts look right, or that runtime behaviour on a device is correct. Those need the CI build plus a device test pass (checklist in `TEST_MATRIX.md` §5).

---

## 1. Inspection of Build 15

### 1.1 Architecture

A single-activity app with all UI built in Java code (no XML layouts). Main pieces:

| Area | Classes | Notes |
|---|---|---|
| Navigation and all screens | `MainActivity` (2,087 lines) | Bottom bar with 5 tabs plus hidden sub-pages (Checkup, App lock). |
| Design system | `Ui`, `Bevel`, `OrbView`, `ShieldView`, `PowerView`, `LogoView`, `BarsView`, `NavIcon` | "Bevelled glass": gradients, glows, embossed shadows, spring and 3-D entrance animations. |
| DNS firewall | `SafeSphereVpnService`, `DnsPacket`, `RuleStore` | Local VPN routing only a virtual DNS server address; UDP/IPv4 DNS parsed, NXDOMAIN for blocked names, others forwarded (DoH to 1.1.1.1, fallback UDP 1.1.1.1/8.8.8.8/9.9.9.9). |
| Threat intelligence | `ThreatDb` | URLhaus (malware-filter mirror), Phishing Army, HaGeZi TIF mini; up to 250,000 domains in memory. |
| Link and message checks | `ScamDetector` | Regex link extraction, 22 PH-centric brand profiles, keyword scoring. |
| QR | `QrReader` | ZXing decoding from an image (no live camera). EMVCo/QR Ph payment codes recognised. |
| Automatic alerts | `ScamMessageWatcher`, `Alerts` | Notification listener; alerts only for messages containing links. |
| Password check | `PasswordCheck` | HIBP range API, k-anonymity, Add-Padding. |
| AI | `AiClient`, `AiSetup`, `AiChatActivity` | Calls a Cloudflare Worker (not in the repository). |
| Device | `DeviceAudit`, `AppScanner`, `Checkup`, `WifiGuard` | Settings audit, permission scan, manual account checklist, Wi-Fi security. |
| App lock and PIN | `AppLock`, `AppLockService`, `LockActivity`, `Prefs` | Usage-stats polling + overlay; PIN = salted SHA-256 × 10,000. |
| History | `EventLog` | SQLite `events(ts, domain, reason)`. |

### 1.2 What worked, what was partial, what was only in the interface

| Function | Build 15 status | Evidence |
|---|---|---|
| DNS filtering, custom rules, live test | Working (code-complete) | Logic traced end to end. Covers IPv4 UDP DNS only. |
| Threat feed download | Working, **with a data-loss bug** | A failed feed was silently dropped from the merged file at the next update. |
| Link checker | Partial | Missed Unicode domains entirely (regex was ASCII-only); no numeric-IP forms; registrable-domain logic knew only 6 second-level endings; false positives from substring matching. |
| Brand impersonation | Partial, Philippines-only | 22 profiles; Google, Microsoft, Apple, Amazon, DHL, FedEx, UPS, USPS, eBay, Instagram, WhatsApp missing. `amazon-prime-renewal.example` rated *No threats found*. |
| Message checker | Partial | Keyword categories only; did not identify what the sender was asking for; no negation ("Do **not** share your OTP" counted as an OTP request). |
| Automatic scam alerts | Working for link messages only | No-link OTP/remote-access requests ignored. |
| QR checking | Working (image only) | — |
| Password breach check | Working and correct | SHA-1 prefix handling verified in §7 tests. |
| AI explainer and chat | Working only if the external Worker is set up | **Security issue:** the APK contains a 43-character app token in `BuildConfig.AI_TOKEN` (confirmed by parsing the uploaded APK's DEX). Clipboard chips sent clipboard contents to the AI with no preview or redaction. |
| Device audit + "Security score" | Working, **misleading score** | A 0–100 score mixing protection state, settings, manual ticks and threat-DB presence, labelled "Well protected / At risk". Not a validated measure. |
| Account checkup | Working (manual ticks) | Its "This phone" items duplicated the device audit. |
| App lock, protection PIN | Working | PIN dialog had no wrong-attempt limit (the lock screen did). |
| History | Working | `onUpgrade` dropped the table, so any schema change would have wiped history. |
| Statistic cards on dashboard | **UI only** | Tappable with a spring animation but did nothing (`setOnClickListener(Ui::tap)`). |
| Header "History" icon | **Duplicate** | Same action as the History tab. |
| Header "hamburger" icon | **Misleading** | Opened the Device tab, not a menu. |
| Protection status copy | Overclaimed | "Checking every domain lookup from every app"; notification said "Blocking dangerous sites in every app". |

### 1.3 Why international links were misjudged (diagnosis)

All three causes the brief asked about were present:

1. **Parsing problems.** Unicode/IDN domains were never extracted (ASCII-only regex), so homograph links like `раураl.com` were invisible. Integer/hex IP hosts (`http://3232235777/`) weren't recognised. The registrable domain (`example.co.uk`) was guessed from a 6-entry list, so endings like `ne.jp`, `ac.uk`, `com.br` and hosting platforms like `web.app` were cut wrongly.
2. **Missing brand profiles.** Only 22 mostly Philippine brands. International impersonation without a scam keyword went undetected.
3. **Heuristics that misfired on legitimate international sites.** Scam words matched inside other words (`fee` in *coffee*, `otp` in *hotpot*), common endings such as `.shop`, `.online`, `.live` scored +2, and words in the path counted even on official sites (DHL/FedEx tracking pages became *Be careful*). One-letter brand typos auto-blocked at DNS level, so **`metabank.com`, a real US bank, was blocked as a fake Metrobank**.

Threat intelligence itself (the three feeds) was not the main problem; it is unchanged in Build 16 apart from reliability fixes.

---

## 2. UI/UX redesign

**Direction:** flat, quiet, Settings-like. No gradients, glows, glass, bevels, decorative circles, 3-D or spring animations, or letter-spaced uppercase.

| Element | Build 15 | Build 16 |
|---|---|---|
| Surfaces | Gradient page, bevelled raised cards, coloured shadows | `#F5F7FA` page, white cards with a 1 dp `#E4E7EC` border, 12 dp corners, no elevation |
| Type | Mixed light/medium, 10–40 sp, uppercase labels with tracking | One scale: page 22, card title 16, body 14, support 13, label 12 sp (Roboto regular/medium). All in sp, so font scaling works. |
| Colour | 12 ad-hoc accents (cyan, lime, pink, violet...) | The brief's palette, one source (`Ui.java`). Status colours darkened slightly so text on tints meets WCAG 4.5:1 (measured: 4.75–6.19). |
| Buttons | Glowing gradient pills | Filled primary (`#245A73`), outlined secondary, text links; ripple feedback; minimum 48 dp height |
| Status | Colour, sometimes with ✓/⚠ | Always symbol + word + colour (`✓ Verified`, `! Needs attention`, `? Suspicious`, `✕ Dangerous`, `i Confirmed by you`, `– Unavailable`) |
| Navigation | Bottom bar + duplicate History icon + hamburger that opened Device | Bottom bar only (Shield · Check · Rules · History · Device). Header: page title, back arrow on sub-pages, ⋮ menu with only *Privacy & permissions* and *About & limitations* (not reachable anywhere else). |
| Animations | Staggered 3-D entrance on every screen, spinning shield, springy taps, growing bars | None, except a short shake on invalid input |
| AI chat | Dark navy theme with animated orb | Same light theme as the app; answers labelled "AI opinion" |

**Semantic colour system** (`Ui.T_*`): green = active/verified, amber = attention, orange = suspicious, red = dangerous/blocked, blue = information/user-confirmed, grey = off/unavailable/unverified. Applied to dashboard, Check results, link rows, Device checks, History badges, Wi-Fi, threat-feed status, password result, AI result and notifications (`setColor`). Android lets users restyle notification channels, so notification colour is only a hint.

**Accessibility work:** content descriptions on icon buttons, chips and checkboxes; headings marked for screen readers (Android 9+); decorative icons hidden from TalkBack; the 7-day chart has a spoken summary; touch targets ≥48 dp.

---

## 3. New and improved features

### 3.1 Before You Act (signature feature) — `ActionAnalyzer`, `CheckPage`
- Works on SMS, chat and e-mail text, links, QR contents, payment instructions and shared/selected text ("Check with SafeSphere" share target and text-selection menu were kept).
- Identifies **what the sender wants you to do** — 9 request types (share OTP/MPIN, enter credentials, send money, pay an advance fee, install an APK, install remote-access/share screen, send personal information, open a shortened link, verify/claim/pay through a link) — plus supporting signs (urgency/threats, prize, too-good job/investment, refund story, move to another app, "new number" impostor, claimed brand/institution).
- Output in five parts: **Risk assessment** (No risky requests / Requires caution / Suspicious indicators / Dangerous), **What it asks you to do**, **Warning signs** with the **exact words quoted**, **Why it matters**, **What to do**; plus "Already acted on it? → Recovery Center".
- Handles negation ("Do not share this OTP", "BPI will never ask for your password") so genuine OTP and advisory texts are not flagged; genuine OTP messages get an explanatory note instead.
- English and common Filipino/Taglish phrasing.
- Screenshots: QR codes are decoded; other text in screenshots is **not** OCR'd (no on-device OCR library is available without a new Google dependency). The screen explains how to copy text from a screenshot with Android's text selection or Google Lens.
- Fully local. Nothing is stored; History records only the verdict, request types and worst website name.

### 3.2 Protection Gap Analyzer — `DeviceAudit`, Device tab
17 checks in four groups, each labelled by **how the result was obtained**:

| State | Meaning |
|---|---|
| Verified | Read from Android (screen lock, patch date, Android version, root indicators, USB debugging, developer options, Private DNS mode, remote-control apps, accessibility services, apps from outside stores, SafeSphere VPN, other VPN, notification access, background restriction) |
| Needs attention | A readable setting is weak (red if serious, amber otherwise) |
| Confirmed by you | Settings Android does not expose to apps: **Google Play Protect**, **Chrome Safe Browsing**, **Install unknown apps** (per-app state). Shown with a guide and a settings shortcut; confirmation expires after 90 days. Never shown as "Verified". |
| Unavailable | Not applicable or not reported (e.g. Chrome not installed, Private DNS unreadable) |
| Not checked | Not yet confirmed / optional feature off |

The old "Security score" is replaced by **Security setup progress** = (Verified + Confirmed) ÷ (checks that apply), with an in-app explanation that it is a setup checklist, not a measured security level. Changes in device issues are written to History ("Needs attention: …" / "Resolved: …").

### 3.3 Recovery Center — `RecoveryGuide`, `RecoveryPage`
- The 8 incident types from the brief, each with an ordered checklist (5–7 steps) and shortcuts to the relevant Android screens (app list, accessibility, unknown sources, Play Protect, downloads, notification access).
- Progress saved per incident; marking steps logs Recovery events.
- **Incident Evidence Report**: category, date/time (picker), sender/website, description, actions taken, completed/pending steps; saved locally (`incidents` table) and shared as plain text through Android's share sheet. Never sent automatically.
- Secrets guard: if the description contains something that looks like a code or "password: …", saving is paused and the user can remove it.
- Contacts: no bank or e-wallet numbers are listed (they vary and change). Steps point to the official app or the number on the user's card. The one hotline shown, **Philippines I-ARC 1326 (CICC)**, was confirmed from CICC statements reported by PNA, ABS-CBN and the Inquirer.

### 3.4 International threat detection — `UrlInfo`, `PublicSuffix`, `BrandCatalog`, `ScamDetector`
- **Parsing:** browser-like parsing of scheme, user-info (`@` trick), ports, IPv6 literals, percent-encoded hosts, backslashes, full-width dots; WHATWG IPv4 rules (decimal, hex, octal, integer forms); IDN via `java.net.IDN`; mixed-script detection with `Character.UnicodeScript`; a "skeleton" with common Cyrillic/Greek look-alikes mapped to Latin for homograph matching.
- **Domain structure:** Mozilla Public Suffix List bundled as an asset (MPL-2.0), with private-section awareness (`web.app`, `github.io`, `workers.dev`) to flag brand names hosted on free platforms.
- **Brand catalogue (`assets/brands.tsv`):** 33 brands — 15 international (Google, Microsoft, Apple, Amazon, PayPal, Facebook, Meta, Instagram, WhatsApp, Netflix, DHL, FedEx, UPS, USPS, eBay) and the 18 Philippine brands kept from Build 15 (Build 15's PayPal, Facebook and Netflix entries moved to the international group). Each row names its verification source (the brand's own fraud/help page, Google's published domain list, Microsoft's endpoint list) or "B15" if carried over. Country-site families (`google.<cc>`, `amazon.co.<cc>`, `ebay.com.<cc>`, `dhl.<cc>`) are supported for brands documented to use them.
- **False-positive controls:** scam words match whole words only; outside a brand name, only words in the owner's own label count (`accounts.spotify.com` is fine); an often-abused ending adds only +1 and never blocks by itself; HTTPS is never treated as proof of safety; a brand typo alone no longer blocks; IDN domains that literally contain the brand word are not treated as homographs (`amazonía`).
- **Honesty in results:** *Confirmed* (on a threat feed — the feed names are shown — or the user's own block list) is shown separately from *SafeSphere's own judgment* (fake-site pattern) and *warning signs only*.
- **DNS path performance:** compiled regexes and a 1,024-entry LRU cache for `fakeBrand`.

### 3.5 Threat intelligence management — `ThreatDb`, Threat intelligence page
Per-feed last-known-good files; per-feed status (last success, last attempt, domain count, last error); freshness (Up to date < 2 days, A few days old < 7, Out of date ≥ 7, Not downloaded); matches name the feed(s) that list the domain; Build 15's merged file is migrated and kept until every feed has its own copy. No new feeds were added (none could be vetted for licence, reliability and format from this environment).

### 3.6 Security Activity — `EventLog` v2, History tab
Categories: Blocked, Message warning, Check, Protection, Device, Recovery, Test. Filters by category; a local weekly summary (sites blocked, warnings, checks, repeated threat domains, unresolved device issues, last protection change) that can be hidden; history clearing (PIN + confirmation) keeps incident reports. **Database migration** adds a column and backfills categories without deleting rows (Build 15 dropped the table on upgrade).

### 3.7 Honest protection status — `ProtectionState`, VPN service
States: On · On with gaps · Off · **Stopped** (shown when protection was on but the service is no longer running or Android/another VPN revoked it). Gaps listed: Private DNS bypass, threat lists missing or older than 7 days, DNS servers unreachable (≥5 consecutive failures). Another active VPN is detected before starting, with a warning that Android allows one VPN at a time. A plain-language "What does protection cover?" explains the limits. Protection on/off/interruption events are logged.

### 3.8 AI privacy — `Redactor`, `AiSetup`, `AiClient`, `AiChatActivity`
- Per-request consent in Check: a dialog shows the **exact redacted text** to be sent, the server host, and what was removed; Cancel sends nothing.
- `Redactor` removes OTP-like codes, PINs/passwords written as "password: …", card/account/phone numbers, e-mail addresses and link paths/queries (keeping the website name). Applied again inside `AiClient` (defence in depth) and to every chat message; the chat shows "Removed before sending: N items".
- Clipboard shortcuts no longer send clipboard contents automatically.
- Client-side limit of 6 AI requests per minute.
- AI output is labelled "AI opinion, not a verified verdict"; it never blocks a site or changes SafeSphere's local result (it never did; now it is stated).

---

## 4. Bugs and weaknesses fixed

1. Threat-feed update discarded a failed feed's previous data → per-feed last-known-good copies.
2. `EventLog.onUpgrade` dropped all history → in-place migration (tested, §7).
3. `metabank.com` (a real bank) auto-blocked as fake Metrobank; any one-letter brand typo auto-blocked → typos need a second strong signal to block.
4. Substring scam-word matches (`coffee`, `hotpot`) → whole-word matching.
5. Official international sites rated *Be careful* (DHL/FedEx tracking, `login.microsoftonline.com`, `accounts.google.co.uk`) → verified brand catalogue and owner-label rule.
6. Unicode domains never extracted from messages → Unicode-aware extraction.
7. Numeric/hex IP hosts, `%`-encoded hosts, backslash tricks not parsed → `UrlInfo`.
8. Registrable domain wrong for most ccTLD second levels → Public Suffix List.
9. "Do not share this OTP" counted as an OTP request → negation handling.
10. No-link scam messages never alerted → alerts for high-confidence requests (OTP, credentials, remote access, APK).
11. Protection PIN dialog allowed unlimited guesses → 5 attempts then 30 s lockout.
12. Dashboard stat cards were tappable but did nothing → removed.
13. Duplicate History shortcut and misleading hamburger → removed; real overflow menu.
14. "Security score" presented as a security level → Security setup progress with formula.
15. Overclaiming copy ("every domain lookup from every app", "Blocking dangerous sites in every app") → accurate wording.
16. AI chat chips sent clipboard text straight to the AI → user must paste and send.
17. Account checkup duplicated device checks → those moved to the Gap Analyzer only.
18. `setAccessibilityHeading` would have crashed on Android 8 if used unguarded → guarded (caught during review).
19. Hyphen count used punycode (`xn--…`), flagging German IDNs as "long hyphenated" → counted on the readable form (caught by tests).

---

## 5. Files

**Added (12):** `ActionAnalyzer.java`, `BrandCatalog.java`, `CheckPage.java`, `ProtectionState.java`, `PublicSuffix.java`, `RecoveryGuide.java`, `RecoveryPage.java`, `Redactor.java`, `UrlInfo.java`, `res/values/themes.xml`, `assets/brands.tsv`, `assets/public_suffix_list.dat`; plus `tools/verification/` (test suite), `.github/workflows/debug.yml`, `docs/`.

**Modified (25):** `MainActivity`, `ScamDetector`, `ThreatDb`, `EventLog`, `DeviceAudit`, `SafeSphereVpnService`, `ScamMessageWatcher`, `Alerts`, `AiClient`, `AiSetup`, `AiChatActivity`, `LockActivity`, `Ui`, `NavIcon`, `BarsView`, `Prefs`, `RuleStore`, `Checkup`, `AppScanner`, `PasswordCheck`, `AppLockService`, `AndroidManifest.xml`, `app/build.gradle` (version 16 / 1.16, token comment), `res/values/colors.xml`, `res/drawable/ic_launcher_fg.xml`.

**Removed (5, decorative only):** `Bevel`, `OrbView`, `ShieldView`, `PowerView`, `LogoView`.

**Unchanged:** `DnsPacket`, `QrReader`, `AppLock`, `WifiGuard`, `BootReceiver`, `ic_notify.xml`, `settings.gradle`, root `build.gradle`, `gradle.properties`, `.github/workflows/build.yml`. Gradle plugin 8.5.2, compile SDK 34, target 33, ZXing 3.5.3: no dependency added or removed.

**Data preservation:** package name and signing setup unchanged; versionCode 16 > 12 so a release build signed with the original key installs over Build 15 and keeps rules, PIN, settings, threat lists (migrated) and history (migrated).

---

## 6. Permissions review

No permission was added or removed. Every permission is still used:

| Permission | Used by | Kept because |
|---|---|---|
| INTERNET | Feeds, HIBP, AI, DoH | Core |
| ACCESS_NETWORK_STATE | Wi-Fi check, other-VPN detection | Core |
| FOREGROUND_SERVICE | VPN, App lock | Required by Android |
| POST_NOTIFICATIONS | Alerts | Core |
| QUERY_ALL_PACKAGES | App scan, remote-app and accessibility checks | Needed to see installed apps; note Google Play restricts this permission and would require a declaration if published there |
| RECEIVE_BOOT_COMPLETED | Restart protection | Core |
| PACKAGE_USAGE_STATS, SYSTEM_ALERT_WINDOW | App lock only | User-granted special access |
| BIND_VPN_SERVICE / BIND_NOTIFICATION_LISTENER_SERVICE | Service bindings | User-granted |

Not requested: contacts, SMS database, call logs, location, accessibility service, storage. The in-app *Privacy & permissions* page lists all of this plus what leaves the phone.

---

## 7. Verification summary (details in `TEST_MATRIX.md`)

| Test | Result |
|---|---|
| Compile all sources against Android API stubs | **PASS** (0 errors) |
| XML resources well-formed | **PASS** |
| Unit tests (122): URL parsing, PSL, link extraction, DNS-filter false-positive guards, redaction, HIBP SHA-1/k-anonymity, feed parsing, DNS packet NXDOMAIN + checksum, recovery report, catalogue integrity, negation | **122 PASS / 0 FAIL** |
| Database migration v1→v2 on a real SQLite engine with Build 15's schema | **PASS** — 4/4 rows kept, categories backfilled; fresh-install schema also valid |
| Link matrix, main set (78) | Build 15 53/78 · **Build 16 77/78** (1 known limitation) |
| Message matrix, main set (30) | Build 15 17/30 · **Build 16 30/30** |
| Holdout links (36), run once before any change | Build 15 32/36 · **Build 16 36/36** |
| Holdout messages (18), run once before any change | Build 15 8/18 · **Build 16 15/18** (3 gaps found → fixed → 18/18 after, no longer a blind test) |
| False alarms on legitimate cases (all sets) | Build 15: 2 · **Build 16: 0** |
| On-device functional, UI, notification, VPN, accessibility tests | **NOT VERIFIED** (no device/emulator) |

These test sets were written for this project and use reserved `.example` domains for every simulated malicious case. They show the rules behave as designed and improved over Build 15; they are **not** a measurement of real-world detection rates.

---

## 8. Remaining limitations

- No APK was built or run here; on-device behaviour, layout on small screens and font scaling are unverified until the CI build is tested on a phone.
- DNS-only filtering: no page content, no inspection inside TLS, no coverage for apps with hard-coded DNS/DoH outside the bypass list or direct IP connections, IPv4 UDP DNS only, nothing while another VPN is active.
- Brand detection covers the catalogue only; new brands need a verified row in `brands.tsv`. Three-letter brands (UPS, BDO, BPI…) get no typo matching, to avoid false positives (`upss.example` is not flagged — known failing case).
- Message analysis is rule-based English/Filipino/Taglish; paraphrased or other-language scams can pass, and some honest money requests get *Be careful*.
- No OCR for text in screenshots.
- Play Protect, Chrome Safe Browsing and per-app "Install unknown apps" can only be user-confirmed.
- Root detection can be evaded by hiding tools.
- The AI Worker is not in the repository; its prompts, logging, provider and rate limits are unverified. **The app token in Build 15's APK is extractable — rotate it and enforce server-side rate limits.** Names are not redacted.
- Threat feeds were not re-downloaded from here (network blocked); their current availability is unverified.
- `QUERY_ALL_PACKAGES` would need a Play Console declaration for Play Store distribution.

## 9. Manuscript

The manuscript was not among the uploaded files, so no section-by-section comparison was possible and nothing was changed in it. `DEFENSE_QA.md` lists the sections that will need updating to match Build 16, records the scope inconsistency you described (Out of Scope excluding the AI assistant and third-party app lock while other sections describe them as implemented — both **are** implemented in Build 15 and Build 16), and gives panel answers based only on the code.
