# SafeSphere Build 19 verification

## Verification run

Command: `bash tools/verification/run_all.sh`

Results from the actual run in the provided build environment:

- Java source compile check against the bundled Android API stubs: **PASS**.
- Unit tests: **130 passed, 0 failed**.
- URL detection matrix: main set **77/78**; holdout set **36/36**.
- Message detection matrix: main set **30/30**; holdout set **18/18**.
- The existing unresolved URL case is `https://upss.example/`, expected by the test matrix to receive a warning but currently rated SAFE. This patch did not change the URL detector.
- New unit checks verify that Protection Gap Analyzer progress counts verified, user-confirmed, attention, pending-review and unavailable items separately, and excludes optional notification access from the setup denominator.

## Not verified in this environment

- A full Android Gradle build or installable APK: Android SDK/Gradle are not available in this environment.
- Rendering and touch interactions on an Android emulator or physical phone.
- Manufacturer-specific settings paths on every supported device model. These are guidance only and must be confirmed by the user on their own device.
- Play Protect and Chrome Safe Browsing toggle states. Android does not expose these private settings to ordinary third-party apps; SafeSphere records them only as **Confirmed by you**.

## Interpretation

The setup progress is not a security score, malware scan, or guarantee. `Verified` means a value was read from an Android or SafeSphere API. `Confirmed by you` means the user manually checked a setting. `Unavailable` means the app cannot read or apply that check on this device. A permission-risk label is not a malware verdict.
