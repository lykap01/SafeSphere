# SafeSphere Build 17 — focused patch

Package: `com.nekowishy.safesphere`  
Version: `1.17` (`versionCode 17`)

## Changes made to the supplied Build 16 source

### Notification categories and semantic colors

- **Dangerous threat alerts** use a dedicated high-importance Android notification channel with the danger red accent/light color.
- **Security warnings** use a separate high-importance channel with the warning amber accent/light color. Suspicious-message warnings and Wi-Fi warnings use this channel.
- **Protection status** remains a low-importance ongoing channel and now uses the protection green accent/light color.
- The in-app notification-permission diagnostic now checks both alert and warning channels and reports when either is disabled or set to silent.
- Users can independently manage the dangerous-alert and warning categories in Android notification settings. Android and device manufacturers may still control whether accent colors or notification lights are visibly rendered.

## Existing Build 16 features preserved

The supplied Build 16 source already included the flat UI redesign, single bottom navigation, international URL parsing and brand checks, Before You Act, Protection Gap Analyzer, Recovery Center, and Security Activity. These were preserved. The duplicate History shortcut and misleading hamburger were not reintroduced.

## Verification

After the patch, `bash tools/verification/run_all.sh` completed successfully:

- Java source compile check against the bundled Android API stubs: **PASS**.
- Unit tests: **122 PASS / 0 FAIL**.
- Detection matrices: unchanged from Build 16 (main links 77/78, main messages 30/30, holdout links 36/36, holdout messages 18/18). The one known three-letter-brand case (`upss.example`) remains a documented limitation; it was not changed by this notification-only patch.
- Physical-device notification rendering and Android channel settings: **NOT VERIFIED**. Android skins and user channel preferences can alter how colors appear.
- APK build: **NOT BUILT** in this environment; the repository has a GitHub Actions debug-build workflow.
