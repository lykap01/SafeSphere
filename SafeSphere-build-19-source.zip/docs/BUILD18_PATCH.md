# Build 18 patch notes — Before You Act visibility and demo flow

## What changed

- Added a prominent **Before You Act** card to the Shield home screen, with a direct action that opens the Check tab.
- Added an explicit feature introduction at the top of the Check tab explaining that SafeSphere evaluates what a sender is asking the user to do, not only whether a link is present.
- Added two one-tap sample flows: an OTP-sharing request and an advance-fee request. Both are analyzed locally and do not contain a URL.
- Clarified the input privacy copy: local analysis runs on the phone; text is not saved or sent unless the user separately opts into the external AI explanation.
- Updated the input hint and primary action label to make the workflow easier to understand.
- Added unit tests for the no-link OTP and advance-fee sample flows.
- Bumped app version to 1.18 / versionCode 18.

## Existing implementation preserved

The underlying `ActionAnalyzer` rule engine and result breakdown were already present in Build 17. This patch makes the feature discoverable and demonstrable rather than replacing the existing detection logic.

## Verification

Run `bash tools/verification/run_all.sh`. Results should be recorded from the actual run; this patch does not claim an Android device test or installable APK build.
