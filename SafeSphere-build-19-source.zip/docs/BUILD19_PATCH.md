# SafeSphere Build 19 - Protection Gap Analyzer improvements

## Purpose

Make Feature 2 visible and useful without adding another navigation tab or duplicating existing controls. The existing Device tab remains the single detailed location for the analyzer. The Shield dashboard provides one clear entry point.

## User-visible changes

- Renamed the Shield dashboard summary to **Protection Gap Analyzer**.
- Added a **Review protection gaps** action that opens the existing Device tab.
- Renamed the Device page introduction to **Protection Gap Analyzer** and clarified that it complements Android and manufacturer security rather than replacing them.
- The overview now distinguishes checks that are verified or user-confirmed, items needing attention, items awaiting user review, and unavailable checks.
- Added a clear summary banner so warnings are not presented as proof that a device is infected.
- Added a manufacturer-specific manual review item with guidance for Samsung, Google/Pixel, Xiaomi/Redmi/POCO, OPPO/realme/OnePlus, vivo, Huawei, and a generic fallback. Manufacturer settings are never described as verified by SafeSphere; users must review and confirm them.

## Technical accuracy improvements

- Android version alone is no longer treated as proof that a device is supported or secure. The exact model's update-support status is marked for user review because Android does not expose the manufacturer's support lifecycle to ordinary apps.
- Security patch age remains a freshness indicator; the UI explicitly says that a recent patch is not a guarantee of security.
- Root, USB debugging, and developer-options explanations were softened to avoid overstating what these indicators prove.
- Unknown installer metadata is no longer automatically labelled as sideloading. Apps with a recognized but non-listed installer and apps whose installer cannot be identified are separated for review.
- Added F-Droid and Aurora Store to the recognized installer list.
- App permission scan labels now describe permission risk, not malware detection. The UI states that it is not a malware scan or verdict.
- Manual checks remain labelled **Confirmed by you**, expire after 90 days, and are not represented as independently verified.

## Files changed

- `app/src/main/java/com/nekowishy/safesphere/DeviceAudit.java`
- `app/src/main/java/com/nekowishy/safesphere/MainActivity.java`
- `app/src/main/java/com/nekowishy/safesphere/AppScanner.java`
- `app/build.gradle` (version 1.19 / code 19)
- `tools/verification/gen_stubs.py` (Build.MANUFACTURER compile stub)
- `tools/verification/harness/UnitTests.java` (progress accounting tests)
- `README.md`

## Preserved

- Existing bottom navigation: Shield, Check, Rules, History, Device.
- Existing History tab and event database.
- Existing Before You Act feature and ActionAnalyzer.
- Existing DNS firewall, threat feeds, QR checking, notifications, password checking, Recovery Center, and account checkup.
- No new Android permission was added.
