package com.nekowishy.safesphere;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.InstallSourceInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Protection Gap Analyzer: which protections this phone already has, which need attention, and how
 * SafeSphere fits in. It complements Android's own security (Play Protect, Safe Browsing, updates);
 * it does not replace it.
 *
 * Every check says how its result was obtained. Some settings (Play Protect, Chrome Safe Browsing)
 * are not readable by other apps, so SafeSphere shows a guide and lets the user confirm them; those are
 * labelled "Confirmed by you", never "Verified".
 */
final class DeviceAudit {

    static final int VERIFIED = 0, ATTENTION = 1, CONFIRMED = 2, UNAVAILABLE = 3, NOT_CHECKED = 4;
    private static final long CONFIRM_VALID_MS = TimeUnit.DAYS.toMillis(90);

    static final class Check {
        String id;
        String group;
        String title;
        String detail;
        String guide;          // how to check it yourself (for settings Android doesn't expose)
        String how;            // how SafeSphere got this result
        int state = NOT_CHECKED;
        boolean high;          // a serious gap (shown in red instead of amber)
        boolean confirmable;   // the user can confirm it after checking
        long confirmedAt;
        String button;
        String confirmLabel;
        String[] settings;     // settings screens to try, in order
        String launchPkg;      // or an app to open
        final List<String> apps = new ArrayList<>();
    }

    static final String G_PHONE = "Phone security", G_ANDROID = "Android protections", G_APPS = "Apps",
            G_SAFESPHERE = "SafeSphere";

    /** Apps that let another person see and control the phone remotely. */
    static final Set<String> REMOTE_APPS = new HashSet<>(Arrays.asList(
            "com.anydesk.anydeskandroid", "com.teamviewer.quicksupport.market", "com.teamviewer.teamviewer.market.mobile",
            "com.teamviewer.host.market", "com.carriez.flutter_hbb", "com.rustdesk.rustdesk", "com.realvnc.viewer.android",
            "com.sand.airdroid", "com.sand.airdroidbiz", "com.sand.airmirror", "com.splashtop.remote.pad.v2",
            "com.splashtop.sos", "com.logmein.rescuemobile"));

    /** Official app stores; apps from anywhere else were installed from outside a store. */
    private static final Set<String> STORES = new HashSet<>(Arrays.asList(
            "com.android.vending", "com.google.android.feedback", "com.sec.android.app.samsungapps",
            "com.huawei.appmarket", "com.heytap.market", "com.oppo.market", "com.oplus.market", "com.xiaomi.market",
            "com.xiaomi.mipicks", "com.vivo.appstore", "com.bbk.appstore", "com.amazon.venezia",
            "org.fdroid.fdroid", "com.aurora.store", "org.fdroid.fdroid.privileged.ota"));

    private static final String[] SU_PATHS = {
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su", "/system/sd/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su", "/system/app/Superuser.apk"};

    private static final Set<String> ROOT_APPS = new HashSet<>(Arrays.asList(
            "com.topjohnwu.magisk", "eu.chainfire.supersu", "com.koushikdutta.superuser", "com.noshufou.android.su",
            "me.weishu.kernelsu"));

    private static volatile List<Check> lastResult;

    private DeviceAudit() {}

    static List<Check> last() { return lastResult; }

    static String installer(PackageManager pm, String pkg) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                InstallSourceInfo info = pm.getInstallSourceInfo(pkg);
                return info.getInstallingPackageName();
            }
            //noinspection deprecation
            return pm.getInstallerPackageName(pkg);
        } catch (Exception e) {
            return null;
        }
    }

    static boolean fromOutsideStore(Context c, PackageManager pm, String pkg) {
        if (pkg.equals(c.getPackageName())) return false; // SafeSphere itself is installed from GitHub
        String inst = installer(pm, pkg);
        // An unknown installer is not proof of sideloading. It is reported separately for review.
        return inst != null && !STORES.contains(inst);
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("gap_analyzer", Context.MODE_PRIVATE);
    }

    static void confirm(Context c, String id, boolean yes) {
        if (yes) prefs(c).edit().putLong("confirm_" + id, System.currentTimeMillis()).apply();
        else prefs(c).edit().remove("confirm_" + id).apply();
    }

    private static Check check(String id, String group) {
        Check ch = new Check();
        ch.id = id;
        ch.group = group;
        return ch;
    }

    @SuppressWarnings("deprecation")
    static List<Check> run(Context c) {
        List<Check> out = new ArrayList<>();
        PackageManager pm = c.getPackageManager();

        // ---------------------------------------------------------------- phone security
        Check lock = check("lock", G_PHONE);
        KeyguardManager km = c.getSystemService(KeyguardManager.class);
        boolean secure = km != null && km.isDeviceSecure();
        lock.title = "Screen lock";
        lock.state = secure ? VERIFIED : ATTENTION;
        lock.high = true;
        lock.detail = secure ? "A PIN, pattern, password or biometric protects this phone."
                : "Anyone holding this phone can open your e-wallet, chats and e-mail.";
        lock.how = "Read from Android (KeyguardManager).";
        lock.button = "Set screen lock";
        lock.settings = new String[]{Settings.ACTION_SECURITY_SETTINGS};
        out.add(lock);

        Check patch = check("patch", G_PHONE);
        patch.title = "Security update";
        patch.button = "Check for updates";
        patch.settings = new String[]{"android.settings.SYSTEM_UPDATE_SETTINGS", Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_SETTINGS};
        patch.how = "Read from Android (security patch date).";
        try {
            SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            parser.setLenient(false);
            Date d = parser.parse(Build.VERSION.SECURITY_PATCH);
            if (d == null || d.getTime() > System.currentTimeMillis() + TimeUnit.DAYS.toMillis(7)) {
                throw new IllegalArgumentException("Invalid security patch date");
            }
            long days = Math.max(0, TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - d.getTime()));
            String when = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(d);
            patch.state = days > 90 ? ATTENTION : VERIFIED;
            patch.high = days > 180;
            patch.detail = "Last security patch: " + when + " (" + days + " days ago). " + (days > 90
                    ? "This patch level is over 90 days old. Check for updates from your phone maker."
                    : "This patch level is within 90 days. This is a freshness indicator, not a guarantee that the phone is secure.");
        } catch (Exception e) {
            patch.state = UNAVAILABLE;
            patch.detail = "This phone did not report its security patch date.";
        }
        out.add(patch);

        Check ver = check("android", G_PHONE);
        ver.title = "Android version support";
        ver.how = "Android version is read from the system. Support dates for the exact model are not exposed to third-party apps.";
        ver.detail = "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + "). Whether this exact model still receives updates depends on the manufacturer, model and region. Use the patch date above and check the manufacturer's official support information.";
        ver.guide = "Check the official support page for your exact phone model and region. Compare its update-support period with the security patch date above.";
        ver.button = "Device information";
        ver.settings = new String[]{Settings.ACTION_DEVICE_INFO_SETTINGS, Settings.ACTION_SETTINGS};
        ver.confirmable = true;
        ver.confirmLabel = "I've checked my model's support";
        applyConfirmation(c, ver, true);
        out.add(ver);

        Check root = check("root", G_PHONE);
        boolean rooted = Build.TAGS != null && Build.TAGS.contains("test-keys");
        for (String p : SU_PATHS) if (new File(p).exists()) rooted = true;
        List<PackageInfo> pkgs = pm.getInstalledPackages(0);
        for (PackageInfo p : pkgs) if (ROOT_APPS.contains(p.packageName)) rooted = true;
        root.title = "Root access";
        root.state = rooted ? ATTENTION : VERIFIED;
        root.high = true;
        root.detail = rooted ? "Signs associated with rooting were found. Root access can weaken Android's app sandbox and increase the impact if an app gains elevated privileges."
                : "No common signs of rooting were found. Well-hidden root tools may not be detected.";
        root.how = "Looked for su files, root-manager apps and test-keys.";
        out.add(root);

        Check adb = check("adb", G_PHONE);
        boolean adbOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
        adb.title = "USB debugging";
        adb.state = adbOn ? ATTENTION : VERIFIED;
        adb.high = adbOn;
        adb.detail = adbOn ? "On. A computer you authorize can communicate with this phone through Android Debug Bridge. Turn it off when you are not using it."
                : "Off. USB debugging is not enabled.";
        adb.how = "Read from Android settings.";
        adb.button = "Developer options";
        adb.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(adb);

        Check dev = check("devopts", G_PHONE);
        boolean devOn = Settings.Global.getInt(c.getContentResolver(), Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
        dev.title = "Developer options";
        dev.state = devOn ? ATTENTION : VERIFIED;
        dev.detail = devOn ? "On. This is not proof of compromise, but developer settings can expose advanced controls. Turn them off if you do not use them."
                : "Off. Developer options are not enabled.";
        dev.how = "Read from Android settings.";
        dev.button = "Developer options";
        dev.settings = new String[]{Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(dev);

        // ---------------------------------------------------------------- Android's own protections
        Check pp = check("playprotect", G_ANDROID);
        pp.title = "Google Play Protect";
        pp.confirmable = true;
        pp.how = "Android does not let other apps read this setting, so SafeSphere can't verify it.";
        pp.guide = "Open Play Protect and make sure \"Scan apps with Play Protect\" is on.";
        pp.detail = "Scans installed apps for malware. SafeSphere does not replace it.";
        pp.button = "Open Play Protect";
        pp.settings = new String[]{"com.google.android.gms.settings.VERIFY_APPS_SETTINGS", Settings.ACTION_SECURITY_SETTINGS};
        applyConfirmation(c, pp, isInstalled(pm, "com.android.vending") || isInstalled(pm, "com.google.android.gms"));
        out.add(pp);

        Check sb = check("safebrowsing", G_ANDROID);
        sb.title = "Chrome Safe Browsing";
        sb.confirmable = true;
        sb.how = "Chrome does not let other apps read this setting, so SafeSphere can't verify it.";
        sb.guide = "In Chrome: ⋮ → Settings → Privacy and security → Safe Browsing → choose Standard or Enhanced protection.";
        sb.detail = "Warns about dangerous pages inside Chrome, including ones not yet on SafeSphere's lists.";
        sb.button = "Open Chrome";
        sb.launchPkg = "com.android.chrome";
        applyConfirmation(c, sb, isInstalled(pm, "com.android.chrome"));
        if (sb.state == UNAVAILABLE) sb.detail = "Chrome isn't installed. If you use another browser, turn on its phishing protection.";
        out.add(sb);

        Check maker = check("maker_security", G_ANDROID);
        String makerName = manufacturerName(Build.MANUFACTURER);
        maker.title = makerName + " security features";
        maker.confirmable = true;
        maker.confirmLabel = "I've reviewed these settings";
        maker.how = "Phone maker identified from Android. SafeSphere cannot read the status of proprietary manufacturer security features.";
        maker.guide = manufacturerGuide(Build.MANUFACTURER);
        maker.detail = "Review any additional security and theft-protection options provided for this model. Availability varies by model, Android version and region.";
        maker.button = "Open security settings";
        maker.settings = new String[]{Settings.ACTION_SECURITY_SETTINGS, Settings.ACTION_SETTINGS};
        applyConfirmation(c, maker, true);
        out.add(maker);

        Check pdns = check("privatedns", G_ANDROID);
        String mode = Prefs.privateDnsMode(c);
        pdns.title = "Private DNS";
        pdns.how = "Read from Android settings.";
        pdns.button = "Network settings";
        pdns.settings = new String[]{Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS};
        if (mode == null) {
            pdns.state = UNAVAILABLE;
            pdns.detail = "This phone doesn't report its Private DNS setting.";
        } else if ("hostname".equals(mode)) {
            pdns.state = ATTENTION;
            pdns.high = true;
            pdns.detail = "Set to a specific provider. Apps send lookups there directly, skipping SafeSphere's filter. "
                    + "Choose Automatic or Off to use SafeSphere.";
        } else {
            pdns.state = VERIFIED;
            pdns.detail = "Automatic or Off: lookups pass through SafeSphere while protection is on.";
        }
        out.add(pdns);

        // ---------------------------------------------------------------- apps
        Check remote = check("remote", G_APPS);
        Check outside = check("outside", G_APPS);
        Check unknownSource = check("unknownsource", G_APPS);
        Check installers = check("installers", G_APPS);
        Check access = check("accessibility", G_APPS);
        String enabledA11y = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        List<PackageInfo> withPerms;
        try {
            withPerms = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
        } catch (RuntimeException e) {
            withPerms = pkgs;
        }
        for (PackageInfo p : withPerms) {
            ApplicationInfo ai = p.applicationInfo;
            if (ai == null || p.packageName.equals(c.getPackageName())) continue;
            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            String label = String.valueOf(ai.loadLabel(pm));
            if (!system && REMOTE_APPS.contains(p.packageName)) {
                remote.apps.add(label);
            } else if (!system) {
                String source = installer(pm, p.packageName);
                if (source == null || source.trim().isEmpty()) unknownSource.apps.add(label);
                else if (!STORES.contains(source)) outside.apps.add(label);
            }
            if (!system && p.requestedPermissions != null
                    && Arrays.asList(p.requestedPermissions).contains("android.permission.REQUEST_INSTALL_PACKAGES")) {
                installers.apps.add(label);
            }
            if (!system && enabledA11y != null && enabledA11y.contains(p.packageName + "/")) access.apps.add(label);
        }
        remote.title = "Remote-control apps";
        remote.state = remote.apps.isEmpty() ? VERIFIED : ATTENTION;
        remote.high = true;
        remote.detail = remote.apps.isEmpty() ? "None installed."
                : "Installed. Scammers sometimes ask victims to install remote-access tools. Keep these only if you recognize and trust them.";
        remote.how = "Compared installed apps with a list of remote-access tools.";
        out.add(remote);

        access.title = "Accessibility access";
        access.state = access.apps.isEmpty() ? VERIFIED : ATTENTION;
        access.detail = access.apps.isEmpty() ? "No downloaded app can read or control your screen."
                : "These services may read screen content or perform actions on your behalf. Review each one and keep only services you recognize and trust.";
        access.how = "Read from Android's list of enabled accessibility services.";
        access.button = "Accessibility settings";
        access.settings = new String[]{Settings.ACTION_ACCESSIBILITY_SETTINGS};
        out.add(access);

        outside.title = "Apps from unrecognized stores";
        outside.state = outside.apps.isEmpty() ? VERIFIED : ATTENTION;
        outside.detail = outside.apps.isEmpty() ? "No installed app was found with an installer outside SafeSphere's recognized store list."
                : "These apps were installed by a source SafeSphere does not recognize. This does not prove they are malicious; verify the source before keeping them.";
        outside.how = "Compared installer package names with a list of recognized app stores.";
        outside.guide = "Check whether you intentionally installed each app from its official developer or a trusted app store.";
        out.add(outside);

        unknownSource.title = "Unknown installation source";
        unknownSource.how = "Android did not report an installer package for these apps.";
        unknownSource.guide = "Review whether you installed each listed app yourself and whether its source was trusted. An unknown installer does not prove an app is harmful.";
        unknownSource.detail = unknownSource.apps.isEmpty() ? "Android reported an installer for the downloaded apps SafeSphere checked."
                : "SafeSphere could not identify the installer for these apps. Review them before deciding whether to keep them.";
        if (unknownSource.apps.isEmpty()) {
            unknownSource.state = VERIFIED;
        } else {
            unknownSource.confirmable = true;
            unknownSource.confirmLabel = "I've reviewed these apps";
            applyConfirmation(c, unknownSource, true);
        }
        out.add(unknownSource);

        installers.title = "Install unknown apps";
        installers.confirmable = true;
        installers.how = "Android doesn't show other apps whether this is switched on, only which apps can ask for it.";
        installers.guide = "Open the setting and switch it off for apps that don't need it, especially browsers and chat apps.";
        installers.detail = installers.apps.isEmpty() ? "No downloaded app can ask to install other apps."
                : installers.apps.size() + " app(s) can be allowed to install other apps.";
        installers.button = "Open setting";
        installers.settings = new String[]{Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Settings.ACTION_SECURITY_SETTINGS};
        if (installers.apps.isEmpty()) installers.state = VERIFIED;
        else applyConfirmation(c, installers, true);
        out.add(installers);

        // ---------------------------------------------------------------- SafeSphere
        Check prot = check("protection", G_SAFESPHERE);
        prot.title = "SafeSphere DNS protection";
        ProtectionState ps = ProtectionState.compute(c);
        prot.state = ps.state == ProtectionState.ACTIVE ? VERIFIED : ATTENTION;
        prot.high = ps.state == ProtectionState.INTERRUPTED;
        prot.detail = ps.title + ". " + (ps.gaps.isEmpty() ? ps.detail : ps.gaps.get(0));
        prot.how = "Read from SafeSphere's own VPN service.";
        out.add(prot);

        Check vpn = check("vpn", G_SAFESPHERE);
        vpn.title = "Other VPN apps";
        vpn.how = "Read from Android's network list.";
        boolean other = ProtectionState.otherVpnActive(c);
        vpn.state = other ? ATTENTION : VERIFIED;
        vpn.detail = other ? "Another VPN is connected. Only one VPN can run at a time, so SafeSphere's filter can't run with it."
                : SafeSphereVpnService.isRunning() ? "SafeSphere is the active VPN." : "No other VPN is connected.";
        vpn.button = "VPN settings";
        vpn.settings = new String[]{Settings.ACTION_VPN_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS};
        out.add(vpn);

        Check notif = check("notification", G_SAFESPHERE);
        boolean listener = ScamMessageWatcher.isEnabled(c);
        notif.title = "Scam message alerts";
        notif.how = "Read from Android's notification-access list.";
        notif.state = listener ? VERIFIED : NOT_CHECKED;
        notif.detail = listener ? "On. SafeSphere reads new message notifications on the phone and never stores their text."
                : "Optional and off. Turn it on in Check if you want automatic warnings about scam messages.";
        out.add(notif);

        Check battery = check("battery", G_SAFESPHERE);
        battery.title = "Background running";
        battery.how = "Read from Android's battery and background settings.";
        PowerManager pmgr = c.getSystemService(PowerManager.class);
        boolean optimized = pmgr != null && !pmgr.isIgnoringBatteryOptimizations(c.getPackageName());
        boolean restricted = false;
        ActivityManager am = c.getSystemService(ActivityManager.class);
        if (am != null && Build.VERSION.SDK_INT >= 28) restricted = am.isBackgroundRestricted();
        battery.state = restricted ? ATTENTION : VERIFIED;
        battery.detail = restricted ? "Background activity is restricted, so Android may stop protection and alerts."
                : optimized ? "Battery optimisation is on. Most phones keep the VPN running anyway; if protection keeps "
                + "stopping, set SafeSphere to \"Unrestricted\"." : "SafeSphere may run in the background.";
        battery.button = "Battery settings";
        battery.settings = new String[]{Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS, Settings.ACTION_SETTINGS};
        out.add(battery);

        recordChanges(c, out);
        lastResult = out;
        return out;
    }

    private static String manufacturerName(String manufacturer) {
        String m = manufacturer == null ? "" : manufacturer.trim().toLowerCase(Locale.US);
        if (m.contains("samsung")) return "Samsung";
        if (m.contains("google")) return "Google / Pixel";
        if (m.contains("xiaomi")) return "Xiaomi";
        if (m.contains("redmi")) return "Redmi";
        if (m.contains("poco")) return "POCO";
        if (m.contains("oppo")) return "OPPO";
        if (m.contains("realme")) return "realme";
        if (m.contains("oneplus")) return "OnePlus";
        if (m.contains("vivo")) return "vivo";
        if (m.contains("huawei")) return "Huawei";
        if (m.contains("motorola") || m.contains("motorola mobility")) return "Motorola";
        if (m.contains("sony")) return "Sony";
        if (m.contains("asus")) return "ASUS";
        if (m.isEmpty()) return "Phone maker";
        return Character.toUpperCase(m.charAt(0)) + m.substring(1);
    }

    private static String manufacturerGuide(String manufacturer) {
        String m = manufacturer == null ? "" : manufacturer.trim().toLowerCase(Locale.US);
        if (m.contains("samsung")) return "Open Settings > Security and privacy. Review Auto Blocker and other protection options shown for your Galaxy model, if available.";
        if (m.contains("google")) return "Open Settings > Security & privacy. Review device protection, Find Hub and theft-protection options available for your Pixel model.";
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) return "Open Settings > Security or the Security app. Review app installation, permissions and device-protection options available for your model.";
        if (m.contains("oppo") || m.contains("realme") || m.contains("oneplus")) return "Open Settings > Security and privacy or the phone manager app. Review app protection, installation and permission controls available for your model.";
        if (m.contains("vivo")) return "Open Settings > Security or Privacy. Review app installation, permission and device-protection options available for your model.";
        if (m.contains("huawei")) return "Open Settings > Security. Review AppGallery protection, app installation and permission controls available for your model.";
        return "Open Settings > Security or Security & privacy. Review the security, app-installation, device-finding and theft-protection options provided for your exact model, if available.";
    }

    private static boolean isInstalled(PackageManager pm, String pkg) {
        try {
            pm.getApplicationInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void applyConfirmation(Context c, Check ch, boolean applicable) {
        if (!applicable) {
            ch.state = UNAVAILABLE;
            ch.confirmable = false;
            return;
        }
        long at = prefs(c).getLong("confirm_" + ch.id, 0);
        ch.confirmedAt = at;
        ch.state = at > 0 && System.currentTimeMillis() - at < CONFIRM_VALID_MS ? CONFIRMED : NOT_CHECKED;
    }

    /** Writes "found" / "resolved" device events to History when a check changes state. */
    private static void recordChanges(Context c, List<Check> checks) {
        SharedPreferences p = prefs(c);
        Set<String> before = new HashSet<>(p.getStringSet("open_issues", new HashSet<>()));
        Set<String> now = new HashSet<>();
        long t = System.currentTimeMillis();
        for (Check ch : checks) {
            if (ch.state != ATTENTION || ch.id.equals("protection")) continue;
            now.add(ch.id);
            if (!before.contains(ch.id)) EventLog.get(c).record(EventLog.CAT_DEVICE, "", "Needs attention: " + ch.title, t);
        }
        for (String id : before) {
            if (now.contains(id)) continue;
            for (Check ch : checks) if (ch.id.equals(id)) EventLog.get(c).record(EventLog.CAT_DEVICE, "", "Resolved: " + ch.title, t);
        }
        p.edit().putStringSet("open_issues", now).apply();
    }

    // ------------------------------------------------------------------ setup progress

    static final class Progress {
        int done, applicable, attention, pending, unavailable;
    }

    /**
     * Security setup progress = checks that are Verified or Confirmed by you, out of all checks that can
     * apply on this phone (Unavailable ones are left out). It counts completed setup steps; it is NOT a
     * measured level of security.
     */
    static Progress progress(List<Check> checks) {
        Progress p = new Progress();
        if (checks == null) return p;
        for (Check ch : checks) {
            if (ch.state == UNAVAILABLE) {
                p.unavailable++;
                continue;
            }
            if (ch.id.equals("notification")) continue; // optional feature, not a gap
            p.applicable++;
            if (ch.state == VERIFIED || ch.state == CONFIRMED) p.done++;
            if (ch.state == ATTENTION) p.attention++;
            if (ch.state == NOT_CHECKED) p.pending++;
        }
        return p;
    }

    static String stateLabel(int state) {
        switch (state) {
            case VERIFIED: return "Verified";
            case ATTENTION: return "Needs attention";
            case CONFIRMED: return "Confirmed by you";
            case UNAVAILABLE: return "Unavailable";
            default: return "Not checked";
        }
    }

    static int tone(Check ch) {
        switch (ch.state) {
            case VERIFIED: return Ui.T_SUCCESS;
            case ATTENTION: return ch.high ? Ui.T_DANGER : Ui.T_WARNING;
            case CONFIRMED: return Ui.T_INFO;
            default: return Ui.T_NEUTRAL;
        }
    }
}
