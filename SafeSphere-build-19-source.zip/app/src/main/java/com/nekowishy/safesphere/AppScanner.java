package com.nekowishy.safesphere;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.provider.Settings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Scores installed apps by the sensitive permissions they actually hold. */
final class AppScanner {

    static final class AppRisk {
        String label;
        String pkg;
        Drawable icon;
        int score;
        final Set<String> flags = new LinkedHashSet<>();

        String level() { return score >= 8 ? "High permission risk" : score >= 4 ? "Medium permission risk" : "Lower permission risk"; }
        int tone() { return score >= 8 ? Ui.T_DANGER : score >= 4 ? Ui.T_WARNING : Ui.T_NEUTRAL; }
    }

    private static final class Rule {
        final String label;
        final int weight;
        final boolean special; // special access: counted when requested (grant state is not visible)

        Rule(String label, int weight, boolean special) {
            this.label = label;
            this.weight = weight;
            this.special = special;
        }
    }

    private static final Map<String, Rule> RULES = new HashMap<>();

    private static void rule(String perm, String label, int weight, boolean special) {
        RULES.put("android.permission." + perm, new Rule(label, weight, special));
    }

    static {
        rule("READ_SMS", "Reads SMS", 3, false);
        rule("RECEIVE_SMS", "Reads SMS", 3, false);
        rule("SEND_SMS", "Sends SMS", 3, false);
        rule("READ_CALL_LOG", "Call history", 3, false);
        rule("WRITE_CALL_LOG", "Call history", 3, false);
        rule("ACCESS_BACKGROUND_LOCATION", "Location in background", 3, false);
        rule("ACCESS_FINE_LOCATION", "Precise location", 2, false);
        rule("ACCESS_COARSE_LOCATION", "Approximate location", 1, false);
        rule("CAMERA", "Camera", 2, false);
        rule("RECORD_AUDIO", "Microphone", 2, false);
        rule("READ_CONTACTS", "Contacts", 2, false);
        rule("READ_PHONE_STATE", "Phone identity", 1, false);
        rule("CALL_PHONE", "Makes calls", 1, false);
        rule("BODY_SENSORS", "Body sensors", 1, false);
        rule("READ_EXTERNAL_STORAGE", "Files & media", 1, false);
        rule("READ_MEDIA_IMAGES", "Photos", 1, false);
        rule("READ_MEDIA_VIDEO", "Videos", 1, false);
        rule("SYSTEM_ALERT_WINDOW", "Can draw over other apps", 2, true);
        rule("REQUEST_INSTALL_PACKAGES", "Can install other apps", 2, true);
        rule("PACKAGE_USAGE_STATS", "Can track app usage", 1, true);
    }

    private AppScanner() {}

    static List<AppRisk> scan(Context c) {
        PackageManager pm = c.getPackageManager();
        String accessibility = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        List<AppRisk> result = new ArrayList<>();
        for (PackageInfo p : pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)) {
            ApplicationInfo ai = p.applicationInfo;
            if (ai == null || p.packageName.equals(c.getPackageName())) continue;
            // Skip apps that came built into the phone (Google Play services, Messages, etc.).
            // Users can't uninstall them, and they hold broad access by design.
            if ((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;

            AppRisk r = new AppRisk();
            r.pkg = p.packageName;
            String[] req = p.requestedPermissions;
            int[] reqFlags = p.requestedPermissionsFlags;
            if (req != null) {
                for (int i = 0; i < req.length; i++) {
                    Rule rule = RULES.get(req[i]);
                    if (rule == null) continue;
                    boolean granted = reqFlags != null && i < reqFlags.length
                            && (reqFlags[i] & PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0;
                    if ((granted || rule.special) && r.flags.add(rule.label)) r.score += rule.weight;
                }
            }
            if (accessibility != null && accessibility.contains(p.packageName + "/")) {
                if (r.flags.add("Accessibility control (can read your screen)")) r.score += 5;
            }
            if (DeviceAudit.REMOTE_APPS.contains(p.packageName)) {
                if (r.flags.add("Remote-control app (used in bank and GCash scams)")) r.score += 6;
            }
            if (DeviceAudit.fromOutsideStore(c, pm, p.packageName)) {
                if (r.flags.add("Installed from outside an app store")) r.score += 2;
            }
            if (r.score == 0) continue;
            r.label = String.valueOf(ai.loadLabel(pm));
            r.icon = ai.loadIcon(pm);
            result.add(r);
        }
        result.sort((a, b) -> b.score != a.score ? b.score - a.score : a.label.compareToIgnoreCase(b.label));
        return result;
    }
}
