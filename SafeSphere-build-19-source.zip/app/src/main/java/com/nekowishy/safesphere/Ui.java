package com.nekowishy.safesphere;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * SafeSphere design system (Build 16): flat surfaces, one type scale, one colour system.
 *
 * Status is never shown by colour alone: every status badge pairs its colour with a symbol and a
 * word (Verified, Needs attention, Suspicious...). All sizes use sp/dp so Android font scaling works.
 */
final class Ui {

    // ------------------------------------------------------------------ colour
    static final int BG = 0xFFF5F7FA;
    static final int SURFACE = 0xFFFFFFFF;
    static final int SURFACE_MUTED = 0xFFF0F2F5;
    static final int BORDER = 0xFFE4E7EC;
    static final int TEXT = 0xFF18212B;
    static final int TEXT2 = 0xFF667085;
    static final int PRIMARY = 0xFF245A73;
    static final int PRIMARY_TINT = 0xFFE7EFF2;
    static final int WHITE = 0xFFFFFFFF;

    // Semantic status colours (adjusted slightly from the brief so text reaches 4.5:1 contrast on tints)
    static final int SUCCESS = 0xFF137452;     // protection active, verified checks
    static final int WARNING = 0xFF8F5B00;     // attention required
    static final int SUSPICIOUS = 0xFFAE4E14;  // suspicious activity
    static final int DANGER = 0xFFB42318;      // dangerous / blocked
    static final int INFO = 0xFF2457A6;        // information, user-confirmed
    static final int NEUTRAL = 0xFF5B6578;     // disabled, unavailable, unverified

    // Tones (index into the tables below)
    static final int T_SUCCESS = 0, T_WARNING = 1, T_SUSPICIOUS = 2, T_DANGER = 3, T_INFO = 4, T_NEUTRAL = 5;
    private static final int[] TONE_FG = {SUCCESS, WARNING, SUSPICIOUS, DANGER, INFO, NEUTRAL};
    private static final int[] TONE_BG = {0xFFEAF5F0, 0xFFFBF4E4, 0xFFFCEEE6, 0xFFFDEDEB, 0xFFEBF1FA, 0xFFF0F2F5};
    /** Symbols that make each tone readable without colour. */
    private static final String[] TONE_GLYPH = {"✓", "!", "?", "✕", "i", "–"};

    static int fg(int tone) { return TONE_FG[tone]; }
    static int tint(int tone) { return TONE_BG[tone]; }
    static String glyph(int tone) { return TONE_GLYPH[tone]; }

    // ------------------------------------------------------------------ type scale (sp)
    static final float PAGE_TITLE = 22, SECTION = 13, CARD_TITLE = 16, BODY = 14, SUPPORT = 13, LABEL = 12;

    static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private Ui() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    // ------------------------------------------------------------------ text

    static TextView text(Context c, String s, float sp, int color, boolean medium) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        t.setLineSpacing(0, 1.2f);
        return t;
    }

    /** Marks a view as a heading for screen readers (Android 9+; ignored on 8.x). */
    static void heading(View v) {
        if (android.os.Build.VERSION.SDK_INT >= 28) v.setAccessibilityHeading(true);
    }

    static TextView pageTitle(Context c, String s) {
        TextView t = text(c, s, PAGE_TITLE, TEXT, true);
        heading(t);
        return t;
    }

    static TextView cardTitle(Context c, String s) {
        TextView t = text(c, s, CARD_TITLE, TEXT, true);
        heading(t);
        return t;
    }

    static TextView body(Context c, String s) {
        return text(c, s, BODY, TEXT, false);
    }

    static TextView support(Context c, String s) {
        return text(c, s, SUPPORT, TEXT2, false);
    }

    /** Section heading above a group of cards. */
    static TextView section(Context c, String s) {
        TextView t = text(c, s, SECTION, TEXT2, true);
        t.setPadding(dp(c, 4), dp(c, 24), dp(c, 4), dp(c, 8));
        heading(t);
        return t;
    }

    /** Bulleted list as one text view (keeps screen readers reading it as a list of sentences). */
    static TextView bullets(Context c, java.util.List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (String s : items) {
            if (sb.length() > 0) sb.append('\n');
            sb.append("•  ").append(s);
        }
        TextView t = body(c, sb.toString());
        t.setLineSpacing(dp(c, 4), 1.15f);
        return t;
    }

    // ------------------------------------------------------------------ surfaces

    static GradientDrawable rounded(int fill, int stroke, float radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    /** White card with a hairline border. */
    static LinearLayout card(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(rounded(SURFACE, BORDER, 12, c));
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    /** Card without inner padding, for lists of rows. */
    static LinearLayout listCard(Context c) {
        LinearLayout l = vbox(c);
        l.setBackground(rounded(SURFACE, BORDER, 12, c));
        l.setPadding(0, dp(c, 4), 0, dp(c, 4));
        return l;
    }

    static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, Math.max(1, dp(c, 1)));
        v.setLayoutParams(lp);
        return v;
    }

    /** Ripple on top of a background (touch feedback without decorative animation). */
    static Drawable ripple(Drawable content, Drawable mask) {
        return new RippleDrawable(ColorStateList.valueOf(alpha(PRIMARY, 0x22)), content, mask);
    }

    static void clickable(View v, String description, View.OnClickListener l) {
        if (v.getBackground() == null) v.setBackground(ripple(null, rounded(WHITE, 0, 8, v.getContext())));
        v.setClickable(true);
        v.setFocusable(true);
        if (description != null) v.setContentDescription(description);
        v.setOnClickListener(l);
    }

    // ------------------------------------------------------------------ buttons

    private static TextView baseButton(Context c, String s, View.OnClickListener l) {
        TextView b = text(c, s, BODY, PRIMARY, true);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(c, 48));
        b.setMinimumHeight(dp(c, 48));
        b.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(l);
        return b;
    }

    /** The main action on a screen. */
    static TextView primary(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setTextColor(WHITE);
        b.setBackground(ripple(rounded(PRIMARY, 0, 8, c), null));
        return b;
    }

    /** Secondary actions: outlined. */
    static TextView secondary(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setBackground(ripple(rounded(SURFACE, BORDER, 8, c), null));
        return b;
    }

    /** Destructive secondary action. */
    static TextView destructive(Context c, String s, View.OnClickListener l) {
        TextView b = secondary(c, s, l);
        b.setTextColor(DANGER);
        return b;
    }

    /** Low-emphasis inline action. */
    static TextView link(Context c, String s, View.OnClickListener l) {
        TextView b = baseButton(c, s, l);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(0, dp(c, 10), dp(c, 8), dp(c, 10));
        b.setBackground(ripple(null, rounded(WHITE, 0, 8, c)));
        return b;
    }

    /** Two buttons side by side, equal width. */
    static LinearLayout pair(Context c, View a, View b) {
        LinearLayout row = hbox(c);
        row.addView(a, params(0, WRAP, 1f));
        LinearLayout.LayoutParams lp = params(0, WRAP, 1f);
        lp.leftMargin = dp(c, 8);
        row.addView(b, lp);
        return row;
    }

    // ------------------------------------------------------------------ status

    /** Small status label: symbol + word on a tinted background. */
    static TextView badge(Context c, int tone, String label) {
        TextView t = text(c, glyph(tone) + "  " + label, LABEL, fg(tone), true);
        t.setPadding(dp(c, 8), dp(c, 3), dp(c, 8), dp(c, 3));
        t.setBackground(rounded(tint(tone), 0, 6, c));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        return t;
    }

    /** Round status symbol (used at the start of rows). */
    static TextView statusDot(Context c, int tone) {
        TextView t = text(c, glyph(tone), 13, fg(tone), true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(tint(tone));
        t.setBackground(g);
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        int s = dp(c, 28);
        t.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        return t;
    }

    /** Tinted message box: a status, with a title and explanation. */
    static LinearLayout banner(Context c, int tone, String title, String detail) {
        LinearLayout box = hbox(c);
        box.setGravity(Gravity.TOP);
        box.setBackground(rounded(tint(tone), 0, 10, c));
        int p = dp(c, 14);
        box.setPadding(p, p, p, p);
        box.addView(statusDot(c, tone));
        LinearLayout texts = vbox(c);
        texts.setPadding(dp(c, 12), dp(c, 2), 0, 0);
        TextView t = text(c, title, BODY, fg(tone), true);
        texts.addView(t);
        if (detail != null && !detail.isEmpty()) {
            TextView d = text(c, detail, SUPPORT, TEXT, false);
            d.setPadding(0, dp(c, 2), 0, 0);
            texts.addView(d);
        }
        box.addView(texts, params(0, WRAP, 1f));
        box.setContentDescription(title + ". " + (detail == null ? "" : detail));
        return box;
    }

    /** Flat progress bar (no gradient). */
    static LinearLayout progress(Context c, int done, int total, int tone) {
        LinearLayout track = hbox(c);
        track.setBackground(rounded(SURFACE_MUTED, 0, 4, c));
        View fill = new View(c);
        fill.setBackground(rounded(fg(tone), 0, 4, c));
        View rest = new View(c);
        int h = dp(c, 8);
        track.addView(fill, params(0, h, Math.max(0, done)));
        track.addView(rest, params(0, h, Math.max(0, total - done)));
        track.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return track;
    }

    // ------------------------------------------------------------------ rows

    /**
     * A list row: optional leading status, title, subtitle and trailing view. Tappable when l != null.
     * Minimum height 56dp so it is an easy touch target.
     */
    static LinearLayout row(Context c, View leading, String title, String subtitle, View trailing, View.OnClickListener l) {
        LinearLayout row = hbox(c);
        row.setMinimumHeight(dp(c, 56));
        row.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10));
        if (leading != null) {
            row.addView(leading);
            View gap = new View(c);
            row.addView(gap, new LinearLayout.LayoutParams(dp(c, 12), 1));
        }
        LinearLayout texts = vbox(c);
        texts.addView(text(c, title, BODY, TEXT, true));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = support(c, subtitle);
            s.setPadding(0, dp(c, 2), 0, 0);
            texts.addView(s);
        }
        row.addView(texts, params(0, WRAP, 1f));
        if (trailing != null) {
            LinearLayout.LayoutParams lp = params(WRAP, WRAP, 0f);
            lp.leftMargin = dp(c, 8);
            row.addView(trailing, lp);
        }
        if (l != null) {
            row.setBackground(ripple(null, rounded(WHITE, 0, 0, c)));
            row.setClickable(true);
            row.setFocusable(true);
            row.setOnClickListener(l);
        }
        return row;
    }

    /** Right-pointing chevron for navigational rows. */
    static TextView chevron(Context c) {
        TextView t = text(c, "›", 22, TEXT2, false);
        t.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return t;
    }

    // ------------------------------------------------------------------ input

    static void field(EditText e) {
        Context c = e.getContext();
        e.setBackground(rounded(SURFACE, BORDER, 8, c));
        int p = dp(c, 12);
        e.setPadding(p, p, p, p);
        e.setTextColor(TEXT);
        e.setHintTextColor(TEXT2);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, BODY);
        e.setMinHeight(dp(c, 48));
    }

    /** Small horizontal shake for invalid input (functional feedback, not decoration). */
    static void shake(View v) {
        android.animation.ObjectAnimator.ofFloat(v, "translationX", 0, 10, -10, 6, -6, 0).setDuration(240).start();
    }

    // ------------------------------------------------------------------ layout

    static LinearLayout vbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout hbox(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout.LayoutParams params(int w, int h, float weight) {
        return new LinearLayout.LayoutParams(w, h, weight);
    }

    static LinearLayout.LayoutParams margins(Context c, int w, int h, int top) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(c, top);
        return lp;
    }

    static FrameLayout.LayoutParams frame(int w, int h, int gravity) {
        return new FrameLayout.LayoutParams(w, h, gravity);
    }
}
