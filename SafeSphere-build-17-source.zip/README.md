# SafeSphere — Build 17

Android cybersecurity app (Java, native Views). Package `com.nekowishy.safesphere`, version 1.17 (code 17).

- **Shield** – local DNS firewall (VPN) with honest status and coverage gaps.
- **Check – Before you act** – explains what a message, link or QR code asks you to do and whether it's risky; local-first, optional AI with consent.
- **Rules** – your block and allow lists.
- **History – Security activity** – categorised events, weekly summary, stored only on the phone.
- **Device – Protection check** – what Android already protects and what needs attention; app scan; account checkup; app lock; settings.
- **Recovery Center** – checklists and an incident report after a scam.
- **Notifications** – separate dangerous-threat, security-warning, and protection-status channels with red, amber, and green status colors.

Docs: `docs/BUILD16_REPORT.md` (changes, limitations), `docs/TEST_MATRIX.md` (results), `docs/DEFENSE_QA.md` (manuscript notes, panel Q&A).

## Build
- Release (signed, needs repository secrets): `.github/workflows/build.yml` → `gradle assembleRelease`.
- Debug (no secrets): `.github/workflows/debug.yml` → `gradle assembleDebug` + verification suite.
- Verification only (JDK 17+ and Python 3, no Android SDK): `bash tools/verification/run_all.sh`.

## Data files
- `app/src/main/assets/brands.tsv` – brand catalogue with verification sources. Add a brand only with domains confirmed on the brand's own site.
- `app/src/main/assets/public_suffix_list.dat` – Mozilla Public Suffix List (MPL-2.0), snapshot 2025-12-28. Refresh from https://publicsuffix.org/list/ when updating the app.
