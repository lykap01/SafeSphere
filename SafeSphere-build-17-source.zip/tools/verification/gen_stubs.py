import os, re, sys
OUT=sys.argv[1] if len(sys.argv)>1 else 'astubs'
# Each entry: fully-qualified name -> java body (without package line). Bodies return defaults.
S={}
def c(fq, body): S[fq]=body
c('android.Manifest','public final class Manifest { public static final class permission { public static final String POST_NOTIFICATIONS="android.permission.POST_NOTIFICATIONS"; } }')
c('android.animation.ObjectAnimator','public final class ObjectAnimator extends android.animation.ValueAnimator { public static ObjectAnimator ofFloat(Object t, String p, float... v){return null;} public ObjectAnimator setDuration(long d){return this;} }')
c('android.animation.ValueAnimator','public class ValueAnimator { public void start(){} public ValueAnimator setDuration(long d){return this;} }')
c('android.app.Activity','''public class Activity extends android.content.ContextWrapper {
 public static final int RESULT_OK=-1, RESULT_CANCELED=0;
 protected void onCreate(android.os.Bundle b){} protected void onNewIntent(android.content.Intent i){} protected void onResume(){} protected void onPause(){} protected void onDestroy(){}
 public void onBackPressed(){} protected void onActivityResult(int a,int b,android.content.Intent d){}
 public android.view.Window getWindow(){return null;} public void setContentView(android.view.View v){} public android.content.Intent getIntent(){return null;} public void setIntent(android.content.Intent i){}
 public void startActivityForResult(android.content.Intent i,int r){} public void startActivity(android.content.Intent i){} public final void runOnUiThread(Runnable r){} public boolean isFinishing(){return false;} public void finish(){}
 public final void requestPermissions(String[] p,int r){} public void overridePendingTransition(int a,int b){} }''')
c('android.view.Window','public abstract class Window { public abstract void setStatusBarColor(int c); public abstract void setNavigationBarColor(int c); public abstract android.view.View getDecorView(); }')
c('android.content.ContextWrapper','''public class ContextWrapper extends android.content.Context { }''')
c('android.content.Context','''public abstract class Context {
 public static final int MODE_PRIVATE=0; public static final String CLIPBOARD_SERVICE="clipboard", INPUT_METHOD_SERVICE="input_method";
 public Context getApplicationContext(){return null;} public android.content.SharedPreferences getSharedPreferences(String n,int m){return null;}
 public android.content.res.AssetManager getAssets(){return null;} public java.io.File getFilesDir(){return null;}
 public android.content.res.Resources getResources(){return null;} public android.content.pm.PackageManager getPackageManager(){return null;} public String getPackageName(){return null;}
 public android.content.ContentResolver getContentResolver(){return null;} public Object getSystemService(String n){return null;} public final <T> T getSystemService(Class<T> c){return null;}
 public int checkSelfPermission(String p){return 0;} public void startActivity(android.content.Intent i){} public android.content.ComponentName startService(android.content.Intent i){return null;}
 public android.content.ComponentName startForegroundService(android.content.Intent i){return null;} public boolean stopService(android.content.Intent i){return false;}
 public android.content.Intent registerReceiver(android.content.BroadcastReceiver r, android.content.IntentFilter f){return null;} public void unregisterReceiver(android.content.BroadcastReceiver r){} }''')
c('android.content.ContentResolver','public abstract class ContentResolver { public final java.io.InputStream openInputStream(android.net.Uri u) throws java.io.FileNotFoundException {return null;} }')
c('android.content.res.Resources','public class Resources { public android.util.DisplayMetrics getDisplayMetrics(){return null;} }')
c('android.util.DisplayMetrics','public class DisplayMetrics { public float density; public int widthPixels, heightPixels; }')
c('android.content.res.AssetManager','public final class AssetManager { public java.io.InputStream open(String n) throws java.io.IOException {return null;} }')
c('android.content.res.ColorStateList','public class ColorStateList { public static ColorStateList valueOf(int c){return null;} }')
c('android.app.ActivityManager','public class ActivityManager { public boolean isBackgroundRestricted(){return false;} }')
c('android.app.AlertDialog','''public class AlertDialog extends android.app.Dialog { public static class Builder { public Builder(android.content.Context c){}
 public Builder setTitle(CharSequence t){return this;} public Builder setMessage(CharSequence m){return this;} public Builder setView(android.view.View v){return this;}
 public Builder setPositiveButton(CharSequence t, android.content.DialogInterface.OnClickListener l){return this;} public Builder setNegativeButton(CharSequence t, android.content.DialogInterface.OnClickListener l){return this;}
 public AlertDialog show(){return null;} public AlertDialog create(){return null;} } }''')
c('android.app.Dialog','public class Dialog implements android.content.DialogInterface { public void show(){} public void dismiss(){} public void cancel(){} }')
c('android.content.DialogInterface','public interface DialogInterface { void dismiss(); void cancel(); interface OnClickListener { void onClick(DialogInterface d, int which); } }')
c('android.app.DatePickerDialog','public class DatePickerDialog extends android.app.AlertDialog { public interface OnDateSetListener { void onDateSet(android.widget.DatePicker v,int y,int m,int d); } public DatePickerDialog(android.content.Context c, OnDateSetListener l,int y,int m,int d){} }')
c('android.app.TimePickerDialog','public class TimePickerDialog extends android.app.AlertDialog { public interface OnTimeSetListener { void onTimeSet(android.widget.TimePicker v,int h,int m); } public TimePickerDialog(android.content.Context c, OnTimeSetListener l,int h,int m,boolean is24){} }')
c('android.widget.DatePicker','public class DatePicker extends android.widget.FrameLayout { public DatePicker(android.content.Context c){super(c);} }')
c('android.widget.TimePicker','public class TimePicker extends android.widget.FrameLayout { public TimePicker(android.content.Context c){super(c);} }')
c('android.app.DownloadManager','public class DownloadManager { public static final String ACTION_VIEW_DOWNLOADS="android.intent.action.VIEW_DOWNLOADS"; }')
c('android.app.KeyguardManager','public class KeyguardManager { public boolean isDeviceSecure(){return false;} }')
c('android.app.Notification','''public class Notification implements android.os.Parcelable {
 public static final String CATEGORY_MESSAGE="msg", CATEGORY_EMAIL="email", CATEGORY_STATUS="status", EXTRA_MESSAGES="android.messages", EXTRA_BIG_TEXT="android.bigText", EXTRA_TEXT="android.text";
 public static final int FLAG_GROUP_SUMMARY=0x200; public int flags; public String category; public android.os.Bundle extras;
 public static class Builder { public Builder(android.content.Context c,String ch){} public Builder setSmallIcon(int i){return this;} public Builder setContentTitle(CharSequence t){return this;}
  public Builder setContentText(CharSequence t){return this;} public Builder setColor(int c){return this;} public Builder setOngoing(boolean o){return this;} public Builder setContentIntent(android.app.PendingIntent p){return this;}
  public Builder addAction(Action a){return this;} public Builder setStyle(Style s){return this;} public Builder setCategory(String c){return this;} public Builder setAutoCancel(boolean a){return this;} public Notification build(){return null;} }
 public static abstract class Style {} public static class BigTextStyle extends Style { public BigTextStyle(){} public BigTextStyle bigText(CharSequence t){return this;} }
 public static class Action { public static final class Builder { public Builder(android.graphics.drawable.Icon i, CharSequence t, android.app.PendingIntent p){} public Action build(){return null;} } } }''')
c('android.app.NotificationChannel','public final class NotificationChannel { public NotificationChannel(String id, CharSequence n, int imp){} public void setDescription(String d){} public void enableLights(boolean b){} public void setLightColor(int c){} public int getImportance(){return 0;} }')
c('android.app.NotificationManager','public class NotificationManager { public static final int IMPORTANCE_NONE=0, IMPORTANCE_MIN=1, IMPORTANCE_LOW=2, IMPORTANCE_DEFAULT=3, IMPORTANCE_HIGH=4; public void createNotificationChannel(android.app.NotificationChannel c){} public android.app.NotificationChannel getNotificationChannel(String id){return null;} public boolean areNotificationsEnabled(){return true;} public void notify(int id, android.app.Notification n){} }')
c('android.app.PendingIntent','public final class PendingIntent { public static final int FLAG_IMMUTABLE=67108864, FLAG_UPDATE_CURRENT=134217728; public static PendingIntent getActivity(android.content.Context c,int r,android.content.Intent i,int f){return null;} public static PendingIntent getService(android.content.Context c,int r,android.content.Intent i,int f){return null;} }')
c('android.app.Service','''public abstract class Service extends android.content.ContextWrapper { public static final int START_STICKY=1, START_NOT_STICKY=2; public void onCreate(){} public int onStartCommand(android.content.Intent i,int f,int s){return 0;} public void onDestroy(){}
 public abstract android.os.IBinder onBind(android.content.Intent i); public final void startForeground(int id, android.app.Notification n){} public final void stopForeground(boolean r){} public final void stopSelf(){} }''')
c('android.app.AppOpsManager','public class AppOpsManager { public static final int MODE_ALLOWED=0; public static final String OPSTR_GET_USAGE_STATS="android:get_usage_stats"; @Deprecated public int checkOpNoThrow(String op,int uid,String pkg){return 0;} }')
c('android.app.usage.UsageEvents','public final class UsageEvents { public boolean hasNextEvent(){return false;} public boolean getNextEvent(Event e){return false;} public static final class Event { public static final int MOVE_TO_FOREGROUND=1; public Event(){} public int getEventType(){return 0;} public String getPackageName(){return null;} } }')
c('android.app.usage.UsageStatsManager','public final class UsageStatsManager { public android.app.usage.UsageEvents queryEvents(long b,long e){return null;} }')
c('android.content.ActivityNotFoundException','public class ActivityNotFoundException extends RuntimeException { }')
c('android.content.BroadcastReceiver','public abstract class BroadcastReceiver { public abstract void onReceive(android.content.Context c, android.content.Intent i); }')
c('android.content.ClipData','public class ClipData { public static ClipData newPlainText(CharSequence l, CharSequence t){return null;} public int getItemCount(){return 0;} public Item getItemAt(int i){return null;} public static class Item { public CharSequence coerceToText(android.content.Context c){return null;} } }')
c('android.content.ClipboardManager','public class ClipboardManager { public android.content.ClipData getPrimaryClip(){return null;} public void setPrimaryClip(android.content.ClipData c){} }')
c('android.content.ComponentName','public final class ComponentName { public ComponentName(android.content.Context c, Class<?> cls){} }')
c('android.content.ContentValues','public final class ContentValues { public void put(String k, String v){} public void put(String k, Long v){} public void put(String k, Integer v){} }')
c('android.content.Intent','''public class Intent implements android.os.Parcelable {
 public static final String ACTION_SEND="android.intent.action.SEND", ACTION_PROCESS_TEXT="android.intent.action.PROCESS_TEXT", EXTRA_STREAM="android.intent.extra.STREAM", EXTRA_TEXT="android.intent.extra.TEXT",
  EXTRA_PROCESS_TEXT="android.intent.extra.PROCESS_TEXT", EXTRA_SUBJECT="android.intent.extra.SUBJECT", ACTION_VIEW="android.intent.action.VIEW", ACTION_DIAL="android.intent.action.DIAL", ACTION_GET_CONTENT="android.intent.action.GET_CONTENT",
  CATEGORY_OPENABLE="android.intent.category.OPENABLE", ACTION_MAIN="android.intent.action.MAIN", CATEGORY_HOME="android.intent.category.HOME", CATEGORY_LAUNCHER="android.intent.category.LAUNCHER",
  ACTION_BOOT_COMPLETED="android.intent.action.BOOT_COMPLETED", ACTION_MY_PACKAGE_REPLACED="android.intent.action.MY_PACKAGE_REPLACED", ACTION_SCREEN_OFF="android.intent.action.SCREEN_OFF";
 public static final int FLAG_ACTIVITY_NEW_TASK=0x10000000, FLAG_ACTIVITY_SINGLE_TOP=0x20000000, FLAG_ACTIVITY_CLEAR_TOP=0x04000000, FLAG_ACTIVITY_NO_ANIMATION=0x00010000, FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS=0x00800000;
 public Intent(){} public Intent(String a){} public Intent(String a, android.net.Uri u){} public Intent(android.content.Context c, Class<?> cls){}
 public String getAction(){return null;} public Intent setAction(String a){return this;} public String getType(){return null;} public Intent setType(String t){return this;} public android.net.Uri getData(){return null;}
 public Intent addCategory(String c){return this;} public Intent addFlags(int f){return this;} public boolean hasExtra(String n){return false;}
 public Intent putExtra(String n, int v){return this;} public Intent putExtra(String n, String v){return this;} public Intent putExtra(String n, CharSequence v){return this;}
 public int getIntExtra(String n,int d){return d;} public String getStringExtra(String n){return null;} public CharSequence getCharSequenceExtra(String n){return null;}
 @Deprecated public <T extends android.os.Parcelable> T getParcelableExtra(String n){return null;} public static Intent createChooser(Intent t, CharSequence title){return null;} }''')
c('android.content.IntentFilter','public class IntentFilter { public IntentFilter(String a){} }')
c('android.content.SharedPreferences','''public interface SharedPreferences { interface Editor { Editor putString(String k,String v); Editor putLong(String k,long v); Editor putInt(String k,int v); Editor putBoolean(String k,boolean v);
 Editor putStringSet(String k, java.util.Set<String> v); Editor remove(String k); void apply(); boolean commit(); }
 String getString(String k,String d); long getLong(String k,long d); int getInt(String k,int d); boolean getBoolean(String k,boolean d); java.util.Set<String> getStringSet(String k, java.util.Set<String> d); Editor edit(); }''')
c('android.content.pm.ApplicationInfo','public class ApplicationInfo { public static final int FLAG_SYSTEM=1; public int flags; public CharSequence loadLabel(android.content.pm.PackageManager pm){return null;} public android.graphics.drawable.Drawable loadIcon(android.content.pm.PackageManager pm){return null;} }')
c('android.content.pm.InstallSourceInfo','public final class InstallSourceInfo { public String getInstallingPackageName(){return null;} }')
c('android.content.pm.PackageInfo','public class PackageInfo { public static final int REQUESTED_PERMISSION_GRANTED=2; public String packageName; public String versionName; public android.content.pm.ApplicationInfo applicationInfo; public String[] requestedPermissions; public int[] requestedPermissionsFlags; }')
c('android.content.pm.ResolveInfo','public class ResolveInfo { public android.content.pm.ActivityInfo activityInfo; public CharSequence loadLabel(android.content.pm.PackageManager pm){return null;} }')
c('android.content.pm.ActivityInfo','public class ActivityInfo { public String packageName; }')
c('android.content.pm.PackageManager','''public abstract class PackageManager { public static final int PERMISSION_GRANTED=0, GET_PERMISSIONS=4096;
 public static class NameNotFoundException extends Exception {}
 public abstract java.util.List<android.content.pm.PackageInfo> getInstalledPackages(int f); public abstract android.content.pm.ApplicationInfo getApplicationInfo(String p,int f) throws NameNotFoundException;
 public abstract android.content.pm.PackageInfo getPackageInfo(String p,int f) throws NameNotFoundException; public abstract CharSequence getApplicationLabel(android.content.pm.ApplicationInfo a);
 public abstract android.graphics.drawable.Drawable getApplicationIcon(String p) throws NameNotFoundException; public abstract android.content.Intent getLaunchIntentForPackage(String p);
 public abstract java.util.List<android.content.pm.ResolveInfo> queryIntentActivities(android.content.Intent i,int f); public android.content.pm.InstallSourceInfo getInstallSourceInfo(String p) throws NameNotFoundException {return null;}
 @Deprecated public abstract String getInstallerPackageName(String p); }''')
c('android.database.Cursor','public interface Cursor extends java.io.Closeable { boolean moveToNext(); long getLong(int i); String getString(int i); int getInt(int i); void close(); }')
c('android.database.DatabaseUtils','public class DatabaseUtils { public static long queryNumEntries(android.database.sqlite.SQLiteDatabase db, String t){return 0;} public static long queryNumEntries(android.database.sqlite.SQLiteDatabase db, String t, String sel, String[] args){return 0;} public static long longForQuery(android.database.sqlite.SQLiteDatabase db, String q, String[] args){return 0;} }')
c('android.database.sqlite.SQLiteDatabase','''public final class SQLiteDatabase { public void execSQL(String s) throws android.database.SQLException {} public long insert(String t, String n, android.content.ContentValues v){return 0;}
 public int update(String t, android.content.ContentValues v, String w, String[] a){return 0;} public int delete(String t, String w, String[] a){return 0;}
 public android.database.Cursor query(String t, String[] cols, String sel, String[] args, String g, String h, String o){return null;}
 public android.database.Cursor query(String t, String[] cols, String sel, String[] args, String g, String h, String o, String limit){return null;}
 public android.database.Cursor rawQuery(String s, String[] a){return null;} public interface CursorFactory {} }''')
c('android.database.SQLException','public class SQLException extends RuntimeException {}')
c('android.database.sqlite.SQLiteOpenHelper','public abstract class SQLiteOpenHelper { public SQLiteOpenHelper(android.content.Context c, String n, android.database.sqlite.SQLiteDatabase.CursorFactory f, int v){} public abstract void onCreate(android.database.sqlite.SQLiteDatabase db); public abstract void onUpgrade(android.database.sqlite.SQLiteDatabase db,int o,int n); public android.database.sqlite.SQLiteDatabase getWritableDatabase(){return null;} public android.database.sqlite.SQLiteDatabase getReadableDatabase(){return null;} }')
c('android.graphics.Bitmap','public final class Bitmap { public int getWidth(){return 0;} public int getHeight(){return 0;} public void getPixels(int[] p,int o,int s,int x,int y,int w,int h){} public void recycle(){} }')
c('android.graphics.BitmapFactory','public class BitmapFactory { public static class Options { public boolean inJustDecodeBounds; public int inSampleSize, outWidth, outHeight; } public static android.graphics.Bitmap decodeStream(java.io.InputStream i, android.graphics.Rect r, Options o){return null;} }')
c('android.graphics.Rect','public final class Rect { }')
c('android.graphics.Canvas','public class Canvas { public int save(){return 0;} public void restore(){} public void translate(float x,float y){} public void rotate(float d,float px,float py){} public void drawPath(android.graphics.Path p, android.graphics.Paint pt){} public void drawCircle(float x,float y,float r, android.graphics.Paint p){} public void drawLine(float a,float b,float c,float d, android.graphics.Paint p){} public void drawPoint(float x,float y, android.graphics.Paint p){} public void drawRoundRect(float l,float t,float r,float b,float rx,float ry, android.graphics.Paint p){} public void drawRoundRect(android.graphics.RectF r,float rx,float ry, android.graphics.Paint p){} public void drawArc(float l,float t,float r,float b,float s,float sw,boolean u, android.graphics.Paint p){} public void drawText(String t,float x,float y, android.graphics.Paint p){} }')
c('android.graphics.Paint','public class Paint { public static final int ANTI_ALIAS_FLAG=1; public enum Style { FILL, STROKE, FILL_AND_STROKE } public enum Cap { BUTT, ROUND, SQUARE } public enum Join { MITER, ROUND, BEVEL } public enum Align { LEFT, CENTER, RIGHT } public Paint(){} public Paint(int f){} public void setStyle(Style s){} public Style getStyle(){return null;} public void setStrokeCap(Cap c){} public void setStrokeJoin(Join j){} public void setColor(int c){} public void setStrokeWidth(float w){} public void setTextAlign(Align a){} public void setTextSize(float s){} public android.graphics.Typeface setTypeface(android.graphics.Typeface t){return t;} }')
c('android.graphics.Path','public class Path { public void reset(){} public void moveTo(float x,float y){} public void lineTo(float x,float y){} public void cubicTo(float a,float b,float c,float d,float e,float f){} public void quadTo(float a,float b,float c,float d){} public void close(){} }')
c('android.graphics.RectF','public class RectF { public RectF(){} public void set(float l,float t,float r,float b){} }')
c('android.graphics.Typeface','public class Typeface { public static final int NORMAL=0, BOLD=1; public static Typeface create(String f,int s){return null;} }')
c('android.graphics.drawable.Drawable','public abstract class Drawable { }')
c('android.graphics.drawable.GradientDrawable','public class GradientDrawable extends android.graphics.drawable.Drawable { public static final int OVAL=1; public GradientDrawable(){} public void setColor(int c){} public void setCornerRadius(float r){} public void setStroke(int w,int c){} public void setShape(int s){} }')
c('android.graphics.drawable.LayerDrawable','public class LayerDrawable extends android.graphics.drawable.Drawable { }')
c('android.graphics.drawable.RippleDrawable','public class RippleDrawable extends android.graphics.drawable.LayerDrawable { public RippleDrawable(android.content.res.ColorStateList c, android.graphics.drawable.Drawable content, android.graphics.drawable.Drawable mask){} }')
c('android.graphics.drawable.Icon','public final class Icon { public static Icon createWithResource(android.content.Context c,int id){return null;} }')
c('android.net.ConnectivityManager','''public class ConnectivityManager { @Deprecated public android.net.Network[] getAllNetworks(){return null;} public android.net.NetworkCapabilities getNetworkCapabilities(android.net.Network n){return null;}
 public void registerNetworkCallback(android.net.NetworkRequest r, NetworkCallback cb){}
 public static class NetworkCallback { public void onCapabilitiesChanged(android.net.Network n, android.net.NetworkCapabilities c){} public void onLost(android.net.Network n){} } }''')
c('android.net.Network','public class Network { public long getNetworkHandle(){return 0;} }')
c('android.net.NetworkCapabilities','public final class NetworkCapabilities { public static final int TRANSPORT_WIFI=1, TRANSPORT_VPN=4, NET_CAPABILITY_CAPTIVE_PORTAL=17; public boolean hasTransport(int t){return false;} public boolean hasCapability(int c){return false;} public android.net.TransportInfo getTransportInfo(){return null;} }')
c('android.net.NetworkRequest','public class NetworkRequest { public static class Builder { public Builder(){} public Builder addTransportType(int t){return this;} public android.net.NetworkRequest build(){return null;} } }')
c('android.net.TransportInfo','public interface TransportInfo { }')
c('android.net.Uri','public abstract class Uri implements android.os.Parcelable { public static Uri parse(String s){return null;} }')
c('android.net.VpnService','''public class VpnService extends android.app.Service { public static android.content.Intent prepare(android.content.Context c){return null;} public boolean protect(java.net.DatagramSocket s){return false;} public void onRevoke(){} public android.os.IBinder onBind(android.content.Intent i){return null;}
 public class Builder { public Builder(){} public Builder setSession(String s){return this;} public Builder addAddress(String a,int p){return this;} public Builder addRoute(String a,int p){return this;} public Builder addDnsServer(String a){return this;}
  public Builder setMtu(int m){return this;} public Builder setBlocking(boolean b){return this;} public Builder setMetered(boolean m){return this;} public Builder setConfigureIntent(android.app.PendingIntent p){return this;} public android.os.ParcelFileDescriptor establish(){return null;} } }''')
c('android.net.wifi.WifiInfo','public class WifiInfo implements android.net.TransportInfo { public static final int SECURITY_TYPE_OPEN=0, SECURITY_TYPE_WEP=1, SECURITY_TYPE_OWE=6; public int getCurrentSecurityType(){return 0;} }')
c('android.os.Build','public class Build { public static final String TAGS=null; public static class VERSION { public static final int SDK_INT=0; public static final String RELEASE=null, SECURITY_PATCH=null; } }')
c('android.os.Bundle','public final class Bundle implements android.os.Parcelable { public CharSequence getCharSequence(String k){return null;} public android.os.Parcelable[] getParcelableArray(String k){return null;} }')
c('android.os.Handler','public class Handler { public Handler(android.os.Looper l){} public final boolean post(Runnable r){return true;} public final boolean postDelayed(Runnable r,long d){return true;} public final void removeCallbacks(Runnable r){} public final void removeCallbacksAndMessages(Object t){} }')
c('android.os.HandlerThread','public class HandlerThread extends Thread { public HandlerThread(String n){} public android.os.Looper getLooper(){return null;} public boolean quitSafely(){return true;} }')
c('android.os.IBinder','public interface IBinder { }')
c('android.os.Looper','public final class Looper { public static Looper getMainLooper(){return null;} }')
c('android.os.ParcelFileDescriptor','public class ParcelFileDescriptor implements java.io.Closeable { public java.io.FileDescriptor getFileDescriptor(){return null;} public void close() throws java.io.IOException {} }')
c('android.os.Parcelable','public interface Parcelable { }')
c('android.os.PowerManager','public final class PowerManager { public boolean isIgnoringBatteryOptimizations(String p){return false;} public boolean isInteractive(){return true;} }')
c('android.os.Process','public class Process { public static final int myUid(){return 0;} }')
c('android.os.SystemClock','public final class SystemClock { public static long elapsedRealtime(){return 0;} }')
c('android.provider.Settings','''public final class Settings {
 public static final String ACTION_SECURITY_SETTINGS="a", ACTION_DEVICE_INFO_SETTINGS="b", ACTION_SETTINGS="c", ACTION_APPLICATION_DEVELOPMENT_SETTINGS="d", ACTION_WIRELESS_SETTINGS="e",
  ACTION_MANAGE_UNKNOWN_APP_SOURCES="f", ACTION_ACCESSIBILITY_SETTINGS="g", ACTION_VPN_SETTINGS="h", ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS="i", ACTION_NOTIFICATION_LISTENER_SETTINGS="j",
  ACTION_APPLICATION_DETAILS_SETTINGS="k", ACTION_APP_NOTIFICATION_SETTINGS="l", EXTRA_APP_PACKAGE="m", ACTION_USAGE_ACCESS_SETTINGS="n", ACTION_MANAGE_OVERLAY_PERMISSION="o", ACTION_APPLICATION_SETTINGS="p";
 public static boolean canDrawOverlays(android.content.Context c){return false;}
 public static final class Global { public static final String ADB_ENABLED="adb_enabled", DEVELOPMENT_SETTINGS_ENABLED="development_settings_enabled";
  public static int getInt(android.content.ContentResolver r,String n,int d){return d;} public static String getString(android.content.ContentResolver r,String n){return null;} }
 public static final class Secure { public static final String ENABLED_ACCESSIBILITY_SERVICES="enabled_accessibility_services"; public static String getString(android.content.ContentResolver r,String n){return null;} } }''')
c('android.service.notification.NotificationListenerService','public abstract class NotificationListenerService extends android.app.Service { public void onListenerConnected(){} public void onListenerDisconnected(){} public void onNotificationPosted(android.service.notification.StatusBarNotification s){} public static void requestRebind(android.content.ComponentName c){} public android.os.IBinder onBind(android.content.Intent i){return null;} }')
c('android.service.notification.StatusBarNotification','public class StatusBarNotification { public String getPackageName(){return null;} public android.app.Notification getNotification(){return null;} }')
c('android.text.Editable','public interface Editable extends CharSequence { Editable insert(int w, CharSequence t); }')
c('android.text.InputType','public interface InputType { int TYPE_CLASS_TEXT=1, TYPE_CLASS_NUMBER=2, TYPE_TEXT_VARIATION_PASSWORD=128, TYPE_TEXT_VARIATION_VISIBLE_PASSWORD=144, TYPE_TEXT_VARIATION_URI=16, TYPE_NUMBER_VARIATION_PASSWORD=16, TYPE_TEXT_FLAG_MULTI_LINE=131072, TYPE_TEXT_FLAG_NO_SUGGESTIONS=524288, TYPE_TEXT_FLAG_CAP_SENTENCES=16384; }')
c('android.text.TextUtils','public class TextUtils { public enum TruncateAt { START, MIDDLE, END, MARQUEE } public static String join(CharSequence d, Iterable t){return null;} public static String join(CharSequence d, Object[] t){return null;} }')
c('android.text.TextWatcher','public interface TextWatcher { void beforeTextChanged(CharSequence s,int a,int b,int c); void onTextChanged(CharSequence s,int a,int b,int c); void afterTextChanged(android.text.Editable e); }')
c('android.text.format.DateUtils','public class DateUtils { public static final long MINUTE_IN_MILLIS=60000; public static CharSequence getRelativeTimeSpanString(long t,long n,long m){return null;} }')
c('android.util.TypedValue','public class TypedValue { public static final int COMPLEX_UNIT_SP=2; }')
c('android.view.Gravity','public class Gravity { public static final int TOP=48, BOTTOM=80, START=8388611, END=8388613, CENTER=17, CENTER_VERTICAL=16, CENTER_HORIZONTAL=1; }')
c('android.view.View','''public class View { public static final int VISIBLE=0, GONE=8, FOCUS_DOWN=130, IMPORTANT_FOR_ACCESSIBILITY_NO=2, SYSTEM_UI_FLAG_LIGHT_STATUS_BAR=8192, SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR=16;
 public View(android.content.Context c){} public android.content.Context getContext(){return null;} public void setPadding(int l,int t,int r,int b){} public void setBackground(android.graphics.drawable.Drawable d){}
 public android.graphics.drawable.Drawable getBackground(){return null;} public void setBackgroundColor(int c){} public void setClickable(boolean c){} public void setFocusable(boolean f){} public void setFocusableInTouchMode(boolean f){}
 public void setOnClickListener(OnClickListener l){} public void setOnLongClickListener(OnLongClickListener l){} public void setContentDescription(CharSequence d){} public void setVisibility(int v){} public void setLayoutParams(android.view.ViewGroup.LayoutParams p){}
 public android.view.ViewGroup.LayoutParams getLayoutParams(){return null;} public void setImportantForAccessibility(int m){} public void setAccessibilityHeading(boolean h){} public void setMinimumHeight(int h){} public void setAlpha(float a){}
 public void setEnabled(boolean e){} public void setSelected(boolean s){} public void setTag(Object t){} public Object getTag(){return null;} public final boolean requestFocus(){return true;} public android.os.IBinder getWindowToken(){return null;}
 public boolean post(Runnable r){return true;} public android.view.ViewTreeObserver getViewTreeObserver(){return null;} public void invalidate(){} public void setSystemUiVisibility(int v){} public final int getWidth(){return 0;} public final int getHeight(){return 0;}
 protected void onDraw(android.graphics.Canvas c){} public void setTranslationX(float x){} public android.view.ViewPropertyAnimator animate(){return null;} public void postInvalidateOnAnimation(){}
 public interface OnClickListener { void onClick(View v); } public interface OnLongClickListener { boolean onLongClick(View v); } }''')
c('android.view.ViewPropertyAnimator','public class ViewPropertyAnimator { public void cancel(){} }')
c('android.view.ViewGroup','''public abstract class ViewGroup extends android.view.View { public static final int FOCUS_BEFORE_DESCENDANTS=131072; public ViewGroup(android.content.Context c){super(c);}
 public void addView(android.view.View v){} public void addView(android.view.View v, android.view.ViewGroup.LayoutParams p){} public void addView(android.view.View v,int i){} public void removeAllViews(){} public void removeView(android.view.View v){}
 public int getChildCount(){return 0;} public android.view.View getChildAt(int i){return null;} public void setDescendantFocusability(int f){} public void setClipToPadding(boolean c){}
 public static class LayoutParams { public static final int MATCH_PARENT=-1, WRAP_CONTENT=-2; public int width, height; public LayoutParams(int w,int h){} }
 public static class MarginLayoutParams extends LayoutParams { public int leftMargin, topMargin, rightMargin, bottomMargin; public MarginLayoutParams(int w,int h){super(w,h);} } }''')
c('android.view.ViewTreeObserver','public final class ViewTreeObserver { public interface OnPreDrawListener { boolean onPreDraw(); } public void addOnPreDrawListener(OnPreDrawListener l){} public void removeOnPreDrawListener(OnPreDrawListener l){} }')
c('android.view.inputmethod.EditorInfo','public class EditorInfo { public static final int IME_ACTION_DONE=6, IME_ACTION_SEND=4; }')
c('android.view.inputmethod.InputMethodManager','public final class InputMethodManager { public static final int SHOW_IMPLICIT=1; public boolean hideSoftInputFromWindow(android.os.IBinder t,int f){return false;} public boolean showSoftInput(android.view.View v,int f){return false;} }')
c('android.widget.TextView','''public class TextView extends android.view.View { public TextView(android.content.Context c){super(c);} public final void setText(CharSequence t){} public CharSequence getText(){return null;}
 public void setTextSize(int u,float s){} public void setTextSize(float s){} public void setTextColor(int c){} public void setTypeface(android.graphics.Typeface t){} public void setLineSpacing(float a,float m){}
 public void setGravity(int g){} public void setSingleLine(boolean s){} public void setEllipsize(android.text.TextUtils.TruncateAt w){} public void setMaxWidth(int w){} public void setMinHeight(int h){} public void setMinWidth(int w){}
 public void setHint(CharSequence h){} public final void setHintTextColor(int c){} public void setInputType(int t){} public void setImeOptions(int o){} public void setMinLines(int m){} public void setMaxLines(int m){}
 public void setError(CharSequence e){} public void addTextChangedListener(android.text.TextWatcher w){} public void setLetterSpacing(float s){} }''')
c('android.widget.EditText','public class EditText extends android.widget.TextView { public EditText(android.content.Context c){super(c);} public android.text.Editable getText(){return null;} public void setSelection(int i){} public int getSelectionStart(){return 0;} }')
c('android.widget.Button','public class Button extends android.widget.TextView { public Button(android.content.Context c){super(c);} }')
c('android.widget.CompoundButton','public abstract class CompoundButton extends android.widget.Button { public CompoundButton(android.content.Context c){super(c);} public void setChecked(boolean c){} public boolean isChecked(){return false;} public void setButtonTintList(android.content.res.ColorStateList t){} public void setOnCheckedChangeListener(OnCheckedChangeListener l){} public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b, boolean c); } }')
c('android.widget.CheckBox','public class CheckBox extends android.widget.CompoundButton { public CheckBox(android.content.Context c){super(c);} }')
c('android.widget.Switch','public class Switch extends android.widget.CompoundButton { public Switch(android.content.Context c){super(c);} }')
c('android.widget.FrameLayout','public class FrameLayout extends android.view.ViewGroup { public FrameLayout(android.content.Context c){super(c);} public static class LayoutParams extends android.view.ViewGroup.MarginLayoutParams { public int gravity; public LayoutParams(int w,int h){super(w,h);} public LayoutParams(int w,int h,int g){super(w,h);} } }')
c('android.widget.LinearLayout','public class LinearLayout extends android.view.ViewGroup { public static final int HORIZONTAL=0, VERTICAL=1; public LinearLayout(android.content.Context c){super(c);} public void setOrientation(int o){} public void setGravity(int g){} public static class LayoutParams extends android.view.ViewGroup.MarginLayoutParams { public float weight; public int gravity; public LayoutParams(int w,int h){super(w,h);} public LayoutParams(int w,int h,float wt){super(w,h);} } }')
c('android.widget.ScrollView','public class ScrollView extends android.widget.FrameLayout { public ScrollView(android.content.Context c){super(c);} public void setFillViewport(boolean f){} public boolean fullScroll(int d){return true;} public void scrollTo(int x,int y){} public int getScrollY(){return 0;} }')
c('android.widget.HorizontalScrollView','public class HorizontalScrollView extends android.widget.FrameLayout { public HorizontalScrollView(android.content.Context c){super(c);} public void setHorizontalScrollBarEnabled(boolean e){} }')
c('android.widget.ImageView','public class ImageView extends android.view.View { public ImageView(android.content.Context c){super(c);} public void setImageDrawable(android.graphics.drawable.Drawable d){} }')
c('android.widget.PopupMenu','public class PopupMenu { public PopupMenu(android.content.Context c, android.view.View a){} public android.view.Menu getMenu(){return null;} public void setOnMenuItemClickListener(OnMenuItemClickListener l){} public void show(){} public interface OnMenuItemClickListener { boolean onMenuItemClick(android.view.MenuItem i); } }')
c('android.view.Menu','public interface Menu { android.view.MenuItem add(int g,int id,int o,CharSequence t); }')
c('android.view.MenuItem','public interface MenuItem { int getItemId(); }')
c('android.widget.Toast','public class Toast { public static final int LENGTH_SHORT=0, LENGTH_LONG=1; public static Toast makeText(android.content.Context c, CharSequence t,int d){return null;} public void show(){} }')
c('org.json.JSONObject','public class JSONObject { public JSONObject(){} public JSONObject(String s) throws JSONException {} public JSONObject put(String k,Object v) throws JSONException {return this;} public boolean has(String k){return false;} public String optString(String k){return null;} public String optString(String k,String d){return null;} public JSONArray optJSONArray(String k){return null;} }')
c('org.json.JSONArray','public class JSONArray { public JSONArray(){} public JSONArray put(Object v){return this;} public int length(){return 0;} public String optString(int i){return null;} }')
c('org.json.JSONException','public class JSONException extends Exception { }')
c('com.google.zxing.BinaryBitmap','public final class BinaryBitmap { public BinaryBitmap(com.google.zxing.Binarizer b){} }')
c('com.google.zxing.Binarizer','public abstract class Binarizer { }')
c('com.google.zxing.LuminanceSource','public abstract class LuminanceSource { }')
c('com.google.zxing.DecodeHintType','public enum DecodeHintType { TRY_HARDER }')
c('com.google.zxing.MultiFormatReader','public final class MultiFormatReader { public com.google.zxing.Result decode(com.google.zxing.BinaryBitmap b, java.util.Map<com.google.zxing.DecodeHintType,?> h) throws com.google.zxing.NotFoundException {return null;} }')
c('com.google.zxing.NotFoundException','public final class NotFoundException extends Exception { }')
c('com.google.zxing.RGBLuminanceSource','public final class RGBLuminanceSource extends com.google.zxing.LuminanceSource { public RGBLuminanceSource(int w,int h,int[] p){} }')
c('com.google.zxing.Result','public final class Result { public String getText(){return null;} }')
c('com.google.zxing.common.HybridBinarizer','public final class HybridBinarizer extends com.google.zxing.Binarizer { public HybridBinarizer(com.google.zxing.LuminanceSource s){} }')
c('com.nekowishy.safesphere.BuildConfig','public final class BuildConfig { public static final String AI_URL=""; public static final String AI_TOKEN=""; }')
c('com.nekowishy.safesphere.R','public final class R { public static final class drawable { public static final int ic_notify=1; } }')
for fq,body in S.items():
    pkg,cls=fq.rsplit('.',1)
    d=os.path.join(OUT,*pkg.split('.')); os.makedirs(d,exist_ok=True)
    open(os.path.join(d,cls+'.java'),'w').write(f'package {pkg};\n{body}\n')
print(len(S),'stubs')
