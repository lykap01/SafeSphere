package com.nekowishy.safesphere;
import java.io.*; import java.util.*;
public class UnitTests {
  static int pass=0, fail=0; static List<String> log=new ArrayList<>();
  static void t(String name, boolean ok, Object detail){ if(ok)pass++; else fail++; log.add((ok?"PASS":"FAIL")+"\t"+name+(ok?"":"\t"+detail)); }
  static void eq(String name, Object exp, Object got){ t(name, Objects.equals(exp,got), "expected="+exp+" got="+got); }
  public static void main(String[] a) throws Exception {
    PublicSuffix.load(new FileInputStream(a[0])); BrandCatalog.load(new FileInputStream(a[1]));
    // ---- Public suffix / registrable domain
    String[][] reg={{"www.example.co.uk","example.co.uk"},{"shop.example.com.au","example.com.au"},{"a.b.example.ne.jp","example.ne.jp"},
      {"www.ox.ac.uk","ox.ac.uk"},{"user.github.io","user.github.io"},{"paypal-login.web.app","paypal-login.web.app"},{"www.bdo.com.ph","bdo.com.ph"},
      {"login.microsoftonline.com","microsoftonline.com"},{"outlook.cloud.microsoft","cloud.microsoft"},{"x.example","x.example"},{"www.gov.sg","www.gov.sg"},
      {"www.amazon.com.mx","amazon.com.mx"},{"sub.domain.example.com.br","example.com.br"}};
    for (String[] r: reg) eq("PSL registrable "+r[0], r[1], PublicSuffix.registrable(r[0]));
    eq("PSL shared platform web.app", "web.app", PublicSuffix.sharedPlatform("paypal-login.web.app"));
    eq("PSL known TLD museum", Boolean.TRUE, PublicSuffix.isKnownTld("museum"));
    eq("PSL unknown TLD po", Boolean.FALSE, PublicSuffix.isKnownTld("po"));
    // ---- UrlInfo
    UrlInfo u=UrlInfo.parse("https://www.usps.com@serviceyuwt.sbs/TrackConfirm/");
    eq("URL userinfo host", "serviceyuwt.sbs", u.host); eq("URL userinfo text", "www.usps.com", u.userInfo);
    u=UrlInfo.parse("http://3232235777/"); eq("URL integer IP", "192.168.1.1", u.host); t("URL integer IP obfuscated", u.ipObfuscated, u.host);
    u=UrlInfo.parse("http://0x7f.0.0.1:8080/x"); eq("URL hex IP","127.0.0.1",u.host); eq("URL port",8080,u.port);
    u=UrlInfo.parse("http://[2001:db8::1]:443/"); t("URL IPv6", u.ipv6 && u.host.equals("2001:db8::1") && u.port==443, u.host);
    u=UrlInfo.parse("https://www.раураl.com/"); t("URL IDN punycode", u.host.startsWith("www.xn--"), u.host); eq("URL IDN skeleton","www.paypal.com",u.skeleton);
    u=UrlInfo.parse("https://www.münchen.de/"); eq("URL IDN legit skeleton","www.munchen.de",u.skeleton); t("URL legit IDN not mixed", !u.mixedScript, "mixed");
    u=UrlInfo.parse("https://pаypal.com/"); t("URL mixed-script detected", u.mixedScript, u.hostUnicode);
    u=UrlInfo.parse("https://%70aypal.example/"); t("URL encoded host decoded", u.encodedHost && u.host.equals("paypal.example"), u.host);
    u=UrlInfo.parse("https://paypal.com\\@evil.example/"); eq("URL backslash -> real host","paypal.com",u.host);
    u=UrlInfo.parse("example.com:8443/path"); eq("URL scheme-less host:port","example.com",u.host); eq("URL scheme-less port",8443,u.port);
    u=UrlInfo.parse("javascript:alert(1)"); t("URL non-web scheme", !u.webScheme, u.scheme);
    u=UrlInfo.parse("https://例え.jp/"); t("URL Japanese IDN not mixed", !u.mixedScript, u.hostUnicode);
    u=UrlInfo.parse("HTTPS://WWW.Example.COM./"); eq("URL case+trailing dot","www.example.com",u.host);
    // ---- link extraction
    List<String> ex=ScamDetector.extractLinks("Email me at juan@gmail.com or see www.bbc.co.uk/news and https://bit.ly/x. Salamat.po Mr.Smith");
    t("extract skips email", !ex.toString().contains("gmail.com"), ex); t("extract www link", ex.toString().contains("www.bbc.co.uk/news"), ex);
    t("extract shortener", ex.toString().contains("https://bit.ly/x"), ex); t("extract skips Salamat.po / Mr.Smith", ex.size()==2, ex);
    ex=ScamDetector.extractLinks("Bisitahin ang раураl.com ngayon"); t("extract Unicode domain", ex.size()==1 && ex.get(0).equals("раураl.com"), ex);
    ex=ScamDetector.extractLinks("go to http://3232235777/login now"); t("extract integer-IP link", ex.size()==1, ex);
    // ---- fakeBrand (DNS filter) false-positive guards
    eq("DNS no block metabank.com", null, ScamDetector.fakeBrand("www.metabank.com"));
    eq("DNS no block coffee", null, ScamDetector.fakeBrand("coffeeshop.store"));
    eq("DNS no block amazonaws", null, ScamDetector.fakeBrand("s3.amazonaws.com"));
    eq("DNS no block official", null, ScamDetector.fakeBrand("accounts.google.com"));
    eq("DNS no block brand+risky TLD only", null, ScamDetector.fakeBrand("gcash.xyz"));
    eq("DNS block gcash-login", "GCash", ScamDetector.fakeBrand("gcash-login.example"));
    // ---- Redactor
    Redactor.Result rr=Redactor.redact("My OTP is 482913 and password: Hunter22! Call 0917-123-4567 or mail juan@example.com. Card 4111 1111 1111 1111. See https://evil.example/verify?u=juan");
    t("redact OTP", !rr.text.contains("482913"), rr.text); t("redact password", !rr.text.contains("Hunter22"), rr.text);
    t("redact phone", !rr.text.contains("4567"), rr.text); t("redact email", !rr.text.contains("juan@example.com"), rr.text);
    t("redact card", !rr.text.contains("1111"), rr.text); t("redact link path keeps host", rr.text.contains("https://evil.example/[path removed]") && !rr.text.contains("u=juan"), rr.text);
    rr=Redactor.redact("Pay PHP 45 for the parcel"); t("redact keeps short amounts", rr.text.contains("45"), rr.text);
    rr=Redactor.redact(Redactor.redact("code: 123456").text); t("redact idempotent", rr.text.contains("[REMOVED]") && !rr.text.contains("123456"), rr.text);
    // ---- Password check (k-anonymity)
    String h=PasswordCheck.sha1Hex("password"); eq("SHA-1 of 'password'","5BAA61E4C9B93F3F0682250B6CF8331B7EE68FD8",h);
    String body="003D68EB55068C33ACE09247EE4C639306B:3\n1E4C9B93F3F0682250B6CF8331B7EE68FD8:9659365\n1E4C9B93F3F0682250B6CF8331B7EE68FD9:0\n";
    eq("HIBP suffix match", 9659365L, PasswordCheck.findCount(h.substring(5), new BufferedReader(new StringReader(body))));
    eq("HIBP suffix lowercase match", 9659365L, PasswordCheck.findCount(h.substring(5).toLowerCase(), new BufferedReader(new StringReader(body))));
    eq("HIBP padded zero entry", 0L, PasswordCheck.findCount("1E4C9B93F3F0682250B6CF8331B7EE68FD9", new BufferedReader(new StringReader(body))));
    eq("HIBP prefix length", 5, h.substring(0,5).length());
    // ---- ThreatDb.parseLine
    eq("feed hosts line","bad.example",ThreatDb.parseLine("0.0.0.0 bad.example # comment"));
    eq("feed adblock line","bad.example",ThreatDb.parseLine("||bad.example^"));
    eq("feed wildcard","bad.example",ThreatDb.parseLine("*.bad.example"));
    eq("feed comment",null,ThreatDb.parseLine("# hello"));
    eq("feed bare IP",null,ThreatDb.parseLine("1.2.3.4"));
    eq("feed localhost",null,ThreatDb.parseLine("127.0.0.1 localhost"));
    // ---- DnsPacket
    byte[] q=dnsQuery("gcash-login.example");
    DnsPacket.Query dq=DnsPacket.parse(q,q.length); eq("DNS parse name","gcash-login.example",dq==null?null:dq.name);
    byte[] blocked=DnsPacket.blocked(dq); t("DNS NXDOMAIN rcode", (blocked[28+3]&0x0F)==3 && (blocked[28+2]&0x80)!=0, Arrays.toString(Arrays.copyOf(blocked,40)));
    t("DNS reply swaps ports", ((blocked[20]&0xFF)<<8|(blocked[21]&0xFF))==53, "src port");
    int sum=0; for(int i=0;i<20;i+=2) sum+=((blocked[i]&0xFF)<<8)|(blocked[i+1]&0xFF); while((sum>>16)!=0) sum=(sum&0xFFFF)+(sum>>16);
    eq("DNS IPv4 header checksum valid", 0xFFFF, sum);
    // ---- Recovery report
    EventLog.Incident inc=new EventLog.Incident(); inc.type="shared_otp"; inc.occurredAt=1700000000000L; inc.sender="+63 900 000 0000"; inc.description="Caller said he was from my bank"; inc.stepsDone="0,2";
    String rep=RecoveryGuide.report(inc);
    t("report has title", rep.contains("I shared an OTP or MPIN"), rep); t("report has progress 2 of 7", rep.contains("(2 of 7)"), rep);
    t("report marks done", rep.contains("[x] Contact the provider") , rep); t("report disclaimer", rep.contains("not verified by SafeSphere"), rep);
    eq("doneCsv sorted","0,2,5",RecoveryGuide.doneCsv(new HashSet<>(Arrays.asList(5,0,2))));
    for (RecoveryGuide.Incident g: RecoveryGuide.INCIDENTS) t("guide has steps "+g.id, g.steps.length>=4, g.steps.length);
    t("8 incident types", RecoveryGuide.INCIDENTS.length==8, RecoveryGuide.INCIDENTS.length);
    // ---- Brand catalogue sanity
    t("catalogue loaded", BrandCatalog.all().size()>=30, BrandCatalog.all().size());
    for (BrandCatalog.Brand b: BrandCatalog.all()) t("brand has source "+b.name, b.source!=null && !b.source.isEmpty(), b.source);
    // ---- ActionAnalyzer specifics
    t("negation: do not share OTP not a request", !ActionAnalyzer.analyzeText("Do not share your OTP with anyone.").has(ActionAnalyzer.OTP), "");
    t("request: send me the OTP", ActionAnalyzer.analyzeText("Please send me the OTP now.").has(ActionAnalyzer.OTP), "");
    ActionAnalyzer.Report otpExample = ActionAnalyzer.analyzeText(
            "Your bank needs your OTP. Reply with the OTP to keep your account active.");
    t("Before You Act sample detects no-link OTP request", otpExample.has(ActionAnalyzer.OTP)
            && otpExample.level >= ScamDetector.SUSPICIOUS, otpExample.summary);
    t("Before You Act OTP example has no URL", ScamDetector.extractLinks(
            "Your bank needs your OTP. Reply with the OTP to keep your account active.").isEmpty(), "");
    ActionAnalyzer.Report feeExample = ActionAnalyzer.analyzeText(
            "Pay a PHP 500 processing fee before your prize can be released.");
    t("Before You Act sample detects advance-fee request", feeExample.has(ActionAnalyzer.FEE)
            && feeExample.level >= ScamDetector.CAUTION, feeExample.summary);
    t("APK from Play Store not flagged", !ActionAnalyzer.analyzeText("Download the GCash app from the Google Play Store here.").has(ActionAnalyzer.APK), "");
    t("evidence quotes exact words", ActionAnalyzer.analyzeText("Kindly install AnyDesk so I can help").findings.get(0).evidence.get(0).equalsIgnoreCase("AnyDesk"), "");
    try (PrintWriter w=new PrintWriter(a[2])) { for (String l: log) w.println(l); }
    System.out.println("unit tests: "+pass+" passed, "+fail+" failed");
    for (String l: log) if (l.startsWith("FAIL")) System.out.println(l);
  }
  static byte[] dnsQuery(String name){
    ByteArrayOutputStream d=new ByteArrayOutputStream(); d.write(0x12);d.write(0x34);d.write(0x01);d.write(0x00);d.write(0);d.write(1);for(int i=0;i<6;i++)d.write(0);
    for(String l: name.split("\\.")){ d.write(l.length()); d.writeBytes(l.getBytes()); } d.write(0); d.write(0);d.write(1);d.write(0);d.write(1);
    byte[] dns=d.toByteArray(); byte[] p=new byte[28+dns.length]; p[0]=0x45; p[9]=17; p[12]=10;p[13]=111;p[14]=(byte)222;p[15]=1; p[16]=10;p[17]=111;p[18]=(byte)222;p[19]=2;
    p[20]=(byte)0xC3;p[21]=0x50; p[22]=0;p[23]=53; int ul=8+dns.length; p[24]=(byte)(ul>>8);p[25]=(byte)ul; System.arraycopy(dns,0,p,28,dns.length); return p; }
}
